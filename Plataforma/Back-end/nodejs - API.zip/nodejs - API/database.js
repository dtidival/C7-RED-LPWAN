"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const mysql_1 = __importDefault(require("mysql"));
const conn = mysql_1.default.createPool({
    host: 'localhost',
    user: 'root',
    password: 'DivalSw4T20*',
    //password: '',
    database: 'swat_gesinen' //'gomera_database'//'swat_gesinen'
});
/*conn.connect((err) => {
    if (err) {
        console.error('Error connecting: ' + err.stack)
    }
})*/
conn.getConnection((err) => {
    if (err) {
        console.error('Error connecting: ' + err.stack);
    }
});
exports.default = conn;
