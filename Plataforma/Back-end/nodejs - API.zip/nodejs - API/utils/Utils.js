"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Utils = void 0;
class Utils {
    static checkUndefined(expression) {
        if (expression == undefined) {
            return '';
        }
        return expression;
    }
}
exports.Utils = Utils;
