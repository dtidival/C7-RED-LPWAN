<?php

/* ::basetrans_es.html.twig */
class __TwigTemplate_7a1e1be9399e94594f9ee0d4b84402aa1fa4ee9d6ee1fc94d088dc2e1f6ad3ba extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"";
        // line 2
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "getPreferredLanguage", array(), "method"), "html", null, true);
        echo "\">
    <head>
        <meta charset=\"UTF-8\" />
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
       
        <title>Ardumaster |";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        
        <link href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/bootstrap/dist/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>\t\t
        <link href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/fontawesome/css/font-awesome.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
        <link href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/admin-lte/dist/css/AdminLTE.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>";
        // line 13
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 14
        echo "
        <link href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("css/base.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>\t
\t<!-- Navigation -->
\t\t<nav class=\"navbar navbar-inverse navbar-fixed-top\" role=\"navigation\">\t\t\t
\t\t\t<div class=\"container-fluid\">
\t\t\t\t<!-- Brand and toggle get grouped for better mobile display -->
\t\t\t\t<div class=\"navbar-header\">\t\t\t\t\t\t\t
\t\t\t\t\t<button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\">
\t\t\t\t\t\t<span class=\"sr-only\">Toggle navigation</span>
\t\t\t\t\t\t<span class=\"icon-bar\"></span>
\t\t\t\t\t\t<span class=\"icon-bar\"></span>
\t\t\t\t\t\t<span class=\"icon-bar\"></span>
\t\t\t\t\t</button>
\t\t\t\t\t<!--<a class=\"navbar-brand\" href=\"#\">Ardumaster Web</a>-->
\t\t\t\t\t<a class=\"navbar-brand\"  style=\"padding: 2px 15px;\" href=\"#\"><img src=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/logo_version.png"), "html", null, true);
        echo "\" alt=\"Logo\" class=\"img-responsive\" style=\"height:49px;\" height=\"49\"></a>
\t\t\t\t</div>
\t\t\t\t<!-- Collect the nav links, forms, and other content for toggling -->
\t\t\t\t<div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
\t\t\t\t\t<ul class=\"nav navbar-nav navbar-right\">
\t\t\t\t\t    <li class=\"dropdown\">
\t\t\t\t\t\t\t<a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" >";
        // line 37
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Data"), "html", null, true);
        echo " <b class=\"caret\"></b></a>
\t\t\t\t\t\t\t<ul class=\"dropdown-menu\">
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 40
        echo $this->env->getExtension('routing')->getPath("device_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Devices"), "html", null, true);
        echo "</i></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 43
        echo $this->env->getExtension('routing')->getPath("poweroutage_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Power Outage"), "html", null, true);
        echo "</i></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<!--<li>
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 46
        echo $this->env->getExtension('routing')->getPath("residualcurrent_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Residual Current Meter"), "html", null, true);
        echo "</i></a>
\t\t\t\t\t\t\t\t</li>-->";
        // line 51
        echo "\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 52
        echo $this->env->getExtension('routing')->getPath("inputwarningview_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Digital Inputs Warnings"), "html", null, true);
        echo "</i></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 55
        echo $this->env->getExtension('routing')->getPath("ElectricCurrentPower_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Control Cabinet Parameters"), "html", null, true);
        echo "</i></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 58
        echo $this->env->getExtension('routing')->getPath("electricmeter_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Electric Meter"), "html", null, true);
        echo "</a>
\t\t\t\t\t\t\t\t</li>";
        // line 75
        echo "\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t</li>
\t\t\t\t\t    <li class=\"dropdown\">
\t\t\t\t\t\t\t<a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" >";
        // line 78
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Settings"), "html", null, true);
        echo " <b class=\"caret\"></b></a>
\t\t\t\t\t\t\t<ul class=\"dropdown-menu\"> 
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 81
        echo $this->env->getExtension('routing')->getPath("group_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Groups"), "html", null, true);
        echo "</i></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 84
        echo $this->env->getExtension('routing')->getPath("phoneemailsetting_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Phone book and Emails"), "html", null, true);
        echo "</i></a>
\t\t\t\t\t\t\t\t</li> 
\t\t\t\t\t\t\t\t<!--<li>
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 87
        echo $this->env->getExtension('routing')->getPath("inputwarningsetting_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Setting warnings Digital Inputs"), "html", null, true);
        echo "</i></a>
\t\t\t\t\t\t\t\t</li>-->
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 90
        echo $this->env->getExtension('routing')->getPath("sunsetrise_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Setting Sunset and Sunrise"), "html", null, true);
        echo "</i></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 93
        echo $this->env->getExtension('routing')->getPath("deviceoutput_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Settings auxiliar outputs"), "html", null, true);
        echo "</i></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 96
        echo $this->env->getExtension('routing')->getPath("report_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Report Setting"), "html", null, true);
        echo "</i></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t    </li> 
\t\t\t\t\t\t<li class=\"dropdown\">
\t\t\t\t\t\t\t<a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" >";
        // line 101
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Lamp Control"), "html", null, true);
        echo " <b class=\"caret\"></b></a>
\t\t\t\t\t\t\t<ul class=\"dropdown-menu\">\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 104
        echo $this->env->getExtension('routing')->getPath("onetotenv_index");
        echo "\">1-10v</i></a>
\t\t\t\t\t\t\t\t</li>\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t <li>
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 107
        echo $this->env->getExtension('routing')->getPath("dali_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Dali"), "html", null, true);
        echo "</i></a>
\t\t\t\t\t\t\t\t</li> 
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 110
        echo $this->env->getExtension('routing')->getPath("googlemapbulb_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("GooglemapBulb"), "html", null, true);
        echo "</i></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 113
        echo $this->env->getExtension('routing')->getPath("nodebulb_index");
        echo "\">Node Bulb</i></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t</li>\t\t\t\t\t\t\t\t
\t\t\t\t\t    <li class=\"dropdown\">
\t\t\t\t\t\t\t<a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" ><span class=\"label label-danger notification \">0</span>";
        // line 118
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Users"), "html", null, true);
        echo " <b class=\"caret\"></b></a>
\t\t\t\t\t\t\t<ul class=\"dropdown-menu\">
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a >";
        // line 121
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : null), "first_name", array()), "html", null, true);
        echo "&nbsp;";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : null), "last_name", array()), "html", null, true);
        echo "</i></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<!--<a >";
        // line 124
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : null), "email", array()), "html", null, true);
        echo "</i></a>-->
\t\t\t\t\t\t\t\t</li>";
        // line 126
        if (($this->getAttribute((isset($context["user"]) ? $context["user"] : null), "permission", array()) == 1)) {
            echo " 
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 128
            echo $this->env->getExtension('routing')->getPath("user_manage");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Manage Users"), "html", null, true);
            echo "</i></a>
\t\t\t\t\t\t\t\t</li>";
        }
        // line 131
        if (($this->getAttribute((isset($context["user"]) ? $context["user"] : null), "permission", array()) == 2)) {
            echo " 
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 133
            echo $this->env->getExtension('routing')->getPath("user_manage_manager");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Manage Users"), "html", null, true);
            echo "</i></a>
\t\t\t\t\t\t\t\t</li>";
        }
        // line 136
        if (($this->getAttribute((isset($context["user"]) ? $context["user"] : null), "permission", array()) == 1)) {
            echo " 
\t\t\t\t\t\t\t\t <li>
\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 138
            echo $this->env->getExtension('routing')->getPath("activity_index");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Activity Log"), "html", null, true);
            echo "</i></a>
\t\t\t\t\t\t\t\t</li>";
        }
        // line 141
        if ((($this->getAttribute((isset($context["user"]) ? $context["user"] : null), "permission", array()) == 2) || ($this->getAttribute((isset($context["user"]) ? $context["user"] : null), "permission", array()) == 0))) {
            echo " 
\t\t\t\t\t\t\t\t <li>
\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 143
            echo $this->env->getExtension('routing')->getPath("activity_index");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Activity Log"), "html", null, true);
            echo "</i></a>
\t\t\t\t\t\t\t\t</li>";
        }
        // line 146
        if (($this->getAttribute((isset($context["user"]) ? $context["user"] : null), "permission", array()) == 1)) {
            echo " 
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 148
            echo $this->env->getExtension('routing')->getPath("managenode_index");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Manage Node"), "html", null, true);
            echo "</i></a>
\t\t\t\t\t\t\t\t</li>";
        }
        // line 151
        if (($this->getAttribute((isset($context["user"]) ? $context["user"] : null), "permission", array()) == 1)) {
            echo " 
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 153
            echo $this->env->getExtension('routing')->getPath("ControlCabinetPowerReport_index");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Control Cabinet Report"), "html", null, true);
            echo "</i></a>
\t\t\t\t\t\t\t\t</li>";
        }
        // line 156
        echo "\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 157
        echo $this->env->getExtension('routing')->getPath("Notification_index");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Notifications"), "html", null, true);
        echo " <span class=\"label label-danger notification\">0</span></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 160
        echo $this->env->getExtension('routing')->getPath("user_logout");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Log out"), "html", null, true);
        echo "</i></a>
\t\t\t\t\t\t\t\t</li>\t\t\t\t\t\t    \t\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<!--<li><a href=\"";
        // line 162
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "_route"), "method"), twig_array_merge($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "_route_params"), "method"), array("_locale" => "es"))), "html", null, true);
        echo "\">spanish</a></li>
\t\t\t\t\t\t\t\t<li><a href=\"";
        // line 163
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "_route"), "method"), twig_array_merge($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "_route_params"), "method"), array("_locale" => "en"))), "html", null, true);
        echo "\">English</a></li>-->
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t    </li>
\t\t\t\t\t\t<li class=\"dropdown\">
\t\t\t\t\t\t\t<a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" >";
        // line 167
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Language"), "html", null, true);
        echo " <b class=\"caret\"></b></a>
\t\t\t\t\t\t\t<ul class=\"dropdown-menu\">\t\t\t\t\t\t     \t\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<li><a href=\"";
        // line 169
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "_route"), "method"), twig_array_merge($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "_route_params"), "method"), array("_locale" => "es"))), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Spanish"), "html", null, true);
        echo "</a></li>
\t\t\t\t\t\t\t\t<li><a href=\"";
        // line 170
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "_route"), "method"), twig_array_merge($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "get", array(0 => "_route_params"), "method"), array("_locale" => "en"))), "html", null, true);
        echo "\">English</a></li>
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t    </li>\t\t\t\t\t
\t\t\t\t\t</ul>\t\t\t\t\t\t 
\t\t\t\t</div>
\t\t\t\t<!-- /.navbar-collapse -->
\t\t\t</div>\t\t
\t\t</nav>
\t\t<div class=\"container-fluid\">\t
\t\t\t<input type=\"hidden\" name=\"languageIndex\" id=\"languageIndex\" value=\"de\" />";
        // line 180
        $this->displayBlock('body', $context, $blocks);
        // line 181
        echo "\t\t</div>
        <script src=\"";
        // line 182
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/jquery/dist/jquery.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 183
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/bootstrap/dist/js/bootstrap.js"), "html", null, true);
        echo "\"></script>\t\t
        <script src=\"";
        // line 184
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/admin-lte/dist/js/app.js"), "html", null, true);
        echo "\"></script>
\t\t<script>
\t\tfunction notificationRefresh () {\t     
\t     getNotificationScan();
\t     setTimeout(notificationRefresh, 1000);
\t\t}
        //notificationRefresh();
\t\tvar count =0;
\t\tfunction getNotificationScan()
\t\t{
\t\t\t\turl = \"";
        // line 194
        echo $this->env->getExtension('routing')->getPath("Notification_count_index");
        echo "\";
\t\t\t\t\$.ajax(url, {
\t\t\t\tdata : null,
\t\t\t\ttype : \"get\",
\t\t\t\tsuccess : function (response) {
\t\t\t\tcount=0;
\t\t\t\tconsole.log('response');
\t\t\t\t\$.each(response,function(key,value){
\t\t\t\tif(value['isRead']==0)
\t\t\t\t{
\t\t\t\t\tcount++;
\t\t\t\t}
\t\t\t\t});
\t\t\t\t\t
\t\t\t\t}
\t\t\t\t});
\t\t\t
\t\t\t\$('.notification').text(count);\t\t\t
\t\t}
\t\t</script>";
        // line 214
        $this->displayBlock('javascripts', $context, $blocks);
        // line 215
        echo "    </body>
</html>
";
    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
    }

    // line 13
    public function block_stylesheets($context, array $blocks = array())
    {
    }

    // line 180
    public function block_body($context, array $blocks = array())
    {
    }

    // line 214
    public function block_javascripts($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "::basetrans_es.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  449 => 214,  444 => 180,  439 => 13,  434 => 7,  428 => 215,  426 => 214,  404 => 194,  391 => 184,  387 => 183,  383 => 182,  380 => 181,  378 => 180,  366 => 170,  360 => 169,  355 => 167,  348 => 163,  344 => 162,  337 => 160,  329 => 157,  326 => 156,  319 => 153,  314 => 151,  307 => 148,  302 => 146,  295 => 143,  290 => 141,  283 => 138,  278 => 136,  271 => 133,  266 => 131,  259 => 128,  254 => 126,  250 => 124,  242 => 121,  236 => 118,  228 => 113,  220 => 110,  212 => 107,  206 => 104,  200 => 101,  190 => 96,  182 => 93,  174 => 90,  166 => 87,  158 => 84,  150 => 81,  144 => 78,  139 => 75,  133 => 58,  125 => 55,  117 => 52,  114 => 51,  108 => 46,  100 => 43,  92 => 40,  86 => 37,  77 => 31,  59 => 16,  55 => 15,  52 => 14,  50 => 13,  47 => 11,  43 => 10,  39 => 9,  34 => 7,  26 => 2,  23 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html lang="{{ app.request.getPreferredLanguage() }}">*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <meta name="viewport" content="width=device-width, initial-scale=1" />*/
/*        */
/*         <title>Ardumaster | {% block title %}{% endblock %}</title>*/
/*         */
/*         <link href="{{ asset('vendor/bootstrap/dist/css/bootstrap.min.css') }}" rel="stylesheet"/>		*/
/*         <link href="{{ asset('vendor/fontawesome/css/font-awesome.min.css') }}" rel="stylesheet"/>*/
/*         <link href="{{ asset('vendor/admin-lte/dist/css/AdminLTE.min.css') }}" rel="stylesheet"/>*/
/* */
/*         {% block stylesheets %}{% endblock %}*/
/* */
/*         <link href="{{ asset('css/base.css') }}" rel="stylesheet"/>*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/*     <body>	*/
/* 	<!-- Navigation -->*/
/* 		<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">			*/
/* 			<div class="container-fluid">*/
/* 				<!-- Brand and toggle get grouped for better mobile display -->*/
/* 				<div class="navbar-header">							*/
/* 					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">*/
/* 						<span class="sr-only">Toggle navigation</span>*/
/* 						<span class="icon-bar"></span>*/
/* 						<span class="icon-bar"></span>*/
/* 						<span class="icon-bar"></span>*/
/* 					</button>*/
/* 					<!--<a class="navbar-brand" href="#">Ardumaster Web</a>-->*/
/* 					<a class="navbar-brand"  style="padding: 2px 15px;" href="#"><img src="{{ asset('assets/images/logo_version.png') }}" alt="Logo" class="img-responsive" style="height:49px;" height="49"></a>*/
/* 				</div>*/
/* 				<!-- Collect the nav links, forms, and other content for toggling -->*/
/* 				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">*/
/* 					<ul class="nav navbar-nav navbar-right">*/
/* 					    <li class="dropdown">*/
/* 							<a href="#" class="dropdown-toggle" data-toggle="dropdown" >{{ 'Data'|trans }} <b class="caret"></b></a>*/
/* 							<ul class="dropdown-menu">*/
/* 								<li>*/
/* 									<a href="{{ path('device_index')}}">{{ 'Devices'|trans }}</i></a>*/
/* 								</li>*/
/* 								<li>*/
/* 									<a href="{{ path('poweroutage_index')}}">{{ 'Power Outage'|trans }}</i></a>*/
/* 								</li>*/
/* 								<!--<li>*/
/* 									<a href="{{ path('residualcurrent_index')}}">{{ 'Residual Current Meter'|trans }}</i></a>*/
/* 								</li>-->*/
/* 							{#  <li>*/
/* 									<a href="{{ path('contactosoporte_index')}}">{{ 'Phone and email settings'|trans }}</i></a>*/
/* 								</li>  #}*/
/* 								<li>*/
/* 									<a href="{{ path('inputwarningview_index')}}">{{ 'Digital Inputs Warnings'|trans }}</i></a>*/
/* 								</li>*/
/* 								<li>*/
/* 									<a href="{{ path('ElectricCurrentPower_index')}}">{{ 'Control Cabinet Parameters'|trans }}</i></a>*/
/* 								</li>*/
/* 								<li>*/
/* 									<a href="{{ path('electricmeter_index')}}">{{ 'Electric Meter'|trans }}</a>*/
/* 								</li>					*/
/* 							{#  <li>*/
/* 									<a>Valores Eléctricos</i></a>*/
/* 								</li>*/
/* 								<li>*/
/* 									<a>Apagones detectados</i></a>*/
/* 								</li>*/
/* 								<li>*/
/* 									<a>Tarifador</i></a>*/
/* 								</li>*/
/* 								<li>*/
/* 									<a>Alarmas Entradas digitales</i></a>*/
/* 								</li>*/
/* 								<li>*/
/* 									<a>Medidor Diferencial</i></a>*/
/* 								</li> #}*/
/* 							</ul>*/
/* 						</li>*/
/* 					    <li class="dropdown">*/
/* 							<a href="#" class="dropdown-toggle" data-toggle="dropdown" >{{ 'Settings'|trans }} <b class="caret"></b></a>*/
/* 							<ul class="dropdown-menu"> */
/* 								<li>*/
/* 									<a href="{{ path('group_index')}}">{{ 'Groups'|trans }}</i></a>*/
/* 								</li>*/
/* 								<li>*/
/* 									<a href="{{ path('phoneemailsetting_index')}}">{{ 'Phone book and Emails'|trans }}</i></a>*/
/* 								</li> */
/* 								<!--<li>*/
/* 									<a href="{{ path('inputwarningsetting_index')}}">{{ 'Setting warnings Digital Inputs'|trans }}</i></a>*/
/* 								</li>-->*/
/* 								<li>*/
/* 									<a href="{{ path('sunsetrise_index')}}">{{ 'Setting Sunset and Sunrise'|trans }}</i></a>*/
/* 								</li>*/
/* 								<li>*/
/* 									<a href="{{ path('deviceoutput_index')}}">{{ 'Settings auxiliar outputs'|trans }}</i></a>*/
/* 								</li>*/
/* 								<li>*/
/* 									<a href="{{ path('report_index')}}">{{ 'Report Setting'|trans }}</i></a>*/
/* 								</li>*/
/* 							</ul>*/
/* 					    </li> */
/* 						<li class="dropdown">*/
/* 							<a href="#" class="dropdown-toggle" data-toggle="dropdown" >{{ 'Lamp Control'|trans }} <b class="caret"></b></a>*/
/* 							<ul class="dropdown-menu">							*/
/* 								<li>*/
/* 									<a href="{{ path('onetotenv_index')}}">1-10v</i></a>*/
/* 								</li>							*/
/* 								 <li>*/
/* 									<a href="{{ path('dali_index')}}">{{ 'Dali'|trans }}</i></a>*/
/* 								</li> */
/* 								<li>*/
/* 									<a href="{{ path('googlemapbulb_index')}}">{{ 'GooglemapBulb'|trans }}</i></a>*/
/* 								</li>*/
/* 								<li>*/
/* 									<a href="{{ path('nodebulb_index')}}">Node Bulb</i></a>*/
/* 								</li>*/
/* 							</ul>*/
/* 						</li>								*/
/* 					    <li class="dropdown">*/
/* 							<a href="#" class="dropdown-toggle" data-toggle="dropdown" ><span class="label label-danger notification ">0</span>{{ 'Users'|trans }} <b class="caret"></b></a>*/
/* 							<ul class="dropdown-menu">*/
/* 								<li>*/
/* 									<a >{{ user.first_name }}&nbsp;{{ user.last_name }}</i></a>*/
/* 								</li>*/
/* 								<li>*/
/* 									<!--<a >{{ user.email }}</i></a>-->*/
/* 								</li>*/
/* 								{% if user.permission == 1 %} */
/* 								<li>*/
/* 									<a href="{{ path('user_manage')}}">{{ 'Manage Users'|trans }}</i></a>*/
/* 								</li>*/
/* 								{% endif %}*/
/* 								{% if user.permission == 2 %} */
/* 								<li>*/
/* 									<a href="{{ path('user_manage_manager')}}">{{ 'Manage Users'|trans }}</i></a>*/
/* 								</li>*/
/* 								{% endif %}*/
/* 								{% if user.permission == 1  %} */
/* 								 <li>*/
/* 									<a href="{{ path('activity_index')}}">{{ 'Activity Log'|trans }}</i></a>*/
/* 								</li>*/
/* 								{% endif %}*/
/* 								{% if user.permission == 2 or  user.permission == 0 %} */
/* 								 <li>*/
/* 									<a href="{{ path('activity_index')}}">{{ 'Activity Log'|trans }}</i></a>*/
/* 								</li>*/
/* 								{% endif %}*/
/* 								{% if user.permission == 1 %} */
/* 								<li>*/
/* 									<a href="{{ path('managenode_index')}}">{{ 'Manage Node'|trans }}</i></a>*/
/* 								</li>*/
/* 								{% endif %}*/
/* 								{% if user.permission == 1 %} */
/* 								<li>*/
/* 									<a href="{{ path('ControlCabinetPowerReport_index')}}">{{ 'Control Cabinet Report'|trans }}</i></a>*/
/* 								</li>*/
/* 								{% endif %}*/
/* 								<li>*/
/* 									<a href="{{ path('Notification_index')}}">{{ 'Notifications'|trans }} <span class="label label-danger notification">0</span></a>*/
/* 								</li>*/
/* 								<li>*/
/* 									<a href="{{ path('user_logout')}}">{{ 'Log out'|trans }}</i></a>*/
/* 								</li>						    													*/
/* 								<!--<li><a href="{{ path(app.request.get('_route'), app.request.get('_route_params')|merge({'_locale': 'es'})) }}">spanish</a></li>*/
/* 								<li><a href="{{  path(app.request.get('_route'), app.request.get('_route_params')|merge({'_locale': 'en'}))}}">English</a></li>-->*/
/* 							</ul>*/
/* 					    </li>*/
/* 						<li class="dropdown">*/
/* 							<a href="#" class="dropdown-toggle" data-toggle="dropdown" >{{ 'Language'|trans }} <b class="caret"></b></a>*/
/* 							<ul class="dropdown-menu">						     													*/
/* 								<li><a href="{{ path(app.request.get('_route'), app.request.get('_route_params')|merge({'_locale': 'es'})) }}">{{ 'Spanish'|trans }}</a></li>*/
/* 								<li><a href="{{  path(app.request.get('_route'), app.request.get('_route_params')|merge({'_locale': 'en'}))}}">English</a></li>*/
/* 							</ul>*/
/* 					    </li>					*/
/* 					</ul>						 */
/* 				</div>*/
/* 				<!-- /.navbar-collapse -->*/
/* 			</div>		*/
/* 		</nav>*/
/* 		<div class="container-fluid">	*/
/* 			<input type="hidden" name="languageIndex" id="languageIndex" value="de" />	*/
/* 			{% block body %}{% endblock %}*/
/* 		</div>*/
/*         <script src="{{ asset('vendor/jquery/dist/jquery.js') }}"></script>*/
/*         <script src="{{ asset('vendor/bootstrap/dist/js/bootstrap.js') }}"></script>		*/
/*         <script src="{{ asset('vendor/admin-lte/dist/js/app.js') }}"></script>*/
/* 		<script>*/
/* 		function notificationRefresh () {	     */
/* 	     getNotificationScan();*/
/* 	     setTimeout(notificationRefresh, 1000);*/
/* 		}*/
/*         //notificationRefresh();*/
/* 		var count =0;*/
/* 		function getNotificationScan()*/
/* 		{*/
/* 				url = "{{ path('Notification_count_index') }}";*/
/* 				$.ajax(url, {*/
/* 				data : null,*/
/* 				type : "get",*/
/* 				success : function (response) {*/
/* 				count=0;*/
/* 				console.log('response');*/
/* 				$.each(response,function(key,value){*/
/* 				if(value['isRead']==0)*/
/* 				{*/
/* 					count++;*/
/* 				}*/
/* 				});*/
/* 					*/
/* 				}*/
/* 				});*/
/* 			*/
/* 			$('.notification').text(count);			*/
/* 		}*/
/* 		</script>*/
/*         {% block javascripts %}{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
