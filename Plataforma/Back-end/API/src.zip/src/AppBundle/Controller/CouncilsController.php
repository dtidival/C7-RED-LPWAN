<?php

namespace AppBundle\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use AppBundle\Entity\Councils;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Normalizer\GetSetMethodNormalizer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Normalizer\DateTimeNormalizer;


/**
 * Councils controller.
 *
 * @Route("/councils")
 */
class CouncilsController extends Controller
{
	
	/**
     * List
     *                                                                                 
	 * @Route("/list", name="councils_list")
	 */
	public function CouncilsListApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());
		$userId = $data->userId;
		$councilsId = $data->councilsId;
		$permission = $data->permission;
		if($permission == 1){
			$councilsList= $em 
			->getRepository('AppBundle:Councils')
			->findAll();	
		}
		else if($permission == 2){
			if($councilsId != null){
				$councilsList= $em 
			->getRepository('AppBundle:Councils')
			->findBy(array('id'=>$councilsId));	
			}
			else{
				$councilsList = null;
			}
				
		}
		else{
			return new JsonResponse(array('status' => 'success','message' => 'No Response for normal User'));
		}
		/*$councilsList= $em 
			->getRepository('AppBundle:Councils')
			->findAll();*/
		
		$json = '';
		//var_dump($user);
		
		 if($councilsList != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($councilsList, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','details' => $json));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','details' => $json));
			//return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in councils data'));
	}
	/**
     * Get Council by Id
     *                                                                                 
	 * @Route("/getcouncilbyid", name="council_getcouncilbyid")
	 */
	public function getCouncilByIdApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$coucilId = $data->id;
		
		$council= $em 
			->getRepository('AppBundle:Councils')
			->findBy(array('id' => $coucilId));
		
		if( $council != null)
		{
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new GetSetMethodNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($council, 'json');
			
			return new JsonResponse(array('status' => 'Success','details' => $json));
		}
		else{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in getting councils details!!'));
		} 
		
	}
	/**
     * Delete a Council
     *                                                                                 
	 * @Route("/deletecouncil", name="council_deletecouncil")
	 */
	public function deleteCouncilApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());		
		$councilId = $data->id;	
		$council= $em 
			->getRepository('AppBundle:Councils')
			->findOneBy(array('id' => $councilId));
		if($council != null)
		{
			$em->remove($council);
            $em->flush();	
		return new JsonResponse(array('status' => 'SUCCESS','message' => 'Councils has been successfully removed!!'));
		}
		else{
			return new JsonResponse(array('status' => 'Failed','message' => 'No Councils is Present with this Id!!'));
		}
	}
	
	/**
     * Create New Council
     *                                                                                 
	 * @Route("/newCouncil", name="council_newcouncil")
	 */
	public function newCouncilApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		// var_dump($data);
		
		$name = $data->name;		
		$address = $data->address;
		$country = $data->country;
		$state = $data->state;
		$city = $data->city;
		$postalCode = $data->postalCode;
		$contactPerson = $data->contactPerson;
		$email = $data->email;
		$telephone = $data->telephone;
		$web = $data->web;
				
		
		$councilObj= $em 
			->getRepository('AppBundle:Councils')
			->findBy(array('name' => $name));
			
			
		if($councilObj != null)
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Requested Councils is already exists!!'));
		}
		else{
			
			$council = new Councils();
			$council->setName($name);
			
			if($address != "")
			$council->setAddress($address);
		
			if($country != "")
			$council->setCountry($country);
		
			if($state != "")
			$council->setState($state);
		
			if($city != "")
			$council->setCity($city);
			
			if($postalCode != "")
			$council->setPostalCode($postalCode);
		
			if($contactPerson != "")
			$council->setContactPerson($contactPerson);
		
			if($email != "")
			$council->setEmail($email);
			
			if($telephone != "")
			$council->setTelephone($telephone);
		
			if($web != "")
			$council->setWeb($web);			
			
		
			$em->persist($council);
			$em->flush();
			$Id = $council->getId();
			
			if( $Id != '')
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'council has been successfully created!!','id' => $Id));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in registering council registeration!!'));
			} 
		}
		
	}
	
	/**
     * Update a Councils
     *                                                                                 
	 * @Route("/updatecouncil", name="council_updatecouncil")
	 */
	public function updateCouncilApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$councilId = $data->id;
		$name = $data->name;		
		$address = $data->address;
		$country = $data->country;
		$state = $data->state;
		$city = $data->city;
		$postalCode = $data->postalCode;
		$contactPerson = $data->contactPerson;
		$email = $data->email;
		$telephone = $data->telephone;
		$web = $data->web;	
		
		$council= $em 
			->getRepository('AppBundle:Councils')
			->findOneBy(array('id' => $councilId));
			
		if($council !=null)
		{
		
			if($name != "")
			{
				$council->setName($name);
			}
			if($address != "")
			$council->setAddress($address);
		
			if($country != "")
			$council->setCountry($country);
		
			if($state != "")
			$council->setState($state);
		
			if($city != "")
			$council->setCity($city);
			
			if($postalCode != "")
			$council->setPostalCode($postalCode);
		
			if($contactPerson != "")
			$council->setContactPerson($contactPerson);
		
			if($email != "")
			$council->setEmail($email);
			
			if($telephone != "")
			$council->setTelephone($telephone);
		
			if($web != "")
			$council->setWeb($web);
			
			$council->setUpdatedDt(new \DateTime());
			
			$em->persist($council);
			$em->flush();
			$councilId = $council->getId();
			
			if( $councilId != "")
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'council has been successfully updated!!'));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating council details!!'));
			}
		}
		else
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating council Detail No Record found with this Id'));
		}
		
	}
}
?>