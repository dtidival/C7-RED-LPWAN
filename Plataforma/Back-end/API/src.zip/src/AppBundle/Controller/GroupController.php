<?php

namespace AppBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use AppBundle\Entity\Groups;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Normalizer\GetSetMethodNormalizer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Normalizer\DateTimeNormalizer;


/**
 * Group controller.
 *
 * @Route("/group")
 */
class GroupController extends Controller
{
	
	/**
     * List
     *                                                                                 
	 * @Route("/list", name="group_list")
	 */
	public function GroupListApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());
		$userId = $data->userId;
		$permission = $data->permission;
		
		if($permission == 1){
			$groupList= $em 
			->getRepository('AppBundle:Groups')
			->findAll();	
		}
		else if($permission == 2){
			if($underAdmin != null)
			{
			$groupList= $em 
			->getRepository('AppBundle:Groups')
			->findBy(array('userId'=>$underAdmin));	
			}
			else{
			$groupList= $em 
			->getRepository('AppBundle:Groups')
			->findBy(array('userId'=>$userId));	
			}  
			
			
		}
		else{
			$user= $em 
			->getRepository('AppBundle:Users')
			->findOneBy(array('id'=>$userId));
			$groupList= $em 
			->getRepository('AppBundle:Groups')
			->findBy(array('userId' =>$user->getUnderAdmin()));	
		}

		/*$groupList= $em 
			->getRepository('AppBundle:Groups')
			->findAll();*/
		
		$json = '';
		//var_dump($user);
		
		 if($groupList != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($groupList, 'json');
			
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','group_details' => $json));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','group_details' => $json));
			//return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in user data'));
	}
	
	/**
     * Create New Group
     *                                                                                 
	 * @Route("/newGroup", name="group_newgroup")
	 */
	public function newGroupApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		// var_dump($data);
		
		$groupName = $data->groupName;		
		$groupType = $data->groupType;
		$parentId = $data->parentId;		
		
		//$sensorsId = $data->sensorsId;
		//$serverId = $data->serverId;
		
		
		$groupObj= $em 
			->getRepository('AppBundle:Groups')
			->findBy(array('groupName' => $groupName,'groupType' => $groupType,'parentId' => $parentId));
			
			
		if($groupObj != null)
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Requested Group is already exists!!'));
		}
		else{
			
			$group = new Groups();
			$group->setGroupName($groupName);
			$group->setGroupType($groupType);
			//$group->setParentId($parentId);
			if ($parentId != "")
			{
				$group->setParentId($parentId);
				
				if($parentId > 0)
				{
					$groupObj= $em 
						->getRepository('AppBundle:Groups')
						->findBy(array('id' => $parentId))[0];
					$level = $groupObj->getLevel() + 1;
					$group->setLevel($level);
				}
				else
				{
					$group->setLevel(0);
				}				
			}
			$em->persist($group);
			$em->flush();
			$Id = $group->getId();
			
			if( $Id != '')
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'Group has been successfully created!!','id' => $Id));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in registering Group registeration!!'));
			} 
		}
		
	}
	
	/**
     * Get Group by Id
     *                                                                                 
	 * @Route("/getgroupbyid", name="group_getgroupbyid")
	 */
	public function getgroupbyidApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$groupId = $data->id;
		
		$group= $em 
			->getRepository('AppBundle:Groups')
			->findBy(array('id' => $groupId));
		
		if( $group != null)
		{
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new GetSetMethodNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($group, 'json');
			
			return new JsonResponse(array('status' => 'Success','group_details' => $json));
		}
		else{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in getting group details!!'));
		} 
		
	}
	
	/**
     * Get Group parent list
     *                                                                                 
	 * @Route("/groupparentlist", name="group_groupparentlist")
	 */
	public function getgroupparentlistApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$entities = $em->getRepository('AppBundle:Groups')->getGroupsByLevel(1);
		//$parentLists = $em->getRepository('AppBundle:Groups')->getGroupsforParent();
		
		
		
		if( $entities != null)
		{
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new GetSetMethodNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($entities, 'json');
			
			return new JsonResponse(array('status' => 'Success','group_details' => $json));
		}
		else{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in getting group details!!'));
		} 
		
	}
	
	/**
     * Update a Group
     *                                                                                 
	 * @Route("/updategroup", name="group_updategroup")
	 */
	public function updategroupApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$groupId = $data->id;
		$groupName = $data->groupName;
		$groupType = $data->groupType;
		$parentId = $data->parentId;
		$sensorId = $data->sensorId;
		$serverId = $data->serverId;
		
		
		
		$group= $em 
			->getRepository('AppBundle:Groups')
			->findOneBy(array('id' => $groupId));
		
		if($groupName != "")
		{
			$group->setGroupName($groupName);
		}
		if($groupType != "")
		{
			$group->setGroupType($groupType);
		}
		if ($parentId != "")
		{
			$group->setParentId($parentId);
			
			if($parentId > 0)
			{
				$groupObj= $em 
					->getRepository('AppBundle:Groups')
					->findBy(array('id' => $parentId))[0];
				$level = $groupObj->getLevel() + 1;
				$group->setLevel($level);
			}
			else
			{
				$group->setLevel(0);
			}				
		}
		if($sensorId != "")
		{
			$group->setSensorId($sensorId);
		}
		if($serverId != "")
		{
			$group->setServerId($serverId);
		}
		
		$group->setUpdatedDt(new \DateTime());
		
		$em->persist($group);
		$em->flush();
		$groupId = $group->getId();
		
		if( $groupId != "")
		{
			return new JsonResponse(array('status' => 'SUCCESS','message' => 'Group has been successfully updated!!'));
		}
		else{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating Group details!!'));
		} 
		
	}
	
	/**
     * Delete a Group
     *                                                                                 
	 * @Route("/deletegroup", name="group_deletegroup")
	 */
	public function deleteGroupApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());		
		$groupId = $data->id;	
		$group= $em 
			->getRepository('AppBundle:Groups')
			->findOneBy(array('id' => $groupId));
		if($group != null)
		{
			$em->remove($group);
            $em->flush();	
		return new JsonResponse(array('status' => 'SUCCESS','message' => 'Group has been successfully removed!!'));
		}
		else{
			return new JsonResponse(array('status' => 'Failed','message' => 'No Group is Present with this Id!!'));
		}
	}
}

?>