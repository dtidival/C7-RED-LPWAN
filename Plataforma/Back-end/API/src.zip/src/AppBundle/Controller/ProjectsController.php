<?php

namespace AppBundle\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use AppBundle\Entity\Projects;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Normalizer\GetSetMethodNormalizer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Normalizer\DateTimeNormalizer;


/**
 * Projects controller.
 *
 * @Route("/projects")
 */
class ProjectsController extends Controller
{
	
	/**
     * List
     *                                                                                 
	 * @Route("/list", name="projects_list")
	 */
	public function ProjectsListApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());
		$userId = $data->userId;
		$councilsId = $data->councilsId;
		$businessId = $data->businessId;
		$permission = $data->permission;
		
		if($permission == 1){
			$projectsList= $em 
			->getRepository('AppBundle:Projects')
			->findAll();	
		}
		else if($permission == 2){
			if($businessId != "NULL"){
				$projectsList= $em 
			->getRepository('AppBundle:Projects')
			->findBy(array('business'=>$businessId));
			}
			else if ($councilsId != "NULL")
			{
				$projectsList= $em 
			->getRepository('AppBundle:Projects')
			->findBy(array('councils'=>$councilsId));
			}
			else{
				$projectsList = null;
			}
		}
		else{
			return new JsonResponse(array('status' => 'success','message' => 'No Response for normal User'));
		}
		/*$projectsList= $em 
			->getRepository('AppBundle:Projects')
			->findAll();*/
		
		$json = '';
		//var_dump($user);
		
		 if($projectsList != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($projectsList, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','details' => $json));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','details' => $json));
			//return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in projects data'));
	}
	/**
     * Get Projects by Id
     *                                                                                 
	 * @Route("/getprojectsbyid", name="projects_getprojectsbyid")
	 */
	public function getProjectsByIdApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$projectId = $data->id;
		
		$project= $em 
			->getRepository('AppBundle:Projects')
			->findBy(array('id' => $projectId));
		
		if( $project != null)
		{			
			$serializer = new Serializer(array(new DateTimeNormalizer('Y-m-d H:i:s'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($project, 'json');
			
			return new JsonResponse(array('status' => 'Success','details' => $json));
		}
		else{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in getting project details!!'));
		} 
		
	}
	/**
     * Delete a Project
     *                                                                                 
	 * @Route("/deleteproject", name="project_deleteproject")
	 */
	public function deleteProjectApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());		
		$projectId = $data->id;	
		$project= $em 
			->getRepository('AppBundle:Projects')
			->findOneBy(array('id' => $projectId));
		if($project != null)
		{
			$em->remove($project);
            $em->flush();	
		return new JsonResponse(array('status' => 'SUCCESS','message' => 'Project has been successfully removed!!'));
		}
		else{
			return new JsonResponse(array('status' => 'Failed','message' => 'No Project is Present with this Id!!'));
		}
	}
	
	/**
     * Create New Project
     *                                                                                 
	 * @Route("/newProject", name="project_newproject")
	 */
	public function newProjectApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		// var_dump($data);
		
		$name = $data->name;		
		$description = $data->description;
		$dateOfStart = $data->dateOfStart;
		$councils = $data->councils;
		$business = $data->business;
		$users = implode(",",$data->users);
		$status = $data->status;
				
		
		$projectObj= $em 
			->getRepository('AppBundle:Projects')
			->findBy(array('name' => $name));
			
			
		if($projectObj != null)
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Requested project is already exists!!'));
		}
		else{
			
			$project = new Projects();
			$project->setName($name);
			
			if($description != "")
			$project->setDescription($description);
		
			if($dateOfStart != "")
			$project->setDateOfStart(new \DateTime($dateOfStart));
		
			if($councils != "")
			$project->setCouncils($councils);
			
			if($business != "")
			$project->setBusiness($business);
		
			if($users != "")
			$project->setUsers($users);
		
			if($status != "")
			$project->setStatus($status);
			
			
		
			$em->persist($project);
			$em->flush();
			$Id = $project->getId();
			
			if( $Id != '')
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'project has been successfully created!!','id' => $Id));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in registering project registeration!!'));
			} 
		}
		
	}
	/**
     * Update a Projects
     *                                                                                 
	 * @Route("/updateproject", name="project_updateproject")
	 */
	public function updateProjectsApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$projectId = $data->id;
		$name = $data->name;		
		$description = $data->description;
		$dateOfStart = $data->dateOfStart;
		$councils = $data->councils;
		$business = $data->business;
		$users = implode(",",$data->users);
		$status = $data->status;		
		
		$project= $em 
			->getRepository('AppBundle:Projects')
			->findOneBy(array('id' => $projectId));
			
		if($project !=null)
		{
		
			if($name != "")
			{
				$project->setName($name);
			}
			if($description != "")
			{
				$project->setDescription($description);
			}
			if($dateOfStart != "")
			$project->setDateOfStart(new \DateTime($dateOfStart));
		
			if($councils != "")
			$project->setCouncils($councils);
			
			if($business != "")
			$project->setBusiness($business);
		
			if($users != "")
			$project->setUsers($users);
		
			if($status != "")
			$project->setStatus($status);
			
			$project->setUpdatedDt(new \DateTime());
			
			$em->persist($project);
			$em->flush();
			$gatewayId = $project->getId();
			
			if( $gatewayId != "")
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'project has been successfully updated!!'));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating project details!!'));
			}
		}
		else
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating project Detail No Record found with this Id'));
		}
		
	}
}
?>