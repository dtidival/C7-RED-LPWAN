<?php

namespace AppBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use AppBundle\Entity\Users;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Normalizer\GetSetMethodNormalizer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Normalizer\DateTimeNormalizer;
use Symfony\Component\HttpKernel\Exception\HttpException;

/**
 * User controller.
 *
 * @Route("/user")
 */
class UserController extends Controller
{
	
	
	/**
     * Login API
     *                                                                                 
	 * @Route("/login", name="user_login")
	 */
	public function loginApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();		
		
		$data = json_decode($request->getContent());
		// var_dump($data);
		
		$e_mail = $data->email;
		$pwd = $data->password;
		

		$users = $em->getRepository('AppBundle:Users')->findAll();

		
			foreach($users as $user)
			{
				if ($e_mail == $user->getEmail())
				{
					if ($user->getDisable()== false)
					{
						if ($pwd == $user->getPwd())
						{
							return new JsonResponse(array('message' => 'Login Sucess','user' =>$e_mail,'user_id'=> $user->getId(),'underAdmin'=> $user->getUnderAdmin(),'permission'=> $user->getPermission(),'userType'=> $user->getDefineView(),'business'=> $user->getBusiness(),'councils'=> $user->getCouncils(),'doorModuleAccess'=> $user->getDoorModuleAccess(),'energyModuleAccess'=> $user->getEnergyModuleAccess(),'deviceModuleAccess'=> $user->getDeviceModuleAccess(),'waterModuleAccess'=> $user->getWaterModuleAccess(),'capacityModuleAccess'=> $user->getCapacityModuleAccess(),'irrigationModuleAccess'=> $user->getIrrigationModuleAccess(),'genericModuleAccess'=> $user->getGenericModuleAccess(),'onlyDoorModuleUser'=> $user->getOnlyDoorModuleUser()));
						}
						else
						{
							return new JsonResponse(array('message' => 'Incorrect email/password','user' =>$e_mail ));
						}
					}
				}
			}
		
		
			return new JsonResponse(array('message' => 'User is not authorized!!',"user" => $e_mail  ));
	
	}
	
	
	
	/**
     * Get User API
     *                                                                                 
	 * @Route("/getuserbyid", name="user_getuserbyid")
	 */
	public function getuserbyidApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();		
		
		$data = json_decode($request->getContent());
		// var_dump($data);
		
		$userId = $data->id;
		

		$user= $em 
			->getRepository('AppBundle:Users')
			->find($userId);
		
		$json = '';
		//var_dump($user);
		
		 if($user != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($user, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','user_details' => $json));
		}
		else{
			//return new JsonResponse(array('message' => 'this is a json response','user_details' => $json));
			return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in user data'));
	
	}
	
	/**
     * Delete a User
     *                                                                                 
	 * @Route("/deleteuser", name="user_deleteuser")
	 */
	public function deleteUserApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());		
		$userId = $data->id;	
		$user= $em 
			->getRepository('AppBundle:Users')
			->findOneBy(array('id' => $userId));
		if($user != null)
		{
			$em->remove($user);
            $em->flush();	
		return new JsonResponse(array('status' => 'SUCCESS','message' => 'User has been successfully removed!!'));
		}
		else{
			return new JsonResponse(array('status' => 'Failed','message' => 'No User is Present with this Id!!'));
		}
	}
	
	/**
     * Get User API
     *                                                                                 
	 * @Route("/getalluser", name="user_getalluser")
	 */
	public function getalluserbyApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());
		$userId = $data->userId;
		$underAdmin = $data->underAdmin;
		$permission = $data->permission;
		if($permission == 1){
			$users= $em 
			->getRepository('AppBundle:Users')
			->findBy(array('onlyDoorModuleUser'=>0));	
		}
		else if($permission == 2){
			$users= $em 
			->getRepository('AppBundle:Users')
			->getUsersUnderAdmin($userId,$underAdmin);	
		}
		else{
			$users= $em 
			->getRepository('AppBundle:Users')
			->findOneBy(array('id' => $userId));	
		}
		// $userRepo = $this->getDoctrine()->getRepository('AppBundle:Users');
		//	$users = $userRepo->getUsersUnderAdmin($userId);
		
		//return new JsonResponse(array('status' => 'FAILED','message' => $data));
			
			$user_array = array();
			$i = 0;			
			foreach ($users as $user)
			{
				$user_array[$i] = array(
					'id' => $user->getId(),
					'firstName' => $user->getFirstName(),
					'lastName' => $user->getLastName(),
					'email' => $user->getEmail(),
					'phone' => $user->getPhone(),
					'underAdmin' => $user->getUnderAdmin(),
					'userCreatedBy' => $user->getUserCreatedBy(),
					'address' => $user->getAddress(),					
					'city' => $user->getCity(),
					'state' => $user->getState(),
					'country' => $user->getCountry(),
					'disable' => $user->getDisable(),
					'permission' => $user->getPermission(),
					'defineView'=> $user->getDefineView(),
					'councils' => $user->getCouncils(),
					'business' => $user->getBusiness(),
					'project' => $user->getProjects(),
					'doorModuleAccess' => $user->getDoorModuleAccess(),
					'doorModuleUsertype' => $user->getDoorModuleUsertype(),
					'energyModuleAccess' => $user->getEnergyModuleAccess(),
					'energyModuleUsertype' => $user->getEnergyModuleUsertype(),
					'deviceModuleAccess' => $user->getDeviceModuleAccess(),
					'deviceModuleUsertype' => $user->getDeviceModuleUsertype(),
					'waterModuleAccess' => $user->getWaterModuleAccess(),
					'waterModuleUsertype' => $user->getWaterModuleUsertype(),
					'capacityModuleAccess' => $user->getCapacityModuleAccess(),
					'capacityModuleUsertype' => $user->getCapacityModuleUsertype(),
					'irrigationModuleAccess' => $user->getIrrigationModuleAccess(),
					'irrigationModuleUsertype' => $user->getIrrigationModuleUsertype(),
					'genericModuleAccess' => $user->getGenericModuleAccess(),
					'genericModuleUsertype' => $user->getGenericModuleUsertype(),
					
					
			);
			$i++;
			}			
			//return new JsonResponse($user_array);	
		
		$json = '';
		//var_dump($user);
		
		 if($users != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($user_array, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','user_details' => $json));
		}
		else{
			//return new JsonResponse(array('message' => 'this is a json response','user_details' => $json));
			return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in user data'));
	
	}
	
	/**
     * Get User API
     *                                                                                 
	 * @Route("/getalluserCompleteList", name="user_getalluserCompleteList")
	 */
	public function getalluserCompleteListbyApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		
			$users= $em 
			->getRepository('AppBundle:Users')
			->findAll(array('onlyDoorModuleUser'=>0));	
		
			
			$user_array = array();
			$i = 0;			
			foreach ($users as $user)
			{
				$user_array[$i] = array(
					'id' => $user->getId(),
					'firstName' => $user->getFirstName(),
					'lastName' => $user->getLastName(),
					'email' => $user->getEmail(),
					'phone' => $user->getPhone(),
					'underAdmin' => $user->getUnderAdmin(),
					'userCreatedBy' => $user->getUserCreatedBy(),
					'address' => $user->getAddress(),					
					'city' => $user->getCity(),
					'state' => $user->getState(),
					'country' => $user->getCountry(),
					'disable' => $user->getDisable(),
					'permission' => $user->getPermission()				
					
			);
			$i++;
			}			
			//return new JsonResponse($user_array);	
		
		$json = '';
		//var_dump($user);
		
		 if($users != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($user_array, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','user_details' => $json));
		}
		else{
			//return new JsonResponse(array('message' => 'this is a json response','user_details' => $json));
			return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in user data'));
	
	}
	
	/**
     * Get User API
     *                                                                                 
	 * @Route("/getalluserofdoormodule", name="user_getalluserofdoormodule")
	 */
	public function getalluserordoormodulebyApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());
		$userId = $data->userId;
		$underAdmin = $data->underAdmin;
		$permission = $data->permission;
		if($permission == 1){
			$users= $em 
			->getRepository('AppBundle:Users')
			->findBy(array('onlyDoorModuleUser'=>1));	
		}
		else if($permission == 2){
			$users= $em 
			->getRepository('AppBundle:Users')
			->findBy(array('onlyDoorModuleUser'=>1,'underAdmin'=>$userId ));	
		}
		else{
			$users= $em 
			->getRepository('AppBundle:Users')
			->findBy(array('id' => $userId));	
		}
		// $userRepo = $this->getDoctrine()->getRepository('AppBundle:Users');
		//	$users = $userRepo->getUsersUnderAdmin($userId);
		
		//return new JsonResponse(array('status' => 'FAILED','message' => $data));
		$user_array = array();
			if($users != null){
			
			$i = 0;			
			foreach ($users as $user)
			{
				$user_array[$i] = array(
					'id' => $user->getId(),
					'firstName' => $user->getFirstName(),
					'lastName' => $user->getLastName(),
					'email' => $user->getEmail(),
					'phone' => $user->getPhone(),
					'underAdmin' => $user->getUnderAdmin(),
					'userCreatedBy' => $user->getUserCreatedBy(),
					'address' => $user->getAddress(),					
					'city' => $user->getCity(),
					'state' => $user->getState(),
					'country' => $user->getCountry(),
					'permission' => $user->getPermission(),
					'disable' => $user->getDisable(),
					'defineView'=> $user->getDefineView(),
					'councils' => $user->getCouncils(),
					'business' => $user->getBusiness(),
					'project' => $user->getProjects(),
					'doorModuleAccess' => $user->getDoorModuleAccess(),
					'doorModuleUsertype' => $user->getDoorModuleUsertype(),
					'energyModuleAccess' => $user->getEnergyModuleAccess(),
					'energyModuleUsertype' => $user->getEnergyModuleUsertype(),
					'deviceModuleAccess' => $user->getDeviceModuleAccess(),
					'deviceModuleUsertype' => $user->getDeviceModuleUsertype(),
					'waterModuleAccess' => $user->getWaterModuleAccess(),
					'waterModuleUsertype' => $user->getWaterModuleUsertype(),
					'capacityModuleAccess' => $user->getCapacityModuleAccess(),
					'capacityModuleUsertype' => $user->getCapacityModuleUsertype(),
					'irrigationModuleAccess' => $user->getIrrigationModuleAccess(),
					'irrigationModuleUsertype' => $user->getIrrigationModuleUsertype(),
					'genericModuleAccess' => $user->getGenericModuleAccess(),
					'genericModuleUsertype' => $user->getGenericModuleUsertype(),
					
					
			);
			$i++;
			}			
			//return new JsonResponse($user_array);	
		
		$json = '';
		//var_dump($user);
		
		 if($user != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($user_array, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','user_details' => $json));
		}
		else{
			//return new JsonResponse(array('message' => 'this is a json response','user_details' => $json));
			return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in user data'));
			}
			else{
				return new JsonResponse(array('status' => 'SUCCESS', 'message' => 'No Record Found'));
			}
	
	}
	
		/**
     * Get User API
     *                                                                                 
	 * @Route("/getalluserpagination", name="user_getalluserpagination")	
	 */
	public function getalluserpaginationbyApi(Request $request)    
	{
		
		try {
            $userRepo = $this->getDoctrine()->getRepository('AppBundle:Users');
			$data = json_decode($request->getContent());
            $users = $userRepo->getUserListing(
                $data->pageNo,
                $data->limit,                
                $data->search,
                $data->sortBy,
                $data->sortOrder
                
            );

        } catch (\Exception $e) {
            throw new HttpException(422, $e->getMessage());
        }
		$json = '';
		//var_dump($user);
		
		 if($users != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($users, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','user_details' => $json));
		}
		else{
			//return new JsonResponse(array('message' => 'this is a json response','user_details' => $json));
			return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in user data'));
        //$view = $this->view($users, 200);
        //return $this->handleView($view);	
	}
	
	/**
     * Get User Email API
     *                                                                                 
	 * @Route("/getuserbyemailapi", name="user_getuserbyemailapi")
	 */
	public function getuserbyemailApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();		
		
		$data = json_decode($request->getContent());
		// var_dump($data);
		
		$userEmail = $data->email;
		
			
		$user= $em 
			->getRepository('AppBundle:Users')
			->findBy(array('email' => $userEmail))[0];			
		
		$json = '';
		//var_dump($user);
		
		 if($user != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($user, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','user_details' => $json));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','user_details' => $json));
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in user data'));
	
	}
	
	/**
     * Register API
     *                                                                                 
	 * @Route("/registerapi", name="user_registerapi")
	 */
	public function registerApi(Request $request)    
	{
		$em = 
		$this->getDoctrine()->getManager();
		$users = $em->getRepository('AppBundle:Users')->findAll();
		
		$data = json_decode($request->getContent());
		// var_dump($data);
		

		$firstName = $data->firstName;
		$lastName = $data->lastName;
		$email = $data->email;
		$pwd = $data->password;	
		$underAdmin = $data->underAdmin;
		$userCreatedBy = $data->userCreatedBy;		
		$phone = $data->mobile;	
		$address = $data->address;
		$city = $data->city;
		$state = $data->state;		
		$country = $data->country;	
		$permission = $data->permission;
		$defineView = $data->defineView;
		$councils = $data->councils;
		$business = $data->business;
		$projects = $data->projects;
		$onlyDoorModuleUser = $data->onlyDoorModuleUser;
		$doorModuleAccess = $data->doorModuleAccess == true?1:0;
		$energyModuleAccess = $data->energyModuleAccess == true?1:0;
		$deviceModuleAccess = $data->deviceModuleAccess == true?1:0;
		$waterModuleAccess = $data->waterModuleAccess == true?1:0;
		$capacityModuleAccess = $data->capacityModuleAccess == true?1:0;
		$irrigationModuleAccess = $data->irrigationModuleAccess == true?1:0;
		$genericModuleAccess = $data->genericModuleAccess == true?1:0;
		$waterModuleAccess = $data->waterModuleAccess == true?1:0;
		$doorModuleUsertype = $data->doorModuleUsertype == true?1:2;
		$energyModuleUsertype = $data->energyModuleUsertype == true?1:2;
		$deviceModuleUsertype = $data->deviceModuleUsertype == true?1:2;
		$waterModuleUsertype = $data->waterModuleUsertype == true?1:2;
		$capacityModuleUsertype = $data->capacityModuleUsertype == true?1:2;
		$irrigationModuleUsertype = $data->irrigationModuleUsertype == true?1:2;
		$genericModuleUsertype = $data->genericModuleUsertype == true?1:2;

		foreach($users as $user)
		{
			if ($user->getEmail() == $email)
			{	
				return new JsonResponse(array('status' => 'FAILED','error' => 'This email is used by another user! Please, enter another email'));
			}
		}

		$user = new Users();
		$user->setFirstName($firstName);
		$user->setLastName($lastName);
		$user->setEmail($email);
		$user->setPwd($pwd);
		$user->setUnderAdmin($underAdmin);
		$user->setUserCreatedBy($userCreatedBy);
		
		if($phone != "")
		$user->setPhone($phone);
		else
		$user->setPhone('7777777777');	
	
		if($address != "")
		$user->setAddress($address);
		
		if($city != "")
		$user->setCity($city);
	
		if($state != "")
		$user->setState($state);
	
		if($country != "")
		$user->setCountry($country);
	
		if($permission != "")
		$user->setPermission($permission);
	
		if($defineView != "")
		$user->setDefineView($defineView);
	
		
		$user->setResetKey('Setting Hard Code');
		$user->setDisable(0);
		$user->setTempAllow(0);
		
		if($councils != "")
			$user->setCouncils($councils);
		
		if($business != "")
			$user->setBusiness($business);
		
		if($projects != "")
			$user->setProjects($projects);
		if($onlyDoorModuleUser != 0)
		$user->setOnlyDoorModuleUser($onlyDoorModuleUser);
		
		$user->setDoorModuleAccess($doorModuleAccess);
		$user->setDoorModuleUsertype($doorModuleUsertype);
		$user->setEnergyModuleAccess($energyModuleAccess);
		$user->setEnergyModuleUsertype($energyModuleUsertype);
		$user->setDeviceModuleAccess($deviceModuleAccess);
		$user->setDeviceModuleUsertype($deviceModuleUsertype);
		$user->setWaterModuleAccess($waterModuleAccess);
		$user->setWaterModuleUsertype($waterModuleUsertype);
		$user->setCapacityModuleAccess($capacityModuleAccess);
		$user->setCapacityModuleUsertype($capacityModuleUsertype);
		$user->setIrrigationModuleAccess($irrigationModuleAccess);
		$user->setIrrigationModuleUsertype($irrigationModuleUsertype);
		$user->setGenericModuleAccess($genericModuleAccess);
		$user->setGenericModuleUsertype($genericModuleUsertype);
		
		

		$em = $this->getDoctrine()->getManager();
		$em->persist($user);
		$em->flush();
		$userId = $user->getId();
		
		if( $userId > 0)
		{
			return new JsonResponse(array('status' => 'SUCCESS','message' => 'User has been successfully created!!','id' => $userId));
		}
		else{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in registering user account!!'));
		} 
		
	}
	
	/**
     * Update a User
     *                                                                                 
	 * @Route("/updateuser", name="user_updateuser")
	 */
	public function updateUserApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$userId = $data->id;
		$firstName = $data->firstName;
		$lastName = $data->lastName;
		$email = $data->email;
		$pwd = $data->password;		
		$phone = $data->mobile;	
		$address = $data->address;
		$city = $data->city;
		$state = $data->state;		
		$country = $data->country;	
		$permission = $data->permission;
		$defineView = $data->defineView;
		$councils = $data->councils;
		$business = $data->business;
		$projects = $data->projects;
		
		$doorModuleAccess = $data->doorModuleAccess == true?1:0;
		$energyModuleAccess = $data->energyModuleAccess == true?1:0;
		$deviceModuleAccess = $data->deviceModuleAccess == true?1:0;
		$waterModuleAccess = $data->waterModuleAccess == true?1:0;
		$capacityModuleAccess = $data->capacityModuleAccess == true?1:0;
		$irrigationModuleAccess = $data->irrigationModuleAccess == true?1:0;
		$genericModuleAccess = $data->genericModuleAccess == true?1:0;
		$doorModuleUsertype = $data->doorModuleUsertype == true?1:2;
		$energyModuleUsertype = $data->energyModuleUsertype == true?1:2;
		$deviceModuleUsertype = $data->deviceModuleUsertype == true?1:2;
		$waterModuleUsertype = $data->waterModuleUsertype == true?1:2;
		$capacityModuleUsertype = $data->capacityModuleUsertype == true?1:2;
		$irrigationModuleUsertype = $data->irrigationModuleUsertype == true?1:2;
		$genericModuleUsertype = $data->genericModuleUsertype == true?1:2;
		
		$user = $em 
			->getRepository('AppBundle:Users')
			->findOneBy(array('id' => $userId));
			
		if($user !=null)
		{
		
			if($firstName != "")
			{
				$user->setFirstName($firstName);
			}
			if($lastName != "")
			{
				$user->setLastName($lastName);
			}
			if($email != "")
			{
				$user->setEmail($email);
			}
			
			if($pwd != "")
			{
				$user->setPwd($pwd);
			}
			if($phone != "")
			{
				$user->setPhone($phone);
			}
			if($address != "")
			{
				$user->setAddress($address);
			}
			if($city != "")
			{
				$user->setCity($city);
			}
			if($state != "")
			{
				$user->setState($state);
			}
			if($country != "")
			{
				$user->setCountry($country);
			}
			if($permission != "")
			{
				$user->setPermission($permission);
			}
			if($defineView){
			$user->setDefineView($defineView);
			}
			
			if($councils != "")
			$user->setCouncils($councils);
		
		if($business != "")
			$user->setBusiness($business);
		
		if($projects != "")
			$user->setProjects($projects);
		
		
		$user->setDoorModuleAccess($doorModuleAccess);
		$user->setDoorModuleUsertype($doorModuleUsertype);
		$user->setEnergyModuleAccess($energyModuleAccess);
		$user->setEnergyModuleUsertype($energyModuleUsertype);
		$user->setDeviceModuleAccess($deviceModuleAccess);
		$user->setDeviceModuleUsertype($deviceModuleUsertype);
		$user->setWaterModuleAccess($waterModuleAccess);
		$user->setWaterModuleUsertype($waterModuleUsertype);
		$user->setCapacityModuleAccess($capacityModuleAccess);
		$user->setCapacityModuleUsertype($capacityModuleUsertype);
		$user->setIrrigationModuleAccess($irrigationModuleAccess);
		$user->setIrrigationModuleUsertype($irrigationModuleUsertype);
		$user->setGenericModuleAccess($genericModuleAccess);
		$user->setGenericModuleUsertype($genericModuleUsertype);
		
			$user->setUpdatedDt(new \DateTime());
			
			$em->persist($user);
			$em->flush();
			$userId = $user->getId();
			
			if( $userId != "")
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'User has been successfully updated!!'));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating User details!!'));
			}
		}
		else
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating User Detail No Record found with this Id'));
		}
		
	}
	/**
     * Reset Password API
     *                                                                                 
	 * @Route("/resetpasswordapi", name="user_resetpasswordapi")
	 */
	public function resetpasswordApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();

		$data = json_decode($request->getContent());
		
		$e_mail = $data->e_mail;		
		
		if($e_mail != "")
		{
			$random = random_int(100000, 999999);
			$em = $this->getDoctrine();
			
			//echo $id;
			$user= $em 
				->getRepository('AppBundle\Entity\Users')
				->findBy(array('email' => $e_mail))[0];

			if (!$user) {
				return new JsonResponse(array('status' => 'FAILED','message' => 'No email found with entered email id!!'));
			}

			$user->setResetKey($random);
			$em->getManager()->flush($user);
			$userId = $user->getId();
			$key = $user->getResetKey();
			
			//Sending email for resetting password
				try
					{
					$message = \Swift_Message::newInstance()
					->setSubject('Gesinen reset password')
					->setFrom('no-reply@gesinen.com')
					->setTo($e_mail)
					->setBody(
						$this->renderView(
							// app/Resources/views/Emails/resetpassword.html.twig
							'Emails/resetpassword.html.twig',
							array('name' => '','phone' => '','email' => $e_mail,'id'=>$userId,'key'=>$key)
						),
						'text/html'
					);
				 
					$this->get('mailer')->send($message);
				
				}	
				catch (Exception $e) {
				
					echo 'Caught exception: ',  $e->getMessage(), "\n";
				}
	
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'Email has been sent to your registered email id!!'));
		}
		else{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Please enter correct email id!!'));
		}
	}
	
	/**
     * Contact Request API
     *                                                                                 
	 * @Route("/contactrequestapi", name="user_contactrequestapi")
	 */
	public function contactrequestApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();

		$data = json_decode($request->getContent());
		
		$e_mail = $data->e_mail;		
		$phone = $data->phone;	
		$first_name = $data->first_name;	
		$last_name = $data->last_name;	
		$message = $data->message;	
		
		if($e_mail != "")
		{
			
			//Sending email for contact request
				try
					{
					$message = \Swift_Message::newInstance()
					->setSubject('Gesinen contact request')
					->setFrom($e_mail)
					->setTo('manojsinghgnitgnit@outlook.com')
					->setBody(
						$this->renderView(
							// app/Resources/views/Emails/resetpassword.html.twig
							'Emails/contactusmail.html.twig',
							array('first_name' => $first_name,'last_name' => $last_name,'phone' => $phone,'e_mail' => $e_mail,'message'=>$message)
						),
						'text/html'
					);
				 
					$this->get('mailer')->send($message);
				
				}	
				catch (Exception $e) {
				
					echo 'Caught exception: ',  $e->getMessage(), "\n";
				}
	
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'Your contact request has been successfully sent you admin. You will get response in next 24 hours!!'));
		}
		else{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Please enter correct email id!!'));
		}
	}
}