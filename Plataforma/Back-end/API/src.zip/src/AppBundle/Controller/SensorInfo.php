<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Validator\Constraints\DateTime;

/**
 * SensorInfo
 *
 * @ORM\Table(name="sensor_info")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\SensorTypeIboxPayloadRepository")
 * @UniqueEntity(
 *     fields={"id"},
 *     message="The user id is already used."
 * )
 */
class SensorInfo
{

//	const ESTADO_INICIAL = 1;
//	const ESTADO_ALARMAS_INICIAL = 1;

    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

	/**
     * @var string
     *
     * @ORM\Column(name="sensor_unique_id", type="string", length=64, nullable=true)
     */
    private $sensorUniqueId;
	
	/**
     * @var string
     *
     * @ORM\Column(name="gateways_id", type="string", length=64, nullable=true)
     */
    private $gatewaysId;
	
	/**
     * @var int
     *
     * @ORM\Column(name="user_id", type="integer", nullable=true)
     */
    private $userId;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=64, nullable=true)
     */
    private $name;
	
	/**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=255, nullable=true)
     */
    private $description;
	
	/**
     * @var string
     *
     * @ORM\Column(name="provider", type="string", length=64, nullable=true)
     */
    private $provider;
	
	/**
     * @var string
     *
     * @ORM\Column(name="type_sensor", type="string", length=64, nullable=true)
     */
    private $typeSensor;
	/**
     * @var datetime
     *
     * @ORM\Column(name="installation_date", type="datetime",nullable=true)
     */
    private $installationDate;
	/**
     * @var string
     *
     * @ORM\Column(name="application_name", type="string", length=64, nullable=true)
     */
    private $applicationName;
	/**
     * @var float
     *
     * @ORM\Column(name="latitude", type="float", nullable=true)
     */
    private $latitude;
	/**
     * @var string
     *
     * @ORM\Column(name="longitude", type="float", nullable=true)
     */
    private $longitude;
	/**
     * @var string
     *
     * @ORM\Column(name="device_EUI", type="string", length=64, nullable=true)
     */
    private $deviceEUI;
	/**
     * @var string
     *
     * @ORM\Column(name="app_EUI", type="string", length=64, nullable=true)
     */
    private $appEUI;
	/**
     * @var string
     *
     * @ORM\Column(name="app_KEY", type="string", length=64, nullable=true)
     */
    private $appKEY;
	
	
	/**
     * @var array
     *
     * @ORM\Column(name="input_component_names", type="array")
     */
    private $inputComponentNames;
	
	/**
     * @var array
     *
     * @ORM\Column(name="meter_component_names", type="array")
     */
    private $meterComponentNames;

   /**
     * @var datetime
     *
     * @ORM\Column(name="created_dt", type="datetime", nullable=true)
     */
    private $createdDt;
	/**
     * @var datetime
     *
     * @ORM\Column(name="updated_dt", type="datetime", nullable=true)
     */
    private $updatedDt;
	
	/**
     * @var \AppBundle\Entity\SensorPing
     */
    private $sensorPing;
	
	/**
     * Constructor
     */
    public function __construct()
    {		
		$this->createdDt = new \DateTime();
		$this->updatedDt = new \DateTime();	
    }

	/**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }
	

    /**
     * Set sensorUniqueId
     *
     * @param string $sensorUniqueId
     *
     * @return SensorInfo
     */
    public function setSensorUniqueId($sensorUniqueId)
    {
        $this->sensorUniqueId = $sensorUniqueId;

        return $this;
    }

    /**
     * Get sensorUniqueId
     *
     * @return string
     */
    public function getSensorUniqueId()
    {
        return $this->sensorUniqueId;
    }
	
	/**
     * Set gatewaysId
     *
     * @param string $gatewaysId
     *
     * @return SensorInfo
     */
    public function setGatewaysId($gatewaysId)
    {
        $this->gatewaysId = $gatewaysId;

        return $this;
    }

    /**
     * Get gatewaysId
     *
     * @return string
     */
    public function getGatewaysId()
    {
        return $this->gatewaysId;
    }
	
	/**
     * Set userId
     *
     * @param integer $userId
     *
     * @return SensorInfo
     */
    public function setUserId($userId)
    {
        $this->userId = $userId;

        return $this;
    }

    /**
     * Get userId
     *
     * @return integer
     */
    public function getUserId()
    {
        return $this->userId;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return SensorInfo
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return SensorInfo
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set provider
     *
     * @param string $provider
     *
     * @return SensorInfo
     */
    public function setProvider($provider)
    {
        $this->provider = $provider;

        return $this;
    }

    /**
     * Get provider
     *
     * @return string
     */
    public function getProvider()
    {
        return $this->provider;
    }

    /**
     * Set typeSensor
     *
     * @param string $typeSensor
     *
     * @return SensorInfo
     */
    public function setTypeSensor($typeSensor)
    {
        $this->typeSensor = $typeSensor;

        return $this;
    }

    /**
     * Get typeSensor
     *
     * @return string
     */
    public function getTypeSensor()
    {
        return $this->typeSensor;
    }

    /**
     * Set installationDate
     *
     * @param \DateTime $installationDate
     *
     * @return SensorInfo
     */
    public function setInstallationDate($installationDate)
    {
        $this->installationDate = $installationDate;

        return $this;
    }

    /**
     * Get installationDate
     *
     * @return \DateTime
     */
    public function getInstallationDate()
    {
        return $this->installationDate;
    }
	
	 /**
     * Set applicationName
     *
     * @param string $applicationName
     *
     * @return SensorInfo
     */
    public function setApplicationName($applicationName)
    {
        $this->applicationName = $applicationName;

        return $this;
    }

    /**
     * Get applicationName
     *
     * @return string
     */
    public function getApplicationName()
    {
        return $this->applicationName;
    }

    /**
     * Set latitude
     *
     * @param float $latitude
     *
     * @return SensorInfo
     */
    public function setLatitude($latitude)
    {
        $this->latitude = $latitude;

        return $this;
    }

    /**
     * Get latitude
     *
     * @return float
     */
    public function getLatitude()
    {
        return $this->latitude;
    }

    /**
     * Set longitude
     *
     * @param float $longitude
     *
     * @return SensorInfo
     */
    public function setLongitude($longitude)
    {
        $this->longitude = $longitude;

        return $this;
    }

    /**
     * Get longitude
     *
     * @return float
     */
    public function getLongitude()
    {
        return $this->longitude;
    }

    /**
     * Set deviceEUI
     *
     * @param string $deviceEUI
     *
     * @return SensorInfo
     */
    public function setDeviceEUI($deviceEUI)
    {
        $this->deviceEUI = $deviceEUI;

        return $this;
    }

    /**
     * Get deviceEUI
     *
     * @return string
     */
    public function getDeviceEUI()
    {
        return $this->deviceEUI;
    }

    /**
     * Set appEUI
     *
     * @param string $appEUI
     *
     * @return SensorInfo
     */
    public function setAppEUI($appEUI)
    {
        $this->appEUI = $appEUI;

        return $this;
    }

    /**
     * Get appEUI
     *
     * @return string
     */
    public function getAppEUI()
    {
        return $this->appEUI;
    }

    /**
     * Set appKEY
     *
     * @param string $appKEY
     *
     * @return SensorInfo
     */
    public function setAppKEY($appKEY)
    {
        $this->appKEY = $appKEY;

        return $this;
    }

    /**
     * Get appKEY
     *
     * @return string
     */
    public function getAppKEY()
    {
        return $this->appKEY;
    }
	
	/**
     * Set inputComponentNames
     *
     * @param array $inputComponentNames
     *
     * @return SensorInfo
     */
    public function setInputComponentNames($inputComponentNames)
    {
        $this->inputComponentNames = $inputComponentNames;

        return $this;
    }

    /**
     * Get inputComponentNames
     *
     * @return array
     */
    public function getInputComponentNames()
    {
        return $this->inputComponentNames;
    }
	
	/**
     * Set meterComponentNames
     *
     * @param array $meterComponentNames
     *
     * @return SensorInfo
     */
    public function setMeterComponentNames($meterComponentNames)
    {
        $this->meterComponentNames = $meterComponentNames;

        return $this;
    }

    /**
     * Get meterComponentNames
     *
     * @return array
     */
    public function getMeterComponentNames()
    {
        return $this->meterComponentNames;
    }

    /**
     * Set createdDt
     *
     * @param \DateTime $createdDt
     *
     * @return SensorInfo
     */
    public function setCreatedDt($createdDt)
    {
        $this->createdDt = $createdDt;

        return $this;
    }

    /**
     * Get createdDt
     *
     * @return \DateTime
     */
    public function getCreatedDt()
    {
        return $this->createdDt;
    }

    /**
     * Set updatedDt
     *
     * @param \DateTime $updatedDt
     *
     * @return SensorInfo
     */
    public function setUpdatedDt($updatedDt)
    {
        $this->updatedDt = $updatedDt;

        return $this;
    }

    /**
     * Get updatedDt
     *
     * @return \DateTime
     */
    public function getUpdatedDt()
    {
        return $this->updatedDt;
    }
	
	public function setSensorPing(\AppBundle\Entity\SensorPing $sensorPing) {
        $this->sensorPing = $sensorPing;
    }
	
    public function getSensorPing() {
        return $this->sensorPing;
    }
}
