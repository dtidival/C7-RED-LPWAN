<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Validator\Constraints\DateTime;

/**
 * SensorTypePayload
 *
 * @ORM\Table(name="sensor_type_payload")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\UsersRepository")
 * @UniqueEntity(
 *     fields={"email"},
 *     message="The user id is already used."
 * )
 */
class SensorTypePayload
{

//	const ESTADO_INICIAL = 1;
//	const ESTADO_ALARMAS_INICIAL = 1;

    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;
	
	/**
     * @var integer
     *
     * @ORM\Column(name="sensor_type_id", type="integer")
     */
    private $sensorTypeId;
	
	/**
     * @var string
     *
     * @ORM\Column(name="type_of_data", type="string")
     */
    private $typeOfData;
	
	/**
     * @var integer
     *
     * @ORM\Column(name="reverse", type="integer", options={"default":0})
     */
    private $reverse;
	
	/**
     * @var string
     *
     * @ORM\Column(name="payload_unique_id", type="string", length=64, nullable=true)
     */
    private $payloadUniqueId;

	/**
     * @var string
     *
     * @ORM\Column(name="var_name", type="string", length=64, nullable=true)
     */
    private $varname;
	/**
     * @var string
     *
     * @ORM\Column(name="start", type="string", length=32, nullable=true)
     */
    private $start;
    /**
     * @var string
     *
     * @ORM\Column(name="length", type="string", length=32, nullable=true)
     */
    private $length;
	
	/**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=255, nullable=true)
     */
    private $description;

	/**
     * @var integer
     *
     * @ORM\Column(name="decimal_number", type="integer")
     */
    private $decimalNumber;
	
	/**
     * @var integer
     *
     * @ORM\Column(name="bit_number", type="integer")
     */
    private $bitNumber;

	/**
     * @var integer
     *
     * @ORM\Column(name="any", type="integer", options={"default":0})
     */
    private $any;
	
	/**
     * @var string
     *
     * @ORM\Column(name="expresion", type="string", length=64, nullable=true)
     */
    private $expresion;
	
	/**
     * @var string
     *
     * @ORM\Column(name="component_override", type="string", length=64, nullable=true)
     */
    private $componentOverride;
	
	/**
     * @var integer
     *
     * @ORM\Column(name="show_filter", type="integer", options={"default":0})
     */
    private $showFilter;
	
	/**
     * @var string
     *
     * @ORM\Column(name="sensor_to_filter", type="string", length=64, nullable=true)
     */
    private $sensorToFilter;
	
	/**
     * @var integer
     *
     * @ORM\Column(name="true_value_filter", type="integer")
     */
    private $trueValueFilter;
	
	/**
     * @var string
     *
     * @ORM\Column(name="sensor_name_filter", type="string", length=64, nullable=true)
     */
    private $sensorNameFilter;
	
	/**
     * @var string
     *
     * @ORM\Column(name="data_type_filter", type="string", length=64, nullable=true)
     */
    private $dataTypeFilter;
	
	/**
     * @var string
     *
     * @ORM\Column(name="byte_offset_filter", type="string", length=64, nullable=true)
     */
    private $byteOffsetFilter;
	
	
	/**
     * @var integer
     *
     * @ORM\Column(name="length_filter", type="integer")
     */
    private $lengthFilter;
	
	/**
     * @var integer
     *
     * @ORM\Column(name="decimals_filter", type="integer")
     */
    private $decimalsFilter;
	
	/**
     * @var integer
     *
     * @ORM\Column(name="bit_offset_filter", type="integer")
     */
    private $bitOffsetFilter;
	
	/**
     * @var integer
     *
     * @ORM\Column(name="reversed_filter", type="integer")
     */
    private $reversedFilter;
	
	
	/**
     * @var string
     *
     * @ORM\Column(name="expresion_filter", type="string", length=64, nullable=true)
     */
    private $expresionFilter;
	
	
	/**
     * @var string
     *
     * @ORM\Column(name="component_override_filter", type="string", length=64, nullable=true)
     */
    private $componentOverrideFilter;
	
   /**
     * @var datetime
     *
     * @ORM\Column(name="created_dt", type="datetime", nullable=true)
     */
	
    private $createdDt;
	/**
     * @var datetime
     *
     * @ORM\Column(name="updated_dt", type="datetime", nullable=true)
     */
    private $updatedDt;
	/**
     * Constructor
     */
    public function __construct()
    {		
		$this->createdDt = new \DateTime();
		$this->updatedDt = new \DateTime();	
		$this->reverse = 0;
		$this->any = 0;
		$this->showFilter = 0;
    }

	/**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }
	
	/**
     * Set typeOfData
     *
     * @param string $typeOfData
     *
     * @return SensorTypePayload
     */
    public function setTypeOfData($typeOfData)
    {
        $this->typeOfData = $typeOfData;

        return $this;
    }

    /**
     * Get typeOfData
     *
     * @return string
     */
    public function getTypeOfData()
    {
        return $this->typeOfData;
    }
	
	/**
     * Set reverse
     *
     * @param integer $reverse
     *
     * @return SensorTypePayload
     */
    public function setReverse($reverse)
    {
        $this->reverse = $reverse;

        return $this;
    }

    /**
     * Get reverse
     *
     * @return integer
     */
    public function getReverse()
    {
        return $this->reverse;
    }
	
	/**
     * Set reverse
     *
     * @param integer $any
     *
     * @return SensorTypePayload
     */
    public function setAny($any)
    {
        $this->any = $any;

        return $this;
    }

    /**
     * Get any
     *
     * @return integer
     */
    public function getAny()
    {
        return $this->any;
    }
    /**
     * Set sensorTypeId
     *
     * @param integer $sensorTypeId
     *
     * @return SensorTypePayload
     */
    public function setSensorTypeId($sensorTypeId)
    {
        $this->sensorTypeId = $sensorTypeId;

        return $this;
    }

    /**
     * Get sensorTypeId
     *
     * @return integer
     */
    public function getSensorTypeId()
    {
        return $this->sensorTypeId;
    }

    /**
     * Set payloadUniqueId
     *
     * @param string $payloadUniqueId
     *
     * @return SensorTypePayload
     */
    public function setPayloadUniqueId($payloadUniqueId)
    {
        $this->payloadUniqueId = $payloadUniqueId;

        return $this;
    }

    /**
     * Get payloadUniqueId
     *
     * @return string
     */
    public function getPayloadUniqueId()
    {
        return $this->payloadUniqueId;
    }

    /**
     * Set varname
     *
     * @param string $varname
     *
     * @return SensorTypePayload
     */
    public function setVarname($varname)
    {
        $this->varname = $varname;

        return $this;
    }

    /**
     * Get varname
     *
     * @return string
     */
    public function getVarname()
    {
        return $this->varname;
    }

    /**
     * Set start
     *
     * @param string $start
     *
     * @return SensorTypePayload
     */
    public function setStart($start)
    {
        $this->start = $start;

        return $this;
    }

    /**
     * Get start
     *
     * @return string
     */
    public function getStart()
    {
        return $this->start;
    }

    /**
     * Set length
     *
     * @param string $length
     *
     * @return SensorTypePayload
     */
    public function setLength($length)
    {
        $this->length = $length;

        return $this;
    }

    /**
     * Get length
     *
     * @return string
     */
    public function getLength()
    {
        return $this->length;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return SensorTypePayload
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }
	
	
	/**
     * Set decimalNumber
     *
     * @param integer $decimalNumber
     *
     * @return SensorTypePayload
     */
    public function setDecimalNumber($decimalNumber)
    {
        $this->decimalNumber = $decimalNumber;

        return $this;
    }

    /**
     * Get decimalNumber
     *
     * @return integer
     */
    public function getDecimalNumber()
    {
        return $this->decimalNumber;
    }
	
	/**
     * Set bitNumber
     *
     * @param integer $bitNumber
     *
     * @return SensorTypePayload
     */
    public function setBitNumber($bitNumber)
    {
        $this->bitNumber = $bitNumber;

        return $this;
    }

    /**
     * Get bitNumber
     *
     * @return integer
     */
    public function getBitNumber()
    {
        return $this->bitNumber;
    }
	
	/**
     * Set expresion
     *
     * @param string $expresion
     *
     * @return SensorTypePayload
     */
    public function setExpresion($expresion)
    {
        $this->expresion = $expresion;

        return $this;
    }

    /**
     * Get expresion
     *
     * @return string
     */
    public function getExpresion()
    {
        return $this->expresion;
    }
	
	/**
     * Set componentOverride
     *
     * @param string $componentOverride
     *
     * @return SensorTypePayload
     */
    public function setComponentOverride($componentOverride)
    {
        $this->componentOverride = $componentOverride;

        return $this;
    }

    /**
     * Get componentOverride
     *
     * @return string
     */
    public function getComponentOverride()
    {
        return $this->componentOverride;
    }
	
	/**
     * Set showFilter
     *
     * @param integer $showFilter
     *
     * @return SensorTypePayload
     */
    public function setShowFilter($showFilter)
    {
        $this->showFilter = $showFilter;

        return $this;
    }

    /**
     * Get showFilter
     *
     * @return integer
     */
    public function getShowFilter()
    {
        return $this->showFilter;
    }
	
	/**
     * Set sensorToFilter
     *
     * @param string $sensorToFilter
     *
     * @return SensorTypePayload
     */
    public function setSensorToFilter($sensorToFilter)
    {
        $this->sensorToFilter = $sensorToFilter;

        return $this;
    }

    /**
     * Get sensorToFilter
     *
     * @return string
     */
    public function getSensorToFilter()
    {
        return $this->sensorToFilter;
    }
	
	/**
     * Set sensorNameFilter
     *
     * @param string $sensorNameFilter
     *
     * @return SensorTypePayload
     */
    public function setSensorNameFilter($sensorNameFilter)
    {
        $this->sensorNameFilter = $sensorNameFilter;

        return $this;
    }

    /**
     * Get sensorNameFilter
     *
     * @return string
     */
    public function getSensorNameFilter()
    {
        return $this->sensorNameFilter;
    }
	
	/**
     * Set trueValueFilter
     *
     * @param integer $trueValueFilter
     *
     * @return SensorTypePayload
     */
    public function setTrueValueFilter($trueValueFilter)
    {
        $this->trueValueFilter = $trueValueFilter;

        return $this;
    }

    /**
     * Get trueValueFilter
     *
     * @return integer
     */
    public function getTrueValueFilter()
    {
        return $this->trueValueFilter;
    }
	
	/**
     * Set lengthFilter
     *
     * @param integer $lengthFilter
     *
     * @return SensorTypePayload
     */
    public function setLengthFilter($lengthFilter)
    {
        $this->lengthFilter = $lengthFilter;

        return $this;
    }

    /**
     * Get lengthFilter
     *
     * @return integer
     */
    public function getLengthFilter()
    {
        return $this->lengthFilter;
    }
	
	/**
     * Set decimalsFilter
     *
     * @param integer $decimalsFilter
     *
     * @return SensorTypePayload
     */
    public function setDecimalsFilter($decimalsFilter)
    {
        $this->decimalsFilter = $decimalsFilter;

        return $this;
    }

    /**
     * Get decimalsFilter
     *
     * @return integer
     */
    public function getDecimalsFilter()
    {
        return $this->decimalsFilter;
    }
	
	/**
     * Set bitOffsetFilter
     *
     * @param integer $bitOffsetFilter
     *
     * @return SensorTypePayload
     */
    public function setBitOffsetFilter($bitOffsetFilter)
    {
        $this->bitOffsetFilter = $bitOffsetFilter;

        return $this;
    }

    /**
     * Get bitOffsetFilter
     *
     * @return integer
     */
    public function getBitOffsetFilter()
    {
        return $this->bitOffsetFilter;
    }
	
	/**
     * Set reversedFilter
     *
     * @param integer $reversedFilter
     *
     * @return SensorTypePayload
     */
    public function setReversedFilter($reversedFilter)
    {
        $this->reversedFilter = $reversedFilter;

        return $this;
    }

    /**
     * Get reversedFilter
     *
     * @return integer
     */
    public function getReversedFilter()
    {
        return $this->reversedFilter;
    }

	/**
     * Set dataTypeFilter
     *
     * @param string $dataTypeFilter
     *
     * @return SensorTypePayload
     */
    public function setDataTypeFilter($dataTypeFilter)
    {
        $this->dataTypeFilter = $dataTypeFilter;

        return $this;
    }

    /**
     * Get dataTypeFilter
     *
     * @return string
     */
    public function getDataTypeFilter()
    {
        return $this->dataTypeFilter;
    }
	
	
	/**
     * Set byteOffsetFilter
     *
     * @param string $byteOffsetFilter
     *
     * @return SensorTypePayload
     */
    public function setByteOffsetFilter($byteOffsetFilter)
    {
        $this->byteOffsetFilter = $byteOffsetFilter;

        return $this;
    }

    /**
     * Get byteOffsetFilter
     *
     * @return string
     */
    public function getByteOffsetFilter()
    {
        return $this->byteOffsetFilter;
    }
	
	
	/**
     * Set expresionFilter
     *
     * @param string $expresionFilter
     *
     * @return SensorTypePayload
     */
    public function setExpresionFilter($expresionFilter)
    {
        $this->expresionFilter = $expresionFilter;

        return $this;
    }

    /**
     * Get expresionFilter
     *
     * @return string
     */
    public function getExpresionFilter()
    {
        return $this->expresionFilter;
    }
	
	/**
     * Set componentOverrideFilter
     *
     * @param string $componentOverrideFilter
     *
     * @return SensorTypePayload
     */
    public function setComponentOverrideFilter($componentOverrideFilter)
    {
        $this->componentOverrideFilter = $componentOverrideFilter;

        return $this;
    }

    /**
     * Get componentOverrideFilter
     *
     * @return string
     */
    public function getComponentOverrideFilter()
    {
        return $this->componentOverrideFilter;
    }
	

    /**
     * Set createdDt
     *
     * @param \DateTime $createdDt
     *
     * @return SensorTypePayload
     */
    public function setCreatedDt($createdDt)
    {
        $this->createdDt = $createdDt;

        return $this;
    }

    /**
     * Get createdDt
     *
     * @return \DateTime
     */
    public function getCreatedDt()
    {
        return $this->createdDt;
    }

    /**
     * Set updatedDt
     *
     * @param \DateTime $updatedDt
     *
     * @return SensorTypePayload
     */
    public function setUpdatedDt($updatedDt)
    {
        $this->updatedDt = $updatedDt;

        return $this;
    }

    /**
     * Get updatedDt
     *
     * @return \DateTime
     */
    public function getUpdatedDt()
    {
        return $this->updatedDt;
    }
}
