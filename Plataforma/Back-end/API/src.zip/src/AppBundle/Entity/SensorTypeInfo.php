<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Validator\Constraints\DateTime;

/**
 * SensorTypeInfo
 *
 * @ORM\Table(name="sensor_type_info")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\UsersRepository")
 * @UniqueEntity(
 *     fields={"email"},
 *     message="The user id is already used."
 * )
 */
class SensorTypeInfo
{

//	const ESTADO_INICIAL = 1;
//	const ESTADO_ALARMAS_INICIAL = 1;

    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

	/**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=64, nullable=true)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="sensor_type_unique_id", type="string", length=64, nullable=true)
     */
    private $sensorTypeUniqueId;
	
	/**
     * @var string
     *
     * @ORM\Column(name="gateways_id", type="string", length=64, nullable=true)
     */
    private $gatewaysId;
	
	/**
     * @var int
     *
     * @ORM\Column(name="user_id", type="integer", nullable=true)
     */
    private $userId;
	
	/**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=255, nullable=true)
     */
    private $description;
	/**
     * @var string
     *
     * @ORM\Column(name="supplier", type="string", length=64, nullable=true)
     */
    private $supplier;
	
	/**
     * @var string
     *
     * @ORM\Column(name="sensor_type", type="string", length=64, nullable=true)
     */
    private $sensorType;
	
	/**
     * @var string
     *
     * @ORM\Column(name="component_type", type="string", length=64, nullable=true)
     */
    private $componentType;
	
	/**
     * @var string
     *
     * @ORM\Column(name="application_name", type="string", length=64, nullable=true)
     */
    private $applicationName;
	

   /**
     * @var datetime
     *
     * @ORM\Column(name="created_dt", type="datetime", nullable=true)
     */
    private $createdDt;
	/**
     * @var datetime
     *
     * @ORM\Column(name="updated_dt", type="datetime", nullable=true)
     */
    private $updatedDt;
	/**
     * Constructor
     */
    public function __construct()
    {		
		$this->createdDt = new \DateTime();
		$this->updatedDt = new \DateTime();	
    }

	/**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return SensorTypeInfo
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set sensorTypeUniqueId
     *
     * @param string $sensorTypeUniqueId
     *
     * @return SensorTypeInfo
     */
    public function setSensorTypeUniqueId($sensorTypeUniqueId)
    {
        $this->sensorTypeUniqueId = $sensorTypeUniqueId;

        return $this;
    }

    /**
     * Get sensorTypeUniqueId
     *
     * @return string
     */
    public function getSensorTypeUniqueId()
    {
        return $this->sensorTypeUniqueId;
    }
	
	/**
     * Set gatewaysId
     *
     * @param string $gatewaysId
     *
     * @return Servers
     */
    public function setGatewaysId($gatewaysId)
    {
        $this->gatewaysId = $gatewaysId;

        return $this;
    }

    /**
     * Get gatewaysId
     *
     * @return string
     */
    public function getGatewaysId()
    {
        return $this->gatewaysId;
    }
	
	/**
     * Set userId
     *
     * @param integer $userId
     *
     * @return SensorTypeInfo
     */
    public function setUserId($userId)
    {
        $this->userId = $userId;

        return $this;
    }

    /**
     * Get userId
     *
     * @return integer
     */
    public function getUserId()
    {
        return $this->userId;
    }
	
    /**
     * Set description
     *
     * @param string $description
     *
     * @return SensorTypeInfo
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set supplier
     *
     * @param string $supplier
     *
     * @return SensorTypeInfo
     */
    public function setSupplier($supplier)
    {
        $this->supplier = $supplier;

        return $this;
    }

    /**
     * Get supplier
     *
     * @return string
     */
    public function getSupplier()
    {
        return $this->supplier;
    }

    /**
     * Set createdDt
     *
     * @param \DateTime $createdDt
     *
     * @return SensorTypeInfo
     */
    public function setCreatedDt($createdDt)
    {
        $this->createdDt = $createdDt;

        return $this;
    }

    /**
     * Get createdDt
     *
     * @return \DateTime
     */
    public function getCreatedDt()
    {
        return $this->createdDt;
    }

    /**
     * Set updatedDt
     *
     * @param \DateTime $updatedDt
     *
     * @return SensorTypeInfo
     */
    public function setUpdatedDt($updatedDt)
    {
        $this->updatedDt = $updatedDt;

        return $this;
    }

    /**
     * Get updatedDt
     *
     * @return \DateTime
     */
    public function getUpdatedDt()
    {
        return $this->updatedDt;
    }

    /**
     * Set sensorType
     *
     * @param string $sensorType
     *
     * @return SensorTypeInfo
     */
    public function setSensorType($sensorType)
    {
        $this->sensorType = $sensorType;

        return $this;
    }

    /**
     * Get sensorType
     *
     * @return string
     */
    public function getSensorType()
    {
        return $this->sensorType;
    }

    /**
     * Set componentType
     *
     * @param string $componentType
     *
     * @return SensorTypeInfo
     */
    public function setComponentType($componentType)
    {
        $this->componentType = $componentType;

        return $this;
    }

    /**
     * Get componentType
     *
     * @return string
     */
    public function getComponentType()
    {
        return $this->componentType;
    }

    /**
     * Set applicationName
     *
     * @param string $applicationName
     *
     * @return SensorTypeInfo
     */
    public function setApplicationName($applicationName)
    {
        $this->applicationName = $applicationName;

        return $this;
    }

    /**
     * Get applicationName
     *
     * @return string
     */
    public function getApplicationName()
    {
        return $this->applicationName;
    }
}
