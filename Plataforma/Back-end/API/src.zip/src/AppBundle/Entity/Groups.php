<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Validator\Constraints\DateTime;

/**
 * Groups
 *
 * @ORM\Table(name="groups")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\GroupRepository")
 * @UniqueEntity(
 *     fields={"id"},
 *     message="The user id is already used."
 * )
 */
class Groups
{

//	const ESTADO_INICIAL = 1;
//	const ESTADO_ALARMAS_INICIAL = 1;

    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

	/**
     * @var string
     *
     * @ORM\Column(name="group_name", type="string", length=64, nullable=true)
     */
    private $groupName;

    /**
     * @var string
     *
     * @ORM\Column(name="group_type", type="string", length=64, nullable=true)
     */
    private $groupType;
	
	/**
     * @var string
     *
     * @ORM\Column(name="parent_id", type="string", length=64, nullable=true)
     */
    private $parentId;
	
	 /**
     * @var int
     *
     * @ORM\Column(name="level", type="integer", nullable=true)
     */
    private $level;
	
	/**
     * @var int
     *
     * @ORM\Column(name="user_id", type="integer", nullable=true)
     */
    private $userId;
	
	/**
     * @var int
     *
     * @ORM\Column(name="server_id", type="string", length=255)
     */
    private $serverId;
	
	/**
     * @var int
     *
     * @ORM\Column(name="sensor_id", type="string", length=255)
     */
    private $sensorId;

   /**
     * @var datetime
     *
     * @ORM\Column(name="created_dt", type="datetime", nullable=true)
     */
    private $createdDt;
	/**
     * @var datetime
     *
     * @ORM\Column(name="updated_dt", type="datetime", nullable=true)
     */
    private $updatedDt;
	/**
     * Constructor
     */
    public function __construct()
    {		
		$this->createdDt = new \DateTime();
		$this->updatedDt = new \DateTime();	
    }

	/**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set groupName
     *
     * @param string $groupName
     *
     * @return Groups
     */
    public function setGroupName($groupName)
    {
        $this->groupName = $groupName;

        return $this;
    }

    /**
     * Get groupName
     *
     * @return string
     */
    public function getGroupName()
    {
        return $this->groupName;
    }

    /**
     * Set groupType
     *
     * @param string $groupType
     *
     * @return Groups
     */
    public function setGroupType($groupType)
    {
        $this->groupType = $groupType;

        return $this;
    }

    /**
     * Get groupType
     *
     * @return string
     */
    public function getGroupType()
    {
        return $this->groupType;
    }

    /**
     * Set parentId
     *
     * @param string $parentId
     *
     * @return Groups
     */
    public function setParentId($parentId)
    {
        $this->parentId = $parentId;

        return $this;
    }
	
	  /**
     * Set level
     *
     * @param int $level
     * @return Groups
     */
    public function setLevel($level)
    {
        $this->level = $level;

        return $this;
    }

    /**
     * Get level
     *
     * @return string
     */
    public function getLevel()
    {
        return $this->level;
    }

	/**
     * Set userId
     *
     * @param int $userId
     * @return Groups
     */
    public function setUserId($userId)
    {
        $this->userId = $userId;

        return $this;
    }

    /**
     * Get userId
     *
     * @return string
     */
    public function getUserId()
    {
        return $this->userId;
    }
	
    /**
     * Get parentId
     *
     * @return string
     */
    public function getParentId()
    {
        return $this->parentId;
    }
	
	/**
     * Set serverId
     *
     * @param string $serverId
     *
     * @return Groups
     */
    public function setServerId($serverId)
    {
        $this->serverId = $serverId;

        return $this;
    }

    /**
     * Get serverId
     *
     * @return string
     */
    public function getServerId()
    {
        return $this->serverId;
    }
	
	/**
     * Set sensorId
     *
     * @param string $sensorId
     *
     * @return Groups
     */
    public function setSensorId($sensorId)
    {
        $this->sensorId = $sensorId;

        return $this;
    }

    /**
     * Get sensorId
     *
     * @return string
     */
    public function getSensorId()
    {
        return $this->sensorId;
    }

    /**
     * Set createdDt
     *
     * @param \DateTime $createdDt
     *
     * @return Groups
     */
    public function setCreatedDt($createdDt)
    {
        $this->createdDt = $createdDt;

        return $this;
    }

    /**
     * Get createdDt
     *
     * @return \DateTime
     */
    public function getCreatedDt()
    {
        return $this->createdDt;
    }

    /**
     * Set updatedDt
     *
     * @param \DateTime $updatedDt
     *
     * @return Groups
     */
    public function setUpdatedDt($updatedDt)
    {
        $this->updatedDt = $updatedDt;

        return $this;
    }

    /**
     * Get updatedDt
     *
     * @return \DateTime
     */
    public function getUpdatedDt()
    {
        return $this->updatedDt;
    }
}
