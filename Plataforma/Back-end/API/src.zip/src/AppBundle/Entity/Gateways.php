<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Validator\Constraints\DateTime;

/**
 * Gateways
 *
 * @ORM\Table(name="gateways")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\UsersRepository")
 * @UniqueEntity(
 *     fields={"email"},
 *     message="The user id is already used."
 * )
 */
class Gateways
{

//	const ESTADO_INICIAL = 1;
//	const ESTADO_ALARMAS_INICIAL = 1;

    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

	/**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=64, nullable=true)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=255)
     */
    private $description;
	
	/**
     * @var string
     *
     * @ORM\Column(name="application", type="string", length=64)
     */
    private $application;
	
	/**
     * @var string
     *
     * @ORM\Column(name="application_name", type="string", length=64)
     */
    private $applicationName;
	
	/**
     * @var string
     *
     * @ORM\Column(name="profileId", type="string", length=64)
     */
    private $profileId;

    /**
     * @var string
     *
     * @ORM\Column(name="mac", type="string", length=64)
     */
    private $mac;
	
	

    /**
     * @var float
     *
     * @ORM\Column(name="latitude", type="float")
     */
    private $latitude;
	
	/**
     * @var float
     *
     * @ORM\Column(name="longitude", type="float")
     */
    private $longitude;
	
	/**
     * @var string
     *
     * @ORM\Column(name="town", type="string", length=64, nullable=true)
     */
    private $town;
	
	/**
     * @var float
     *
     * @ORM\Column(name="radius", type="float")
     */
    private $radius;
	/**
     * @var int
     *
     * @ORM\Column(name="inharit_group", type="integer")
     */
    private $inharitGroup;

	/**
     * @var string
     *
     * @ORM\Column(name="server_id", type="string", length=255)
     */
    private $serverId;
	/**
     * @var string
     *
     * @ORM\Column(name="groups_id", type="string", length=255)
     */
    private $groupsId;
	/**
     * @var string
     *
     * @ORM\Column(name="sensors_id", type="string", length=600)
     */
    private $sensorsId;
	
	/**
     * @var string
     *
     * @ORM\Column(name="project_id", type="string", length=64)
     */
    private $projectId;
	
	/**
     * @var string
     *
     * @ORM\Column(name="project_name", type="string", length=255)
     */
    private $projectName;	
	
	/**
     * @var int
     *
     * @ORM\Column(name="user_id", type="integer")
     */
    private $userId;
	/**
     * @var int
     *
     * @ORM\Column(name="status", type="integer", options={"default":0})
     */
    private $status;
	
	
	
	/**
     * @var int
     *
     * @ORM\Column(name="disable", type="integer", options={"default":0})
     */
    private $disable;
	
	
	/**
     * @var datetime
     *
     * @ORM\Column(name="created_dt", type="datetime", nullable=true)
     */
    private $createdDt;
	/**
     * @var datetime
     *
     * @ORM\Column(name="updated_dt", type="datetime", nullable=true)
     */
    private $updatedDt;
	
	/**
     * @var \AppBundle\Entity\GatewayPing
     */
    private $gatewayPing;
	

    /**
     * Constructor
     */
    public function __construct()
    {		
		$this->createdDt = new \DateTime();
		$this->updatedDt = new \DateTime();
		$this->status = 0;
		$this->disable = 0;
		
    }

	/**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }
	

    /**
     * Set name
     *
     * @param string $name
     *
     * @return Gateways
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return Gateways
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set application
     *
     * @param string $application
     *
     * @return Gateways
     */
    public function setApplication($application)
    {
        $this->application = $application;

        return $this;
    }

    /**
     * Get application
     *
     * @return string
     */
    public function getApplication()
    {
        return $this->application;
    }
	
	/**
     * Set applicationName
     *
     * @param string $applicationName
     *
     * @return Gateways
     */
    public function setApplicationName($applicationName)
    {
        $this->applicationName = $applicationName;

        return $this;
    }

    /**
     * Get applicationName
     *
     * @return string
     */
    public function getApplicationName()
    {
        return $this->applicationName;
    }
	
	/**
     * Set profileId
     *
     * @param string $profileId
     *
     * @return Gateways
     */
    public function setProfileId($profileId)
    {
        $this->profileId = $profileId;

        return $this;
    }

    /**
     * Get profileId
     *
     * @return string
     */
    public function getProfileId()
    {
        return $this->profileId;
    }

    /**
     * Set mac
     *
     * @param string $mac
     *
     * @return Gateways
     */
    public function setMac($mac)
    {
        $this->mac = $mac;

        return $this;
    }

    /**
     * Get mac
     *
     * @return string
     */
    public function getMac()
    {
        return $this->mac;
    }

    /**
     * Set latitude
     *
     * @param float $latitude
     *
     * @return Gateways
     */
    public function setLatitude($latitude)
    {
        $this->latitude = $latitude;

        return $this;
    }

    /**
     * Get latitude
     *
     * @return float
     */
    public function getLatitude()
    {
        return $this->latitude;
    }

    /**
     * Set longitude
     *
     * @param float $longitude
     *
     * @return Gateways
     */
    public function setLongitude($longitude)
    {
        $this->longitude = $longitude;

        return $this;
    }

    /**
     * Get longitude
     *
     * @return float
     */
    public function getLongitude()
    {
        return $this->longitude;
    }

    /**
     * Set serverId
     *
     * @param string $serverId
     *
     * @return Gateways
     */
    public function setServerId($serverId)
    {
        $this->serverId = $serverId;

        return $this;
    }

    /**
     * Get serverId
     *
     * @return string
     */
    public function getServerId()
    {
        return $this->serverId;
    }

    /**
     * Set groupsId
     *
     * @param string $groupsId
     *
     * @return Gateways
     */
    public function setGroupsId($groupsId)
    {
        $this->groupsId = $groupsId;

        return $this;
    }

    /**
     * Get groupsId
     *
     * @return string
     */
    public function getGroupsId()
    {
        return $this->groupsId;
    }

    /**
     * Set sensorsId
     *
     * @param string $sensorsId
     *
     * @return Gateways
     */
    public function setSensorsId($sensorsId)
    {
        $this->sensorsId = $sensorsId;

        return $this;
    }

    /**
     * Get sensorsId
     *
     * @return string
     */
    public function getSensorsId()
    {
        return $this->sensorsId;
    }
	
	/**
     * Set projectId
     *
     * @param string $projectId
     *
     * @return Gateways
     */
    public function setProjectId($projectId)
    {
        $this->projectId = $projectId;

        return $this;
    }

    /**
     * Get projectId
     *
     * @return string
     */
    public function getProjectId()
    {
        return $this->projectId;
    }
	
	/**
     * Set projectName
     *
     * @param string $projectName
     *
     * @return Gateways
     */
    public function setProjectName($projectName)
    {
        $this->projectName = $projectName;

        return $this;
    }

    /**
     * Get projectName
     *
     * @return string
     */
    public function getProjectName()
    {
        return $this->projectName;
    }

    /**
     * Set status
     *
     * @param integer $status
     *
     * @return Gateways
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return integer
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set disable
     *
     * @param integer $disable
     *
     * @return Gateways
     */
    public function setDisable($disable)
    {
        $this->disable = $disable;

        return $this;
    }

    /**
     * Get disable
     *
     * @return integer
     */
    public function getDisable()
    {
        return $this->disable;
    }

    /**
     * Set createdDt
     *
     * @param \DateTime $createdDt
     *
     * @return Gateways
     */
    public function setCreatedDt($createdDt)
    {
        $this->createdDt = $createdDt;

        return $this;
    }

    /**
     * Get createdDt
     *
     * @return \DateTime
     */
    public function getCreatedDt()
    {
        return $this->createdDt;
    }

    /**
     * Set updatedDt
     *
     * @param \DateTime $updatedDt
     *
     * @return Gateways
     */
    public function setUpdatedDt($updatedDt)
    {
        $this->updatedDt = $updatedDt;

        return $this;
    }

    /**
     * Get updatedDt
     *
     * @return \DateTime
     */
    public function getUpdatedDt()
    {
        return $this->updatedDt;
    }

    /**
     * Set town
     *
     * @param string $town
     *
     * @return Gateways
     */
    public function setTown($town)
    {
        $this->town = $town;

        return $this;
    }

    /**
     * Get town
     *
     * @return string
     */
    public function getTown()
    {
        return $this->town;
    }

    /**
     * Set radius
     *
     * @param float $radius
     *
     * @return Gateways
     */
    public function setRadius($radius)
    {
        $this->radius = $radius;

        return $this;
    }

    /**
     * Get radius
     *
     * @return float
     */
    public function getRadius()
    {
        return $this->radius;
    }

    /**
     * Set inharitGroup
     *
     * @param integer $inharitGroup
     *
     * @return Gateways
     */
    public function setInharitGroup($inharitGroup)
    {
        $this->inharitGroup = $inharitGroup;

        return $this;
    }

    /**
     * Get inharitGroup
     *
     * @return integer
     */
    public function getInharitGroup()
    {
        return $this->inharitGroup;
    }
	
	/**
     * Set userId
     *
     * @param integer $userId
     *
     * @return Gateways
     */
    public function setUserId($userId)
    {
        $this->userId = $userId;

        return $this;
    }

    /**
     * Get userId
     *
     * @return integer
     */
    public function getUserId()
    {
        return $this->userId;
    }
	
	public function setGatewayPing(\AppBundle\Entity\GatewayPing $gatewayPing) {
        $this->gatewayPing = $gatewayPing;
    }

    public function getGatewayPing() {
        return $this->gatewayPing;
    }
	
}
