<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Validator\Constraints\DateTime;

/**
 * ServerMqqt
 *
 * @ORM\Table(name="server_mqtt")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\GroupRepository")
 * @UniqueEntity(
 *     fields={"id"},
 *     message="The user id is already used."
 * )
 */
class ServerMqqt
{

//	const ESTADO_INICIAL = 1;
//	const ESTADO_ALARMAS_INICIAL = 1;

    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

	/**
     * @var string
     *
     * @ORM\Column(name="profile_name", type="string", length=64, nullable=true)
     */
    private $profileName;

    /**
     * @var string
     *
     * @ORM\Column(name="broker_address", type="string", length=64, nullable=true)
     */
    private $brokerAddress;
	
	/**
     * @var string
     *
     * @ORM\Column(name="broker_port", type="string", length=64, nullable=true)
     */
    private $brokerPort;
	
	 /**
     * @var string
     *
     * @ORM\Column(name="topic", type="string", length=255, nullable=true)
     */
    private $topic;
	
	/**
     * @var int
     *
     * @ORM\Column(name="server_id", type="integer", nullable=true)
     */
    private $serverId;
	/**
     * @var int
     *
     * @ORM\Column(name="is_transparent_mode", type="integer")
     */
    private $isTransparentMode;


   /**
     * @var datetime
     *
     * @ORM\Column(name="created_dt", type="datetime", nullable=true)
     */
    private $createdDt;
	/**
     * @var datetime
     *
     * @ORM\Column(name="updated_dt", type="datetime", nullable=true)
     */
    private $updatedDt;
	/**
     * Constructor
     */
    public function __construct()
    {		
		$this->createdDt = new \DateTime();
		$this->updatedDt = new \DateTime();	
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set profileName
     *
     * @param string $profileName
     *
     * @return ServerMqqt
     */
    public function setProfileName($profileName)
    {
        $this->profileName = $profileName;

        return $this;
    }

    /**
     * Get profileName
     *
     * @return string
     */
    public function getProfileName()
    {
        return $this->profileName;
    }

    /**
     * Set brokerAddress
     *
     * @param string $brokerAddress
     *
     * @return ServerMqqt
     */
    public function setBrokerAddress($brokerAddress)
    {
        $this->brokerAddress = $brokerAddress;

        return $this;
    }

    /**
     * Get brokerAddress
     *
     * @return string
     */
    public function getBrokerAddress()
    {
        return $this->brokerAddress;
    }

    /**
     * Set brokerPort
     *
     * @param string $brokerPort
     *
     * @return ServerMqqt
     */
    public function setBrokerPort($brokerPort)
    {
        $this->brokerPort = $brokerPort;

        return $this;
    }

    /**
     * Get brokerPort
     *
     * @return string
     */
    public function getBrokerPort()
    {
        return $this->brokerPort;
    }

    /**
     * Set topic
     *
     * @param string $topic
     *
     * @return ServerMqqt
     */
    public function setTopic($topic)
    {
        $this->topic = $topic;

        return $this;
    }

    /**
     * Get topic
     *
     * @return string
     */
    public function getTopic()
    {
        return $this->topic;
    }

    /**
     * Set serverId
     *
     * @param integer $serverId
     *
     * @return ServerMqqt
     */
    public function setServerId($serverId)
    {
        $this->serverId = $serverId;

        return $this;
    }

    /**
     * Get serverId
     *
     * @return integer
     */
    public function getServerId()
    {
        return $this->serverId;
    }
	
	/**
     * Set isTransparentMode
     *
     * @param integer $isTransparentMode
     *
     * @return ServerMqqt
     */
    public function setIsTransparentMode($isTransparentMode)
    {
        $this->isTransparentMode = $isTransparentMode;
        return $this;
    }

    /**
     * Get isTransparentMode
     *
     * @return integer
     */
    public function getIsTransparentMode()
    {
        return $this->isTransparentMode;
    }


    /**
     * Set createdDt
     *
     * @param \DateTime $createdDt
     *
     * @return ServerMqqt
     */
    public function setCreatedDt($createdDt)
    {
        $this->createdDt = $createdDt;

        return $this;
    }

    /**
     * Get createdDt
     *
     * @return \DateTime
     */
    public function getCreatedDt()
    {
        return $this->createdDt;
    }

    /**
     * Set updatedDt
     *
     * @param \DateTime $updatedDt
     *
     * @return ServerMqqt
     */
    public function setUpdatedDt($updatedDt)
    {
        $this->updatedDt = $updatedDt;

        return $this;
    }

    /**
     * Get updatedDt
     *
     * @return \DateTime
     */
    public function getUpdatedDt()
    {
        return $this->updatedDt;
    }
}
