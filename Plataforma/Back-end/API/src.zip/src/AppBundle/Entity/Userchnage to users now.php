<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Validator\Constraints\DateTime;

/**
 * User
 *
 * @ORM\Table(name="users")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\UserRepository")
 * @UniqueEntity(
 *     fields={"email"},
 *     message="The user id is already used."
 * )
 */
class User
{

//	const ESTADO_INICIAL = 1;
//	const ESTADO_ALARMAS_INICIAL = 1;

	const ROOT_PERMISSION = 1;
    const ADMIN_PERMISSION = 2;
	const USER_PERMISSION = 3;
	
	const DOORMODULEUSERTYPE_ADMIN = 1;
    const DOORMODULEUSERTYPE_USER =  2;
	const ENERGYMODULEUSERTYPE_ADMIN = 1;
    const ENERGYMODULEUSERTYPE_USER = 2;
	const DEVICEMODULEUSERTYPE_ADMIN = 1;
    const DEVICEMODULEUSERTYPE_USER = 2;

    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

	/**
     * @var string
     *
     * @ORM\Column(name="email", type="string", length=64, nullable=true)
     */
    private $email;

    /**
     * @var string
     *
     * @ORM\Column(name="pwd", type="string", length=64)
     */
    private $pwd;
	
	/**
     * @var string
     *
     * @ORM\Column(name="user_name", type="string", length=64)
     */
    private $userName;

    /**
     * @var string
     *
     * @ORM\Column(name="first_name", type="string", length=64)
     */
    private $firstName;

    /**
     * @var string
     *
     * @ORM\Column(name="last_name", type="string", length=64)
     */
    private $lastName;
	
	/**
     * @var string
     *
     * @ORM\Column(name="location", type="string", length=200)
     */
    private $location;

	/**
     * @var int
     *
     * @ORM\Column(name="permission", type="integer", options={"default":0})
     */
    private $permission = self::USER_PERMISSION;
	/**
     * @var string
     *
     * @ORM\Column(name="define_view", type="string", length=64)
     */
    private $defineView;
	
	
	
	/**
     * @var int
     *
     * @ORM\Column(name="disable", type="integer", options={"default":0})
     */
    private $disable;
	
	/**
     * @var int
     *
     * @ORM\Column(name="temp_allow", type="integer", options={"default":0})
     */
    private $temp_allow;
	

	/**
     * @var datetime
     *
     * @ORM\Column(name="temp_allow_time", type="datetime", nullable=true)
     */
    private $temp_allow_time;
	
	/**
     * @var string
     *
     * @ORM\Column(name="phone", type="string", length=128, nullable=true)
     */
    private $phone;

	/**
     * @var datetime
     *
     * @ORM\Column(name="reg_date", type="datetime", nullable=true)
     */
    private $regDate;

	/**
     * @var datetime
     *
     * @ORM\Column(name="last_time", type="datetime", nullable=true)
     */
    private $lastTime;
	
	/**
     * @var string
     *
     * @ORM\Column(name="reset_key", type="string", length=64)
     */
    private $resetKey;
	
	/**
     * @var string
     *
     * @ORM\Column(name="address", type="string", length=255)
     */
    private $address;
	/**
     * @var string
     *
     * @ORM\Column(name="city", type="string", length=32)
     */
    private $city;
	/**
     * @var string
     *
     * @ORM\Column(name="state", type="string", length=32)
     */
    private $state;
	/**
     * @var string
     *
     * @ORM\Column(name="country", type="string", length=255)
     */
    private $country;
	
	/**
     * @var string
     *
     * @ORM\Column(name="profile_image_path", type="string", length=255)
     */
    private $profileImagePath;
	/**
     * @var string
     *
     * @ORM\Column(name="councils", type="string", length=65)
     */
    private $councils;
	/**
     * @var string
     *
     * @ORM\Column(name="business	", type="string", length=65)
     */
    private $business	;
	/**
     * @var string
     *
     * @ORM\Column(name="projects	", type="string", length=65)
     */
    private $projects	;
	
	/**
     * @var int
     *
     * @ORM\Column(name="door_module_access", type="integer", options={"default":0})
     */
    private $doorModuleAccess;
	
	/**
     * @var int
     *
     * @ORM\Column(name="door_module_usertype", type="integer", options={"default":0})
     */
    private $doorModuleUsertype = self::DOORMODULEUSERTYPE_USER;
	
	/**
     * @var int
     *
     * @ORM\Column(name="energy_module_access", type="integer", options={"default":0})
     */
    private $energyModuleAccess;
	
	/**
     * @var int
     *
     * @ORM\Column(name="energy_module_usertype", type="integer", options={"default":0})
     */
    private $energyModuleUsertype = self::ENERGYMODULEUSERTYPE_USER;
	
	
	/**
     * @var int
     *
     * @ORM\Column(name="device_module_access", type="integer", options={"default":0})
     */
    private $deviceModuleAccess;
	
	/**
     * @var int
     *
     * @ORM\Column(name="device_module_usertype", type="integer", options={"default":0})
     */
    private $deviceModuleUsertype = self::DEVICEMODULEUSERTYPE_USER;
	
	/**
     * @var datetime
     *
     * @ORM\Column(name="created_dt", type="datetime", nullable=true)
     */
    private $createdDt;
	/**
     * @var datetime
     *
     * @ORM\Column(name="updated_dt", type="datetime", nullable=true)
     */
    private $updatedDt;
	

    /**
     * Constructor
     */
    public function __construct()
    {
		$this->regDate = new \DateTime();
		$this->lastTime = new \DateTime();
		$this->temp_allow_time = new \DateTime();
		$this->createdDt = new \DateTime();
		$this->updatedDt = new \DateTime();
		$this->permission = 0;
		$this->disable = 0;
		$this->temp_allow = 0;
    }

	public function __toString(){
		return $this->email;
	}

	/**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set email
     *
     * @param string $email
     * @return User
     */
	public function setEmail($email)
	{
		$this->email = $email;

		return $this;
	}

    /**
     * Get userId
     *
     * @return string
     */
	public function getEmail()
	{
		return $this->email;
	}

    /**
     * Set password
     *
     * @param string $pwd
     * @return User
     */
	public function setPwd($pwd)
	{
		$this->pwd = $pwd;

		return $this;
	}

    /**
     * Get password
     *
     * @return string
     */
	public function getPwd()
	{
		return $this->pwd;
	}

	/**
     * Get first name
     *
     * @return string
     */
	public function getFirstName()
	{
		return $this->firstName;
	}

    /**
     * Set first name
     *
     * @param string $firstName
     * @return User
     */
	public function setFirstName($firstName)
	{
		$this->firstName = $firstName;

		return $this;
	}

	
		/**
     * Get reset key
     *
     * @return string
     */
	public function getResetKey()
	{
		return $this->resetKey;
	}

    /**
     * Set reset key
     *
     * @param string $resetKey
     * @return User
     */
	public function setResetKey($resetKey)
	{
		$this->resetKey = $resetKey;

		return $this;
	}

    /**
     * Get last name
     *
     * @return string
     */
	public function getLastName()
	{
		return $this->lastName;
	}

    /**
     * Set last name
     *
     * @param string $lastName
     * @return User
     */
	public function setLastName($lastName)
	{
		$this->lastName = $lastName;

		return $this;
	}
	
	 /**
     * Get location
     *
     * @return string
     */
	public function getLocation()
	{
		return $this->location;
	}

    /**
     * Set location
     *
     * @param string $location
     * @return User
     */
	public function setLocation($location)
	{
		$this->location = $location;

		return $this;
	}

    /**
     * Get permission
     *
     * @return int
     */
	public function getPermission()
	{
		return $this->permission;
	}

    /**
     * Set permission
     *
     * @param integer $permission
     * @return User
     */
	public function setPermission($permission)
	{
		$this->permission = $permission;

		return $this;
	}	
    /**
     * Get disable
     *
     * @return int
     */
	public function getDisable()
	{
		return $this->disable;
	}

    /**
     * Set disable
     *
     * @param integer $disable
     * @return User
     */
	public function setDisable($disable)
	{
		$this->disable = $disable;

		return $this;
	}

	/**
     * Get temp_allow
     *
     * @return int
     */
	public function getTemp_Allow()
	{
		return $this->temp_allow;
	}

    /**
     * Set temp_allow
     *
     * @param float $temp_allow
     * @return User
     */
	public function setTemp_Allow($temp_allow)
	{
		$this->temp_allow = $temp_allow;

		return $this;
	}	
	/**
     * Get temp_allow_time
     *
     * @return DateTime
     */
	public function getTemp_Allow_time()
	{
		return $this->temp_allow_time;
	}

	/**
     * Set temp_allow_time
     *
     * @param DateTime $temp_allow_time
     * @return User
     */
    public function setTemp_Allow_time($temp_allow_time)
    {
        $this->temp_allow_time = $temp_allow_time;

        return $this;
    }	
	
	/**
     * Get phone
     *
     * @return string
     */
	public function getPhone()
	{
		return $this->phone;
	}

    /**
     * Set phone
     *
     * @param float $phone
     * @return User
     */
	public function setPhone($phone)
	{
		$this->phone = $phone;

		return $this;
	}

    /**
     * Get regdate
     *
     * @return DateTime
     */
	public function getRegDate()
	{
		return $this->regDate;
	}

    /**
     * Set set regdate
     *
     * @param float $regDate
     * @return User
     */
	public function setRegDate($regDate)
	{
		$this->regDate = $regDate;

		return $this;
	}

    /**
     * Get lastTime
     *
     * @return DateTime
     */
	public function getLastTime()
	{
		return $this->lastTime;
	}

	/**
     * Set SunRiseOffset
     *
     * @param int $sunRiseOffset
     * @return User
     */
    public function setLastTime($lastTime)
    {
        $this->lastTime = $lastTime;

        return $this;
    }


    /**
     * Set userName
     *
     * @param string $userName
     *
     * @return User
     */
    public function setUserName($userName)
    {
        $this->userName = $userName;

        return $this;
    }

    /**
     * Get userName
     *
     * @return string
     */
    public function getUserName()
    {
        return $this->userName;
    }

    /**
     * Set address
     *
     * @param string $address
     *
     * @return User
     */
    public function setAddress($address)
    {
        $this->address = $address;

        return $this;
    }

    /**
     * Get address
     *
     * @return string
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * Set city
     *
     * @param string $city
     *
     * @return User
     */
    public function setCity($city)
    {
        $this->city = $city;

        return $this;
    }

    /**
     * Get city
     *
     * @return string
     */
    public function getCity()
    {
        return $this->city;
    }

    /**
     * Set state
     *
     * @param string $state
     *
     * @return User
     */
    public function setState($state)
    {
        $this->state = $state;

        return $this;
    }

    /**
     * Get state
     *
     * @return string
     */
    public function getState()
    {
        return $this->state;
    }

    /**
     * Set country
     *
     * @param string $country
     *
     * @return User
     */
    public function setCountry($country)
    {
        $this->country = $country;

        return $this;
    }

    /**
     * Get country
     *
     * @return string
     */
    public function getCountry()
    {
        return $this->country;
    }

	/**
     * Set defineView
     *
     * @param string $defineView
     *
     * @return User
     */
    public function setDefineView($defineView)
    {
        $this->defineView = $defineView;

        return $this;
    }

    /**
     * Get defineView
     *
     * @return string
     */
    public function getDefineView()
    {
        return $this->defineView;
    }
	

    /**
     * Set profileImagePath
     *
     * @param string $profileImagePath
     *
     * @return User
     */
    public function setProfileImagePath($profileImagePath)
    {
        $this->profileImagePath = $profileImagePath;

        return $this;
    }

    /**
     * Get profileImagePath
     *
     * @return string
     */
    public function getProfileImagePath()
    {
        return $this->profileImagePath;
    }
	
	 /**
     * Set councils	
     *
     * @param string $councils	
     *
     * @return User
     */
    public function setCouncils($councils	)
    {
        $this->councils	 = $councils	;

        return $this;
    }

    /**
     * Get councils	
     *
     * @return string
     */
    public function getCouncils	()
    {
        return $this->councils	;
    }
	
	 /**
     * Set business	
     *
     * @param string $business	
     *
     * @return User
     */
    public function setBusiness($business	)
    {
        $this->business	 = $business	;

        return $this;
    }

    /**
     * Get business	
     *
     * @return string
     */
    public function getBusiness	()
    {
        return $this->business	;
    }
	 /**
     * Set projects	
     *
     * @param string $projects	
     *
     * @return User
     */
    public function setProjects($projects	)
    {
        $this->projects	 = $projects	;

        return $this;
    }

    /**
     * Get projects	
     *
     * @return string
     */
    public function getProjects	()
    {
        return $this->projects	;
    }
	
    /**
     * Set createdDt
     *
     * @param \DateTime $createdDt
     *
     * @return User
     */
    public function setCreatedDt($createdDt)
    {
        $this->createdDt = $createdDt;

        return $this;
    }

    /**
     * Get createdDt
     *
     * @return \DateTime
     */
    public function getCreatedDt()
    {
        return $this->createdDt;
    }

    /**
     * Set updatedDt
     *
     * @param \DateTime $updatedDt
     *
     * @return User
     */
    public function setUpdatedDt($updatedDt)
    {
        $this->updatedDt = $updatedDt;

        return $this;
    }

    /**
     * Get updatedDt
     *
     * @return \DateTime
     */
    public function getUpdatedDt()
    {
        return $this->updatedDt;
    }

    /**
     * Set tempAllow
     *
     * @param integer $tempAllow
     *
     * @return User
     */
    public function setTempAllow($tempAllow)
    {
        $this->temp_allow = $tempAllow;

        return $this;
    }

    /**
     * Get tempAllow
     *
     * @return integer
     */
    public function getTempAllow()
    {
        return $this->temp_allow;
    }

    /**
     * Set tempAllowTime
     *
     * @param \DateTime $tempAllowTime
     *
     * @return User
     */
    public function setTempAllowTime($tempAllowTime)
    {
        $this->temp_allow_time = $tempAllowTime;

        return $this;
    }

    /**
     * Get tempAllowTime
     *
     * @return \DateTime
     */
    public function getTempAllowTime()
    {
        return $this->temp_allow_time;
    }

    /**
     * Set doorModuleAccess
     *
     * @param integer $doorModuleAccess
     *
     * @return User
     */
    public function setDoorModuleAccess($doorModuleAccess)
    {
        $this->doorModuleAccess = $doorModuleAccess;

        return $this;
    }

    /**
     * Get doorModuleAccess
     *
     * @return integer
     */
    public function getDoorModuleAccess()
    {
        return $this->doorModuleAccess;
    }

    /**
     * Set doorModuleUsertype
     *
     * @param integer $doorModuleUsertype
     *
     * @return User
     */
    public function setDoorModuleUsertype($doorModuleUsertype)
    {
        $this->doorModuleUsertype = $doorModuleUsertype;

        return $this;
    }

    /**
     * Get doorModuleUsertype
     *
     * @return integer
     */
    public function getDoorModuleUsertype()
    {
        return $this->doorModuleUsertype;
    }

    /**
     * Set energyModuleAccess
     *
     * @param integer $energyModuleAccess
     *
     * @return User
     */
    public function setEnergyModuleAccess($energyModuleAccess)
    {
        $this->energyModuleAccess = $energyModuleAccess;

        return $this;
    }

    /**
     * Get energyModuleAccess
     *
     * @return integer
     */
    public function getEnergyModuleAccess()
    {
        return $this->energyModuleAccess;
    }

    /**
     * Set energyModuleUsertype
     *
     * @param integer $energyModuleUsertype
     *
     * @return User
     */
    public function setEnergyModuleUsertype($energyModuleUsertype)
    {
        $this->energyModuleUsertype = $energyModuleUsertype;

        return $this;
    }

    /**
     * Get energyModuleUsertype
     *
     * @return integer
     */
    public function getEnergyModuleUsertype()
    {
        return $this->energyModuleUsertype;
    }

    /**
     * Set deviceModuleAccess
     *
     * @param integer $deviceModuleAccess
     *
     * @return User
     */
    public function setDeviceModuleAccess($deviceModuleAccess)
    {
        $this->deviceModuleAccess = $deviceModuleAccess;

        return $this;
    }

    /**
     * Get deviceModuleAccess
     *
     * @return integer
     */
    public function getDeviceModuleAccess()
    {
        return $this->deviceModuleAccess;
    }

    /**
     * Set deviceModuleUsertype
     *
     * @param integer $deviceModuleUsertype
     *
     * @return User
     */
    public function setDeviceModuleUsertype($deviceModuleUsertype)
    {
        $this->deviceModuleUsertype = $deviceModuleUsertype;

        return $this;
    }

    /**
     * Get deviceModuleUsertype
     *
     * @return integer
     */
    public function getDeviceModuleUsertype()
    {
        return $this->deviceModuleUsertype;
    }
}
