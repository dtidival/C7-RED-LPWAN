<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Validator\Constraints\DateTime;

/**
 * Servers
 *
 * @ORM\Table(name="servers")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\UsersRepository")
 * @UniqueEntity(
 *     fields={"email"},
 *     message="The user id is already used."
 * )
 */
class Servers
{

//	const ESTADO_INICIAL = 1;
//	const ESTADO_ALARMAS_INICIAL = 1;

    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;
	/**
     * @var integer
     *
     * @ORM\Column(name="pk_id", type="integer")
     */
    private $pkId;
	/**
     * @var string
     *
     * @ORM\Column(name="gateways_id", type="string", length=64, nullable=true)
     */
    private $gatewaysId;
	
	/**
     * @var int
     *
     * @ORM\Column(name="user_id", type="integer", nullable=true)
     */
    private $userId;
	
	/**
     * @var string
     *
     * @ORM\Column(name="type", type="string", length=64, nullable=true)
     */
    private $type;
	
	/**
     * @var string
     *
     * @ORM\Column(name="server_url", type="string", length=255, nullable=true)
     */
    private $serverUrl;
	
	/**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=64, nullable=true)
     */
    private $name;

	/**
     * @var string
     *
     * @ORM\Column(name="provider_id",length=64, nullable=true, type="string")
     */
    private $providerId;
	/**
     * @var string
     *
     * @ORM\Column(name="authorization_token", type="string", length=64, nullable=true)
     */
    private $authorizationToken;
	
	/**
     * @var string
     *
     * @ORM\Column(name="profile_name", type="string", length=64, nullable=true)
     */
    private $profileName;

    /**
     * @var string
     *
     * @ORM\Column(name="broker_address", type="string", length=64, nullable=true)
     */
    private $brokerAddress;
	
	/**
     * @var string
     *
     * @ORM\Column(name="broker_port", type="string", length=64, nullable=true)
     */
    private $brokerPort;
	
	 /**
     * @var string
     *
     * @ORM\Column(name="topic", type="string", length=255, nullable=true)
     */
    private $topic;
	/**
     * @var int
     *
     * @ORM\Column(name="is_transparent_mode", type="integer" , options={"default":0})
     */
    private $isTransparentMode;
    /**
     * @var integer
     *
     * @ORM\Column(name="status", type="integer", options={"default":0})
     */
    private $status;
	
	/**
     * @var integer
     *
     * @ORM\Column(name="disable", type="integer", options={"default":0})
     */
    private $disable;	

   /**
     * @var datetime
     *
     * @ORM\Column(name="created_dt", type="datetime", nullable=true)
     */
    private $createdDt;
	/**
     * @var datetime
     *
     * @ORM\Column(name="updated_dt", type="datetime", nullable=true)
     */
    private $updatedDt;
	/**
     * Constructor
     */
    public function __construct()
    {		
		$this->createdDt = new \DateTime();
		$this->updatedDt = new \DateTime();	
		$this->status = 0;
		$this->disable = 0;
		$this->isTransparentMode = 0;
    }

	/**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }
	
	/**
     * Set pkId
     *
     * @param integer $pkId
     *
     * @return Servers
     */
    public function setPkId($pkId)
    {
        $this->pkId = $pkId;

        return $this;
    }

    /**
     * Get pkId
     *
     * @return integer
     */
    public function getPkId()
    {
        return $this->pkId;
    }
	
	/**
     * Set gatewaysId
     *
     * @param string $gatewaysId
     *
     * @return Servers
     */
    public function setGatewaysId($gatewaysId)
    {
        $this->gatewaysId = $gatewaysId;

        return $this;
    }

    /**
     * Get gatewaysId
     *
     * @return string
     */
    public function getGatewaysId()
    {
        return $this->gatewaysId;
    }
	
	/**
     * Set userId
     *
     * @param integer $userId
     *
     * @return Servers
     */
    public function setUserId($userId)
    {
        $this->userId = $userId;

        return $this;
    }

    /**
     * Get userId
     *
     * @return integer
     */
    public function getUserId()
    {
        return $this->userId;
    }

    /**
     * Set type
     *
     * @param string $type
     *
     * @return Servers
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return Servers
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set providerId
     *
     * @param string $providerId
     *
     * @return Servers
     */
    public function setProviderId($providerId)
    {
        $this->providerId = $providerId;

        return $this;
    }

    /**
     * Get providerId
     *
     * @return string
     */
    public function getProviderId()
    {
        return $this->providerId;
    }

    /**
     * Set authorizationToken
     *
     * @param string $authorizationToken
     *
     * @return Servers
     */
    public function setAuthorizationToken($authorizationToken)
    {
        $this->authorizationToken = $authorizationToken;

        return $this;
    }

    /**
     * Get authorizationToken
     *
     * @return string
     */
    public function getAuthorizationToken()
    {
        return $this->authorizationToken;
    }
	
	/**
     * Set profileName
     *
     * @param string $profileName
     *
     * @return Servers
     */
    public function setProfileName($profileName)
    {
        $this->profileName = $profileName;

        return $this;
    }

    /**
     * Get profileName
     *
     * @return string
     */
    public function getProfileName()
    {
        return $this->profileName;
    }

    /**
     * Set brokerAddress
     *
     * @param string $brokerAddress
     *
     * @return Servers
     */
    public function setBrokerAddress($brokerAddress)
    {
        $this->brokerAddress = $brokerAddress;

        return $this;
    }

    /**
     * Get brokerAddress
     *
     * @return string
     */
    public function getBrokerAddress()
    {
        return $this->brokerAddress;
    }

    /**
     * Set brokerPort
     *
     * @param string $brokerPort
     *
     * @return Servers
     */
    public function setBrokerPort($brokerPort)
    {
        $this->brokerPort = $brokerPort;

        return $this;
    }

    /**
     * Get brokerPort
     *
     * @return string
     */
    public function getBrokerPort()
    {
        return $this->brokerPort;
    }

    /**
     * Set topic
     *
     * @param string $topic
     *
     * @return Servers
     */
    public function setTopic($topic)
    {
        $this->topic = $topic;

        return $this;
    }

    /**
     * Get topic
     *
     * @return string
     */
    public function getTopic()
    {
        return $this->topic;
    }
	
	/**
     * Set isTransparentMode
     *
     * @param integer $isTransparentMode
     *
     * @return Servers
     */
    public function setIsTransparentMode($isTransparentMode)
    {
        $this->isTransparentMode = $isTransparentMode;
        return $this;
    }

    /**
     * Get isTransparentMode
     *
     * @return integer
     */
    public function getIsTransparentMode()
    {
        return $this->isTransparentMode;
    }
	
    /**
     * Set status
     *
     * @param integer $status
     *
     * @return Servers
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return integer
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set disable
     *
     * @param integer $disable
     *
     * @return Servers
     */
    public function setDisable($disable)
    {
        $this->disable = $disable;

        return $this;
    }

    /**
     * Get disable
     *
     * @return integer
     */
    public function getDisable()
    {
        return $this->disable;
    }

    /**
     * Set createdDt
     *
     * @param \DateTime $createdDt
     *
     * @return Servers
     */
    public function setCreatedDt($createdDt)
    {
        $this->createdDt = $createdDt;

        return $this;
    }

    /**
     * Get createdDt
     *
     * @return \DateTime
     */
    public function getCreatedDt()
    {
        return $this->createdDt;
    }

    /**
     * Set updatedDt
     *
     * @param \DateTime $updatedDt
     *
     * @return Servers
     */
    public function setUpdatedDt($updatedDt)
    {
        $this->updatedDt = $updatedDt;

        return $this;
    }

    /**
     * Get updatedDt
     *
     * @return \DateTime
     */
    public function getUpdatedDt()
    {
        return $this->updatedDt;
    }

    /**
     * Set serverUrl
     *
     * @param string $serverUrl
     *
     * @return Servers
     */
    public function setServerUrl($serverUrl)
    {
        $this->serverUrl = $serverUrl;

        return $this;
    }

    /**
     * Get serverUrl
     *
     * @return string
     */
    public function getServerUrl()
    {
        return $this->serverUrl;
    }
}
