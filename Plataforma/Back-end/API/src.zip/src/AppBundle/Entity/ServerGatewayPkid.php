<?php
namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Validator\Constraints\DateTime;

/**
 * ServerGatewayPkid
 *
 * @ORM\Table(name="server_gateway_pkid")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\UsersRepository")
 * @UniqueEntity(
 *     fields={"id"},
 *     message="The id is already used."
 * )
 */
class ServerGatewayPkid
{

//	const ESTADO_INICIAL = 1;
//	const ESTADO_ALARMAS_INICIAL = 1;

    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;	
	/**
     * @var string
     *
     * @ORM\Column(name="mac_number", type="string", length=255, nullable=true)
     */
    private $macNumber;
	/**
     * @var integer
     *
     * @ORM\Column(name="server_id", type="integer")
     */
    private $serverId;
	/**
     * @var integer
     *
     * @ORM\Column(name="pk_id", type="integer")
     */
    private $pkId;
	
	/**
     * Constructor
     */
    public function __construct()
    {		
		
    }

	/**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }	
	
	/**
     * Set macNumber
     *
     * @param string $macNumber
     *
     * @return ServerGatewayPkid
     */
    public function setMacNumber($macNumber)
    {
        $this->macNumber = $macNumber;

        return $this;
    }

    /**
     * Get macNumber
     *
     * @return string
     */
    public function getMacNumber()
    {
        return $this->macNumber;
    }
	
	/**
     * Set serverId
     *
     * @param integer $serverId
     *
     * @return ServerGatewayPkid
     */
    public function setServerId($serverId)
    {
        $this->serverId = $serverId;

        return $this;
    }

    /**
     * Get serverId
     *
     * @return integer
     */
    public function getServerId()
    {
        return $this->serverId;
    }
	
	/**
     * Set pkId
     *
     * @param integer $pkId
     *
     * @return ServerGatewayPkid
     */
    public function setPkId($pkId)
    {
        $this->pkId = $pkId;

        return $this;
    }

    /**
     * Get pkId
     *
     * @return integer
     */
    public function getPkId()
    {
        return $this->pkId;
    }
}
?>