	google.charts.load('current', {'packages':['corechart']});	
    //google.charts.setOnLoadCallback(drawChart);	
		
		function autoRefreshTimeChart () {
		//console.log('autoRefreshTimeChart');
	    wholeYearSupervalleFrom = document.getElementById('ratesFranjaSupervalleFrom').value;
		wholeYearValleFrom = document.getElementById('ratesFranjaValleFrom').value 
		wholeYearValle2From = document.getElementById('ratesFranjaValleFrom2').value 
		wholeYearPuntaFrom = document.getElementById('ratesFranjaPuntaFrom').value
		//console.log(wholeYearSupervalleFrom);
		wholeYearSupervalleTo = document.getElementById('ratesFranjaSupervalleTo').value;
		wholeYearValleTo = document.getElementById('ratesFranjaValleTo').value; 
		wholeYearValle2To = document.getElementById('ratesFranjaValleTo2').value ;
		wholeYearPuntaTo = document.getElementById('ratesFranjaPuntaTo').value;
		
		winterSupervalleFrom = document.getElementById('ratesFranjaSupervalleFromWinter').value;
		winterValleFrom = document.getElementById('ratesFranjaValleFromWinter').value 
		winterValle2From = document.getElementById('ratesFranjaValleFrom2Winter').value 
		winterPuntaFrom = document.getElementById('ratesFranjaPuntaFromWinter').value
		//console.log(winterSupervalleFrom);
		winterSupervalleTo = document.getElementById('ratesFranjaSupervalleToWinter').value;
		winterValleTo = document.getElementById('ratesFranjaValleToWinter').value; 
		winterValle2To = document.getElementById('ratesFranjaValleTo2Winter').value ;
		winterPuntaTo = document.getElementById('ratesFranjaPuntaToWinter').value;
		
		summerSupervalleFrom = document.getElementById('ratesFranjaSupervalleFromSummer').value;
		summerValleFrom = document.getElementById('ratesFranjaValleFromSummer').value 
		summerValle2From = document.getElementById('ratesFranjaValleFrom2Summer').value 
		summerPuntaFrom = document.getElementById('ratesFranjaPuntaFromSummer').value
		//console.log(summerSupervalleFrom);
		summerSupervalleTo = document.getElementById('ratesFranjaSupervalleToSummer').value;
		summerValleTo = document.getElementById('ratesFranjaValleToSummer').value; 
		summerValle2To = document.getElementById('ratesFranjaValleTo2Summer').value ;
		summerPuntaTo = document.getElementById('ratesFranjaPuntaToSummer').value;
		
		if(winterSupervalleFrom && winterValleFrom  && winterValle2From && winterPuntaFrom   && winterSupervalleTo  && winterValleTo && winterValle2To  && winterPuntaTo)
		{
		 season = 'Winter';
	     drawChart(season,winterSupervalleFrom,winterValleFrom,winterValle2From,winterPuntaFrom,winterSupervalleTo,winterValleTo,winterValle2To,winterPuntaTo);
		}
		
		if(summerSupervalleFrom && summerValleFrom  && summerValle2From && summerPuntaFrom   && summerSupervalleTo  && summerValleTo && summerValle2To  && summerPuntaTo)
		{
		 season = 'Summer';
	     drawChart(season,summerSupervalleFrom,summerValleFrom,summerValle2From,summerPuntaFrom,summerSupervalleTo,summerValleTo,summerValle2To,summerPuntaTo);
		}
		if(wholeYearSupervalleFrom && wholeYearValleFrom && wholeYearValle2From && wholeYearPuntaFrom && wholeYearSupervalleTo && wholeYearValleTo && wholeYearValle2To && wholeYearPuntaTo)
		{
		 season = 'WholeYear';
	     drawChart(season,wholeYearSupervalleFrom,wholeYearValleFrom,wholeYearValle2From,wholeYearPuntaFrom,wholeYearSupervalleTo,wholeYearValleTo,wholeYearValle2To,wholeYearPuntaTo);
		}
		
	     setTimeout(autoRefreshTimeChart, 1000);
		}
        autoRefreshTimeChart();
    function drawChart(season,wholeYearSupervalleFrom,wholeYearValleFrom,wholeYearValle2From,wholeYearPuntaFrom,wholeYearSupervalleTo,wholeYearValleTo,wholeYearValle2To,wholeYearPuntaTo) {
		
		//console.log('drawChart');
		wholeYearSupervalleTo = wholeYearSupervalleTo.slice(0,2);
		wholeYearValleTo = wholeYearValleTo.slice(0, 2);
		wholeYearValle2To = wholeYearValle2To.slice(0, 2);
		wholeYearPuntaTo = wholeYearPuntaTo.slice(0, 2);
		
		wholeYearSupervalleFrom = wholeYearSupervalleFrom.slice(0,2);
		wholeYearValleFrom = wholeYearValleFrom.slice(0, 2);
		wholeYearValle2From = wholeYearValle2From.slice(0, 2);
		wholeYearPuntaFrom = wholeYearPuntaFrom.slice(0, 2);
		
		wholeYearSupervalleHour = wholeYearSupervalleTo - wholeYearSupervalleFrom;		
		wholeYearVallHour = wholeYearValleTo - wholeYearValleFrom;
		wholeYearVall2Hour = wholeYearValle2To - wholeYearValle2From;
		wholeYearPuntaHour = wholeYearPuntaTo - wholeYearPuntaFrom;
		//console.log(wholeYearSupervalleHour);
		//console.log(wholeYearVallHour);
		//console.log(wholeYearVall2Hour);
		//console.log(wholeYearPuntaHour);
		if(wholeYearSupervalleFrom){
			if(wholeYearSupervalleFrom >= 12)
			{wholeYearSupervalleFrom = wholeYearSupervalleFrom +'pm';}
			else{wholeYearSupervalleFrom = wholeYearSupervalleFrom +'am';}
		}
		if(wholeYearValleFrom)
		{
			if(wholeYearValleFrom >= 12)
			{wholeYearValleFrom = wholeYearValleFrom > 12 ? (wholeYearValleFrom - 12)+'pm' : wholeYearValleFrom +'pm';}
			else{wholeYearValleFrom = wholeYearValleFrom +'am';}
		}
		if(wholeYearValle2From)
		{
			if(wholeYearValle2From >= 12)
			{wholeYearValle2From = wholeYearValle2From +'pm';}
			else{wholeYearValle2From = wholeYearValle2From +'am';}
		}
		if(wholeYearPuntaFrom)
		{
			if(wholeYearPuntaFrom >= 12)
			{wholeYearPuntaFrom = wholeYearPuntaFrom +'pm';}
			else{wholeYearPuntaFrom = wholeYearPuntaFrom +'am';}
		}
		
		if(wholeYearSupervalleTo){
			if(wholeYearSupervalleTo >= 12)
			{wholeYearSupervalleTo = wholeYearSupervalleTo +'pm';}
			else{wholeYearSupervalleTo = wholeYearSupervalleTo +'am';}
		}
		if(wholeYearValleTo)
		{
			if(wholeYearValleTo >= 12)
			{wholeYearValleTo = wholeYearValleTo > 12 ? (wholeYearValleTo - 12)+'pm' : wholeYearValleTo +'pm';}
			else{wholeYearValleTo = wholeYearValleTo +'am';}
		}
		if(wholeYearValle2To)
		{
			if(wholeYearValle2To >= 12)
			{wholeYearValle2To = wholeYearValle2To +'pm';}
			else{wholeYearValle2To = wholeYearValle2To +'am';}
		}
		if(wholeYearPuntaTo)
		{
			if(wholeYearPuntaTo >= 12)
			{wholeYearPuntaTo = wholeYearPuntaTo +'pm';}
			else{wholeYearPuntaTo = wholeYearPuntaTo +'am';}
		}
		
      var data1 =  google.visualization.arrayToDataTable([
        ['TimeDevision', 'Hours per Day'],
        ['Franja Supervalle('+wholeYearSupervalleFrom +' to '+ wholeYearSupervalleTo +')',wholeYearSupervalleHour],
		['Franja Valle('+wholeYearValleFrom +' to '+ wholeYearValleTo +')', wholeYearVallHour],
		['Franja punta ('+wholeYearPuntaFrom+' to '+ wholeYearPuntaTo +')', wholeYearPuntaHour],
		['Franja Valle('+wholeYearValle2From +' to '+ wholeYearValle2To +')', wholeYearVall2Hour]		       
        
		
        ]);
		var data2 =  google.visualization.arrayToDataTable([
        ['TimeDevision', 'Hours per Day'],
        ['Franja Supervalle('+wholeYearSupervalleFrom +' to '+ wholeYearSupervalleTo +')',wholeYearSupervalleHour],
		['Franja Valle('+wholeYearValleFrom +' to '+ wholeYearValleTo +')', wholeYearVallHour],
		['Franja punta ('+wholeYearPuntaFrom+' to '+ wholeYearPuntaTo +')', wholeYearPuntaHour],
		['Franja Valle('+wholeYearValle2From +' to '+ wholeYearValle2To +')', wholeYearVall2Hour]		       
        
		
        ]);
		var data3 =  google.visualization.arrayToDataTable([
        ['TimeDevision', 'Hours per Day'],
        ['Franja Supervalle('+wholeYearSupervalleFrom +' to '+ wholeYearSupervalleTo +')',wholeYearSupervalleHour],
		['Franja Valle('+wholeYearValleFrom +' to '+ wholeYearValleTo +')', wholeYearVallHour],
		['Franja punta ('+wholeYearPuntaFrom+' to '+ wholeYearPuntaTo +')', wholeYearPuntaHour],
		['Franja Valle('+wholeYearValle2From +' to '+ wholeYearValle2To +')', wholeYearVall2Hour]		       
        
		
        ]);

      var options = {        
		width: 430,
		is3D: true,
		//pieSliceText: 'label',
		height: 300,		
		legend:{position:'right',
		textStyle:{fontSize:11},
		maxLines:3},
		slices: {
            0: { color: 'green' },
            1: { color: 'lightblue' },			
			2: { color: 'red' },
			3: { color: 'lightblue' }
          }
      };
		if(season=='WholeYear')
		{
      var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
      chart.draw(data1, options);
		}
		if(season=='Winter'){
	  var chart = new google.visualization.PieChart(document.getElementById('piechart_3d_winter'));
      chart.draw(data2, options);
		}
		if(season=='Summer'){
	  var chart = new google.visualization.PieChart(document.getElementById('piechart_3d_summer'));
      chart.draw(data3, options);
		}
    }