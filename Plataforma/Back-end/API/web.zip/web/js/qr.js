function mostrarQR(urlImagen){
    bootbox.dialog({
        title: "Código QR",
        message: '<div class="text-center"><img id="codigoQRSala" src="'+urlImagen+'" /></div>',
        buttons: {
        imprimir: {
          label: "Imprimir",
          //className: "btn-success",
          callback: function() {
            $("#codigoQRSala").print(/*options*/);
          }
        },
        cancelar: {
          label: "Cancelar",
        },
      }  
    });

}
