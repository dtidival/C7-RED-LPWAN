google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);	
function drawChart() {	
      
		var data1 =  google.visualization.arrayToDataTable([
        ['TimeDevision', 'Hours per Day'],	
		['VALLE 12am to 8am',8],
		['LLANO 8am to 11am', 3],
		['PUNTA 11am to 3pm',4],
		['LLANO 3pm to 12am', 9],		
        ]);
		
		var data2 =  google.visualization.arrayToDataTable([
        ['TimeDevision', 'Hours per Day'],	
		['VALLE 12am to 8am',8],
		['LLANO 8am to 6pm', 10],
		['PUNTA 6pm to 10pm',4],
		['LLANO 10pm to 12am', 2],		
        ]);       

      var options = {        
		width: 470,
		is3D: true,
		//pieSliceText: 'label',
		height: 300,		
		legend:{position:'right',
		textStyle:{fontSize:11},
		maxLines:3},
		slices: {
            0: { color: 'green' },
            1: { color: 'yellow' },			
			2: { color: 'red' },
			3: { color: 'yellow' }
          }
      };	
		
	  		
	
		var chart = new google.visualization.PieChart(document.getElementById('piechart_3d_summer1'));
		chart.draw(data1, options);
		
		var chart = new google.visualization.PieChart(document.getElementById('piechart_3d_winter1'));
		chart.draw(data2, options);
    }