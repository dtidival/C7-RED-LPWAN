<?php

namespace AppBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use AppBundle\Entity\Gateways;
use AppBundle\Entity\Servers;
use AppBundle\Entity\SensorInfo;
use AppBundle\Entity\SensorTypePayload;
use AppBundle\Entity\SensorTypeInfo;
use AppBundle\Entity\SensorServerDetail;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Process\Process;
use Symfony\Component\Process\Exception\ProcessFailedException;
use Symfony\Component\Validator\Constraints\DateTime;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Normalizer\GetSetMethodNormalizer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Normalizer\DateTimeNormalizer;


/**
 * Gateways controller.
 *
 * @Route("/gateways")
 */
class GatewaysController extends Controller
{
	
	/**
     * List
     *                                                                                 
	 * @Route("/list", name="gateways_list")
	 */
	public function GatewaysListApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();

		$gatewaysList= $em 
			->getRepository('AppBundle:Gateways')
			->findAll();
		
		$json = '';
		//var_dump($user);
		
		 if($gatewaysList != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($gatewaysList, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','gateway_details' => $json));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','gateway_details' => $json));
			//return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in gateway data'));
	}
	
	/**
     * Get Gateway by Id
     *                                                                                 
	 * @Route("/getgatewaybyid", name="gateway_getgatewaybyid")
	 */
	public function getgatewaybyidApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$gatewayId = $data->id;
		
		$gateway= $em 
			->getRepository('AppBundle:Gateways')
			->findBy(array('id' => $gatewayId));
		
		if( $gateway != null)
		{
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new GetSetMethodNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($gateway, 'json');
			
			return new JsonResponse(array('status' => 'Success','gateway_details' => $json));
		}
		else{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in getting gateway details!!'));
		} 
		
	}
	
	/**
     * Delete a Gateway
     *                                                                                 
	 * @Route("/deletegateway", name="gateway_deletegateway")
	 */
	public function deleteGatewayApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());		
		$gatewayId = $data->id;	
		$gateway= $em 
			->getRepository('AppBundle:Gateways')
			->findOneBy(array('id' => $gatewayId));
		if($gateway != null)
		{
			$em->remove($gateway);
            $em->flush();	
		return new JsonResponse(array('status' => 'SUCCESS','message' => 'Gateway has been successfully removed!!'));
		}
		else{
			return new JsonResponse(array('status' => 'Failed','message' => 'No Gateway is Present with this Id!!'));
		}
	}
	
	/**
     * Create New Gateway
     *                                                                                 
	 * @Route("/newGateway", name="gateway_newgateway")
	 */
	public function newGatewayApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		// var_dump($data);
		
		$name = $data->name;		
		$description = $data->description;
		$application = $data->application;
		$mac = $data->mac;
		$latitude = $data->latitude;
		$longitude = $data->longitude;
		$radius = $data->radius;
		$town = $data->town;
		$inharitGroup = $data->inharitGroup;
		$serverId = $data->serverId;
		$groupsId = $data->groupsId;
		$sensorsId = $data->sensorsId;
		$projectId = $data->project;
		$status = $data->status;
		$disable = $data->disable;		
		
		$gatewayObj= $em 
			->getRepository('AppBundle:Gateways')
			->findBy(array('name' => $name,'mac' => $mac,'application' => $application));
			
			
		if($gatewayObj != null)
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Requested Gateway is already exists!!'));
		}
		else{
			
			$gateway = new Gateways();
			$gateway->setName($name);
			
			if($description != "")
			$gateway->setDescription($description);
		
			if($application != "")
			$gateway->setApplication($application);
		
			if($mac != "")
			$gateway->setMac($mac);
		
			if($latitude != "")
			$gateway->setLatitude($latitude);
			
			if($longitude != "")
			$gateway->setLongitude($longitude);
		
			if($radius != "")
			$gateway->setRadius($radius);
		
			if($town != "")
			$gateway->setTown($town);
			
			if($inharitGroup != "")
			$gateway->setInharitGroup($inharitGroup);
		
			if($serverId != "")
			$gateway->setServerId($serverId);
			
			if($groupsId != "")
			$gateway->setGroupsId($groupsId);
		
			if($sensorsId != "")
			$gateway->setSensorsId($sensorsId);
		
			if($projectId != "")
			{
				$gateway->setProjectId($projectId);
			}
		
			if($status != "" )
			$gateway->setStatus($status);
		
			if($disable != "" )
			$gateway->setDisable($disable);
		
			$em->persist($gateway);
			$em->flush();
			$Id = $gateway->getId();
			
			if( $Id != '')
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'Gateway has been successfully created!!','id' => $Id));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in registering Gateway registeration!!'));
			} 
		}
		
	}
	
	/**
     * Update a Gateway
     *                                                                                 
	 * @Route("/updategateway", name="gateway_updategateway")
	 */
	public function updategatewayApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$gatewayId = $data->id;
		$name = $data->name;		
		$description = $data->description;
		$application = $data->application;
		$mac = $data->mac;
		$latitude = $data->latitude;
		$longitude = $data->longitude;
		$radius = $data->radius;
		$town = $data->town;
		$inharitGroup = $data->inharitGroup;
		$serverId = $data->serverId;
		$groupsId = $data->groupsId;
		$sensorsId = $data->sensorsId;
		$projectId = $data->project;
		$status = $data->status;
		$disable = $data->disable;
		$linkToGateway = $data->linkToGateway;
		$currentdatetime = new  \DateTime();
		
		//if($sensorsId != "")
		$serverIdArray = explode(',', $serverId);
	
		if($sensorsId != "")
		$sensorIdArray = explode(',', $sensorsId);
		
		$gateway= $em 
			->getRepository('AppBundle:Gateways')
			->findOneBy(array('id' => $gatewayId));
			
		if($gateway !=null)
		{
			$macAddress = $gateway->getMac();
			//  message for sensor
			
			if($linkToGateway == "sensor"){
		   $sensorIdfromGateway = $gateway->getSensorsId();
		   //print_r($sensorIdfromGateway);
		   if($sensorIdfromGateway != "")
			  {
				$sensorIdfromGatewayArray = explode(',', $sensorIdfromGateway);
				$newSensorToAddGateway = $sensorsId != "" ? array_diff($sensorIdArray,$sensorIdfromGatewayArray):[];
				$oldSensorToRemoveGateway =  $sensorsId != "" ?  array_diff($sensorIdfromGatewayArray,$sensorIdArray):$sensorIdfromGatewayArray;
				if(count($newSensorToAddGateway) > 0)
				{
					foreach ($newSensorToAddGateway   as $value){ 
					
					$sensorInfo= $em 
					->getRepository('AppBundle:SensorInfo')
					->findOneBy(array('id' => $value));
					
				$typeSensor = $sensorInfo -> getTypeSensor();
					$sensorTypeObj = $em 
					->getRepository('AppBundle:SensorTypeInfo')
					->findOneBy(array('id' => $typeSensor));
					
				$typeSensorName = $sensorTypeObj->getName();
				
				$sensorTypePayloadObj= $em 
				->getRepository('AppBundle:SensorTypePayload')
				->findBy(array('sensorTypeId' => $typeSensor));
				//print('sensorTypePayloadObj');
				//print_r($sensorTypePayloadObj);
					foreach ($sensorTypePayloadObj   as $sensorTypePayload){
						$id = $sensorTypePayload->getId();
						$typeOfData = $sensorTypePayload->getTypeOfData();				
					$reverse = $sensorTypePayload->getReverse();					
					$sensorTypeId = $sensorTypePayload->getSensorTypeId();					
					$payloadUniqueId = $sensorTypePayload->getPayloadUniqueId();
					$varname = $sensorTypePayload->getVarname();				
					$start = $sensorTypePayload->getStart();				
					$length = $sensorTypePayload->getLength();
					$description = $sensorTypePayload->getDescription();
					$decimalNumber = $sensorTypePayload->getDecimalNumber();
					$bitNumber = $sensorTypePayload->getBitNumber();
					$any = $sensorTypePayload->getAny();
					if($typeSensorName !=  "wifi" && $typeSensorName !=  "ibox")
					{					
					$this->sensortypemsg($macAddress, $id, $typeSensorName, $typeOfData, $reverse, $length, $start, $decimalNumber, $bitNumber, $varname);
					}
					}
				$sensorServerObj= $em 
					->getRepository('AppBundle:SensorServerDetail')
					->findBy(array('sensorId' => $value));
					
				$serverIds  = [];
				foreach ($sensorServerObj   as $value){ 
				array_push($serverIds,$value->getServerId());
				}
				$id = $sensorInfo->getId();	
				$typeSensorName = $sensorTypeObj->getName();	
				$sensorUniqueId = $sensorInfo->getSensorUniqueId();			
				$componentName = $sensorInfo->getName();					
				$latitude = $sensorInfo->getLatitude();
				$longitude = $sensorInfo->getLongitude();
				$deviceEUI = $sensorInfo->getDeviceEUI();
				$appEUI = $sensorInfo->getAppEUI();
				$appKEY = $sensorInfo->getAppKEY();
				$hashSensorName="";
				$countSensorName="";
				$customSensor="";
				$this->sensormsg($macAddress, $id,  $typeSensorName, $componentName, $deviceEUI, $serverIds, $hashSensorName, $countSensorName, $customSensor);
				}
				}
				if(count($oldSensorToRemoveGateway) > 0)
				{
					foreach ($oldSensorToRemoveGateway   as $value){ 
					$sensorInfo= $em 
					->getRepository('AppBundle:SensorInfo')
					->findOneBy(array('id' => $value));	
					
				$typeSensor = $sensorInfo->getTypeSensor();
					$sensorTypeObj= $em 
					->getRepository('AppBundle:SensorTypeInfo')
					->findOneBy(array('id' => $typeSensor));
					
				$sensorServerObj= $em 
					->getRepository('AppBundle:SensorServerDetail')
					->findBy(array('sensorId' => $value));
					
				$serverIds  = [];
				foreach ($sensorServerObj   as $value){ 
				array_push($serverIds,$value->getServerId());
				}
				$id = $sensorInfo->getId();	
				$typeSensorName = $sensorTypeObj->getName();	
				$sensorUniqueId = $sensorInfo->getSensorUniqueId();			
				$componentName = $sensorInfo->getName();					
				$latitude = $sensorInfo->getLatitude();
				$longitude = $sensorInfo->getLongitude();
				$deviceEUI = $sensorInfo->getDeviceEUI();
				$appEUI = $sensorInfo->getAppEUI();
				$appKEY = $sensorInfo->getAppKEY();
				$hashSensorName="";
				$countSensorName="";
				$customSensor="";
				$this->sensormsgdelete($macAddress, $id, $typeSensorName,$sensorUniqueId);
				}
				}
			  }
			else{
				foreach ($sensorIdArray   as $value){ 
					$sensorInfo= $em 
					->getRepository('AppBundle:SensorInfo')
					->findOneBy(array('id' => $value));	
					
				$typeSensor = $sensorInfo->getTypeSensor();
					$sensorTypeObj= $em 
					->getRepository('AppBundle:SensorTypeInfo')
					->findOneBy(array('id' => $typeSensor));
					
				$sensorServerObj= $em 
					->getRepository('AppBundle:SensorServerDetail')
					->findBy(array('sensorId' => $value));
					
				$serverIds  = [];
				foreach ($sensorServerObj   as $value){ 
				array_push($serverIds,$value->getServerId());
				}
				$id = $sensorInfo->getId();	
				$typeSensorName = $sensorTypeObj->getName();	
				$sensorUniqueId = $sensorInfo->getSensorUniqueId();			
				$componentName = $sensorInfo->getName();					
				$latitude = $sensorInfo->getLatitude();
				$longitude = $sensorInfo->getLongitude();
				$deviceEUI = $sensorInfo->getDeviceEUI();
				$appEUI = $sensorInfo->getAppEUI();
				$appKEY = $sensorInfo->getAppKEY();
				$hashSensorName="";
				$countSensorName="";
				$customSensor="";
				$this->sensormsg($macAddress, $id,  $typeSensorName, $componentName, $deviceEUI, $serverIds, $hashSensorName, $countSensorName, $customSensor);
				}				
			}
		}
			//  message for server
			if($linkToGateway == "server"){
		   $serverIdfromGateway = $gateway->getServerId();		   
		   if($serverIdfromGateway != "")
			  {
				$serverIdfromGatewayArray = explode(',', $serverIdfromGateway);
				$newServerToAddGateway = array_diff($serverIdArray,$serverIdfromGatewayArray);
				$oldServerToRemoveGateway = array_diff($serverIdfromGatewayArray,$serverIdArray);
				//print_r($newServerToAddGateway);
				//print_r($oldServerToRemoveGateway);
				if(count($newServerToAddGateway) > 0)
				{
					
					foreach ($newServerToAddGateway   as $value){ 
					$serverObj= $em 
					->getRepository('AppBundle:Servers')
					->findOneBy(array('id' => $value)); 					
					//print_r($value);	
					
					$id = $serverObj->getId();
					$type = $serverObj->getType();		
					$serverName  = $serverObj->getName();	
					$url  = $serverObj->getServerUrl();			
					$provider  = $serverObj->getProviderId();	
					$identityKey = $serverObj->getAuthorizationToken();
					
					//print_r($serverName);
					$this->servermsg($macAddress, $id, $type, $serverName, $url, $provider, $identityKey);
				   }
				}
				if(count($oldServerToRemoveGateway) > 0)
				{
					foreach ($oldServerToRemoveGateway   as $value){ 
					$serverObj= $em 
					->getRepository('AppBundle:Servers')
					->findOneBy(array('id' => $value));
					$pkId = $serverObj->getPkId();
					$id = $serverObj->getId();				
					$this->servermsgdelete($macAddress, $id, $pkId);					}
				}
				
				}
			else{
				foreach ($serverIdArray   as $value){ 
				  $serverObj= $em 
					->getRepository('AppBundle:Servers')
					->findOneBy(array('id' => $value));
					
					//	print_r($value);
					//print_r($serverObj);
					$id = $serverObj->getId();
					$type = $serverObj->getType();		
					$serverName  = $serverObj->getName();	
					$url  = $serverObj->getServerUrl();			
					$provider  = $serverObj->getProviderId();	
					$identityKey = $serverObj->getAuthorizationToken();
					$this->servermsg($mac, $id, $type, $serverName, $url, $provider, $identityKey);
				}				
			}
			}
			if($name != "")
			{
				$gateway->setName($name);
			}
			if($description != "")
			{
				$gateway->setDescription($description);
			}
			if($application != "")
			{
				$gateway->setApplication($application);
			}
			
			if($mac != "")
			{
				$gateway->setMac($mac);
			}
			if($latitude != "")
			{
				$gateway->setLatitude($latitude);
			}
			if($longitude != "")
			{
				$gateway->setLongitude($longitude);
			}
			
			if($radius != "")
			$gateway->setRadius($radius);
		
			if($town != "")
			$gateway->setTown($town);
			
			if($inharitGroup != "")
			$gateway->setInharitGroup($inharitGroup);
		
			if($serverId != "")
			{
				$gateway->setServerId($serverId);
			}
			if($groupsId != "")
			{
				$gateway->setGroupsId($groupsId);
			}
			if($sensorsId != "")
			{
				$gateway->setSensorsId($sensorsId);
			}
			if($projectId != "")
			{
				$gateway->setProjectId($projectId);
			}
			if($status != "")
			{
				$gateway->setStatus($status);
			}
			if($disable != "")
			{
				$gateway->setDisable($disable);
			}
			
			$gateway->setUpdatedDt(new \DateTime());
			
			$em->persist($gateway);
			$em->flush();
			$gatewayId = $gateway->getId();
			
			if( $gatewayId != "")
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'Gateway has been successfully updated!!'));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating Gateway details!!'));
			}
		}
		else
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating Gateway Detail No Record found with this Id'));
		}
		
	}
	
	public function servermsg($gatewaymac, $id, $type, $serverName, $url, $provider, $identityKey){
			$currentdatetime = new  \DateTime();
			$topic = $gatewaymac.'/gateway_requests/request';
			$path = "/servers";
			$method = "POST";
			$port = 4999;
			$timestamp = $currentdatetime->format('c'); //"2019-12-08T16:00:02.2805625Z";			
			//$body ='{';			
			$body = '{\"serverName\":\"'.$serverName.'\"';
			$body = $body.',\"url\":\"'.$url.'\"';
			$body = $body.',\"provider\":\"'.$provider.'\"';
			$body = $body.',\"identityKey\":\"'.$identityKey.'\"';
			$body = $body.',\"type\":'.$type;
			$body = $body.'}';
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';			
			$msg = $msg.',"authentication" : true';
			$msg = $msg.',"body":"'.$body.'"';
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$id.'"';			
			$msg = $msg.'}';
			///print_r($msg);
		$this->publish($topic, $msg);
	}
	public function servermsgdelete($gatewaymac, $id, $pkId){
			$currentdatetime = new  \DateTime();			
			$topic =  $gatewaymac.'/gateway_requests/request';
			$path = "/servers/".$pkId;
			$method = "DELETE";
			$port = 4999;
			$timestamp = $currentdatetime->format('c');//"2019-12-08T16:00:02.2805625Z";
			$requestId = $id;
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';
			$msg = $msg.',"authentication" : true';
			$msg = $msg.',"body":""';
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$requestId.'"';			
			$msg = $msg.'}';
			
			if($pkId != null)
			$this->publish($topic, $msg);
	}
	public function sensormsg($gatewaymac, $id,  $typeSensorName, $componentName, $deviceEUI, $serverIds, $hashSensorName, $countSensorName, $customSensor){
			$currentdatetime = new  \DateTime();
			if($typeSensorName!= "wifi" && $typeSensorName!= "ibox")
			{
				$typeSensorName = 'customsensordevices';
		}	
			
			$applicationName = "app";		
			//$componentName = $name;
			$loraAddress = $deviceEUI;
			//$location = "42";//$latitude;
			$serverIds = 1;
			$hashSensorName = "S02";
			$countSensorName = "S01";			
			$customSensor = 2;		
			$topic = $gatewaymac.'/gateway_requests/request';
			$path = "/".$typeSensorName;
			$method = "POST";
			$port = 4999;
			$timestamp = $currentdatetime->format('c'); 
			$requestId = $id;
			$body ='{';
			if($typeSensorName == 'wifi'){
			$body = $body.'\"applicationName\":\"'.$applicationName.'\"';	
			$body = $body.',\"hashSensorName\":\"'.$hashSensorName.'\"';
			$body = $body.',\"countSensorName\":\"'.$countSensorName.'\"';			
			}
			if($typeSensorName == 'ibox'){
			$body = $body.'\"applicationName\":\"'.$applicationName.'\"';	
			$body = $body.',\"hashSensorName\":\"'.$hashSensorName.'\"';
			$body = $body.',\"countSensorName\":\"'.$countSensorName.'\"';
			}
			if($typeSensorName != 'wifi' && $typeSensorName != 'ibox'){
			$body = $body.'\"customSensor\":'.$customSensor;
			
			}
			//$body = $body.',\"sentiloComponentType\":\"'.$sentiloComponentType.'\"';
			$body = $body.',\"componentName\":\"'.$componentName.'\"';
			$body = $body.',\"loraAddress\":\"'.$loraAddress.'\"';
			$body = $body.',\"serverIds\":['.$serverIds.']';
			//$body = $body.',\"location\":\"'.$location.'\"';
			//$body = $body.',\"publicAccess\":\"'.$publicAccess.'\"';
			
			
			
			$body = $body.'}';
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';			
			$msg = $msg.',"authentication" : true';
			$msg = $msg.',"body":"'.$body.'"';
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$requestId.'"';			
			$msg = $msg.'}';
			//print_r($msg);

			$this->publish($topic, $msg);
	}
	public function sensormsgdelete($gatewaymac, $id, $typeSensorName,$sensorUniqueId){
			$currentdatetime = new  \DateTime();			
			$topic =  $gatewaymac.'/gateway_requests/request';
			$path = "/".$typeSensorName."/".$sensorUniqueId;
			$method = "DELETE";
			$port = 4999;
			$timestamp = $currentdatetime->format('c');//"2019-12-08T16:00:02.2805625Z";
			$requestId = $id;
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';
			$msg = $msg.',"authentication" : true';
			$msg = $msg.',"body":""';
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$requestId.'"';			
			$msg = $msg.'}';
			

			$this->publish($topic, $msg);
	}
	public function sensortypemsg($gatewaymac, $id, $typeSensorName, $typeOfData, $reverse, $length, $start, $decimalNumber, $bitNumber, $varname){
		
				
				$currentdatetime = new  \DateTime();
					$configurationName = $typeSensorName;
					$sensorFormatString =  "";
					if($typeOfData == "number")
					{
						if($reverse != ""){
							$sensorFormatString =	'd'.$start.'-'.$length.'.'.$decimalNumber.'R';
						}
						else{
						$sensorFormatString =	'd'.$start.'-'.$length.'.'.$decimalNumber;
						}
					}
					elseif($typeOfData == "string")
					{
						if($reverse != ""){
							$sensorFormatString =	's'.$start.'-'.$length.'R';
						}
						else{
						$sensorFormatString =	's'.$start.'-'.$length;
						}
					}
					elseif($typeOfData == "boolean")
					{
						$sensorFormatString =	'b'.$start.'-'.$bitNumber;
					}
					else{
						
					}
					
					$sensorFormatString = $sensorFormatString;			
			$applicationName = "app";
			$sensorNames = $varname;			
			$topic = $gatewaymac.'/gateway_requests/request';
			$path = "/customsensors";
			$method = "POST";
			$port = 4999;
			$timestamp = $currentdatetime->format('c'); //"2019-12-08T16:00:02.2805625Z";
			$requestId = "123456790";
			//$body ='{';			
			$body = '{\"configurationName\":\"'.$configurationName.'\"';
			$body = $body.',\"sensorFormatString\":\"'.$sensorFormatString.'\"';
			$body = $body.',\"applicationName\":\"'.$applicationName.'\"';
			$body = $body.',\"sensorNames\":[\"'.$sensorNames.'\"]';			
			$body = $body.'}';
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';			
			$msg = $msg.',"authentication" : true';
			$msg = $msg.',"body":"'.$body.'"';
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$id.'"';				
			$msg = $msg.'}';
			//print_r($msg);

			$this->publish($topic, $msg);
	}
	public function publish($topic, $msg)
	{
		$str = "./mosquitto_pub -h gesinen.es -p 1882 -u 'gesinen'  -P 'gesinen2110'  -t '".$topic."' -m '".$msg."'";
		
		$process = new Process($str);
		$process->run();

		// executes after the command finishes
		if (!$process->isSuccessful()) {
			throw new ProcessFailedException($process);
		}
	}
}

?>