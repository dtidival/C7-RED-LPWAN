<?php
namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Validator\Constraints\DateTime;

/**
 * SensorTypeGatewayPkid
 *
 * @ORM\Table(name="sensor_type_gateway_pkid")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\UsersRepository")
 * @UniqueEntity(
 *     fields={"id"},
 *     message="The id is already used."
 * )
 */
class SensorTypeGatewayPkid
{

//	const ESTADO_INICIAL = 1;
//	const ESTADO_ALARMAS_INICIAL = 1;

    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;	
	/**
     * @var string
     *
     * @ORM\Column(name="mac_number", type="string", length=255, nullable=true)
     */
    private $macNumber;
	/**
     * @var integer
     *
     * @ORM\Column(name="sensor_type_id", type="integer")
     */
    private $sensorTypeId;
	/**
     * @var integer
     *
     * @ORM\Column(name="pk_id", type="integer")
     */
    private $pkId;
	
	/**
     * Constructor
     */
    public function __construct()
    {		
		
    }

	/**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }	
	
	/**
     * Set macNumber
     *
     * @param string $macNumber
     *
     * @return SensorTypeGatewayPkid
     */
    public function setMacNumber($macNumber)
    {
        $this->macNumber = $macNumber;

        return $this;
    }

    /**
     * Get macNumber
     *
     * @return string
     */
    public function getMacNumber()
    {
        return $this->macNumber;
    }
	
	/**
     * Set sensorTypeId
     *
     * @param integer $sensorTypeId
     *
     * @return SensorTypeGatewayPkid
     */
    public function setSensorTypeId($sensorTypeId)
    {
        $this->sensorTypeId = $sensorTypeId;

        return $this;
    }

    /**
     * Get sensorTypeId
     *
     * @return integer
     */
    public function getSensorTypeId()
    {
        return $this->sensorTypeId;
    }
	
	/**
     * Set pkId
     *
     * @param integer $pkId
     *
     * @return SensorTypeGatewayPkid
     */
    public function setPkId($pkId)
    {
        $this->pkId = $pkId;

        return $this;
    }

    /**
     * Get pkId
     *
     * @return integer
     */
    public function getPkId()
    {
        return $this->pkId;
    }
}	
?>