<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * GatewayPing
 *
 * @ORM\Table(name="gateway_ping")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\UsersRepository")
 * @ORM\HasLifecycleCallbacks() 
 */
class GatewayPing
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;	
	
	/**
     * @var string
     *
     * @ORM\Column(name="mac_number", type="string", length=64)
     */
    private $macNumber;
	
	/**
     * @var string
     *
     * @ORM\Column(name="status", type="string", length=64)
     */
    private $status;
	
	/**
     * @var string
     *
     * @ORM\Column(name="message_datetime", type="string", length=64)
     */
    private $messageDatetime;
	
	/**
     * @var \DateTime
     *
     * @ORM\Column(name="created_dt", type="datetime")
     */
    private $createdDt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_dt", type="datetime", nullable=true)
     */
    private $updatedDt;

    /**
     * @ORM\PrePersist
     */
    public function setCreatedDtValue()
    {
        $this->createdDt = new \DateTime();
    }

    /**
     * @ORM\PreUpdate
     */
    public function setUpdatedDtValue()
    {
        $this->updatedDt = new \DateTime();
    }
	/**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }
	
	/**
     * Set macNumber
     *
     * @param string $macNumber
     *
     * @return GatewayPing
     */
    public function setMacNumber($macNumber)
    {
        $this->macNumber = $macNumber;

        return $this;
    }

    /**
     * Get macNumber
     *
     * @return string
     */
    public function getMacNumber()
    {
        return $this->macNumber;
    }
	
	/**
     * Set status
     *
     * @param string $status
     *
     * @return GatewayPing
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return string
     */
    public function getStatus()
    {
        return $this->status;
    }
	
	/**
     * Set messageDatetime
     *
     * @param string $messageDatetime
     *
     * @return GatewayPing
     */
    public function setMessageDatetime($messageDatetime)
    {
        $this->messageDatetime = $messageDatetime;

        return $this;
    }

    /**
     * Get messageDatetime
     *
     * @return string
     */
    public function getMessageDatetime()
    {
        return $this->messageDatetime;
    }
	
	/**
     * Set createdDt
     *
     * @param \DateTime $createdDt
     *
     * @return GatewayPing
     */
    public function setCreatedDt($createdDt)
    {
        $this->createdDt = $createdDt;

        return $this;
    }

    /**
     * Get createdDt
     *
     * @return \DateTime
     */
    public function getCreatedDt()
    {
        return $this->createdDt;
    }

    /**
     * Set updatedDt
     *
     * @param \DateTime $updatedDt
     *
     * @return GatewayPing
     */
    public function setUpdatedDt($updatedDt)
    {
        $this->updatedDt = $updatedDt;

        return $this;
    }

    /**
     * Get updatedDt
     *
     * @return \DateTime
     */
    public function getUpdatedDt()
    {
        return $this->updatedDt;
		
	}
}
?>
	