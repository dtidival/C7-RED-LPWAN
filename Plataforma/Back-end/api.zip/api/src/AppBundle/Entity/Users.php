<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Validator\Constraints\DateTime;


/**
 * Users
 *
 * @ORM\Table(name="users")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\UsersRepository")
 * @UniqueEntity(
 *     fields={"email"},
 *     message="The user id is already used."
 * )
 */
class Users
{
	
	const ROOT_PERMISSION = 1;
    const ADMIN_PERMISSION = 2;
	const USER_PERMISSION = 3;
	const Only_DOOR_MODULE_USER = 0;
	
	const DOORMODULEUSERTYPE_ADMIN = 1;
    const DOORMODULEUSERTYPE_USER =  2;
	
	const ENERGYMODULEUSERTYPE_ADMIN = 1;
    const ENERGYMODULEUSERTYPE_USER = 2;
	
	const DEVICEMODULEUSERTYPE_ADMIN = 1;
    const DEVICEMODULEUSERTYPE_USER = 2;
	
	const WATERMODULEUSERTYPE_ADMIN = 1;
    const WATERMODULEUSERTYPE_USER = 2;
	
	const CAPACITYMODULEUSERTYPE_ADMIN = 1;
    const CAPACITYMODULEUSERTYPE_USER = 2;
	
	const IRRIGATIONMODULEUSERTYPE_ADMIN = 1;
    const IRRIGATIONMODULEUSERTYPE_USER = 2;

	const GENERICMODULEUSERTYPE_ADMIN = 1;
    const GENERICMODULEUSERTYPE_USER = 2;
	
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="email", type="string", length=64, nullable=false)
     */
    private $email;

    /**
     * @var string
     *
     * @ORM\Column(name="pwd", type="string", length=64, nullable=true)
     */
    private $pwd = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="user_name", type="string", length=64, nullable=true)
     */
    private $userName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="first_name", type="string", length=64, nullable=true)
     */
    private $firstName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="last_name", type="string", length=64, nullable=true)
     */
    private $lastName = 'NULL';

    /**
     * @var integer
     *
     * @ORM\Column(name="permission", type="integer", nullable=false, options={"default":0})
     */
    private $permission = self::USER_PERMISSION;

    /**
     * @var integer
     *
     * @ORM\Column(name="under_admin", type="integer", nullable=true)
     */
    private $underAdmin = 'NULL';

    /**
     * @var integer
     *
     * @ORM\Column(name="user_created_by", type="integer", nullable=true)
     */
    private $userCreatedBy = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="define_view", type="string", length=64, nullable=true)
     */
    private $defineView = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="phone", type="string", length=128, nullable=false)
     */
    private $phone;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="reg_date", type="datetime", nullable=false)
     */
    private $regDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="last_time", type="datetime", nullable=true)
     */
    private $lastTime = 'NULL';

    /**
     * @var integer
     *
     * @ORM\Column(name="disable", type="integer", nullable=true)
     */
    private $disable = '0';

    /**
     * @var string
     *
     * @ORM\Column(name="reset_key", type="string", length=255, nullable=false)
     */
    private $resetKey;

    /**
     * @var integer
     *
     * @ORM\Column(name="temp_allow", type="integer", nullable=false)
     */
    private $tempAllow = '0';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="temp_allow_time", type="datetime", nullable=true)
     */
    private $tempAllowTime = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="address", type="string", length=255, nullable=true)
     */
    private $address = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="city", type="string", length=32, nullable=true)
     */
    private $city = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="state", type="string", length=32, nullable=true)
     */
    private $state = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="country", type="string", length=32, nullable=true)
     */
    private $country = 'NULL';

    /**
     * @var integer
     *
     * @ORM\Column(name="location", type="integer", nullable=true)
     */
    private $location;

    /**
     * @var string
     *
     * @ORM\Column(name="profile_image_path", type="string", length=255, nullable=true)
     */
    private $profileImagePath = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="councils", type="string", length=65, nullable=true)
     */
    private $councils = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="business", type="string", length=65, nullable=true)
     */
    private $business = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="projects", type="string", length=65, nullable=true)
     */
    private $projects = 'NULL';
	
	/**
     * @var integer
     *
     * @ORM\Column(name="only_door_module_user", type="integer", nullable=false, options={"default":0})
     */
    private $onlyDoorModuleUser = self::Only_DOOR_MODULE_USER;

    /**
     * @var integer
     *
     * @ORM\Column(name="door_module_access", type="integer", nullable=false, options={"default":0})
     */
    private $doorModuleAccess = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="door_module_usertype", type="integer", nullable=false, options={"default":0})
     */
    private $doorModuleUsertype = self::DOORMODULEUSERTYPE_USER;

    /**
     * @var integer
     *
     * @ORM\Column(name="energy_module_access", type="integer", nullable=false, options={"default":0})
     */
    private $energyModuleAccess = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="energy_module_usertype", type="integer", nullable=false, options={"default":0})
     */
    private $energyModuleUsertype = self::ENERGYMODULEUSERTYPE_USER;

    /**
     * @var integer
     *
     * @ORM\Column(name="device_module_access", type="integer", nullable=false, options={"default":0})
     */
    private $deviceModuleAccess = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="device_module_usertype", type="integer", nullable=false, options={"default":0})
     */
    private $deviceModuleUsertype = self::DEVICEMODULEUSERTYPE_USER;
	
	/**
     * @var integer
     *
     * @ORM\Column(name="water_module_access", type="integer", nullable=false, options={"default":0})
     */
    private $waterModuleAccess = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="water_module_usertype", type="integer", nullable=false, options={"default":0})
     */
    private $waterModuleUsertype = self::WATERMODULEUSERTYPE_USER;

    /**
     * @var integer
     *
     * @ORM\Column(name="capacity_module_access", type="integer", nullable=false, options={"default":0})
     */
    private $capacityModuleAccess = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="capacity_module_usertype", type="integer", nullable=false, options={"default":0})
     */
    private $capacityModuleUsertype = self::CAPACITYMODULEUSERTYPE_USER;
	
	/**
     * @var integer
     *
     * @ORM\Column(name="irrigation_module_access", type="integer", nullable=false, options={"default":0})
     */
    private $irrigationModuleAccess = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="irrigation_module_usertype", type="integer", nullable=false, options={"default":0})
     */
    private $irrigationModuleUsertype = self::IRRIGATIONMODULEUSERTYPE_USER;
	
	/**
     * @var integer
     *
     * @ORM\Column(name="generic_module_access", type="integer", nullable=false, options={"default":0})
     */
    private $genericModuleAccess = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="generic_module_usertype", type="integer", nullable=false, options={"default":0})
     */
    private $genericModuleUsertype = self::GENERICMODULEUSERTYPE_USER;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_dt", type="datetime", nullable=false)
     */
    private $createdDt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_dt", type="datetime", nullable=false)
     */
    private $updatedDt;

	/**
     * Constructor
     */
    public function __construct()
    {
		$this->regDate = new \DateTime();
		$this->lastTime = new \DateTime();
		$this->tempAllowTime = new \DateTime();
		$this->createdDt = new \DateTime();
		$this->updatedDt = new \DateTime();
		$this->permission = 3;
		$this->onlyDoorModuleUser = 0;
		$this->disable = 0;
		$this->tempAllow = 0;
    }

	public function __toString(){
		return $this->email;
	}

    /**
     * Set email
     *
     * @param string $email
     *
     * @return Users
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set pwd
     *
     * @param string $pwd
     *
     * @return Users
     */
    public function setPwd($pwd)
    {
        $this->pwd = $pwd;

        return $this;
    }

    /**
     * Get pwd
     *
     * @return string
     */
    public function getPwd()
    {
        return $this->pwd;
    }

    /**
     * Set userName
     *
     * @param string $userName
     *
     * @return Users
     */
    public function setUserName($userName)
    {
        $this->userName = $userName;

        return $this;
    }

    /**
     * Get userName
     *
     * @return string
     */
    public function getUserName()
    {
        return $this->userName;
    }

    /**
     * Set firstName
     *
     * @param string $firstName
     *
     * @return Users
     */
    public function setFirstName($firstName)
    {
        $this->firstName = $firstName;

        return $this;
    }

    /**
     * Get firstName
     *
     * @return string
     */
    public function getFirstName()
    {
        return $this->firstName;
    }

    /**
     * Set lastName
     *
     * @param string $lastName
     *
     * @return Users
     */
    public function setLastName($lastName)
    {
        $this->lastName = $lastName;

        return $this;
    }

    /**
     * Get lastName
     *
     * @return string
     */
    public function getLastName()
    {
        return $this->lastName;
    }

    /**
     * Set permission
     *
     * @param integer $permission
     *
     * @return Users
     */
    public function setPermission($permission)
    {
        $this->permission = $permission;

        return $this;
    }

    /**
     * Get permission
     *
     * @return integer
     */
    public function getPermission()
    {
        return $this->permission;
    }

    /**
     * Set underAdmin
     *
     * @param integer $underAdmin
     *
     * @return Users
     */
    public function setUnderAdmin($underAdmin)
    {
        $this->underAdmin = $underAdmin;

        return $this;
    }

    /**
     * Get underAdmin
     *
     * @return integer
     */
    public function getUnderAdmin()
    {
        return $this->underAdmin;
    }

    /**
     * Set userCreatedBy
     *
     * @param integer $userCreatedBy
     *
     * @return Users
     */
    public function setUserCreatedBy($userCreatedBy)
    {
        $this->userCreatedBy = $userCreatedBy;

        return $this;
    }

    /**
     * Get userCreatedBy
     *
     * @return integer
     */
    public function getUserCreatedBy()
    {
        return $this->userCreatedBy;
    }

    /**
     * Set defineView
     *
     * @param string $defineView
     *
     * @return Users
     */
    public function setDefineView($defineView)
    {
        $this->defineView = $defineView;

        return $this;
    }

    /**
     * Get defineView
     *
     * @return string
     */
    public function getDefineView()
    {
        return $this->defineView;
    }

    /**
     * Set phone
     *
     * @param string $phone
     *
     * @return Users
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;

        return $this;
    }

    /**
     * Get phone
     *
     * @return string
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * Set regDate
     *
     * @param \DateTime $regDate
     *
     * @return Users
     */
    public function setRegDate($regDate)
    {
        $this->regDate = $regDate;

        return $this;
    }

    /**
     * Get regDate
     *
     * @return \DateTime
     */
    public function getRegDate()
    {
        return $this->regDate;
    }

    /**
     * Set lastTime
     *
     * @param \DateTime $lastTime
     *
     * @return Users
     */
    public function setLastTime($lastTime)
    {
        $this->lastTime = $lastTime;

        return $this;
    }

    /**
     * Get lastTime
     *
     * @return \DateTime
     */
    public function getLastTime()
    {
        return $this->lastTime;
    }

    /**
     * Set disable
     *
     * @param integer $disable
     *
     * @return Users
     */
    public function setDisable($disable)
    {
        $this->disable = $disable;

        return $this;
    }

    /**
     * Get disable
     *
     * @return integer
     */
    public function getDisable()
    {
        return $this->disable;
    }

    /**
     * Set resetKey
     *
     * @param string $resetKey
     *
     * @return Users
     */
    public function setResetKey($resetKey)
    {
        $this->resetKey = $resetKey;

        return $this;
    }

    /**
     * Get resetKey
     *
     * @return string
     */
    public function getResetKey()
    {
        return $this->resetKey;
    }

    /**
     * Set tempAllow
     *
     * @param integer $tempAllow
     *
     * @return Users
     */
    public function setTempAllow($tempAllow)
    {
        $this->tempAllow = $tempAllow;

        return $this;
    }

    /**
     * Get tempAllow
     *
     * @return integer
     */
    public function getTempAllow()
    {
        return $this->tempAllow;
    }

    /**
     * Set tempAllowTime
     *
     * @param \DateTime $tempAllowTime
     *
     * @return Users
     */
    public function setTempAllowTime($tempAllowTime)
    {
        $this->tempAllowTime = $tempAllowTime;

        return $this;
    }

    /**
     * Get tempAllowTime
     *
     * @return \DateTime
     */
    public function getTempAllowTime()
    {
        return $this->tempAllowTime;
    }

    /**
     * Set address
     *
     * @param string $address
     *
     * @return Users
     */
    public function setAddress($address)
    {
        $this->address = $address;

        return $this;
    }

    /**
     * Get address
     *
     * @return string
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * Set city
     *
     * @param string $city
     *
     * @return Users
     */
    public function setCity($city)
    {
        $this->city = $city;

        return $this;
    }

    /**
     * Get city
     *
     * @return string
     */
    public function getCity()
    {
        return $this->city;
    }

    /**
     * Set state
     *
     * @param string $state
     *
     * @return Users
     */
    public function setState($state)
    {
        $this->state = $state;

        return $this;
    }

    /**
     * Get state
     *
     * @return string
     */
    public function getState()
    {
        return $this->state;
    }

    /**
     * Set country
     *
     * @param string $country
     *
     * @return Users
     */
    public function setCountry($country)
    {
        $this->country = $country;

        return $this;
    }

    /**
     * Get country
     *
     * @return string
     */
    public function getCountry()
    {
        return $this->country;
    }

    /**
     * Set location
     *
     * @param integer $location
     *
     * @return Users
     */
    public function setLocation($location)
    {
        $this->location = $location;

        return $this;
    }

    /**
     * Get location
     *
     * @return integer
     */
    public function getLocation()
    {
        return $this->location;
    }

    /**
     * Set profileImagePath
     *
     * @param string $profileImagePath
     *
     * @return Users
     */
    public function setProfileImagePath($profileImagePath)
    {
        $this->profileImagePath = $profileImagePath;

        return $this;
    }

    /**
     * Get profileImagePath
     *
     * @return string
     */
    public function getProfileImagePath()
    {
        return $this->profileImagePath;
    }

    /**
     * Set councils
     *
     * @param string $councils
     *
     * @return Users
     */
    public function setCouncils($councils)
    {
        $this->councils = $councils;

        return $this;
    }

    /**
     * Get councils
     *
     * @return string
     */
    public function getCouncils()
    {
        return $this->councils;
    }

    /**
     * Set business
     *
     * @param string $business
     *
     * @return Users
     */
    public function setBusiness($business)
    {
        $this->business = $business;

        return $this;
    }

    /**
     * Get business
     *
     * @return string
     */
    public function getBusiness()
    {
        return $this->business;
    }

    /**
     * Set projects
     *
     * @param string $projects
     *
     * @return Users
     */
    public function setProjects($projects)
    {
        $this->projects = $projects;

        return $this;
    }

    /**
     * Get projects
     *
     * @return string
     */
    public function getProjects()
    {
        return $this->projects;
    }
	
	/**
     * Set onlyDoorModuleUser
     *
     * @param integer $onlyDoorModuleUser
     *
     * @return Users
     */
    public function setOnlyDoorModuleUser($onlyDoorModuleUser)
    {
        $this->onlyDoorModuleUser = $onlyDoorModuleUser;

        return $this;
    }

    /**
     * Get onlyDoorModuleUser
     *
     * @return integer
     */
    public function getOnlyDoorModuleUser()
    {
        return $this->onlyDoorModuleUser;
    } 

    /**
     * Set doorModuleAccess
     *
     * @param integer $doorModuleAccess
     *
     * @return Users
     */
    public function setDoorModuleAccess($doorModuleAccess)
    {
        $this->doorModuleAccess = $doorModuleAccess;

        return $this;
    }

    /**
     * Get doorModuleAccess
     *
     * @return integer
     */
    public function getDoorModuleAccess()
    {
        return $this->doorModuleAccess;
    }

    /**
     * Set doorModuleUsertype
     *
     * @param integer $doorModuleUsertype
     *
     * @return Users
     */
    public function setDoorModuleUsertype($doorModuleUsertype)
    {
        $this->doorModuleUsertype = $doorModuleUsertype;

        return $this;
    }

    /**
     * Get doorModuleUsertype
     *
     * @return integer
     */
    public function getDoorModuleUsertype()
    {
        return $this->doorModuleUsertype;
    }

    /**
     * Set energyModuleAccess
     *
     * @param integer $energyModuleAccess
     *
     * @return Users
     */
    public function setEnergyModuleAccess($energyModuleAccess)
    {
        $this->energyModuleAccess = $energyModuleAccess;

        return $this;
    }

    /**
     * Get energyModuleAccess
     *
     * @return integer
     */
    public function getEnergyModuleAccess()
    {
        return $this->energyModuleAccess;
    }

    /**
     * Set energyModuleUsertype
     *
     * @param integer $energyModuleUsertype
     *
     * @return Users
     */
    public function setEnergyModuleUsertype($energyModuleUsertype)
    {
        $this->energyModuleUsertype = $energyModuleUsertype;

        return $this;
    }

    /**
     * Get energyModuleUsertype
     *
     * @return integer
     */
    public function getEnergyModuleUsertype()
    {
        return $this->energyModuleUsertype;
    }

    /**
     * Set deviceModuleAccess
     *
     * @param integer $deviceModuleAccess
     *
     * @return Users
     */
    public function setDeviceModuleAccess($deviceModuleAccess)
    {
        $this->deviceModuleAccess = $deviceModuleAccess;

        return $this;
    }

    /**
     * Get deviceModuleAccess
     *
     * @return integer
     */
    public function getDeviceModuleAccess()
    {
        return $this->deviceModuleAccess;
    }

    /**
     * Set deviceModuleUsertype
     *
     * @param integer $deviceModuleUsertype
     *
     * @return Users
     */
    public function setDeviceModuleUsertype($deviceModuleUsertype)
    {
        $this->deviceModuleUsertype = $deviceModuleUsertype;

        return $this;
    }

    /**
     * Get deviceModuleUsertype
     *
     * @return integer
     */
    public function getDeviceModuleUsertype()
    {
        return $this->deviceModuleUsertype;
    }
	
	/**
     * Set waterModuleAccess
     *
     * @param integer $waterModuleAccess
     *
     * @return Users
     */
    public function setWaterModuleAccess($waterModuleAccess)
    {
        $this->waterModuleAccess = $waterModuleAccess;

        return $this;
    }

    /**
     * Get waterModuleAccess
     *
     * @return integer
     */
    public function getWaterModuleAccess()
    {
        return $this->waterModuleAccess;
    }

    /**
     * Set waterModuleUsertype
     *
     * @param integer $waterModuleUsertype
     *
     * @return Users
     */
    public function setWaterModuleUsertype($waterModuleUsertype)
    {
        $this->waterModuleUsertype = $waterModuleUsertype;

        return $this;
    }

    /**
     * Get waterModuleUsertype
     *
     * @return integer
     */
    public function getWaterModuleUsertype()
    {
        return $this->waterModuleUsertype;
    }

    //
    /**
     * Set capacityModuleAccess
     *
     * @param integer $capacityModuleAccess
     *
     * @return Users
     */
    public function setCapacityModuleAccess($capacityModuleAccess)
    {
        $this->capacityModuleAccess = $capacityModuleAccess;

        return $this;
    }

    /**
     * Get capacityModuleAccess
     *
     * @return integer
     */
    public function getCapacityModuleAccess()
    {
        return $this->capacityModuleAccess;
    }

    /**
     * Set capacityModuleUsertype
     *
     * @param integer $capacityModuleUsertype
     *
     * @return Users
     */
    public function setCapacityModuleUsertype($capacityModuleUsertype)
    {
        $this->capacityModuleUsertype = $capacityModuleUsertype;

        return $this;
    }

    /**
     * Get capacityModuleUsertype
     *
     * @return integer
     */
    public function getCapacityModuleUsertype()
    {
        return $this->capacityModuleUsertype;
    }
	
	/**
     * Set irrigationModuleAccess
     *
     * @param integer $irrigationModuleAccess
     *
     * @return Users
     */
    public function setIrrigationModuleAccess($irrigationModuleAccess)
    {
        $this->irrigationModuleAccess = $irrigationModuleAccess;

        return $this;
    }

    /**
     * Get irrigationModuleAccess
     *
     * @return integer
     */
    public function getIrrigationModuleAccess()
    {
        return $this->irrigationModuleAccess;
    }

    /**
     * Set irrigationModuleUsertype
     *
     * @param integer $irrigationModuleUsertype
     *
     * @return Users
     */
    public function setIrrigationModuleUsertype($irrigationModuleUsertype)
    {
        $this->irrigationModuleUsertype = $irrigationModuleUsertype;

        return $this;
    }

    /**
     * Get irrigationModuleUsertype
     *
     * @return integer
     */
    public function getIrrigationModuleUsertype()
    {
        return $this->irrigationModuleUsertype;
    }
	
	/**
     * Set genericModuleAccess
     *
     * @param integer $genericModuleAccess
     *
     * @return Users
     */
    public function setGenericModuleAccess($genericModuleAccess)
    {
        $this->genericModuleAccess = $genericModuleAccess;

        return $this;
    }

    /**
     * Get genericModuleAccess
     *
     * @return integer
     */
    public function getGenericModuleAccess()
    {
        return $this->genericModuleAccess;
    }
	
	/**
     * Set genericModuleUsertype
     *
     * @param integer $genericModuleUsertype
     *
     * @return Users
     */
    public function setGenericModuleUsertype($genericModuleUsertype)
    {
        $this->genericModuleUsertype = $genericModuleUsertype;

        return $this;
    }

    /**
     * Get genericModuleUsertype
     *
     * @return integer
     */
    public function getGenericModuleUsertype()
    {
        return $this->genericModuleUsertype;
    }


    /**
     * Set createdDt
     *
     * @param \DateTime $createdDt
     *
     * @return Users
     */
    public function setCreatedDt($createdDt)
    {
        $this->createdDt = $createdDt;

        return $this;
    }

    /**
     * Get createdDt
     *
     * @return \DateTime
     */
    public function getCreatedDt()
    {
        return $this->createdDt;
    }

    /**
     * Set updatedDt
     *
     * @param \DateTime $updatedDt
     *
     * @return Users
     */
    public function setUpdatedDt($updatedDt)
    {
        $this->updatedDt = $updatedDt;

        return $this;
    }

    /**
     * Get updatedDt
     *
     * @return \DateTime
     */
    public function getUpdatedDt()
    {
        return $this->updatedDt;
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }
}
