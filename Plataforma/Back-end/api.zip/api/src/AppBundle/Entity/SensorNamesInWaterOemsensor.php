<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Validator\Constraints\DateTime;

/**
 * SensorNamesInWaterOemsensor
 *
 * @ORM\Table(name="sensor_names_in_water_oemsensor")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\SensorTypeIboxPayloadRepository")
 * @UniqueEntity(
 *     fields={"id"},
 *     message="The sensor name of water sensor id is already used."
 * )
 */
class SensorNamesInWaterOemsensor
{
	/**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;
	
	/**
     * @var string
     *
     * @ORM\Column(name="indexat", type="string", length=128, nullable=true)
     */
    private $indexat;
	
	/**
     * @var string
     *
     * @ORM\Column(name="sensor_name", type="string", length=64, nullable=true)
     */
    private $sensorName;
	
	/**
     * @var int
     *
     * @ORM\Column(name="sensor_id", type="integer", nullable=true)
     */
    private $sensorId;
	
	/**
     * @var string
     *
     * @ORM\Column(name="sensor_model_name", type="string", length=128, nullable=true)
     */
    private $sensorModelName;
	
	/**
     * @var datetime
     *
     * @ORM\Column(name="created_dt", type="datetime", nullable=true)
     */
    private $createdDt;
	/**
     * @var datetime
     *
     * @ORM\Column(name="updated_dt", type="datetime", nullable=true)
     */
    private $updatedDt;
	
	/**
     * @ORM\PrePersist
     */
    public function setCreatedDtValue()
    {
        $this->createdDt = new \DateTime();
    }

    /**
     * @ORM\PreUpdate
     */
    public function setUpdatedDtValue()
    {
        $this->updatedDt = new \DateTime();
    }
	
	

	/**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }
	
	/**
     * Set indexat
     *
     * @param string $indexat
     *
     * @return SensorNamesInWaterOemsensor
     */
    public function setIndexat($indexat)
    {
        $this->indexat = $indexat;

        return $this;
    }

    /**
     * Get indexat
     *
     * @return string
     */
    public function getIndexat()
    {
        return $this->indexat;
    }
	
	/**
     * Set sensorName
     *
     * @param string $sensorName
     *
     * @return SensorNamesInWaterOemsensor
     */
    public function setSensorName($sensorName)
    {
        $this->sensorName = $sensorName;

        return $this;
    }

    /**
     * Get sensorName
     *
     * @return string
     */
    public function getSensorName()
    {
        return $this->sensorName;
    }
	
	/**
     * Set sensorId
     *
     * @param integer $sensorId
     *
     * @return SensorNamesInWaterOemsensor
     */
    public function setSensorId($sensorId)
    {
        $this->sensorId = $sensorId;

        return $this;
    }

    /**
     * Get sensorId
     *
     * @return integer
     */
    public function getSensorId()
    {
        return $this->sensorId;
    }
	
	/**
     * Set sensorModelName
     *
     * @param string $sensorModelName
     *
     * @return SensorNamesInWaterOemsensor
     */
    public function setSensorModelName($sensorModelName)
    {
        $this->sensorModelName = $sensorModelName;

        return $this;
    }

    /**
     * Get sensorModelName
     *
     * @return string
     */
    public function getSensorModelName()
    {
        return $this->sensorModelName;
    }
	
	/**
     * Set createdDt
     *
     * @param \DateTime $createdDt
     *
     * @return SensorNamesInWaterOemsensor
     */
    public function setCreatedDt($createdDt)
    {
        $this->createdDt = $createdDt;

        return $this;
    }

    /**
     * Get createdDt
     *
     * @return \DateTime
     */
    public function getCreatedDt()
    {
        return $this->createdDt;
    }

    /**
     * Set updatedDt
     *
     * @param \DateTime $updatedDt
     *
     * @return SensorNamesInWaterOemsensor
     */
    public function setUpdatedDt($updatedDt)
    {
        $this->updatedDt = $updatedDt;

        return $this;
    }

    /**
     * Get updatedDt
     *
     * @return \DateTime
     */
    public function getUpdatedDt()
    {
        return $this->updatedDt;
    }
	
}
?>