<?php
namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Validator\Constraints\DateTime;

/**
 * SensorGatewayPkid
 *
 * @ORM\Table(name="sensor_gateway_pkid")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\UsersRepository")
 * @UniqueEntity(
 *     fields={"id"},
 *     message="The id is already used."
 * )
 */
class SensorGatewayPkid
{

//	const ESTADO_INICIAL = 1;
//	const ESTADO_ALARMAS_INICIAL = 1;

    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;	
	/**
     * @var string
     *
     * @ORM\Column(name="mac_number", type="string", length=255, nullable=true)
     */
    private $macNumber;
	/**
     * @var integer
     *
     * @ORM\Column(name="sensor_id", type="integer")
     */
    private $sensorId;
	/**
     * @var integer
     *
     * @ORM\Column(name="pk_id", type="integer")
     */
    private $pkId;
	
	/**
     * Constructor
     */
    public function __construct()
    {		
		
    }

	/**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }	
	
	/**
     * Set macNumber
     *
     * @param string $macNumber
     *
     * @return SensorGatewayPkid
     */
    public function setMacNumber($macNumber)
    {
        $this->macNumber = $macNumber;

        return $this;
    }

    /**
     * Get macNumber
     *
     * @return string
     */
    public function getMacNumber()
    {
        return $this->macNumber;
    }
	
	/**
     * Set sensorId
     *
     * @param integer $sensorId
     *
     * @return SensorGatewayPkid
     */
    public function setSensorId($sensorId)
    {
        $this->sensorId = $sensorId;

        return $this;
    }

    /**
     * Get sensorId
     *
     * @return integer
     */
    public function getSensorId()
    {
        return $this->sensorId;
    }
	
	/**
     * Set pkId
     *
     * @param integer $pkId
     *
     * @return SensorGatewayPkid
     */
    public function setPkId($pkId)
    {
        $this->pkId = $pkId;

        return $this;
    }

    /**
     * Get pkId
     *
     * @return integer
     */
    public function getPkId()
    {
        return $this->pkId;
    }
}	
?>