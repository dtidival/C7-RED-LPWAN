<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Validator\Constraints\DateTime;

/**
 * SensorServerDetail
 *
 * @ORM\Table(name="sensor_server_detail")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\UsersRepository")
 * @UniqueEntity(
 *     fields={"id"},
 *     message="The user id is already used."
 * )
 */
class SensorServerDetail
{

//	const ESTADO_INICIAL = 1;
//	const ESTADO_ALARMAS_INICIAL = 1;

    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

	/**
     * @var integer
     *
     * @ORM\Column(name="server_id", type="integer", nullable=true)
     */
    private $serverId;
	
	/**
     * @var integer
     *
     * @ORM\Column(name="sensor_id", type="integer", nullable=true)
     */
    private $sensorId;

    /**
     * @var string
     *
     * @ORM\Column(name="sensor_name", type="string", length=64, nullable=true)
     */
    private $sensorName;
	
	/**
     * @var string
     *
     * @ORM\Column(name="varnames", type="string", length=64,  nullable=true)
     */
    private $varnames;
   

	/**
     * @var datetime
     *
     * @ORM\Column(name="created_dt", type="datetime", nullable=true)
     */
    private $createdDt;
	/**
     * @var datetime
     *
     * @ORM\Column(name="updated_dt", type="datetime", nullable=true)
     */
    private $updatedDt;
	

    /**
     * Constructor
     */
    public function __construct()
    {		
		$this->createdDt = new \DateTime();
		$this->updatedDt = new \DateTime();
		
    }


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set serverId
     *
     * @param integer $serverId
     *
     * @return SensorServerDetail
     */
    public function setServerId($serverId)
    {
        $this->serverId = $serverId;

        return $this;
    }

    /**
     * Get serverId
     *
     * @return integer
     */
    public function getServerId()
    {
        return $this->serverId;
    }

    /**
     * Set sensorId
     *
     * @param integer $sensorId
     *
     * @return SensorServerDetail
     */
    public function setSensorId($sensorId)
    {
        $this->sensorId = $sensorId;

        return $this;
    }

    /**
     * Get sensorId
     *
     * @return integer
     */
    public function getSensorId()
    {
        return $this->sensorId;
    }

    /**
     * Set sensorName
     *
     * @param string $sensorName
     *
     * @return SensorServerDetail
     */
    public function setSensorName($sensorName)
    {
        $this->sensorName = $sensorName;

        return $this;
    }

    /**
     * Get sensorName
     *
     * @return string
     */
    public function getSensorName()
    {
        return $this->sensorName;
    }

    /**
     * Set varnames
     *
     * @param string $varnames
     *
     * @return SensorServerDetail
     */
    public function setVarnames($varnames)
    {
        $this->varnames = $varnames;

        return $this;
    }

    /**
     * Get varnames
     *
     * @return string
     */
    public function getVarnames()
    {
        return $this->varnames;
    }

    /**
     * Set createdDt
     *
     * @param \DateTime $createdDt
     *
     * @return SensorServerDetail
     */
    public function setCreatedDt($createdDt)
    {
        $this->createdDt = $createdDt;

        return $this;
    }

    /**
     * Get createdDt
     *
     * @return \DateTime
     */
    public function getCreatedDt()
    {
        return $this->createdDt;
    }

    /**
     * Set updatedDt
     *
     * @param \DateTime $updatedDt
     *
     * @return SensorServerDetail
     */
    public function setUpdatedDt($updatedDt)
    {
        $this->updatedDt = $updatedDt;

        return $this;
    }

    /**
     * Get updatedDt
     *
     * @return \DateTime
     */
    public function getUpdatedDt()
    {
        return $this->updatedDt;
    }
}
