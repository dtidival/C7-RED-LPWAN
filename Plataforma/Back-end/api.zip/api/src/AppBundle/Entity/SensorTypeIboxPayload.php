<?php
namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * SensorTypeIboxPayload
 *
 * @ORM\Table(name="sensor_type_ibox_payload")
 * @ORM\Entity
 */
class SensorTypeIboxPayload
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="sensor_type_info_id", type="integer", nullable=true)
     */
    private $sensorTypeInfoId = 'NULL';

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_input", type="boolean", nullable=false)
     */
    private $isInput;

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_meter", type="boolean", nullable=false)
     */
    private $isMeter;

    /**
     * @var integer
     *
     * @ORM\Column(name="input_number", type="integer", nullable=true)
     */
    private $inputNumber;

    /**
     * @var string
     *
     * @ORM\Column(name="input_name", type="string", length=64, nullable=true)
     */
    private $inputName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="input_description", type="string", length=255, nullable=true)
     */
    private $inputDescription = 'NULL';

    /**
     * @var integer
     *
     * @ORM\Column(name="meter_number", type="integer", nullable=true)
     */
    private $meterNumber;

    /**
     * @var string
     *
     * @ORM\Column(name="volt_r_sensor_name", type="string", length=64, nullable=true)
     */
    private $voltRSensorName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="volt_r_sensor_name_desc", type="string", length=64, nullable=true)
     */
    private $voltRSensorNameDesc = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="volt_s_sensor_name", type="string", length=64, nullable=true)
     */
    private $voltSSensorName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="volt_s_sensor_name_desc", type="string", length=64, nullable=true)
     */
    private $voltSSensorNameDesc = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="volt_t_sensor_name", type="string", length=64, nullable=true)
     */
    private $voltTSensorName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="volt_t_sensor_name_desc", type="string", length=64, nullable=true)
     */
    private $voltTSensorNameDesc = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="current_r_sensor_name", type="string", length=64, nullable=true)
     */
    private $currentRSensorName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="current_r_sensor_name_desc", type="string", length=64, nullable=true)
     */
    private $currentRSensorNameDesc = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="current_s_sensor_name", type="string", length=64, nullable=true)
     */
    private $currentSSensorName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="current_s_sensor_name_desc", type="string", length=64, nullable=true)
     */
    private $currentSSensorNameDesc = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="current_t_sensor_name", type="string", length=64, nullable=true)
     */
    private $currentTSensorName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="current_t_sensor_name_desc", type="string", length=64, nullable=true)
     */
    private $currentTSensorNameDesc = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="power_all_name", type="string", length=64, nullable=true)
     */
    private $powerAllName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="power_all_name_desc", type="string", length=64, nullable=true)
     */
    private $powerAllNameDesc = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="power_r_name", type="string", length=64, nullable=true)
     */
    private $powerRName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="power_r_name_desc", type="string", length=64, nullable=true)
     */
    private $powerRNameDesc = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="power_s_name", type="string", length=64, nullable=true)
     */
    private $powerSName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="power_s_name_desc", type="string", length=64, nullable=true)
     */
    private $powerSNameDesc = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="power_t_name", type="string", length=64, nullable=true)
     */
    private $powerTName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="power_t_name_desc", type="string", length=64, nullable=true)
     */
    private $powerTNameDesc = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="pf_all_name", type="string", length=64, nullable=true)
     */
    private $pfAllName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="pf_all_name_desc", type="string", length=64, nullable=true)
     */
    private $pfAllNameDesc = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="pf_r_name", type="string", length=64, nullable=true)
     */
    private $pfRName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="pf_r_name_desc", type="string", length=64, nullable=true)
     */
    private $pfRNameDesc = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="pf_s_name", type="string", length=64, nullable=true)
     */
    private $pfSName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="pf_s_name_desc", type="string", length=64, nullable=true)
     */
    private $pfSNameDesc = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="pf_t_name", type="string", length=64, nullable=true)
     */
    private $pfTName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="pf_t_name_desc", type="string", length=64, nullable=true)
     */
    private $pfTNameDesc = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="reactive_power_all_name", type="string", length=64, nullable=true)
     */
    private $reactivePowerAllName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="reactive_power_all_name_desc", type="string", length=64, nullable=true)
     */
    private $reactivePowerAllNameDesc = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="reactive_power_r_name", type="string", length=64, nullable=true)
     */
    private $reactivePowerRName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="reactive_power_r_name_desc", type="string", length=64, nullable=true)
     */
    private $reactivePowerRNameDesc = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="reactive_power_s_name", type="string", length=64, nullable=true)
     */
    private $reactivePowerSName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="reactive_power_s_name_desc", type="string", length=64, nullable=true)
     */
    private $reactivePowerSNameDesc = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="reactive_power_t_name", type="string", length=64, nullable=true)
     */
    private $reactivePowerTName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="reactive_power_t_name_desc", type="string", length=64, nullable=true)
     */
    private $reactivePowerTNameDesc = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="q1_sensor_name", type="string", length=64, nullable=true)
     */
    private $q1SensorName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="q1_sensor_name_desc", type="string", length=64, nullable=true)
     */
    private $q1SensorNameDesc = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="q2_sensor_name", type="string", length=64, nullable=true)
     */
    private $q2SensorName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="q2_sensor_name_desc", type="string", length=64, nullable=true)
     */
    private $q2SensorNameDesc = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="q3_sensor_name", type="string", length=64, nullable=true)
     */
    private $q3SensorName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="q3_sensor_name_desc", type="string", length=64, nullable=true)
     */
    private $q3SensorNameDesc = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="q4_sensor_name", type="string", length=64, nullable=true)
     */
    private $q4SensorName = 'NULL';

    /**
     * @var string
     *
     * @ORM\Column(name="q4_sensor_name_desc", type="string", length=64, nullable=true)
     */
    private $q4SensorNameDesc = 'NULL';

    /**
     * @var datetime
     *
     * @ORM\Column(name="created_dt", type="datetime", nullable=false)
     */
    private $createdDt = 'current_timestamp()';

    /**
     * @var datetime
     *
     * @ORM\Column(name="updated_dt", type="datetime", nullable=false)
     */
    private $updatedDt = 'current_timestamp()';

	/**
     * Constructor
     */
    public function __construct()
    {		
		$this->createdDt = new \DateTime();
		$this->updatedDt = new \DateTime();		
    }

    /**
     * Set sensorTypeInfoId
     *
     * @param integer $sensorTypeInfoId
     *
     * @return SensorTypeIboxPayload
     */
    public function setSensorTypeInfoId($sensorTypeInfoId)
    {
        $this->sensorTypeInfoId = $sensorTypeInfoId;

        return $this;
    }

    /**
     * Get sensorTypeInfoId
     *
     * @return integer
     */
    public function getSensorTypeInfoId()
    {
        return $this->sensorTypeInfoId;
    }

    /**
     * Set isInput
     *
     * @param boolean $isInput
     *
     * @return SensorTypeIboxPayload
     */
    public function setIsInput($isInput)
    {
        $this->isInput = $isInput;

        return $this;
    }

    /**
     * Get isInput
     *
     * @return boolean
     */
    public function getIsInput()
    {
        return $this->isInput;
    }

    /**
     * Set isMeter
     *
     * @param boolean $isMeter
     *
     * @return SensorTypeIboxPayload
     */
    public function setIsMeter($isMeter)
    {
        $this->isMeter = $isMeter;

        return $this;
    }

    /**
     * Get isMeter
     *
     * @return boolean
     */
    public function getIsMeter()
    {
        return $this->isMeter;
    }

    /**
     * Set inputNumber
     *
     * @param integer $inputNumber
     *
     * @return SensorTypeIboxPayload
     */
    public function setInputNumber($inputNumber)
    {
        $this->inputNumber = $inputNumber;

        return $this;
    }

    /**
     * Get inputNumber
     *
     * @return integer
     */
    public function getInputNumber()
    {
        return $this->inputNumber;
    }

    /**
     * Set inputName
     *
     * @param string $inputName
     *
     * @return SensorTypeIboxPayload
     */
    public function setInputName($inputName)
    {
        $this->inputName = $inputName;

        return $this;
    }

    /**
     * Get inputName
     *
     * @return string
     */
    public function getInputName()
    {
        return $this->inputName;
    }

    /**
     * Set inputDescription
     *
     * @param string $inputDescription
     *
     * @return SensorTypeIboxPayload
     */
    public function setInputDescription($inputDescription)
    {
        $this->inputDescription = $inputDescription;

        return $this;
    }

    /**
     * Get inputDescription
     *
     * @return string
     */
    public function getInputDescription()
    {
        return $this->inputDescription;
    }

    /**
     * Set meterNumber
     *
     * @param integer $meterNumber
     *
     * @return SensorTypeIboxPayload
     */
    public function setMeterNumber($meterNumber)
    {
        $this->meterNumber = $meterNumber;

        return $this;
    }

    /**
     * Get meterNumber
     *
     * @return integer
     */
    public function getMeterNumber()
    {
        return $this->meterNumber;
    }

    /**
     * Set voltRSensorName
     *
     * @param string $voltRSensorName
     *
     * @return SensorTypeIboxPayload
     */
    public function setVoltRSensorName($voltRSensorName)
    {
        $this->voltRSensorName = $voltRSensorName;

        return $this;
    }

    /**
     * Get voltRSensorName
     *
     * @return string
     */
    public function getVoltRSensorName()
    {
        return $this->voltRSensorName;
    }

    /**
     * Set voltRSensorNameDesc
     *
     * @param string $voltRSensorNameDesc
     *
     * @return SensorTypeIboxPayload
     */
    public function setVoltRSensorNameDesc($voltRSensorNameDesc)
    {
        $this->voltRSensorNameDesc = $voltRSensorNameDesc;

        return $this;
    }

    /**
     * Get voltRSensorNameDesc
     *
     * @return string
     */
    public function getVoltRSensorNameDesc()
    {
        return $this->voltRSensorNameDesc;
    }

    /**
     * Set voltSSensorName
     *
     * @param string $voltSSensorName
     *
     * @return SensorTypeIboxPayload
     */
    public function setVoltSSensorName($voltSSensorName)
    {
        $this->voltSSensorName = $voltSSensorName;

        return $this;
    }

    /**
     * Get voltSSensorName
     *
     * @return string
     */
    public function getVoltSSensorName()
    {
        return $this->voltSSensorName;
    }

    /**
     * Set voltSSensorNameDesc
     *
     * @param string $voltSSensorNameDesc
     *
     * @return SensorTypeIboxPayload
     */
    public function setVoltSSensorNameDesc($voltSSensorNameDesc)
    {
        $this->voltSSensorNameDesc = $voltSSensorNameDesc;

        return $this;
    }

    /**
     * Get voltSSensorNameDesc
     *
     * @return string
     */
    public function getVoltSSensorNameDesc()
    {
        return $this->voltSSensorNameDesc;
    }

    /**
     * Set voltTSensorName
     *
     * @param string $voltTSensorName
     *
     * @return SensorTypeIboxPayload
     */
    public function setVoltTSensorName($voltTSensorName)
    {
        $this->voltTSensorName = $voltTSensorName;

        return $this;
    }

    /**
     * Get voltTSensorName
     *
     * @return string
     */
    public function getVoltTSensorName()
    {
        return $this->voltTSensorName;
    }

    /**
     * Set voltTSensorNameDesc
     *
     * @param string $voltTSensorNameDesc
     *
     * @return SensorTypeIboxPayload
     */
    public function setVoltTSensorNameDesc($voltTSensorNameDesc)
    {
        $this->voltTSensorNameDesc = $voltTSensorNameDesc;

        return $this;
    }

    /**
     * Get voltTSensorNameDesc
     *
     * @return string
     */
    public function getVoltTSensorNameDesc()
    {
        return $this->voltTSensorNameDesc;
    }

    /**
     * Set currentRSensorName
     *
     * @param string $currentRSensorName
     *
     * @return SensorTypeIboxPayload
     */
    public function setCurrentRSensorName($currentRSensorName)
    {
        $this->currentRSensorName = $currentRSensorName;

        return $this;
    }

    /**
     * Get currentRSensorName
     *
     * @return string
     */
    public function getCurrentRSensorName()
    {
        return $this->currentRSensorName;
    }

    /**
     * Set currentRSensorNameDesc
     *
     * @param string $currentRSensorNameDesc
     *
     * @return SensorTypeIboxPayload
     */
    public function setCurrentRSensorNameDesc($currentRSensorNameDesc)
    {
        $this->currentRSensorNameDesc = $currentRSensorNameDesc;

        return $this;
    }

    /**
     * Get currentRSensorNameDesc
     *
     * @return string
     */
    public function getCurrentRSensorNameDesc()
    {
        return $this->currentRSensorNameDesc;
    }

    /**
     * Set currentSSensorName
     *
     * @param string $currentSSensorName
     *
     * @return SensorTypeIboxPayload
     */
    public function setCurrentSSensorName($currentSSensorName)
    {
        $this->currentSSensorName = $currentSSensorName;

        return $this;
    }

    /**
     * Get currentSSensorName
     *
     * @return string
     */
    public function getCurrentSSensorName()
    {
        return $this->currentSSensorName;
    }

    /**
     * Set currentSSensorNameDesc
     *
     * @param string $currentSSensorNameDesc
     *
     * @return SensorTypeIboxPayload
     */
    public function setCurrentSSensorNameDesc($currentSSensorNameDesc)
    {
        $this->currentSSensorNameDesc = $currentSSensorNameDesc;

        return $this;
    }

    /**
     * Get currentSSensorNameDesc
     *
     * @return string
     */
    public function getCurrentSSensorNameDesc()
    {
        return $this->currentSSensorNameDesc;
    }

    /**
     * Set currentTSensorName
     *
     * @param string $currentTSensorName
     *
     * @return SensorTypeIboxPayload
     */
    public function setCurrentTSensorName($currentTSensorName)
    {
        $this->currentTSensorName = $currentTSensorName;

        return $this;
    }

    /**
     * Get currentTSensorName
     *
     * @return string
     */
    public function getCurrentTSensorName()
    {
        return $this->currentTSensorName;
    }

    /**
     * Set currentTSensorNameDesc
     *
     * @param string $currentTSensorNameDesc
     *
     * @return SensorTypeIboxPayload
     */
    public function setCurrentTSensorNameDesc($currentTSensorNameDesc)
    {
        $this->currentTSensorNameDesc = $currentTSensorNameDesc;

        return $this;
    }

    /**
     * Get currentTSensorNameDesc
     *
     * @return string
     */
    public function getCurrentTSensorNameDesc()
    {
        return $this->currentTSensorNameDesc;
    }

    /**
     * Set powerAllName
     *
     * @param string $powerAllName
     *
     * @return SensorTypeIboxPayload
     */
    public function setPowerAllName($powerAllName)
    {
        $this->powerAllName = $powerAllName;

        return $this;
    }

    /**
     * Get powerAllName
     *
     * @return string
     */
    public function getPowerAllName()
    {
        return $this->powerAllName;
    }

    /**
     * Set powerAllNameDesc
     *
     * @param string $powerAllNameDesc
     *
     * @return SensorTypeIboxPayload
     */
    public function setPowerAllNameDesc($powerAllNameDesc)
    {
        $this->powerAllNameDesc = $powerAllNameDesc;

        return $this;
    }

    /**
     * Get powerAllNameDesc
     *
     * @return string
     */
    public function getPowerAllNameDesc()
    {
        return $this->powerAllNameDesc;
    }

    /**
     * Set powerRName
     *
     * @param string $powerRName
     *
     * @return SensorTypeIboxPayload
     */
    public function setPowerRName($powerRName)
    {
        $this->powerRName = $powerRName;

        return $this;
    }

    /**
     * Get powerRName
     *
     * @return string
     */
    public function getPowerRName()
    {
        return $this->powerRName;
    }

    /**
     * Set powerRNameDesc
     *
     * @param string $powerRNameDesc
     *
     * @return SensorTypeIboxPayload
     */
    public function setPowerRNameDesc($powerRNameDesc)
    {
        $this->powerRNameDesc = $powerRNameDesc;

        return $this;
    }

    /**
     * Get powerRNameDesc
     *
     * @return string
     */
    public function getPowerRNameDesc()
    {
        return $this->powerRNameDesc;
    }

    /**
     * Set powerSName
     *
     * @param string $powerSName
     *
     * @return SensorTypeIboxPayload
     */
    public function setPowerSName($powerSName)
    {
        $this->powerSName = $powerSName;

        return $this;
    }

    /**
     * Get powerSName
     *
     * @return string
     */
    public function getPowerSName()
    {
        return $this->powerSName;
    }

    /**
     * Set powerSNameDesc
     *
     * @param string $powerSNameDesc
     *
     * @return SensorTypeIboxPayload
     */
    public function setPowerSNameDesc($powerSNameDesc)
    {
        $this->powerSNameDesc = $powerSNameDesc;

        return $this;
    }

    /**
     * Get powerSNameDesc
     *
     * @return string
     */
    public function getPowerSNameDesc()
    {
        return $this->powerSNameDesc;
    }

    /**
     * Set powerTName
     *
     * @param string $powerTName
     *
     * @return SensorTypeIboxPayload
     */
    public function setPowerTName($powerTName)
    {
        $this->powerTName = $powerTName;

        return $this;
    }

    /**
     * Get powerTName
     *
     * @return string
     */
    public function getPowerTName()
    {
        return $this->powerTName;
    }

    /**
     * Set powerTNameDesc
     *
     * @param string $powerTNameDesc
     *
     * @return SensorTypeIboxPayload
     */
    public function setPowerTNameDesc($powerTNameDesc)
    {
        $this->powerTNameDesc = $powerTNameDesc;

        return $this;
    }

    /**
     * Get powerTNameDesc
     *
     * @return string
     */
    public function getPowerTNameDesc()
    {
        return $this->powerTNameDesc;
    }

    /**
     * Set pfAllName
     *
     * @param string $pfAllName
     *
     * @return SensorTypeIboxPayload
     */
    public function setPfAllName($pfAllName)
    {
        $this->pfAllName = $pfAllName;

        return $this;
    }

    /**
     * Get pfAllName
     *
     * @return string
     */
    public function getPfAllName()
    {
        return $this->pfAllName;
    }

    /**
     * Set pfAllNameDesc
     *
     * @param string $pfAllNameDesc
     *
     * @return SensorTypeIboxPayload
     */
    public function setPfAllNameDesc($pfAllNameDesc)
    {
        $this->pfAllNameDesc = $pfAllNameDesc;

        return $this;
    }

    /**
     * Get pfAllNameDesc
     *
     * @return string
     */
    public function getPfAllNameDesc()
    {
        return $this->pfAllNameDesc;
    }

    /**
     * Set pfRName
     *
     * @param string $pfRName
     *
     * @return SensorTypeIboxPayload
     */
    public function setPfRName($pfRName)
    {
        $this->pfRName = $pfRName;

        return $this;
    }

    /**
     * Get pfRName
     *
     * @return string
     */
    public function getPfRName()
    {
        return $this->pfRName;
    }

    /**
     * Set pfRNameDesc
     *
     * @param string $pfRNameDesc
     *
     * @return SensorTypeIboxPayload
     */
    public function setPfRNameDesc($pfRNameDesc)
    {
        $this->pfRNameDesc = $pfRNameDesc;

        return $this;
    }

    /**
     * Get pfRNameDesc
     *
     * @return string
     */
    public function getPfRNameDesc()
    {
        return $this->pfRNameDesc;
    }

    /**
     * Set pfSName
     *
     * @param string $pfSName
     *
     * @return SensorTypeIboxPayload
     */
    public function setPfSName($pfSName)
    {
        $this->pfSName = $pfSName;

        return $this;
    }

    /**
     * Get pfSName
     *
     * @return string
     */
    public function getPfSName()
    {
        return $this->pfSName;
    }

    /**
     * Set pfSNameDesc
     *
     * @param string $pfSNameDesc
     *
     * @return SensorTypeIboxPayload
     */
    public function setPfSNameDesc($pfSNameDesc)
    {
        $this->pfSNameDesc = $pfSNameDesc;

        return $this;
    }

    /**
     * Get pfSNameDesc
     *
     * @return string
     */
    public function getPfSNameDesc()
    {
        return $this->pfSNameDesc;
    }

    /**
     * Set pfTName
     *
     * @param string $pfTName
     *
     * @return SensorTypeIboxPayload
     */
    public function setPfTName($pfTName)
    {
        $this->pfTName = $pfTName;

        return $this;
    }

    /**
     * Get pfTName
     *
     * @return string
     */
    public function getPfTName()
    {
        return $this->pfTName;
    }

    /**
     * Set pfTNameDesc
     *
     * @param string $pfTNameDesc
     *
     * @return SensorTypeIboxPayload
     */
    public function setPfTNameDesc($pfTNameDesc)
    {
        $this->pfTNameDesc = $pfTNameDesc;

        return $this;
    }

    /**
     * Get pfTNameDesc
     *
     * @return string
     */
    public function getPfTNameDesc()
    {
        return $this->pfTNameDesc;
    }

    /**
     * Set reactivePowerAllName
     *
     * @param string $reactivePowerAllName
     *
     * @return SensorTypeIboxPayload
     */
    public function setReactivePowerAllName($reactivePowerAllName)
    {
        $this->reactivePowerAllName = $reactivePowerAllName;

        return $this;
    }

    /**
     * Get reactivePowerAllName
     *
     * @return string
     */
    public function getReactivePowerAllName()
    {
        return $this->reactivePowerAllName;
    }

    /**
     * Set reactivePowerAllNameDesc
     *
     * @param string $reactivePowerAllNameDesc
     *
     * @return SensorTypeIboxPayload
     */
    public function setReactivePowerAllNameDesc($reactivePowerAllNameDesc)
    {
        $this->reactivePowerAllNameDesc = $reactivePowerAllNameDesc;

        return $this;
    }

    /**
     * Get reactivePowerAllNameDesc
     *
     * @return string
     */
    public function getReactivePowerAllNameDesc()
    {
        return $this->reactivePowerAllNameDesc;
    }

    /**
     * Set reactivePowerRName
     *
     * @param string $reactivePowerRName
     *
     * @return SensorTypeIboxPayload
     */
    public function setReactivePowerRName($reactivePowerRName)
    {
        $this->reactivePowerRName = $reactivePowerRName;

        return $this;
    }

    /**
     * Get reactivePowerRName
     *
     * @return string
     */
    public function getReactivePowerRName()
    {
        return $this->reactivePowerRName;
    }

    /**
     * Set reactivePowerRNameDesc
     *
     * @param string $reactivePowerRNameDesc
     *
     * @return SensorTypeIboxPayload
     */
    public function setReactivePowerRNameDesc($reactivePowerRNameDesc)
    {
        $this->reactivePowerRNameDesc = $reactivePowerRNameDesc;

        return $this;
    }

    /**
     * Get reactivePowerRNameDesc
     *
     * @return string
     */
    public function getReactivePowerRNameDesc()
    {
        return $this->reactivePowerRNameDesc;
    }

    /**
     * Set reactivePowerSName
     *
     * @param string $reactivePowerSName
     *
     * @return SensorTypeIboxPayload
     */
    public function setReactivePowerSName($reactivePowerSName)
    {
        $this->reactivePowerSName = $reactivePowerSName;

        return $this;
    }

    /**
     * Get reactivePowerSName
     *
     * @return string
     */
    public function getReactivePowerSName()
    {
        return $this->reactivePowerSName;
    }

    /**
     * Set reactivePowerSNameDesc
     *
     * @param string $reactivePowerSNameDesc
     *
     * @return SensorTypeIboxPayload
     */
    public function setReactivePowerSNameDesc($reactivePowerSNameDesc)
    {
        $this->reactivePowerSNameDesc = $reactivePowerSNameDesc;

        return $this;
    }

    /**
     * Get reactivePowerSNameDesc
     *
     * @return string
     */
    public function getReactivePowerSNameDesc()
    {
        return $this->reactivePowerSNameDesc;
    }

    /**
     * Set reactivePowerTName
     *
     * @param string $reactivePowerTName
     *
     * @return SensorTypeIboxPayload
     */
    public function setReactivePowerTName($reactivePowerTName)
    {
        $this->reactivePowerTName = $reactivePowerTName;

        return $this;
    }

    /**
     * Get reactivePowerTName
     *
     * @return string
     */
    public function getReactivePowerTName()
    {
        return $this->reactivePowerTName;
    }

    /**
     * Set reactivePowerTNameDesc
     *
     * @param string $reactivePowerTNameDesc
     *
     * @return SensorTypeIboxPayload
     */
    public function setReactivePowerTNameDesc($reactivePowerTNameDesc)
    {
        $this->reactivePowerTNameDesc = $reactivePowerTNameDesc;

        return $this;
    }

    /**
     * Get reactivePowerTNameDesc
     *
     * @return string
     */
    public function getReactivePowerTNameDesc()
    {
        return $this->reactivePowerTNameDesc;
    }

    /**
     * Set q1SensorName
     *
     * @param string $q1SensorName
     *
     * @return SensorTypeIboxPayload
     */
    public function setQ1SensorName($q1SensorName)
    {
        $this->q1SensorName = $q1SensorName;

        return $this;
    }

    /**
     * Get q1SensorName
     *
     * @return string
     */
    public function getQ1SensorName()
    {
        return $this->q1SensorName;
    }

    /**
     * Set q1SensorNameDesc
     *
     * @param string $q1SensorNameDesc
     *
     * @return SensorTypeIboxPayload
     */
    public function setQ1SensorNameDesc($q1SensorNameDesc)
    {
        $this->q1SensorNameDesc = $q1SensorNameDesc;

        return $this;
    }

    /**
     * Get q1SensorNameDesc
     *
     * @return string
     */
    public function getQ1SensorNameDesc()
    {
        return $this->q1SensorNameDesc;
    }

    /**
     * Set q2SensorName
     *
     * @param string $q2SensorName
     *
     * @return SensorTypeIboxPayload
     */
    public function setQ2SensorName($q2SensorName)
    {
        $this->q2SensorName = $q2SensorName;

        return $this;
    }

    /**
     * Get q2SensorName
     *
     * @return string
     */
    public function getQ2SensorName()
    {
        return $this->q2SensorName;
    }

    /**
     * Set q2SensorNameDesc
     *
     * @param string $q2SensorNameDesc
     *
     * @return SensorTypeIboxPayload
     */
    public function setQ2SensorNameDesc($q2SensorNameDesc)
    {
        $this->q2SensorNameDesc = $q2SensorNameDesc;

        return $this;
    }

    /**
     * Get q2SensorNameDesc
     *
     * @return string
     */
    public function getQ2SensorNameDesc()
    {
        return $this->q2SensorNameDesc;
    }

    /**
     * Set q3SensorName
     *
     * @param string $q3SensorName
     *
     * @return SensorTypeIboxPayload
     */
    public function setQ3SensorName($q3SensorName)
    {
        $this->q3SensorName = $q3SensorName;

        return $this;
    }

    /**
     * Get q3SensorName
     *
     * @return string
     */
    public function getQ3SensorName()
    {
        return $this->q3SensorName;
    }

    /**
     * Set q3SensorNameDesc
     *
     * @param string $q3SensorNameDesc
     *
     * @return SensorTypeIboxPayload
     */
    public function setQ3SensorNameDesc($q3SensorNameDesc)
    {
        $this->q3SensorNameDesc = $q3SensorNameDesc;

        return $this;
    }

    /**
     * Get q3SensorNameDesc
     *
     * @return string
     */
    public function getQ3SensorNameDesc()
    {
        return $this->q3SensorNameDesc;
    }

    /**
     * Set q4SensorName
     *
     * @param string $q4SensorName
     *
     * @return SensorTypeIboxPayload
     */
    public function setQ4SensorName($q4SensorName)
    {
        $this->q4SensorName = $q4SensorName;

        return $this;
    }

    /**
     * Get q4SensorName
     *
     * @return string
     */
    public function getQ4SensorName()
    {
        return $this->q4SensorName;
    }

    /**
     * Set q4SensorNameDesc
     *
     * @param string $q4SensorNameDesc
     *
     * @return SensorTypeIboxPayload
     */
    public function setQ4SensorNameDesc($q4SensorNameDesc)
    {
        $this->q4SensorNameDesc = $q4SensorNameDesc;

        return $this;
    }

    /**
     * Get q4SensorNameDesc
     *
     * @return string
     */
    public function getQ4SensorNameDesc()
    {
        return $this->q4SensorNameDesc;
    }

    /**
     * Set createdDt
     *
     * @param datetime $createdDt
     *
     * @return SensorTypeIboxPayload
     */
    public function setCreatedDt($createdDt)
    {
        $this->createdDt = $createdDt;

        return $this;
    }

    /**
     * Get createdDt
     *
     * @return datetime
     */
    public function getCreatedDt()
    {
        return $this->createdDt;
    }

    /**
     * Set updatedDt
     *
     * @param datetime $updatedDt
     *
     * @return SensorTypeIboxPayload
     */
    public function setUpdatedDt($updatedDt)
    {
        $this->updatedDt = $updatedDt;

        return $this;
    }

    /**
     * Get updatedDt
     *
     * @return datetime
     */
    public function getUpdatedDt()
    {
        return $this->updatedDt;
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }
}
