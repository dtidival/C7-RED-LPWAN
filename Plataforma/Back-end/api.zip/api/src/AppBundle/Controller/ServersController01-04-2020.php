<?php

namespace AppBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use AppBundle\Entity\Servers;
use AppBundle\Entity\Gateways;
use AppBundle\Entity\ServerMqqt;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Process\Process;
use Symfony\Component\Process\Exception\ProcessFailedException;
use Symfony\Component\Validator\Constraints\DateTime;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Normalizer\GetSetMethodNormalizer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Normalizer\DateTimeNormalizer;


/**
 * Servers controller.
 *
 * @Route("/servers")
 */
class ServersController extends Controller
{
	
	/**
     * List
     *                                                                                 
	 * @Route("/list", name="servers_list")
	 */
	public function ServersListApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();

		$serversList= $em 
			->getRepository('AppBundle:Servers')
			->findAll();
		
		$json = '';
		//var_dump($user);
		
		 if($serversList != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($serversList, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','servers_details' => $json));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','servers_details' => $json));
			//return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in server data'));
	}
	
	/**
     * Get Servers by Id
     *                                                                                 
	 * @Route("/getserverbyid", name="server_getserverbyid")
	 */
	public function getserverbyidApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$serverId = $data->id;
		
		$server= $em 
			->getRepository('AppBundle:Servers')
			->findBy(array('id' => $serverId));
		
		if( $server != null)
		{
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new GetSetMethodNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($server, 'json');
			
			return new JsonResponse(array('status' => 'Success','server_details' => $json));
		}
		else{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in getting server details!!'));
		} 
		
	}
	
	/**
     * Delete a Servers
     *                                                                                 
	 * @Route("/deleteserver", name="server_deleteserver")
	 */
	public function deleteServerApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());		
		$serverId = $data->id;	
		$server= $em 
			->getRepository('AppBundle:Servers')
			->findOneBy(array('id' => $serverId));
			
			$currentdatetime = new  \DateTime();
			
		if($server != null)
		{
			$pkId = $server->getPkId();
			$em->remove($server);
            $em->flush();
			$gatewaymac = 'b827eb98e519' ;//'B827EB7C3500';
			$topic =  $gatewaymac.'/gateway_requests/request';
			$path = "/servers/".$pkId;
			$method = "DELETE";
			$port = 4999;
			$timestamp = $currentdatetime->format('c');//"2019-12-08T16:00:02.2805625Z";
			$requestId = "123456790";
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';
			$msg = $msg.',"authentication" : true';
			$msg = $msg.',"body":""';
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$requestId.'"';			
			$msg = $msg.'}';
			
			if($pkId != null)
			$this->publish($topic, $msg);
		
		return new JsonResponse(array('status' => 'SUCCESS','message' => 'Server has been successfully removed!!'));
		}
		else{
			return new JsonResponse(array('status' => 'Failed','message' => 'No Server is Present with this Id!!'));
		}
	}
	
	/**
     * Create New Server
     *                                                                                 
	 * @Route("/newserver", name="server_newserver")
	 */
	public function newServerApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		// var_dump($data);
		
		$type = $data->type;		
		$name = $data->name;
		$serverUrl = $data->serverUrl;
		$providerId = $data->providerId;
		$authorizationToken = $data->authorizationToken;
		$profileName = $data->profileName;		
		$brokerAddress = $data->brokerAddress;
		$brokerPort = $data->brokerPort;
		$topic = $data->topic;
		$isTransparentMode = $data->isTransparentMode;	
		$status = $data->status;
		$disable = $data->disable;		
		
		$serverObj= $em 
			->getRepository('AppBundle:Servers')
			->findBy(array('name' => $name,'profileName' => $profileName));
		$currentdatetime = new  \DateTime();	
			
		if($serverObj != null)
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Requested Server is already exists!!'));
		}
		else{
			
			$servers = new Servers();
			
			if($type != "")
			$servers->setType($type);
			
			if($name != "")
			$servers->setName($name);
		
			if($serverUrl != "")
			$servers->setServerUrl($serverUrl);
			
			if($providerId != "")
			$servers->setProviderId($providerId);
		
			if($authorizationToken != "")
			$servers->setAuthorizationToken($authorizationToken);
		
			if($profileName != "")
			$servers->setProfileName($profileName);
			
			if($brokerAddress != "")
			$servers->setBrokerAddress($brokerAddress);
		
			if($brokerPort != "")
			$servers->setBrokerPort($brokerPort);
			
			if($topic != "")
			$servers->setTopic($topic);
			
			if($isTransparentMode != "")
			$servers->setIsTransparentMode($isTransparentMode);
		
			if($status != "")
			$servers->setStatus($status);
		
			if($disable != "")
			$servers->setDisable($disable);
			
			$em->persist($servers);
			$em->flush();
			
			$serverName = $name;
			$url = $serverUrl;
			$provider = $providerId;
			$identityKey = $authorizationToken;
			$type = $type; //== 'SENTILO'?0:1;
			
			$gatewaymac = 'b827eb98e519' ;//'B827EB7C3500';
			$topic = $gatewaymac.'/gateway_requests/request';
			$path = "/servers";
			$method = "POST";
			$port = 4999;
			$timestamp = $currentdatetime->format('c'); //"2019-12-08T16:00:02.2805625Z";
			$requestId = "123456790";
			//$body ='{';			
			$body = '{\"serverName\":\"'.$serverName.'\"';
			$body = $body.',\"url\":\"'.$url.'\"';
			$body = $body.',\"provider\":\"'.$provider.'\"';
			$body = $body.',\"identityKey\":\"'.$identityKey.'\"';
			$body = $body.',\"type\":'.$type;
			$body = $body.'}';
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';			
			$msg = $msg.',"authentication" : true';
			$msg = $msg.',"body":"'.$body.'"';
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$requestId.'"';			
			$msg = $msg.'}';
			

			//$this->publish($topic, $msg);
			
			$Id = $servers->getId();
			
			if( $Id != '')
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'Server has been successfully created!!','id' => $Id));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in registering Server registeration!!'));
			} 
		}
		
	}
	
	/**
     * Update a Server
     *                                                                                 
	 * @Route("/updateserver", name="server_updateserver")
	 */
	public function updateserverApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$serverId = $data->id;
		$type = $data->type;		
		$name = $data->name;
		$serverUrl = $data->serverUrl;
		$providerId = $data->providerId;
		$authorizationToken = $data->authorizationToken;
		$profileName = $data->profileName;		
		$brokerAddress = $data->brokerAddress;
		$brokerPort = $data->brokerPort;
		$topic = $data->topic;
		$isTransparentMode = $data->isTransparentMode;
		$status = $data->status;
		$disable = $data->disable;		
			
		$server= $em 
			->getRepository('AppBundle:Servers')
			->findOneBy(array('id' => $serverId));
		if($server != null)
		{	
		$ServerGatewayPkids = $em 
			->getRepository('AppBundle:ServerGatewayPkid')
			->findBy(array('serverId' => $serverId));			
			foreach ($ServerGatewayPkid   as $ServerGatewayPkid){
				$pkId = $ServerGatewayPkid->getPkId();
				$macNumber = $ServerGatewayPkid->getMacNumber();
				$serverName = $name;
				$url = $serverUrl;
				$provider = $providerId;
				$identityKey = $authorizationToken;
				$type = $type;//=='SENTILO'?0:1;
			
				$currentdatetime = new  \DateTime();
				$topic = $macNumber.'/gateway_requests/request';			
				$url= rtrim($url);
				$provider= trim($provider);
				$identityKey= trim($identityKey);
				$serverName= trim($serverName);
			
				$path = "/servers/".$pkId;
				$method = "PUT";
				$port = 4999;
				$timestamp = $currentdatetime->format('c'); //"2019-12-08T16:00:02.2805625Z";			
				//$body ='{';			
				$body = '{\"serverName\":\"'.$serverName.'\"';
				$body = $body.',\"url\":\"'.$url.'\"';
				$body = $body.',\"provider\":\"'.$provider.'\"';
				$body = $body.',\"identityKey\":\"'.$identityKey.'\"';
				$body = $body.',\"type\":'.$type;
				$body = $body.'}';
				$msg = '{';
				$msg = $msg.'"path":"'.$path.'"';
				$msg = $msg.',"method":"'.$method.'"';			
				$msg = $msg.',"authentication" : true';
				$msg = $msg.',"body":"'.$body.'"';
				$msg = $msg.',"port":'.$port;
				$msg = $msg.',"timestamp":"'.$timestamp.'"';
				$msg = $msg.',"requestId":"'.$requestId.'"';			
				$msg = $msg.'}';
				//print_r($msg);
				$this->publish($topic, $msg);
			}
		
			//$pkId = $server->getPkId();
			
			if($type != "")
			$server->setType($type);
		
			if($name != "")
			$server->setName($name);
		
			if($serverUrl != "")
			$server->setServerUrl($serverUrl);
		
			if($providerId != "")
			$server->setProviderId($providerId);
		
			if($authorizationToken != "")
			$server->setAuthorizationToken($authorizationToken);
		
			if($profileName != "")
			$server->setProfileName($profileName);
			
			if($brokerAddress != "")
			$server->setBrokerAddress($brokerAddress);
		
			if($brokerPort != "")
			$server->setBrokerPort($brokerPort);
			
			if($topic != "")
			$server->setTopic($topic);
			
			if($isTransparentMode != "")
			$server->setIsTransparentMode($isTransparentMode);
		
			if($status != "")
			$server->setStatus($status);
		
			if($disable != "")
			$server->setDisable($disable);
			
			$server->setUpdatedDt(new \DateTime());
			
			$em->persist($server);
			$em->flush();
			
			
			$serverId = $server->getId();
			
			if( $serverId != "")
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'Server has been successfully updated!!'));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating Server details!!'));
			}
		}
		else
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating Server Detail No Record found with this Id'));
		}
		
	}
	
	
	/**
     * Mqqt List
     *                                                                                 
	 * @Route("/mqqtlist", name="servers_mqqtlist")
	 */
	public function ServersmqqtListApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();

		$serversMqqtList= $em 
			->getRepository('AppBundle:ServerMqqt')
			->findAll();
		
		$json = '';
		//var_dump($user);
		
		 if($serversMqqtList != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($serversMqqtList, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','serversmqqt_details' => $json));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','serversmqqt_details' => $json));
			//return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in server mqqt data'));
	}
	
	/**
     * Get Servers mqqt by Id
     *                                                                                 
	 * @Route("/getservermqqtbyid", name="server_getservermqqtbyid")
	 */
	public function getservermqqtbyidApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$serverMqqtId = $data->id;
		
		$serverMqqt= $em 
			->getRepository('AppBundle:ServerMqqt')
			->findBy(array('id' => $serverMqqtId));
		
		if( $serverMqqt != null)
		{
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new GetSetMethodNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($serverMqqt, 'json');
			
			return new JsonResponse(array('status' => 'Success','servermqqt_details' => $json));
		}
		else{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in getting server mqqt details!!'));
		} 
		
	}
	
	/**
     * Delete a Servers mqqt
     *                                                                                 
	 * @Route("/deleteservermqqt", name="server_deleteservermqqt")
	 */
	public function deleteServerMqqtApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());		
		$serverMqqtId = $data->id;	
		$serverMqqt= $em 
			->getRepository('AppBundle:ServerMqqt')
			->findOneBy(array('id' => $serverMqqtId));
		if($serverMqqt != null)
		{
			$em->remove($serverMqqt);
            $em->flush();	
		return new JsonResponse(array('status' => 'SUCCESS','message' => 'Server mqqt has been successfully removed!!'));
		}
		else{
			return new JsonResponse(array('status' => 'Failed','message' => 'No Server mqqt is Present with this Id!!'));
		}
	}
	
	/**
     * Create New Server mqqt
     *                                                                                 
	 * @Route("/newservermqqt", name="server_newservermqqt")
	 */
	public function newServerMqqtApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		// var_dump($data);
		
		$profileName = $data->profileName;		
		$brokerAddress = $data->brokerAddress;
		$brokerPort = $data->brokerPort;
		$topic = $data->topic;
		$isTransparentMode = $data->isTransparentMode;
				
		
		$serverMqqtObj= $em 
			->getRepository('AppBundle:ServerMqqt')
			->findBy(array('profileName' => $profileName));
			
			
		if($serverMqqtObj != null)
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Requested Server mqqt is already exists!!'));
		}
		else{
			
			$serversmqqt = new ServerMqqt();
			
			if($profileName != "")
			$serversmqqt->setProfileName($profileName);
			
			if($brokerAddress != "")
			$serversmqqt->setBrokerAddress($brokerAddress);
		
			if($brokerPort != "")
			$serversmqqt->setBrokerPort($brokerPort);
			
			if($topic != "")
			$serversmqqt->setTopic($topic);
			
			if($isTransparentMode != "")
			$serversmqqt->setIsTransparentMode($isTransparentMode);	
			
			
			$em->persist($serversmqqt);
			$em->flush();
			$Id = $serversmqqt->getId();
			
			if( $Id != '')
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'Server mqqt has been successfully created!!','id' => $Id));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in registering Server mqqt registeration!!'));
			} 
		}
		
	}
	
	/**
     * Update a Server mqqt
     *                                                                                 
	 * @Route("/updateservermqqt", name="server_updateservermqqt")
	 */
	public function updateServerMqqtApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$serverMqqtId = $data->id;
		$profileName = $data->profileName;		
		$brokerAddress = $data->brokerAddress;
		$brokerPort = $data->brokerPort;
		$topic = $data->topic;
		$isTransparentMode = $data->isTransparentMode;
		
		$serverMqqt= $em 
			->getRepository('AppBundle:ServerMqqt')
			->findOneBy(array('id' => $serverMqqtId));
			
		if($serverMqqt !=null)
		{
		
			if($profileName != "")
			$serverMqqt->setProfileName($profileName);
			
			if($brokerAddress != "")
			$serverMqqt->setBrokerAddress($brokerAddress);
		
			if($brokerPort != "")
			$serverMqqt->setBrokerPort($brokerPort);
			
			if($topic != "")
			$serverMqqt->setTopic($topic);
			
			//if($isTransparentMode != "")
			$serversmqqt->setIsTransparentMode($isTransparentMode);
			
			$serverMqqt->setUpdatedDt(new \DateTime());
			
			$em->persist($serverMqqt);
			$em->flush();
			$serverId = $serverMqqt->getId();
			
			if( $serverId != "")
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'Server mqqt has been successfully updated!!'));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating Server mqqt details!!'));
			}
		}
		else
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating Server mqqt Detail No Record found with this Id'));
		}
		
	}
	
	public function publish($topic, $msg)
	{
		$str = "./mosquitto_pub -h gesinen.es -p 1882 -u 'gesinen'  -P 'gesinen2110'  -t '".$topic."' -m '".$msg."'";
		
		$process = new Process($str);
		$process->run();

		// executes after the command finishes
		if (!$process->isSuccessful()) {
			throw new ProcessFailedException($process);
		}
	}
}

?>