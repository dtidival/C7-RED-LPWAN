<?php

namespace AppBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use AppBundle\Entity\SensorTypeIboxPayload;
use AppBundle\Entity\SensorTypeInfo;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Process\Process;
use Symfony\Component\Process\Exception\ProcessFailedException;
use Symfony\Component\Validator\Constraints\DateTime;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Normalizer\GetSetMethodNormalizer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Normalizer\DateTimeNormalizer;


/**
 * SensorTypeIboxPayload controller.
 *
 * @Route("/sensoriboxtypepayload")
 */
class SensorTypeIboxPayloadController extends Controller
{
	
	/**
     * List
     *                                                                                 
	 * @Route("/list", name="sensortypeiboxpayload_list")
	 */
	public function SensorTypeIboxPayloadListApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();

		$sensorTypeIboxPayload= $em 
			->getRepository('AppBundle:SensorTypeIboxPayload')
			->findAll();
		
		$json = '';
		//var_dump($user);
		
		 if($sensorTypeIboxPayload != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('Y-m-d H:i:s'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($sensorTypeIboxPayload, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','details' => $json));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','details' => $json));
			//return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in sensor type ibox payload data'));
	}
	
	/**
     * input List
     *                                                                                 
	 * @Route("/inputlist", name="sensortypeiboxinputpayload_list")
	 */
	public function SensorTypeIboxInputPayloadListApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();

		$sensorTypeIboxPayload= $em 
			->getRepository('AppBundle:SensorTypeIboxPayload')
			->findby(array('isInput'=>true));
		
		$json = '';
		//var_dump($user);
		
		 if($sensorTypeIboxPayload != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('Y-m-d H:i:s'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($sensorTypeIboxPayload, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','details' => $json));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','details' => $json));
			//return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in sensor type ibox input payload data'));
	}
	/**
     * input List of by sensortype
     *                                                                                 
	 * @Route("/inputlistbysensortype", name="sensortypeiboxinputbysensortypepayload_list")
	 */
	public function SensorTypeIboxInputPayloadBySensorTypeListApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());		
		
		$sensorTypeInfoId = $data->id;

		$sensorTypeIboxPayload= $em 
			->getRepository('AppBundle:SensorTypeIboxPayload')
			->findby(array('isInput'=>true,'sensorTypeInfoId'=>$sensorTypeInfoId));
		
		$json = '';
		//var_dump($user);
		
		 if($sensorTypeIboxPayload != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('Y-m-d H:i:s'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($sensorTypeIboxPayload, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','details' => $json));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','details' => $json));
			//return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in sensor type ibox input payload data'));
	}
	/**
     * meter List
     *                                                                                 
	 * @Route("/meterlist", name="sensortypeiboxmeterpayload_list")
	 */
	public function SensorTypeIboxMeterPayloadListApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();

		$sensorTypeIboxPayload= $em 
			->getRepository('AppBundle:SensorTypeIboxPayload')
			->findby(array('isMeter'=>true));
		
		$json = '';
		//var_dump($user);
		
		 if($sensorTypeIboxPayload != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('Y-m-d H:i:s'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($sensorTypeIboxPayload, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','details' => $json));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','details' => $json));
			//return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in sensor type ibox meter payload data'));
	}
	/**
     * input List of by sensortype
     *                                                                                 
	 * @Route("/meterlistbysensortype", name="sensortypeiboxmeterbysensortypepayload_list")
	 */
	public function SensorTypeIboxMeterPayloadBySensorTypeListApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());		
		
		$sensorTypeInfoId = $data->id;

		$sensorTypeIboxPayload= $em 
			->getRepository('AppBundle:SensorTypeIboxPayload')
			->findby(array('isMeter'=>true,'sensorTypeInfoId'=>$sensorTypeInfoId));
		
		$json = '';
		//var_dump($user);
		
		 if($sensorTypeIboxPayload != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('Y-m-d H:i:s'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($sensorTypeIboxPayload, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','details' => $json));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','details' => $json));
			//return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in sensor type ibox input payload data'));
	}	
	
	
	
	
	/**
     * Get SensorTypeIboxPayload by Id
     *                                                                                 
	 * @Route("/getsensortypeiboxpayloadbyid", name="sensortypeiboxpayload_getsensortypeiboxpayloadbyid")
	 */
	public function getSensorTypeIboxPayloadbyidApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$sensorTypeIboxPayloadId = $data->id;
		
		$sensorTypeIboxPayload= $em 
			->getRepository('AppBundle:SensorTypeIboxPayload')
			->findBy(array('id' => $sensorTypeIboxPayloadId));
		
		if( $sensorTypeIboxPayload != null)
		{
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new GetSetMethodNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($sensorTypeIboxPayload, 'json');
			
			return new JsonResponse(array('status' => 'Success','details' => $json));
		}
		else{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in getting sensor type payload details!!'));
		} 
		
	}
	
	/**
     * Delete a Sensor type ibox payload
     *                                                                                 
	 * @Route("/deletesensortypeiboxpayload", name="sensortypeiboxpayload_deletesensortypeiboxpayload")
	 */
	public function deleteSensorTypeIboxPayloadApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());		
		$sensorTypeIboxPayloadId = $data->id;
		$currentdatetime = new  \DateTime();	
		$sensorTypeIboxPayload= $em 
			->getRepository('AppBundle:SensorTypeIboxPayload')
			->findOneBy(array('id' => $sensorTypeIboxPayloadId));
		$iboxPayloadId  = $sensorTypeIboxPayload->getId();
		if($sensorTypeIboxPayload != null)
		{
			$em->remove($sensorTypeIboxPayload);
            $em->flush();
			
		return new JsonResponse(array('status' => 'SUCCESS','message' => 'sensor type payload has been successfully removed!!'));
		}
		else{
			return new JsonResponse(array('status' => 'Failed','message' => 'No sensor type payload is Present with this Id!!'));
		}
	}
	
	/**
     * Create New Input SensorTypeIboxPayload
     *                                                                                 
	 * @Route("/newinputsensortypeiboxpayload", name="sensorinputtypeiboxpayload_newsensortypeiboxpayload")
	 */
	public function newInputSensorTypeIboxPayloadApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		// var_dump($data);
		
		$sensorTypeInfoId = $data->sensorTypeInfoId;
		$inputNumber = $data->inputNumber;
		$inputName = $data->inputName;
		$inputDescription = $data->inputDescription;
		
		$sensorTypeIboxPayloadObj= $em 
			->getRepository('AppBundle:SensorTypeIboxPayload')
			->findBy(array('sensorTypeInfoId' => $sensorTypeInfoId,'inputNumber' => $inputNumber));			
			
		if($sensorTypeIboxPayloadObj != null)
			{
					return new JsonResponse(array('status' => 'FAILED','message' => 'Requested sensor type ibox payload is already exists!!'));
		}
		else{
			$sensorTypeIboxPayload = new SensorTypeIboxPayload();
					
					
				$sensorTypeIboxPayload->setIsInput(true);
				$sensorTypeIboxPayload->setIsMeter(false);
					
				if($sensorTypeInfoId != "")
					$sensorTypeIboxPayload->setSensorTypeInfoId($sensorTypeInfoId);
				
				if($inputNumber != "")
					$sensorTypeIboxPayload->setInputNumber($inputNumber);
				
				if($inputName != "")
					$sensorTypeIboxPayload->setInputName($inputName);
				
				if($inputDescription != "")
					$sensorTypeIboxPayload->setInputDescription($inputDescription);		
				
					
								
				$em->persist($sensorTypeIboxPayload);
				$em->flush();
				$Id = $sensorTypeIboxPayload->getId();					
					
				if( $Id != ''){
					return new JsonResponse(array('status' => 'SUCCESS','message' => 'sensor type payload has been successfully created!!','id' => $Id));
				}
				else{
					return new JsonResponse(array('status' => 'FAILED','message' => 'Error in registering sensor type payload registeration!!'));
				}		
		}	
		
			
	}
	
	/**
     * update Input SensorTypeIboxPayload
     *                                                                                 
	 * @Route("/updateinputsensortypeiboxpayload", name="sensorinputtypeiboxpayload_updatesensortypeiboxpayload")
	 */
	public function updateInputSensorTypeIboxPayloadApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		
		$data = json_decode($request->getContent());
		$sensorTypeInputPayloadId = $data->id;
		
		$sensorTypeInfoId = $data->sensorTypeInfoId;
		$inputNumber = $data->inputNumber;
		$inputName = $data->inputName;
		$inputDescription = $data->inputDescription;
		
		$sensorTypeIboxPayload= $em 
			->getRepository('AppBundle:SensorTypeIboxPayload')
			->findOneBy(array('id' => $sensorTypeInputPayloadId));
		
			
		if($sensorTypeIboxPayload != null)
			{		
					
				if($sensorTypeInfoId != "")
					$sensorTypeIboxPayload->setSensorTypeInfoId($sensorTypeInfoId);
				
				
				if($inputNumber < 0 &&  $inputNumber > 19)
					$sensorTypeIboxPayload->setInputNumber($inputNumber);
				else
					$sensorTypeIboxPayload->setInputNumber($inputNumber);
					
				
				if($inputName != "")
					$sensorTypeIboxPayload->setInputName($inputName);
				
				if($inputDescription != "")
					$sensorTypeIboxPayload->setInputDescription($inputDescription);
				else
					$sensorTypeIboxPayload->setInputDescription("");	
					
								
				$em->persist($sensorTypeIboxPayload);
				$em->flush();
				$Id = $sensorTypeIboxPayload->getId();				
					
					
				if( $Id != ''){
					return new JsonResponse(array('status' => 'SUCCESS','message' => 'sensor type payload has been successfully created!!','id' => $Id));
				}
				else{
					return new JsonResponse(array('status' => 'FAILED','message' => 'Error in registering sensor type payload registeration!!'));
				}		
		}
		else{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Requested sensor type input ibox payload not found!!'));
		}
		
			
	}
	
	/**
     * Create New Meter SensorTypeIboxPayload
     *                                                                                 
	 * @Route("/newmetersensortypeiboxpayload", name="sensormetertypeiboxpayload_newsensortypeiboxpayload")
	 */
	public function newMeterSensorTypeIboxPayloadApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		// var_dump($data);
		
		$sensorTypeInfoId = $data->sensorTypeInfoId;
		$meterNumber = $data->meterNumber;
		
		$voltRSensorName = $data->voltRSensorName;
		$voltRSensorNameDesc = $data->voltRSensorNameDesc;
		$voltSSensorName = $data->voltSSensorName;
		$voltSSensorNameDesc = $data->voltSSensorNameDesc;
		$voltTSensorName = $data->voltTSensorName;
		$voltTSensorNameDesc = $data->voltTSensorNameDesc;
		
		$currentRSensorName = $data->currentRSensorName;
		$currentRSensorNameDesc = $data->currentRSensorNameDesc;
		$currentSSensorName = $data->currentSSensorName;
		$currentSSensorNameDesc = $data->currentSSensorNameDesc;
		$currentTSensorName = $data->currentTSensorName;
		$currentTSensorNameDesc = $data->currentTSensorNameDesc;
		
		$powerAllName = $data->powerAllName;
		$powerAllNameDesc = $data->powerAllNameDesc;
		$powerRName = $data->powerRName;
		$powerRNameDesc = $data->powerRNameDesc;
		$powerSName = $data->powerSName;
		$powerSNameDesc = $data->powerSNameDesc;
		$powerTName = $data->powerTName;
		$powerTNameDesc = $data->powerTNameDesc;
		
		$pfAllName = $data->pfAllName;
		$pfAllNameDesc = $data->pfAllNameDesc;		
		$pfRName = $data->pfRName;
		$pfRNameDesc = $data->pfRNameDesc;
		$pfSName = $data->pfSName;
		$pfSNameDesc = $data->pfSNameDesc;
		$pfTName = $data->pfTName;
		$pfTNameDesc = $data->pfTNameDesc;
		
		$reactivePowerAllName = $data->reactivePowerAllName;
		$reactivePowerAllNameDesc = $data->reactivePowerAllNameDesc;
		$reactivePowerRName = $data->reactivePowerRName;
		$reactivePowerRNameDesc = $data->reactivePowerRNameDesc;		
		$reactivePowerSName = $data->reactivePowerSName;
		$reactivePowerSNameDesc = $data->reactivePowerSNameDesc;
		$reactivePowerTName = $data->reactivePowerTName;
		$reactivePowerTNameDesc = $data->reactivePowerTNameDesc;
		
		$q1SensorName = $data->q1SensorName;
		$q1SensorNameDesc = $data->q1SensorNameDesc;
		$q2SensorName = $data->q2SensorName;
		$q2SensorNameDesc = $data->q2SensorNameDesc;
		$q3SensorName = $data->q3SensorName;
		$q3SensorNameDesc = $data->q3SensorNameDesc;
		$q4SensorName = $data->q4SensorName;
		$q4SensorNameDesc = $data->q4SensorNameDesc;
		
		
		$sensorTypeIboxPayloadObj= $em 
			->getRepository('AppBundle:SensorTypeIboxPayload')
			->findBy(array('sensorTypeInfoId' => $sensorTypeInfoId,'meterNumber' => $meterNumber));			
			
		if($sensorTypeIboxPayloadObj != null){
					return new JsonResponse(array('status' => 'FAILED','message' => 'Requested sensor type ibox payload is already exists!!'));
		}
		else{
			$sensorTypeIboxPayload = new SensorTypeIboxPayload();
					
					
				$sensorTypeIboxPayload->setIsInput(false);
				$sensorTypeIboxPayload->setIsMeter(true);
					
				if($sensorTypeInfoId != "")
					$sensorTypeIboxPayload->setSensorTypeInfoId($sensorTypeInfoId);
				
				if($meterNumber != "")
					$sensorTypeIboxPayload->setMeterNumber($meterNumber);
				else
					$sensorTypeIboxPayload->setMeterNumber("");
				
				if($voltRSensorName != "")
					$sensorTypeIboxPayload->setVoltRSensorName($voltRSensorName);
				else
					$sensorTypeIboxPayload->setVoltRSensorName("");				
				if($voltRSensorNameDesc != "")
					$sensorTypeIboxPayload->setVoltRSensorNameDesc($voltRSensorNameDesc);
				else
					$sensorTypeIboxPayload->setVoltRSensorNameDesc("");
				if($voltSSensorName != "")
					$sensorTypeIboxPayload->setVoltSSensorName($voltSSensorName);
				else
					$sensorTypeIboxPayload->setVoltSSensorName("");
				if($voltSSensorNameDesc != "")
					$sensorTypeIboxPayload->setVoltSSensorNameDesc($voltSSensorNameDesc);
				else
					$sensorTypeIboxPayload->setVoltSSensorNameDesc("");
				if($voltTSensorName != "")
					$sensorTypeIboxPayload->setVoltTSensorName($voltTSensorName);
				else
					$sensorTypeIboxPayload->setVoltTSensorName("");
				if($voltTSensorNameDesc != "")
					$sensorTypeIboxPayload->setVoltTSensorNameDesc($voltTSensorNameDesc);
				else
					$sensorTypeIboxPayload->setVoltTSensorNameDesc("");
				
				
				if($currentRSensorName != "")
					$sensorTypeIboxPayload->setCurrentRSensorName($currentRSensorName);
				else
					$sensorTypeIboxPayload->setCurrentRSensorName("");
				if($currentRSensorNameDesc != "")
					$sensorTypeIboxPayload->setCurrentRSensorNameDesc($currentRSensorNameDesc);
				else
					$sensorTypeIboxPayload->setCurrentRSensorNameDesc("");
				if($currentSSensorName != "")
					$sensorTypeIboxPayload->setCurrentSSensorName($currentSSensorName);
				else
					$sensorTypeIboxPayload->setCurrentSSensorName("");
				if($currentSSensorNameDesc != "")
					$sensorTypeIboxPayload->setCurrentSSensorNameDesc($currentSSensorNameDesc);
				else
					$sensorTypeIboxPayload->setCurrentSSensorNameDesc("");
				if($currentTSensorName != "")
					$sensorTypeIboxPayload->setCurrentTSensorName($currentTSensorName);
				else
					$sensorTypeIboxPayload->setCurrentTSensorName("");
				if($currentTSensorNameDesc != "")
					$sensorTypeIboxPayload->setCurrentTSensorNameDesc($currentTSensorNameDesc);
				else
					$sensorTypeIboxPayload->setCurrentTSensorNameDesc("");
				
				if($powerAllName != "")
					$sensorTypeIboxPayload->setPowerAllName($powerAllName);
				else
					$sensorTypeIboxPayload->setPowerAllName("");
				if($powerAllNameDesc != "")
					$sensorTypeIboxPayload->setPowerAllNameDesc($powerAllNameDesc);
				else
					$sensorTypeIboxPayload->setPowerAllNameDesc("");
				if($powerRName != "")
					$sensorTypeIboxPayload->setPowerRName($powerRName);
				else
					$sensorTypeIboxPayload->setPowerRName("");
				if($powerRNameDesc != "")
					$sensorTypeIboxPayload->setPowerRNameDesc($powerRNameDesc);
				else
					$sensorTypeIboxPayload->setPowerRNameDesc("");
				if($powerSName != "")
					$sensorTypeIboxPayload->setPowerSName($powerSName);
				else
					$sensorTypeIboxPayload->setPowerSName("");
				if($powerSNameDesc != "")
					$sensorTypeIboxPayload->setPowerSNameDesc($powerSNameDesc);
				else
					$sensorTypeIboxPayload->setPowerSNameDesc("");
				if($powerTName != "")
					$sensorTypeIboxPayload->setPowerTName($powerTName);
				else
					$sensorTypeIboxPayload->setPowerTName("");
				if($powerTNameDesc != "")
					$sensorTypeIboxPayload->setPowerTNameDesc($powerTNameDesc);
				else
					$sensorTypeIboxPayload->setPowerTNameDesc("");
				
				
				if($pfAllName != "")
					$sensorTypeIboxPayload->setPfAllName($pfAllName);
				else
					$sensorTypeIboxPayload->setPfAllName("");
				if($pfAllNameDesc != "")
					$sensorTypeIboxPayload->setPfAllNameDesc($pfAllNameDesc);
				else
					$sensorTypeIboxPayload->setPfAllNameDesc("");
				if($pfRName != "")
					$sensorTypeIboxPayload->setPfRName($pfRName);
				else
					$sensorTypeIboxPayload->setPfRName("");
				if($pfRNameDesc != "")
					$sensorTypeIboxPayload->setPfRNameDesc($pfRNameDesc);
				else
					$sensorTypeIboxPayload->setPfRNameDesc("");
				if($pfSName != "")
					$sensorTypeIboxPayload->setPfSName($pfSName);
				else
					$sensorTypeIboxPayload->setPfSName("");
				if($pfSNameDesc != "")
					$sensorTypeIboxPayload->setPfSNameDesc($pfSNameDesc);
				else
					$sensorTypeIboxPayload->setPfSNameDesc("");
				if($pfTName != "")
					$sensorTypeIboxPayload->setPfTName($pfTName);
				else
					$sensorTypeIboxPayload->setPfTName("");
				if($pfTNameDesc != "")
					$sensorTypeIboxPayload->setPfTNameDesc($pfTNameDesc);
				else
					$sensorTypeIboxPayload->setPfTNameDesc("");
				
				
				if($reactivePowerAllName != "")
					$sensorTypeIboxPayload->setReactivePowerAllName($reactivePowerAllName);
				else
					$sensorTypeIboxPayload->setReactivePowerAllName("");
				if($reactivePowerAllNameDesc != "")
					$sensorTypeIboxPayload->setReactivePowerAllNameDesc($reactivePowerAllNameDesc);
				else
					$sensorTypeIboxPayload->setReactivePowerAllNameDesc("");
				if($reactivePowerRName != "")
					$sensorTypeIboxPayload->setReactivePowerRName($reactivePowerRName);
				else
					$sensorTypeIboxPayload->setReactivePowerRName("");
				if($reactivePowerRNameDesc != "")
					$sensorTypeIboxPayload->setReactivePowerRNameDesc($reactivePowerRNameDesc);
				else
					$sensorTypeIboxPayload->setReactivePowerRNameDesc("");
				if($reactivePowerSName != "")
					$sensorTypeIboxPayload->setReactivePowerSName($reactivePowerSName);
				else
					$sensorTypeIboxPayload->setReactivePowerSName("");
				if($reactivePowerSNameDesc != "")
					$sensorTypeIboxPayload->setReactivePowerSNameDesc($reactivePowerSNameDesc);
				else
					$sensorTypeIboxPayload->setReactivePowerSNameDesc("");
				if($reactivePowerTName != "")
					$sensorTypeIboxPayload->setReactivePowerTName($reactivePowerTName);
				else
					$sensorTypeIboxPayload->setReactivePowerTName("");
				if($reactivePowerTNameDesc != "")
					$sensorTypeIboxPayload->setReactivePowerTNameDesc($reactivePowerTNameDesc);
				else
					$sensorTypeIboxPayload->setReactivePowerTNameDesc("");
				
				
				if($q1SensorName != "")
					$sensorTypeIboxPayload->setQ1SensorName($q1SensorName);
				else
					$sensorTypeIboxPayload->setQ1SensorName("");
				if($q1SensorNameDesc != "")
					$sensorTypeIboxPayload->setQ1SensorNameDesc($q1SensorNameDesc);
				else
					$sensorTypeIboxPayload->setQ1SensorNameDesc("");
				if($q2SensorName != "")
					$sensorTypeIboxPayload->setQ2SensorName($q2SensorName);
				else
					$sensorTypeIboxPayload->setQ2SensorName("");
				if($q2SensorNameDesc != "")
					$sensorTypeIboxPayload->setQ2SensorNameDesc($q2SensorNameDesc);
				else
					$sensorTypeIboxPayload->setQ2SensorNameDesc("");
				if($q3SensorName != "")
					$sensorTypeIboxPayload->setQ3SensorName($q3SensorName);
				else
					$sensorTypeIboxPayload->setQ3SensorName("");
				
				if($q3SensorNameDesc != "")
					$sensorTypeIboxPayload->setQ3SensorNameDesc($q3SensorNameDesc);
				else
					$sensorTypeIboxPayload->setQ3SensorNameDesc("");
				if($q4SensorName != "")
					$sensorTypeIboxPayload->setQ4SensorName($q4SensorName);
				else
					$sensorTypeIboxPayload->setQ4SensorName("");
				if($q4SensorNameDesc != "")
					$sensorTypeIboxPayload->setQ4SensorNameDesc($q4SensorNameDesc);
				else
					$sensorTypeIboxPayload->setQ4SensorNameDesc("");				
								
				$em->persist($sensorTypeIboxPayload);
				$em->flush();
				$Id = $sensorTypeIboxPayload->getId();					
					
				if( $Id != ''){
					return new JsonResponse(array('status' => 'SUCCESS','message' => 'sensor type payload has been successfully created!!','id' => $Id));
				}
				else{
					return new JsonResponse(array('status' => 'FAILED','message' => 'Error in registering sensor type payload registeration!!'));
				}		
		}	
		
			
	}
	
	
	/**
     * Update Meter SensorTypeIboxPayload
     *                                                                                 
	 * @Route("/updatemetersensortypeiboxpayload", name="sensormetertypeiboxpayload_updatesensortypeiboxpayload")
	 */
	public function updateMeterSensorTypeIboxPayloadApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		// var_dump($data);
		
		$sensorTypeInputPayloadId = $data->id;
		$sensorTypeInfoId = $data->sensorTypeInfoId;
		$meterNumber = $data->meterNumber;
		
		$voltRSensorName = $data->voltRSensorName;
		$voltRSensorNameDesc = $data->voltRSensorNameDesc;
		$voltSSensorName = $data->voltSSensorName;
		$voltSSensorNameDesc = $data->voltSSensorNameDesc;
		$voltTSensorName = $data->voltTSensorName;
		$voltTSensorNameDesc = $data->voltTSensorNameDesc;
		
		$currentRSensorName = $data->currentRSensorName;
		$currentRSensorNameDesc = $data->currentRSensorNameDesc;
		$currentSSensorName = $data->currentSSensorName;
		$currentSSensorNameDesc = $data->currentSSensorNameDesc;
		$currentTSensorName = $data->currentTSensorName;
		$currentTSensorNameDesc = $data->currentTSensorNameDesc;
		
		$powerAllName = $data->powerAllName;
		$powerAllNameDesc = $data->powerAllNameDesc;
		$powerRName = $data->powerRName;
		$powerRNameDesc = $data->powerRNameDesc;
		$powerSName = $data->powerSName;
		$powerSNameDesc = $data->powerSNameDesc;
		$powerTName = $data->powerTName;
		$powerTNameDesc = $data->powerTNameDesc;
		
		$pfAllName = $data->pfAllName;
		$pfAllNameDesc = $data->pfAllNameDesc;		
		$pfRName = $data->pfRName;
		$pfRNameDesc = $data->pfRNameDesc;
		$pfSName = $data->pfSName;
		$pfSNameDesc = $data->pfSNameDesc;
		$pfTName = $data->pfTName;
		$pfTNameDesc = $data->pfTNameDesc;
		
		$reactivePowerAllName = $data->reactivePowerAllName;
		$reactivePowerAllNameDesc = $data->reactivePowerAllNameDesc;
		$reactivePowerRName = $data->reactivePowerRName;
		$reactivePowerRNameDesc = $data->reactivePowerRNameDesc;		
		$reactivePowerSName = $data->reactivePowerSName;
		$reactivePowerSNameDesc = $data->reactivePowerSNameDesc;
		$reactivePowerTName = $data->reactivePowerTName;
		$reactivePowerTNameDesc = $data->reactivePowerTNameDesc;
		
		$q1SensorName = $data->q1SensorName;
		$q1SensorNameDesc = $data->q1SensorNameDesc;
		$q2SensorName = $data->q2SensorName;
		$q2SensorNameDesc = $data->q2SensorNameDesc;
		$q3SensorName = $data->q3SensorName;
		$q3SensorNameDesc = $data->q3SensorNameDesc;
		$q4SensorName = $data->q4SensorName;
		$q4SensorNameDesc = $data->q4SensorNameDesc;
		
		
		$sensorTypeIboxPayload= $em 
			->getRepository('AppBundle:SensorTypeIboxPayload')
			->findOneBy(array('id' => $sensorTypeInputPayloadId));
			//->findOneBy(array('sensorTypeInfoId' => $sensorTypeInfoId,'meterNumber' => $meterNumber));			
			
		if($sensorTypeIboxPayload != null){			
					
				//if($sensorTypeInfoId != "")
				//	$sensorTypeIboxPayload->setSensorTypeInfoId($sensorTypeInfoId);
				
				if($meterNumber >= 0)
					$sensorTypeIboxPayload->setMeterNumber($meterNumber);
				
				
				if($voltRSensorName != "")
					$sensorTypeIboxPayload->setVoltRSensorName($voltRSensorName);
				else
					$sensorTypeIboxPayload->setVoltRSensorName("");				
				if($voltRSensorNameDesc != "")
					$sensorTypeIboxPayload->setVoltRSensorNameDesc($voltRSensorNameDesc);
				else
					$sensorTypeIboxPayload->setVoltRSensorNameDesc("");
				if($voltSSensorName != "")
					$sensorTypeIboxPayload->setVoltSSensorName($voltSSensorName);
				else
					$sensorTypeIboxPayload->setVoltSSensorName("");
				if($voltSSensorNameDesc != "")
					$sensorTypeIboxPayload->setVoltSSensorNameDesc($voltSSensorNameDesc);
				else
					$sensorTypeIboxPayload->setVoltSSensorNameDesc("");
				if($voltTSensorName != "")
					$sensorTypeIboxPayload->setVoltTSensorName($voltTSensorName);
				else
					$sensorTypeIboxPayload->setVoltTSensorName("");
				if($voltTSensorNameDesc != "")
					$sensorTypeIboxPayload->setVoltTSensorNameDesc($voltTSensorNameDesc);
				else
					$sensorTypeIboxPayload->setVoltTSensorNameDesc("");
				
				
				if($currentRSensorName != "")
					$sensorTypeIboxPayload->setCurrentRSensorName($currentRSensorName);
				else
					$sensorTypeIboxPayload->setCurrentRSensorName("");
				if($currentRSensorNameDesc != "")
					$sensorTypeIboxPayload->setCurrentRSensorNameDesc($currentRSensorNameDesc);
				else
					$sensorTypeIboxPayload->setCurrentRSensorNameDesc("");
				if($currentSSensorName != "")
					$sensorTypeIboxPayload->setCurrentSSensorName($currentSSensorName);
				else
					$sensorTypeIboxPayload->setCurrentSSensorName("");
				if($currentSSensorNameDesc != "")
					$sensorTypeIboxPayload->setCurrentSSensorNameDesc($currentSSensorNameDesc);
				else
					$sensorTypeIboxPayload->setCurrentSSensorNameDesc("");
				if($currentTSensorName != "")
					$sensorTypeIboxPayload->setCurrentTSensorName($currentTSensorName);
				else
					$sensorTypeIboxPayload->setCurrentTSensorName("");
				if($currentTSensorNameDesc != "")
					$sensorTypeIboxPayload->setCurrentTSensorNameDesc($currentTSensorNameDesc);
				else
					$sensorTypeIboxPayload->setCurrentTSensorNameDesc("");
				
				if($powerAllName != "")
					$sensorTypeIboxPayload->setPowerAllName($powerAllName);
				else
					$sensorTypeIboxPayload->setPowerAllName("");
				if($powerAllNameDesc != "")
					$sensorTypeIboxPayload->setPowerAllNameDesc($powerAllNameDesc);
				else
					$sensorTypeIboxPayload->setPowerAllNameDesc("");
				if($powerRName != "")
					$sensorTypeIboxPayload->setPowerRName($powerRName);
				else
					$sensorTypeIboxPayload->setPowerRName("");
				if($powerRNameDesc != "")
					$sensorTypeIboxPayload->setPowerRNameDesc($powerRNameDesc);
				else
					$sensorTypeIboxPayload->setPowerRNameDesc("");
				if($powerSName != "")
					$sensorTypeIboxPayload->setPowerSName($powerSName);
				else
					$sensorTypeIboxPayload->setPowerSName("");
				if($powerSNameDesc != "")
					$sensorTypeIboxPayload->setPowerSNameDesc($powerSNameDesc);
				else
					$sensorTypeIboxPayload->setPowerSNameDesc("");
				if($powerTName != "")
					$sensorTypeIboxPayload->setPowerTName($powerTName);
				else
					$sensorTypeIboxPayload->setPowerTName("");
				if($powerTNameDesc != "")
					$sensorTypeIboxPayload->setPowerTNameDesc($powerTNameDesc);
				else
					$sensorTypeIboxPayload->setPowerTNameDesc("");
				
				
				if($pfAllName != "")
					$sensorTypeIboxPayload->setPfAllName($pfAllName);
				else
					$sensorTypeIboxPayload->setPfAllName("");
				if($pfAllNameDesc != "")
					$sensorTypeIboxPayload->setPfAllNameDesc($pfAllNameDesc);
				else
					$sensorTypeIboxPayload->setPfAllNameDesc("");
				if($pfRName != "")
					$sensorTypeIboxPayload->setPfRName($pfRName);
				else
					$sensorTypeIboxPayload->setPfRName("");
				if($pfRNameDesc != "")
					$sensorTypeIboxPayload->setPfRNameDesc($pfRNameDesc);
				else
					$sensorTypeIboxPayload->setPfRNameDesc("");
				if($pfSName != "")
					$sensorTypeIboxPayload->setPfSName($pfSName);
				else
					$sensorTypeIboxPayload->setPfSName("");
				if($pfSNameDesc != "")
					$sensorTypeIboxPayload->setPfSNameDesc($pfSNameDesc);
				else
					$sensorTypeIboxPayload->setPfSNameDesc("");
				if($pfTName != "")
					$sensorTypeIboxPayload->setPfTName($pfTName);
				else
					$sensorTypeIboxPayload->setPfTName("");
				if($pfTNameDesc != "")
					$sensorTypeIboxPayload->setPfTNameDesc($pfTNameDesc);
				else
					$sensorTypeIboxPayload->setPfTNameDesc("");
				
				
				if($reactivePowerAllName != "")
					$sensorTypeIboxPayload->setReactivePowerAllName($reactivePowerAllName);
				else
					$sensorTypeIboxPayload->setReactivePowerAllName("");
				if($reactivePowerAllNameDesc != "")
					$sensorTypeIboxPayload->setReactivePowerAllNameDesc($reactivePowerAllNameDesc);
				else
					$sensorTypeIboxPayload->setReactivePowerAllNameDesc("");
				if($reactivePowerRName != "")
					$sensorTypeIboxPayload->setReactivePowerRName($reactivePowerRName);
				else
					$sensorTypeIboxPayload->setReactivePowerRName("");
				if($reactivePowerRNameDesc != "")
					$sensorTypeIboxPayload->setReactivePowerRNameDesc($reactivePowerRNameDesc);
				else
					$sensorTypeIboxPayload->setReactivePowerRNameDesc("");
				if($reactivePowerSName != "")
					$sensorTypeIboxPayload->setReactivePowerSName($reactivePowerSName);
				else
					$sensorTypeIboxPayload->setReactivePowerSName("");
				if($reactivePowerSNameDesc != "")
					$sensorTypeIboxPayload->setReactivePowerSNameDesc($reactivePowerSNameDesc);
				else
					$sensorTypeIboxPayload->setReactivePowerSNameDesc("");
				if($reactivePowerTName != "")
					$sensorTypeIboxPayload->setReactivePowerTName($reactivePowerTName);
				else
					$sensorTypeIboxPayload->setReactivePowerTName("");
				if($reactivePowerTNameDesc != "")
					$sensorTypeIboxPayload->setReactivePowerTNameDesc($reactivePowerTNameDesc);
				else
					$sensorTypeIboxPayload->setReactivePowerTNameDesc("");
				
				
				if($q1SensorName != "")
					$sensorTypeIboxPayload->setQ1SensorName($q1SensorName);
				else
					$sensorTypeIboxPayload->setQ1SensorName("");
				if($q1SensorNameDesc != "")
					$sensorTypeIboxPayload->setQ1SensorNameDesc($q1SensorNameDesc);
				else
					$sensorTypeIboxPayload->setQ1SensorNameDesc("");
				if($q2SensorName != "")
					$sensorTypeIboxPayload->setQ2SensorName($q2SensorName);
				else
					$sensorTypeIboxPayload->setQ2SensorName("");
				if($q2SensorNameDesc != "")
					$sensorTypeIboxPayload->setQ2SensorNameDesc($q2SensorNameDesc);
				else
					$sensorTypeIboxPayload->setQ2SensorNameDesc("");
				if($q3SensorName != "")
					$sensorTypeIboxPayload->setQ3SensorName($q3SensorName);
				else
					$sensorTypeIboxPayload->setQ3SensorName("");
				
				if($q3SensorNameDesc != "")
					$sensorTypeIboxPayload->setQ3SensorNameDesc($q3SensorNameDesc);
				else
					$sensorTypeIboxPayload->setQ3SensorNameDesc("");
				if($q4SensorName != "")
					$sensorTypeIboxPayload->setQ4SensorName($q4SensorName);
				else
					$sensorTypeIboxPayload->setQ4SensorName("");
				if($q4SensorNameDesc != "")
					$sensorTypeIboxPayload->setQ4SensorNameDesc($q4SensorNameDesc);
				else
					$sensorTypeIboxPayload->setQ4SensorNameDesc("");				
								
				$em->persist($sensorTypeIboxPayload);
				$em->flush();
				$Id = $sensorTypeIboxPayload->getId();					
					
				if( $Id != ''){
					return new JsonResponse(array('status' => 'SUCCESS','message' => 'sensor type payload has been successfully created!!','id' => $Id));
				}
				else{
					return new JsonResponse(array('status' => 'FAILED','message' => 'Error in registering sensor type payload registeration!!'));
				}		
		}
		else{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Requested sensor type meter ibox payload not found!!'));
		}
		
			
	}
	
	/**
     * input List of by sensortype
     *                                                                                 
	 * @Route("/listbysensortypeid", name="sensortypeiboxbysensortypeid_list")
	 */
	public function IboxPayloadBySensorTypIdeListApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());		
		
		$sensorTypeInfoId = $data->id;

		$sensorTypeIboxPayload= $em 
			->getRepository('AppBundle:SensorTypeIboxPayload')
			->findby(array('sensorTypeInfoId'=>$sensorTypeInfoId));
		
		$json = '';
		//var_dump($user);
		
		 if($sensorTypeIboxPayload != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('Y-m-d H:i:s'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($sensorTypeIboxPayload, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','details' => $json));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','details' => $json));
			//return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in sensor type ibox input payload data'));
	}
	
	
	
	
	
	
	
	
	
	public function publish($topic, $msg)
	{
		$str = "./mosquitto_pub -h gesinen.es -p 1882 -u 'gesinen'  -P 'gesinen2110'  -t '".$topic."' -m '".$msg."'";
		
		$process = new Process($str);
		$process->run();

		// executes after the command finishes
		if (!$process->isSuccessful()) {
			throw new ProcessFailedException($process);
		}
	}
}

?>