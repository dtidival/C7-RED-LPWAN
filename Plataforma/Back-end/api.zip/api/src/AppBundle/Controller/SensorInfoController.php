<?php

namespace AppBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use AppBundle\Entity\SensorInfo;
use AppBundle\Entity\SensorPing;
use AppBundle\Entity\Users;
use AppBundle\Entity\SensorTypeInfo;
use AppBundle\Entity\Servers;
use AppBundle\Entity\SensorServerDetail;
use AppBundle\Entity\SensorGatewayPkid;
use AppBundle\Entity\ServerGatewayPkid;
use AppBundle\Entity\SensorTypeGatewayPkid;
use AppBundle\Entity\SensorNamesInWaterOemsensor;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Process\Process;
use Symfony\Component\Process\Exception\ProcessFailedException;
use Symfony\Component\Validator\Constraints\DateTime;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Normalizer\GetSetMethodNormalizer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Normalizer\DateTimeNormalizer;


/**
 * SensorInfo controller.
 *
 * @Route("/sensor")
 */
class SensorInfoController extends Controller
{
	/**
     * updateSentilo
     *                                                                                 
	 * @Route("/updateSentilo", name="update_sentilo")
	 */
	public function UpdateSentiloSensorApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		
		$sensorsList = $data->sensors;
		$sentiloDataType = $data->datatype;		
		$sentioUnits = $data->units =='liters' ? "litros" : $data->units;
		
		$sentiloPrivder = $data->sentiloProvider;
		$sentiloToken = $data->sentiloToken;
		$sentiloUrl = $data->sentiloUrl;
		$descriptiontype = $data->descriptiontype;
		$userdescription = $data->userdescription;		
		foreach($sensorsList as $sensor){
				$sensorName = $sensor->name;
				if($descriptiontype != '-1'){
				if($descriptiontype == 'fixed'){
					$sensorDescription = $sensor->deviceEUI;
				}
				else{
					$sensorDescription = $userdescription;
				}
				$curlopt_postfield = '{"sensors":[
		   {"sensor":"'.$sensorName.'S01",
			"dataType":"'.$sentiloDataType.'",
			"unit":"'.$sentioUnits.'",
			"description":"'.$sensorDescription.'",
			"componentDesc":"'.$sensorDescription.'"
		   }
		]}';
		}
		else{
			$curlopt_postfield = '{"sensors":[
		   {"sensor":"'.$sensorName.'S01",
			"dataType":"'.$sentiloDataType.'",
			"unit":"'.$sentioUnits.'"
		   }
		]}';
		}
				
				
		$curl = curl_init();

		curl_setopt_array($curl, array(
		  CURLOPT_URL => $sentiloUrl.'/catalog/'.$sentiloPrivder,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'PUT',
		  CURLOPT_POSTFIELDS => $curlopt_postfield,
		  CURLOPT_HTTPHEADER => array(
			'IDENTITY_KEY: '.$sentiloToken,
			'Content-Type: application/json'
		  ),
		));

		$response = curl_exec($curl);

		curl_close($curl);
		}
			
				
			return new JsonResponse(array('status' => 'Success','sentiloToken'=>$sentiloToken,'sentiloUrl'=>$sentiloUrl,'sensorName'=>$sensorName,'sensors'=>$sensorsList,'sentiloResponse'=>$response));
		
	}
	public function headersToArray( $str )
	{
    $headers = array();
    $headersTmpArray = explode( "\r\n" , $str );
    for ( $i = 0 ; $i < count( $headersTmpArray ) ; ++$i )
    {
        // we dont care about the two \r\n lines at the end of the headers
        if ( strlen( $headersTmpArray[$i] ) > 0 )
        {
            // the headers start with HTTP status codes, which do not contain a colon so we can filter them out too
            if ( strpos( $headersTmpArray[$i] , ":" ) )
            {
                $headerName = substr( $headersTmpArray[$i] , 0 , strpos( $headersTmpArray[$i] , ":" ) );
                $headerValue = substr( $headersTmpArray[$i] , strpos( $headersTmpArray[$i] , ":" )+1 );
                $headers[$headerName] = $headerValue;
            }
        }
    }
    return $headers;
}
	/**
     * decoder  new Method
     *                                                                                 
	 * @Route("/decoderSensorNew", name="decoder_sensor_new")
	 */
	public function CreateDecoderSensorNewApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$sentilomessageArray =[];
		$data = json_decode($request->getContent());
		$sentiloSubTypejsonString = '[{"name":"batteryLevel","value":"Battery Level","type":"AirQualityObserved","unit":"","datatype":"NUMBER"},
    {"name":"boardTemperature","value":"Board Temperature","type":"AirQualityObserved","unit":"°C","datatype":"NUMBER"},
    {"name":"temperature","value":"Temperature","type":"AirQualityObserved","unit":"°C","datatype":"NUMBER"},
    {"name":"humidity","value":"Humidity","type":"AirQualityObserved","unit":"%","datatype":"NUMBER"},
    {"name":"relativeHumidity","value":"Relative Humidity","type":"AirQualityObserved","unit":"% en","datatype":"NUMBER"},
    {"name":"PM1_0","value":"PM1_0","type":"AirQualityObserved","unit":"ug/m3","datatype":"NUMBER"},
    {"name":"PM2_5","value":"PM2_5","type":"AirQualityObserved","unit":"ug/m3","datatype":"NUMBER"},
    {"name":"avgPM2_5_h","value":"avgPM2_5_h","type":"AirQualityObserved","unit":"ug/m3","datatype":"NUMBER"},
    {"name":"PM10","value":"PM10","type":"AirQualityObserved","unit":"ug/m3","datatype":"NUMBER"},
    {"name":"NO2","value":"NO2","type":"AirQualityObserved","unit":"ug/m3","datatype":"NUMBER"},
    {"name":"O3","value":"O3","type":"AirQualityObserved","unit":"ug/m3","datatype":"NUMBER"},
    {"name":"CO","value":"CO","type":"AirQualityObserved","unit":"ug/m3","datatype":"NUMBER"},
    {"name":"SO2","value":"SO2","type":"AirQualityObserved","unit":"ug/m3","datatype":"NUMBER"},
    {"name":"CO2","value":"CO2","type":"AirQualityObserved","unit":"ppm","datatype":"NUMBER"},
    {"name":"category","value":"Category","type":"AirQualityObserved","unit":"","datatype":"TEXT"},
    {"name":"tvoc","value":"tvoc","type":"AirQualityObserved","unit":"mg/m3","datatype":"NUMBER"},
	
	{"name":"waterMeterLecture","value":"Water Meter Lecture","type":"WaterExternal","unit":"litros","datatype":"NUMBER"},
	
	{"name":"status","value":"Status","type":"ParkingSpot","unit":"","datatype":"TEXT"},
    {"name":"batteryLevel","value":"battery Level","type":"ParkingSpot","unit":"litros","datatype":"NUMBER"},
    {"name":"batteryAlarm","value":"Battery Alarm","type":"ParkingSpot","unit":"","datatype":"BOOLEAN"},
    {"name":"category","value":"Category","type":"ParkingSpot","unit":"","datatype":"TEXT"},
	 
	{"name":"batteryLevel","value":"Battery Level","type":"Irrigationvalve","unit":"","datatype":"NUMBER"},
    {"name":"tamperOpened","value":"Tamper Opened","type":"Irrigationvalve","unit":"","datatype":"BOOLEAN"},
    {"name":"valveOpening","value":"Valve Opening","type":"Irrigationvalve","unit":"","datatype":"NUMBER"},
    {"name":"valveOpend","value":"Valve Opend","type":"Irrigationvalve","unit":"","datatype":"BOOLEAN"}
]';
 $sentiloSubTypeArray = json_decode($sentiloSubTypejsonString);
		
		$platformtoCreate = $data->platformtoCreate;
			if($platformtoCreate  === 'fiware'){
				$createFiware = $data->createFiware;
				if($createFiware == 'yes'){
					$fiwareTokenUrl = $data->fiware->fiwaretokenurl;
					$fiwareBrokenUrl = $data->fiware->fiwarebrokenurl;
					$fiwareUser = $data->fiware->fiwareuser;
					$fiwarePassword = $data->fiware->fiwarepassword;
					$fiwareService = $data->fiware->fiwareservice;
					$fiwareSubService = $data->fiware->fiwaresubservice;
					$fiwareType = $data->fiwareType->fiwareType;
					
				}
			}
			elseif($platformtoCreate  === 'sentilo'){
				$createSentilo = $data->createSentilo;
				if($createSentilo == 'yes'){
					//$sentilo = json_decode($data->sentilo); this line not needed
					$sentiloPrivder = $data->sentilo->provider;
					$sentiloToken = $data->sentilo->token;
					$sentiloUrl = $data->sentilo->url;
					//$sentiloTypeVal = json_decode($data->sentiloType); this line not needed
					$sentiloType = $data->sentiloType->SentiloTypeInfo[0]->sentilotype;//'WaterExternal';//
					$sentiloSubType = $data->sentiloType->SentiloTypeInfo[0]->sentilosubtype;//'waterMeterLecture';
					$sentiloSensorNumber = $data->sentiloType->SentiloTypeInfo[0]->sensornumber;
					$sentiloTypeInfo = $data->sentiloType->SentiloTypeInfo;
				}
			}
			else{
				
			}
		
		$gatewayMac = $data->gatewayMac;
		$sensorSubType = $data->sensorSubType;
		$sensorSubTypeSub = $data->sensorSubTypeSub;
		$sensorType = $data->sensorType;
		$serverIds = $data->serverId;
		$subTypes = $data->subTypes->SubTypeInfoFormArray;
		$EncryptionKey = '';
		$servers = $em 
			->getRepository('AppBundle:Servers')
			->findBy(array('id' => $serverIds));
		
			
		
		
	
		$sensorInfo = $data->sensorInfo;
		
			
		foreach($sensorInfo as $info){
			$sentiloMessage =[];
			$sensorAppEUI =  $info->appEUI;
			$sensorAppKEY =  $info->appKEY;
			$sensorDescription =  $info->description;
			$sensorDeviceEUI =  $info->deviceEUI;
			$sensorId =  $info->id;
			$sensorLatitude =  $info->latitude ? $info->latitude :0;
			$sensorLongitude =  $info->longitude ? $info->longitude:0;
			$sensorName =  $info->name;
			$sensorUserId =  $info->userId;
			$EncryptionKey = $info->encryptionKey;
			$units = '';
			$dataType ='NUMBER';
			if($createFiware == 'yes')
			{
				$curl = curl_init();
				$error =  '';
				if ($curl == false) {
						$error = "failed to init";
				}
					curl_setopt_array($curl, array(
					CURLOPT_URL => trim($fiwareTokenUrl),//"https://connecta.dival.es/sentilo-api/catalog/rafelguaraf@geswat",//$sentiloUrl.'/'.$sentiloPrivder,//'https://connecta.dival.es/sentilo-api/data/'.$provider.'/'.$varnames.'S01?from='.$lastMonthFirstDate.'&to='.$currnetDate.'&limit='.$limit,
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_ENCODING => '',
					CURLOPT_MAXREDIRS => 10,
					CURLOPT_TIMEOUT => 0,
					CURLOPT_FOLLOWLOCATION => true,
					CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					CURLOPT_SSL_VERIFYPEER => false,
					CURLOPT_CUSTOMREQUEST => 'POST',
					CURLOPT_POSTFIELDS =>'{"auth": {"identity": {"methods": ["password"],"password": {"user": {"domain": {"name": "'.$fiwareService.'"},"name": "'.$fiwareUser.'","password": "'.$fiwarePassword.'"}}},"scope": {"project": {"domain": {"name": "'.$fiwareService.'"},"name": "'.$fiwareSubService.'"}}}}',
					// include the response headers in the output
					curl_setopt( $curl , CURLOPT_HEADER , true ),
					CURLOPT_HTTPHEADER => array(
						'Content-Type: application/json'
						),
					));
					

					$responseCreate = curl_exec($curl);
					if ($responseCreate === false) {
							$error = curl_error($curl); 
							$errorNo  = curl_errno($curl);
						}
					
					// convert headers to array
				$headers = $this->headersToArray( $responseCreate );
				 $fiwareAuthToken = $headers['X-Subject-Token'];
				 $currentTime = new \DateTime();
				 $currentTimeStr = $currentTime->format('Y-m-d\TH:i:s.\0\0\0\Z');
					curl_close($curl);
					
					// second request to create entity
					$fiwareEntityMessage = '{"id": "'.$sensorName.'","type": "'.$fiwareType.'","address":{"type":"text","value":"Dirección test"},
												"TimeInstant":{"type":"DateTime","value":"'.$currentTimeStr.'"},
												"location":{"type":"geo:json", "value": { "type": "Point", "coordinates": ['.$sensorLongitude.','.$sensorLatitude.']}},
												"serialNumber": {"type": "Text","value": "'.$sensorDeviceEUI.'"},
												"vol": {"type": "Number", "value": 0},
												"dateCalculatedVol": { "type": "DateTime","value":"'.$currentTimeStr.'"},
												"waterConsumption": {"type": "Number","value": 0},
												"consumption": {"type": "Number","value": 0},
												 "maxWaterFlow": {"type": "Number","value": 0},
												 "battery": {"type": "Number","value": 1},
												 "batteryState": {"type": "Text","value": "ok"},
												 "hasTamperAlert": {"type": "Boolean","value": false},
												 "refPointOfInterest": {"type": "Text","value": "Depósito-Argelita"},
												 "refPointOfInterestPath": {"type": "Text","value": "/contadores"},
												 "refPointOfInterestType": {"type": "Text","value": "Depósito"},
												 "category": {"type": "Text","value": "cold"},
												 "municipality": {"type": "Text","value": "Argelita"}}';
					$curl = curl_init();
					$error =  '';
					if ($curl == false) {
						$error = "failed to init";
					}
					curl_setopt_array($curl, array(
					CURLOPT_URL => $fiwareBrokenUrl,//"https://connecta.dival.es/sentilo-api/catalog/rafelguaraf@geswat",//$sentiloUrl.'/'.$sentiloPrivder,//'https://connecta.dival.es/sentilo-api/data/'.$provider.'/'.$varnames.'S01?from='.$lastMonthFirstDate.'&to='.$currnetDate.'&limit='.$limit,
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_ENCODING => '',
					CURLOPT_MAXREDIRS => 10,
					CURLOPT_TIMEOUT => 0,
					CURLOPT_FOLLOWLOCATION => true,
					CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					CURLOPT_SSL_VERIFYPEER => false,
					CURLOPT_CUSTOMREQUEST => 'POST',
					CURLOPT_POSTFIELDS =>$fiwareEntityMessage,
					// include the response headers in the output
					curl_setopt( $curl , CURLOPT_HEADER , true ),
					CURLOPT_HTTPHEADER => array(
						'Content-Type: application/json',
						'Fiware-Service:'.$fiwareService,
						'Fiware-ServicePath:'.$fiwareSubService,
						'X-Auth-Token:'.trim($fiwareAuthToken) //gAAAAABimRyeQeEsvyZ22m3yDi1RkNaY7TZ0xt_tAVEIRfYwP-C4MNfbvuD53MDNKf2HMSQzwPMBNlOTpiln8A0-luSpgmR0RB2WZdM7gk1OONBCCgEIHMluWd03wOEf0qzq7QiiLeOXHHH66jtK98DrEeqByEgH13zctaT_5zl57Cg_5SMG6WY'
						),
					));
					$responseCreate2 = curl_exec($curl);
					if ($responseCreate2 === false) {
							$error2 = curl_error($curl); 
							$errorNo2  = curl_errno($curl);
						}
					curl_close($curl);
				
			}
			if($createSentilo == 'yes')
			{
			foreach($sentiloTypeInfo as $x =>$sentilo){
					foreach($sentiloSubTypeArray as $sentiloSubTypeval){
						
						if($sentilo->sentilosubtype == $sentiloSubTypeval->name)
						{
							$units = $sentiloSubTypeval->unit;//"mg/m3";
							$dataType = $sentiloSubTypeval->datatype;
						}
					}
					
					if($x == 0){
						if(count($sentiloTypeInfo) == 1){
						array_push($sentiloMessage,'{"sensors":[{"component":"'.$sensorName.'","componentType":"'.$sentilo->sentilotype .'","componentDesc":"'.$sensorDescription.'","componentPublicAccess":"true","timeZone":"CET","sensor":"'.$sensorName.$sentilo->sensornumber .'","description":"'.$sensorDescription.'","type":"'.$sentilo->sentilosubtype.'","publicAccess":"true","dataType":"'.$dataType.'","unit":"'.$units.'"}]}');
						}
						else{
							array_push($sentiloMessage,'{"sensors":[{"component":"'.$sensorName.'","componentType":"'.$sentilo->sentilotype .'","componentDesc":"'.$sensorDescription.'","componentPublicAccess":"true","timeZone":"CET","sensor":"'.$sensorName.$sentilo->sensornumber .'","description":"'.$sensorDescription.'","type":"'.$sentilo->sentilosubtype.'","publicAccess":"true","dataType":"'.$dataType.'","unit":"'.$units.'"}');
						}
					}
					elseif($x == count($sentiloTypeInfo)-1){
					array_push($sentiloMessage,'{"component":"'.$sensorName.'","timeZone":"CET","sensor":"'.$sensorName.$sentilo->sensornumber .'","description":"'.$sensorDescription.'","type":"'.$sentilo->sentilosubtype .'","publicAccess":"true","dataType":"'.$dataType.'","unit":"'.$units.'"}]}');
					}
					else{
						
						array_push($sentiloMessage,'{"component":"'.$sensorName.'","timeZone":"CET","sensor":"'.$sensorName.$sentilo->sensornumber .'","description":"'.$sensorDescription.'","type":"'.$sentilo->sentilosubtype .'","publicAccess":"true","dataType":"'.$dataType.'","unit":"'.$units.'"}');
					}
			}
			$sentiloMessageStr = implode(",",$sentiloMessage);
			array_push($sentilomessageArray,$sentiloMessageStr);
		// if want to create sensor on sentilo.
		
	
		$curl = curl_init();
		$error =  '';
		if ($curl == false) {
				$error = "failed to init";
		}
			curl_setopt_array($curl, array(
			CURLOPT_URL => $sentiloUrl.'/catalog/'.$sentiloPrivder,//"https://connecta.dival.es/sentilo-api/catalog/rafelguaraf@geswat",//$sentiloUrl.'/'.$sentiloPrivder,//'https://connecta.dival.es/sentilo-api/data/'.$provider.'/'.$varnames.'S01?from='.$lastMonthFirstDate.'&to='.$currnetDate.'&limit='.$limit,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_SSL_VERIFYPEER => false,
			CURLOPT_CUSTOMREQUEST => 'POST',
			CURLOPT_POSTFIELDS =>$sentiloMessageStr,/*'{"sensors":[
			   {"component":"'.$sensorName.'",
				"componentType":"'.$sentilo->sentilotype.'",
				"componentDesc":"'.$sensorDescription.'",
				"componentPublicAccess":"true",
				"timeZone":"CET",
				"sensor":"'.$sensorName.'S01",
				"description":"'.$sensorDescription.'",
				"type":"'.$sentilo->sentilosubtype.'",
				"publicAccess":"true",
				"dataType":"NUMBER",
				"unit":"litros"
			   }]}',*/
			   /*$sentiloMessageStr,*//*'{"sensors":[
			   {"component":"'.$sensorName.'",
				"componentType":"'.$sentiloType.'",
				"componentDesc":"'.$sensorDescription.'",
				"componentPublicAccess":"true",
				"timeZone":"CET",
				"sensor":"'.$sensorName.'S01",
				"description":"'.$sensorDescription.'",
				"type":"'.$sentiloSubType.'",
				"publicAccess":"true",
				"dataType":"NUMBER",
				"unit":"litros"
			   }
			   
			]}',*/
			CURLOPT_HTTPHEADER => array(
				'IDENTITY_KEY:'.$sentiloToken,//db8fd01040e87d11af347f678f1d76923188abdb8f30e8b4445fde7f60d3cc8d',//38ba795b797b88c88c973f595a97ef53407b57ab754effadfec9354f7c1336cb',
				'Content-Type: application/json'
				),
			));

			$responseCreate = curl_exec($curl);
			if ($responseCreate === false) {
					$error = curl_error($curl); 
					$errorNo  = curl_errno($curl);
				}
			$result = json_decode($responseCreate, true);
			curl_close($curl);
		
			//$observations =  array_reverse($result['observations']);
			
			$curl = curl_init();

		curl_setopt_array($curl, array(
		  CURLOPT_URL => $sentiloUrl.'/catalog/'.$sentiloPrivder,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'PUT',
		  CURLOPT_POSTFIELDS =>'{"components":[
		   {"component":"'.$sensorName.'", 
			"location":"'.$sensorLatitude.' '. $sensorLongitude.'"
		   }
		]}',
		  CURLOPT_HTTPHEADER => array(
			'IDENTITY_KEY: '.$sentiloToken,
			'Content-Type: application/json'
		  ),
		));

		$response = curl_exec($curl);

		curl_close($curl);
		}
		if($sensorType == 'customsensors'){
		$sensorTypeInfo = $em 
			->getRepository('AppBundle:SensorTypeInfo')
			->findOneBy(array('id' => $sensorSubType));
					
			$sensorTypeId  = $sensorTypeInfo->getId();
		
		$SensorTypeGatewayPkid= $em 
		->getRepository('AppBundle:SensorTypeGatewayPkid')
		->findOneBy(array('sensorTypeId' => $sensorTypeId));
		 $sensorTypePkid = $SensorTypeGatewayPkid->getPkId();
		 }
		$sensorInfo= $em 
			->getRepository('AppBundle:SensorInfo')
			->findOneBy(array('id' => $sensorId));
			$decoderServers = explode(",",$sensorInfo->getDecoderServers());
			$sensorFromPort = "4999";
			$sensorInfo->setSensorFromPort($sensorFromPort);
			if (in_array($gatewayMac, $decoderServers)){
				
			}
			else{
				array_push($decoderServers,$gatewayMac);
			}
			$sensorInfo->setDecoderServers(implode(",",$decoderServers));
			if($sensorType == 'customsensors'){
			$sensorInfo->setTypeSensor($sensorTypeId);
			}
			$sensorInfo->setUpdatedDt(new \DateTime());
			$em->persist($sensorInfo);
			$serverPkId =[];
		foreach($servers as $server){
			$serverId = $server->getId();
			$serverUserId = $server->getUserId($userId);
			$serverType = $server->getType($type);
			$serverName = $server->getName($name);
			$serverProviderId =	$server->getProviderId($providerId);
			$serverAuthtoken = $server->getAuthorizationToken($authorizationToken);
			$serverUrl=	$server->getServerUrl($serverUrl);
		
		$serverGatewayPkid = $em 
			->getRepository('AppBundle:ServerGatewayPkid')
			->findOneBy(array('serverId' => $serverId,'macNumber' => $gatewayMac));
			if($serverGatewayPkid){
			array_push($serverPkId,$serverGatewayPkid->getPkId());
			}
			else{
				$this->servermsg($gatewayMac, $serverId, $serverType, $serverName, $serverUrl, $serverProviderId, $serverAuthtoken);
				sleep(3);
				$serverGatewayPkid = $em 
			->getRepository('AppBundle:ServerGatewayPkid')
			->findOneBy(array('serverId' => $serverId,'macNumber' => $gatewayMac));
			array_push($serverPkId,$serverGatewayPkid->getPkId());
			}
		
		$sensorServerDetail = $em 
			->getRepository('AppBundle:SensorServerDetail')
			->findOneBy(array('serverId' => $serverId,'sensorId' =>$sensorId));
			if(!$sensorServerDetail){
				$sensorServerDetail = new SensorServerDetail();
				$sensorServerDetail->setServerId($serverId);
				$sensorServerDetail->setSensorId($sensorId);							
				$sensorServerDetail->setVarnames($sensorName);
				$em->persist($sensorServerDetail);
				//$em->flush();
			}
		}
			$currentdatetime = new  \DateTime();
			$typeSensor =$sensorType;//'OemSensors';
			$applicationName = "app";
			
			$componentName = $sensorName;//$typeSensor;
			$loraAddress = $sensorDeviceEUI;//$typeSensor;
			$serverIds = 1;
			$hashSensorName = "S02";
			$countSensorName = "S01";		
			$gatewaymac = $gatewayMac ;//'B827EB7C3500';
			$topic = $gatewaymac.'/gateway_requests/request';
			if($sensorType == 'customsensors'){
			$path = "/CustomSensorDevices";
			}
			else{
			$path = "/".$typeSensor;	
			}
			$method = "POST";
			$port = 4999;
			$timestamp = $currentdatetime->format('c'); //"2019-12-08T16:00:02.2805625Z";
			if($sensorSubType == 'watersensor' ){
				switch($sensorSubTypeSub){
					case 'diehl':
						$sensorModelName ='DiehlHRLc G3';
						break;
					case 'itroncyble4':
						$sensorModelName ='ItronCyble4IoT';
						break;
					case 'itroncyble5':
						$sensorModelName ='ItronCyble5';
						break;
					case 'bmeters':
						$sensorModelName ='BmetersBmeters';
						break;
					case 'conthidra':
						$sensorModelName ='Conthidra';
						break;
					case 'janz':
						$sensorModelName ='JANZ';
						break;
					case 'SagemcomSiconiaWM15':
						$sensorModelName ='SagemcomSiconiaWM15';
						break;
					default:
						$sensorModelName ='no model name given';
				}
			
			}
			if($sensorSubType == 'parkingsensor'){
			$sensorModelName = $sensorSubTypeSub;
			}
			if($sensorSubType == 'airqualityobserved'){
			$sensorModelName = 'MilesCO2milesight';
			}
			if(count($subTypes) > 0){
				$sensorNames =[];
				foreach($subTypes as $subtype){
					array_push($sensorNames,'\"'.$subtype->subTypeList.'\":\"'.$subtype->subTypenumber.'\"');
				}
				
			}
			
			$requestId = $sensorId;
			$body ='{';
			//$typeSensor = 'OemSensors';
			if($typeSensor == 'oemsensors'){
				if($sensorModelName == 'JANZ'){
			$body = $body.'\"sensorModelName\":\"SJEvoSJEvo\"';
			$body = $body.',\"applicationName\":\"app\"';
				}
				else{
					$body = $body.'\"sensorModelName\":\"'.$sensorModelName.'\"';
					$body = $body.',\"applicationName\":\"'.$applicationName.'\"';
				}
				
			$body = $body.',\"loraAddress\":\"'.$loraAddress.'\"';
			$body = $body.',\"componentName\":\"'.$componentName.'\"';
			
			
			if($sensorSubType == 'parkingsensor'){
				$body = $body.',\"sensorNames\":{\"OccupancyString\":\"S01\"}';
			}
			else if($sensorSubType == 'airqualityobserved'){
				$body = $body.',\"sensorNames\":{\"O3\":\"S12\",\"CO2\":\"S06\",\"PIR\":\"S04\",\"Beep\":\"S13\",\"HCHO\":\"S09\",\"PM10\":\"S11\",\"tVOC\":\"S07\",\"PM2-5\":\"S10\",\"Battery\":\"S01\",\"Humidity\":\"S03\",\"Pressure\":\"S08\",\"LightLevel\":\"S05\",\"Temperature\":\"S02\"}';
			}
			else{
				if($sensorModelName == 'BmetersBmeters'){
					$body = $body.',\"sensorNames\":{\"volume\":\"S01\"}';
				}
				elseif($sensorModelName == 'ItronCyble5'){
					$body = $body.',\"sensorNames\":{'.implode(",",$sensorNames).'}';
					//$body = $body.',\"sensorNames\":{\"GlobalVolumeIndexM3WithScale\":\"S01\"}';
					$body = $body.',\"extraFields\":{\"EncryptionKey\":\"'.$EncryptionKey.'\"}';
				}
				elseif($sensorModelName == 'JANZ'){
					$body = $body.',\"sensorNames\":{'.implode(",",$sensorNames).'}';
					//$body = $body.',\"sensorNames\":{\"volume\":\"S01\"}';
				}
				elseif($sensorModelName == 'SagemcomSiconiaWM15'){
					$body = $body.',\"sensorNames\":{'.implode(",",$sensorNames).'}';
					//$body = $body.',\"sensorNames\":{\"volume\":\"S01\"}';
				}
				else{
				$body = $body.',\"sensorNames\":{'.implode(",",$sensorNames).'}';
				$body = $body.',\"extraFields\":null';
				}
			}
						
			$body = $body.',\"serverIds\":['.implode(",",$serverPkId).']';
			}
			if($typeSensor == 'customsensors'){
				$body = $body.'\"componentName\":\"'.$componentName.'\"';
			$body = $body.',\"loraAddress\":\"'.$loraAddress.'\"';	
			$body = $body.',\"sensorTypeId\":'.$sensorTypePkid.'';					
			$body = $body.',\"serverIds\":['.implode(",",$serverPkId).']';
			}			
			
			$body = $body.'}';
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';			
			$msg = $msg.',"authentication" : true';
			$msg = $msg.',"body":"'.$body.'"';
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$requestId.'"';			
			$msg = $msg.'}';
			

			$this->publish($topic, $msg);
			sleep(1);
			}
			$em->flush();
				
		//	return new JsonResponse(array('status' => 'Success','sentiloMessageStr'=>$sentiloMessage,'sentiloMessage'=>$sentiloMessageStr,'data' => $data,'msg'=>$msg,'sentiloToken'=>$sentiloToken,'sentiloSensorNumber'=>$sentiloSensorNumber,'result'=>$result,'responseCreate'=>$responseCreate,'error'=>$error,'errorNO'=>$errorNo));
		//return new JsonResponse(array('status' => 'Success','header'=>$headers,'authToken'=>$fiwareAuthToken,'fiwareEntityMessage'=>$fiwareEntityMessage,'responseCreate'=>$responseCreate,'responseCreate2'=>$responseCreate2,'error'=>$error,'errorNO'=>$errorNo));
		return new JsonResponse(array('status' => 'Success','error'=>$error,'errorNO'=>$errorNo));
	}
	
	/**
     * decoder
     *                                                                                 
	 * @Route("/decoderSensor", name="decoder_sensor")
	 */
	public function CreateDecoderSensorApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$sentilomessageArray =[];
		$data = json_decode($request->getContent());
		$sentiloSubTypejsonString = '[{"name":"batteryLevel","value":"Battery Level","type":"AirQualityObserved","unit":"","datatype":"NUMBER"},
    {"name":"boardTemperature","value":"Board Temperature","type":"AirQualityObserved","unit":"°C","datatype":"NUMBER"},
    {"name":"temperature","value":"Temperature","type":"AirQualityObserved","unit":"°C","datatype":"NUMBER"},
    {"name":"humidity","value":"Humidity","type":"AirQualityObserved","unit":"%","datatype":"NUMBER"},
    {"name":"relativeHumidity","value":"Relative Humidity","type":"AirQualityObserved","unit":"% en","datatype":"NUMBER"},
    {"name":"PM1_0","value":"PM1_0","type":"AirQualityObserved","unit":"ug/m3","datatype":"NUMBER"},
    {"name":"PM2_5","value":"PM2_5","type":"AirQualityObserved","unit":"ug/m3","datatype":"NUMBER"},
    {"name":"avgPM2_5_h","value":"avgPM2_5_h","type":"AirQualityObserved","unit":"ug/m3","datatype":"NUMBER"},
    {"name":"PM10","value":"PM10","type":"AirQualityObserved","unit":"ug/m3","datatype":"NUMBER"},
    {"name":"NO2","value":"NO2","type":"AirQualityObserved","unit":"ug/m3","datatype":"NUMBER"},
    {"name":"O3","value":"O3","type":"AirQualityObserved","unit":"ug/m3","datatype":"NUMBER"},
    {"name":"CO","value":"CO","type":"AirQualityObserved","unit":"ug/m3","datatype":"NUMBER"},
    {"name":"SO2","value":"SO2","type":"AirQualityObserved","unit":"ug/m3","datatype":"NUMBER"},
    {"name":"CO2","value":"CO2","type":"AirQualityObserved","unit":"ppm","datatype":"NUMBER"},
    {"name":"category","value":"Category","type":"AirQualityObserved","unit":"","datatype":"TEXT"},
    {"name":"tvoc","value":"tvoc","type":"AirQualityObserved","unit":"mg/m3","datatype":"NUMBER"},
	
	{"name":"waterMeterLecture","value":"Water Meter Lecture","type":"WaterExternal","unit":"litros","datatype":"NUMBER"},
	
	{"name":"status","value":"Status","type":"ParkingSpot","unit":"","datatype":"TEXT"},
    {"name":"batteryLevel","value":"battery Level","type":"ParkingSpot","unit":"litros","datatype":"NUMBER"},
    {"name":"batteryAlarm","value":"Battery Alarm","type":"ParkingSpot","unit":"","datatype":"BOOLEAN"},
    {"name":"category","value":"Category","type":"ParkingSpot","unit":"","datatype":"TEXT"},
	 
	{"name":"batteryLevel","value":"Battery Level","type":"Irrigationvalve","unit":"","datatype":"NUMBER"},
    {"name":"tamperOpened","value":"Tamper Opened","type":"Irrigationvalve","unit":"","datatype":"BOOLEAN"},
    {"name":"valveOpening","value":"Valve Opening","type":"Irrigationvalve","unit":"","datatype":"NUMBER"},
    {"name":"valveOpend","value":"Valve Opend","type":"Irrigationvalve","unit":"","datatype":"BOOLEAN"}
]';
 $sentiloSubTypeArray = json_decode($sentiloSubTypejsonString);
		/*  testing */
		/*
		$sentiloMessage = [];
		$sentiloType = $data->sentiloType->SentiloTypeInfo[0]->sentilotype;//'WaterExternal';//
		$sentiloSubType = $data->sentiloType->SentiloTypeInfo[0]->sentilosubtype;//'waterMeterLecture';
		$sentiloSensorNumber = $data->sentiloType->SentiloTypeInfo[0]->sensornumber;
		 $sentiloTypeInfo = $data->sentiloType->SentiloTypeInfo;
		 $sensorInfo = $data->sensorInfo;
		foreach($sensorInfo as $info){
				$sensorAppEUI =  $info->appEUI;
				$sensorAppKEY =  $info->appKEY;
				$sensorDescription =  $info->description;
				$sensorDeviceEUI =  $info->deviceEUI;
				$sensorId =  $info->id;
				$sensorLatitude =  $info->latitude;
				$sensorLongitude =  $info->longitude;
				$sensorName =  $info->name;
				$sensorUserId =  $info->userId;
				$EncryptionKey = $info->encryptionKey;
				
		foreach($sentiloTypeInfo as $x =>$sentilo){
			
			
			if($x == 0){
				array_push($sentiloMessage,'{"sensors":[{"component":"'.$sensorName.'","componentType":"'.$sentiloType.'","componentDesc":"'.$sensorDescription.'","componentPublicAccess":"true","timeZone":"CET","sensor":"'.$sensorName.'S01","description":"'.$sensorDescription.'","type":"'.$sentiloSubType.'","publicAccess":"true","dataType":"NUMBER","unit":"litros"}');
			}
			elseif($x == count($sentiloTypeInfo)-1){
			array_push($sentiloMessage,'{"component":"'.$sensorName.'","timeZone":"CET","sensor":"'.$sensorName.'S01","description":"'.$sensorDescription.'","type":"'.$sentiloSubType.'","publicAccess":"true","dataType":"NUMBER","unit":"litros"}]}');
			}
			else{
				
				array_push($sentiloMessage,'{"component":"'.$sensorName.'","timeZone":"CET","sensor":"'.$sensorName.'S01","description":"'.$sensorDescription.'","type":"'.$sentiloSubType.'","publicAccess":"true","dataType":"NUMBER","unit":"litros"}');
			}
		}
	}
	$sentiloMessageStr = implode(",",$sentiloMessage);
	 return new JsonResponse(array('status' => 'Success','sentiloMessage' => $sentiloMessageStr));*/
		/****/
		
		$createSentilo = $data->createSentilo;
		$gatewayMac = $data->gatewayMac;
		$sensorSubType = $data->sensorSubType;
		$sensorSubTypeSub = $data->sensorSubTypeSub;
		$sensorType = $data->sensorType;
		$serverId = $data->serverId;
		$EncryptionKey = '';
		$servers = $em 
			->getRepository('AppBundle:Servers')
			->findOneBy(array('id' => $serverId));
		
			$serverUserId = $servers->getUserId($userId);
			$serverType = $servers->getType($type);
			$serverName = $servers->getName($name);
			$serverProviderId =	$servers->getProviderId($providerId);
			$serverAuthtoken = $servers->getAuthorizationToken($authorizationToken);
			$serverUrl=	$servers->getServerUrl($serverUrl);
		
		if($createSentilo == 'yes'){
		//$sentilo = json_decode($data->sentilo); this line not needed
		$sentiloPrivder = $data->sentilo->provider;
		$sentiloToken = $data->sentilo->token;
		$sentiloUrl = $data->sentilo->url;
		//$sentiloTypeVal = json_decode($data->sentiloType); this line not needed
		$sentiloType = $data->sentiloType->SentiloTypeInfo[0]->sentilotype;//'WaterExternal';//
		$sentiloSubType = $data->sentiloType->SentiloTypeInfo[0]->sentilosubtype;//'waterMeterLecture';
		$sentiloSensorNumber = $data->sentiloType->SentiloTypeInfo[0]->sensornumber;
		$sentiloTypeInfo = $data->sentiloType->SentiloTypeInfo;
	}
	
		$sensorInfo = $data->sensorInfo;
		$serverGatewayPkid = $em 
			->getRepository('AppBundle:ServerGatewayPkid')
			->findOneBy(array('serverId' => $serverId,'macNumber' => $gatewayMac));
			if($serverGatewayPkid){
			$serverPkId =  $serverGatewayPkid->getPkId();
			}
			else{
				$this->servermsg($gatewayMac, $serverId, $serverType, $serverName, $serverUrl, $serverProviderId, $serverAuthtoken);
				sleep(3);
				$serverGatewayPkid = $em 
			->getRepository('AppBundle:ServerGatewayPkid')
			->findOneBy(array('serverId' => $serverId,'macNumber' => $gatewayMac));
			$serverPkId =  $serverGatewayPkid->getPkId();
			}
			
		foreach($sensorInfo as $info){
			$sentiloMessage =[];
			$sensorAppEUI =  $info->appEUI;
			$sensorAppKEY =  $info->appKEY;
			$sensorDescription =  $info->description;
			$sensorDeviceEUI =  $info->deviceEUI;
			$sensorId =  $info->id;
			$sensorLatitude =  $info->latitude;
			$sensorLongitude =  $info->longitude;
			$sensorName =  $info->name;
			$sensorUserId =  $info->userId;
			$EncryptionKey = $info->encryptionKey;
			$units = '';
			$dataType ='NUMBER';
			foreach($sentiloTypeInfo as $x =>$sentilo){
					foreach($sentiloSubTypeArray as $sentiloSubTypeval){
						
						if($sentilo->sentilosubtype == $sentiloSubTypeval->name)
						{
							$units = $sentiloSubTypeval->unit;//"mg/m3";
							$dataType = $sentiloSubTypeval->datatype;
						}
					}
					
					if($x == 0){
						if(count($sentiloTypeInfo) == 1){
						array_push($sentiloMessage,'{"sensors":[{"component":"'.$sensorName.'","componentType":"'.$sentilo->sentilotype .'","componentDesc":"'.$sensorDescription.'","componentPublicAccess":"true","timeZone":"CET","sensor":"'.$sensorName.$sentilo->sensornumber .'","description":"'.$sensorDescription.'","type":"'.$sentilo->sentilosubtype.'","publicAccess":"true","dataType":"'.$dataType.'","unit":"'.$units.'"}]}');
						}
						else{
							array_push($sentiloMessage,'{"sensors":[{"component":"'.$sensorName.'","componentType":"'.$sentilo->sentilotype .'","componentDesc":"'.$sensorDescription.'","componentPublicAccess":"true","timeZone":"CET","sensor":"'.$sensorName.$sentilo->sensornumber .'","description":"'.$sensorDescription.'","type":"'.$sentilo->sentilosubtype.'","publicAccess":"true","dataType":"'.$dataType.'","unit":"'.$units.'"}');
						}
					}
					elseif($x == count($sentiloTypeInfo)-1){
					array_push($sentiloMessage,'{"component":"'.$sensorName.'","timeZone":"CET","sensor":"'.$sensorName.$sentilo->sensornumber .'","description":"'.$sensorDescription.'","type":"'.$sentilo->sentilosubtype .'","publicAccess":"true","dataType":"'.$dataType.'","unit":"'.$units.'"}]}');
					}
					else{
						
						array_push($sentiloMessage,'{"component":"'.$sensorName.'","timeZone":"CET","sensor":"'.$sensorName.$sentilo->sensornumber .'","description":"'.$sensorDescription.'","type":"'.$sentilo->sentilosubtype .'","publicAccess":"true","dataType":"'.$dataType.'","unit":"'.$units.'"}');
					}
			}
			$sentiloMessageStr = implode(",",$sentiloMessage);
			array_push($sentilomessageArray,$sentiloMessageStr);
		// if want to create sensor on sentilo.
		if($createSentilo == 'yes')
		{
		$curl = curl_init();

			curl_setopt_array($curl, array(
			CURLOPT_URL => $sentiloUrl.'/catalog/'.$sentiloPrivder,//"https://connecta.dival.es/sentilo-api/catalog/rafelguaraf@geswat",//$sentiloUrl.'/'.$sentiloPrivder,//'https://connecta.dival.es/sentilo-api/data/'.$provider.'/'.$varnames.'S01?from='.$lastMonthFirstDate.'&to='.$currnetDate.'&limit='.$limit,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_SSL_VERIFYPEER => false,
			CURLOPT_CUSTOMREQUEST => 'POST',
			CURLOPT_POSTFIELDS =>$sentiloMessageStr,/*'{"sensors":[
			   {"component":"'.$sensorName.'",
				"componentType":"'.$sentiloType.'",
				"componentDesc":"'.$sensorDescription.'",
				"componentPublicAccess":"true",
				"timeZone":"CET",
				"sensor":"'.$sensorName.'S01",
				"description":"'.$sensorDescription.'",
				"type":"'.$sentiloSubType.'",
				"publicAccess":"true",
				"dataType":"NUMBER",
				"unit":"litros"
			   }
			   
			]}',*/
			CURLOPT_HTTPHEADER => array(
				'IDENTITY_KEY:'.$sentiloToken,//db8fd01040e87d11af347f678f1d76923188abdb8f30e8b4445fde7f60d3cc8d',//38ba795b797b88c88c973f595a97ef53407b57ab754effadfec9354f7c1336cb',
				'Content-Type: application/json'
				),
			));

			$response = curl_exec($curl);
			$result = json_decode($response, true);
			curl_close($curl);
			//$observations =  array_reverse($result['observations']);
			
			$curl = curl_init();

		curl_setopt_array($curl, array(
		  CURLOPT_URL => $sentiloUrl.'/catalog/'.$sentiloPrivder,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'PUT',
		  CURLOPT_POSTFIELDS =>'{"components":[
		   {"component":"'.$sensorName.'", 
			"location":"'.$sensorLatitude.' '. $sensorLongitude.'"
		   }
		]}',
		  CURLOPT_HTTPHEADER => array(
			'IDENTITY_KEY: '.$sentiloToken,
			'Content-Type: application/json'
		  ),
		));

		$response = curl_exec($curl);

		curl_close($curl);
		}
		if($sensorType == 'customsensors'){
		$sensorTypeInfo = $em 
			->getRepository('AppBundle:SensorTypeInfo')
			->findOneBy(array('id' => $sensorSubType));
					
			$sensorTypeId  = $sensorTypeInfo->getId();
		
		$SensorTypeGatewayPkid= $em 
		->getRepository('AppBundle:SensorTypeGatewayPkid')
		->findOneBy(array('sensorTypeId' => $sensorTypeId));
		 $sensorTypePkid = $SensorTypeGatewayPkid->getPkId();
		 }
		$sensorInfo= $em 
			->getRepository('AppBundle:SensorInfo')
			->findOneBy(array('id' => $sensorId));
			$sensorFromPort = "4999";
			$sensorInfo->setSensorFromPort($sensorFromPort);
			if($sensorType == 'customsensors'){
			$sensorInfo->setTypeSensor($sensorTypeId);
			}
			$sensorInfo->setUpdatedDt(new \DateTime());
			$em->persist($sensorInfo);
		$sensorServerDetail = $em 
			->getRepository('AppBundle:SensorServerDetail')
			->findOneBy(array('serverId' => $serverId,'sensorId' =>$sensorId));
			if(!$sensorServerDetail){
				$sensorServerDetail = new SensorServerDetail();
				$sensorServerDetail->setServerId($serverId);
				$sensorServerDetail->setSensorId($sensorId);							
				$sensorServerDetail->setVarnames($sensorName);
				$em->persist($sensorServerDetail);
				//$em->flush();
			}
			
			$currentdatetime = new  \DateTime();
			$typeSensor =$sensorType;//'OemSensors';
			$applicationName = "app";
			
			$componentName = $sensorName;//$typeSensor;
			$loraAddress = $sensorDeviceEUI;//$typeSensor;
			$serverIds = 1;
			$hashSensorName = "S02";
			$countSensorName = "S01";		
			$gatewaymac = $gatewayMac ;//'B827EB7C3500';
			$topic = $gatewaymac.'/gateway_requests/request';
			if($sensorType == 'customsensors'){
			$path = "/CustomSensorDevices";
			}
			else{
			$path = "/".$typeSensor;	
			}
			$method = "POST";
			$port = 4999;
			$timestamp = $currentdatetime->format('c'); //"2019-12-08T16:00:02.2805625Z";
			if($sensorSubType == 'watersensor' ){
				switch($sensorSubTypeSub){
					case 'diehl':
						$sensorModelName ='DiehlHRLc G3';
						break;
					case 'itroncyble4':
						$sensorModelName ='ItronCyble4IoT';
						break;
					case 'itroncyble5':
						$sensorModelName ='ItronCyble5';
						break;
					case 'bmeters':
						$sensorModelName ='BmetersBmeters';
						break;
					case 'conthidra':
						$sensorModelName ='Conthidra';
						break;
					default:
						$sensorModelName ='no model name given';
				}
			
			}
			if($sensorSubType == 'parkingsensor'){
			$sensorModelName = $sensorSubTypeSub;
			}
			if($sensorSubType == 'airqualityobserved'){
			$sensorModelName = 'MilesCO2milesight';
			}
			
			$requestId = $sensorId;
			$body ='{';
			$typeSensor = 'OemSensors';
			if($typeSensor == 'OemSensors'){
			$body = $body.'\"sensorModelName\":\"'.$sensorModelName.'\"';
			$body = $body.',\"applicationName\":\"'.$applicationName.'\"';	
			$body = $body.',\"loraAddress\":\"'.$loraAddress.'\"';
			$body = $body.',\"componentName\":\"'.$componentName.'\"';
			
			
			if($sensorSubType == 'parkingsensor'){
				$body = $body.',\"sensorNames\":{\"OccupancyString\":\"S01\"}';
			}
			else if($sensorSubType == 'airqualityobserved'){
				$body = $body.',\"sensorNames\":{\"O3\":\"S12\",\"CO2\":\"S06\",\"PIR\":\"S04\",\"Beep\":\"S13\",\"HCHO\":\"S09\",\"PM10\":\"S11\",\"tVOC\":\"S07\",\"PM2-5\":\"S10\",\"Battery\":\"S01\",\"Humidity\":\"S03\",\"Pressure\":\"S08\",\"LightLevel\":\"S05\",\"Temperature\":\"S02\"}';
			}
			else{
				if($sensorModelName == 'BmetersBmeters'){
					$body = $body.',\"sensorNames\":{\"volume\":\"S01\"}';
				}
				elseif($sensorModelName == 'ItronCyble5'){
					$body = $body.',\"sensorNames\":{\"GlobalVolumeIndexM3WithScale\":\"S01\"}';
					$body = $body.',\"extraFields\":{\"EncryptionKey\":\"'.$EncryptionKey.'\"}';
				}
				else{
				$body = $body.',\"sensorNames\":{\"IndexAt0\":\"S01\"}';
				$body = $body.',\"extraFields\":null';
				}
			}
						
			$body = $body.',\"serverIds\":['.$serverPkId.']';
			}
			if($typeSensor == 'customsensors'){
				$body = $body.'\"componentName\":\"'.$componentName.'\"';
			$body = $body.',\"loraAddress\":\"'.$loraAddress.'\"';	
			$body = $body.',\"sensorTypeId\":'.$sensorTypePkid.'';					
			$body = $body.',\"serverIds\":['.$serverPkId.']';
			}			
			
			$body = $body.'}';
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';			
			$msg = $msg.',"authentication" : true';
			$msg = $msg.',"body":"'.$body.'"';
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$requestId.'"';			
			$msg = $msg.'}';
			

			$this->publish($topic, $msg);
			sleep(1);
			}
			$em->flush();
				
			return new JsonResponse(array('status' => 'Success','sentilomessageArray' => $sentilomessageArray,'data' => $data,'msg'=>$msg,'sentiloToken'=>$sentiloToken,'sentiloSensorNumber'=>$sentiloSensorNumber,'result'=>$result));
		
		
	}
	
	public function sensortypemsg($macAddress, $id, $typeSensorName, $sensorFormatString, $sensorNames,$customSensorsDecodeFormat,$customSensorsValueFilters,$nameofthesensorType){
		
				
				$currentdatetime = new  \DateTime();
					$configurationName = $nameofthesensorType;
					
					$sensorFormatString = $sensorFormatString;			
			$applicationName = "app";
			$sensorNames = $sensorNames;			
			$topic = $macAddress.'/gateway_requests/request';
			$path = "/customsensors";
			$method = "POST";
			$port = 4999;
			$timestamp = $currentdatetime->format('c'); //"2019-12-08T16:00:02.2805625Z";
			$requestId = "123456790";
			$body = '{';			
			$body = $body.'\"configurationName\":\"'.$configurationName.'\"';
			$body = $body.',\"customSensorsDecodeFormat\":['.$customSensorsDecodeFormat.']';
			$body = $body.',\"customSensorsValueFilters\":['.$customSensorsValueFilters.']';
			//$body = $body.',\"sensorFormatString\":\"'.$sensorFormatString.'\"';
			$body = $body.',\"applicationName\":\"'.$applicationName.'\"';
			//$body = $body.',\"sensorNames\":['.$sensorNames.']';			
			$body = $body.'}';
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';			
			$msg = $msg.',"authentication" : true';
			$msg = $msg.',"body":"'.$body.'"';
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$id.'"';				
			$msg = $msg.'}';
			//print_r($msg);

			$this->publish($topic, $msg);
	}
	
	/**
     * Update a Sensor Info remove from decoder
     *                                                                                 
	 * @Route("/removeFromDecoder", name="sensorinfo_removeFromDecoder")
	 */
	public function removeFromDecoderApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		$requesstedSensors = $data;//->sensorsFiltered;		
		$sensors_not_in_Database_array = [];
		$sensors_array = [];
		foreach ($requesstedSensors as $row) {
			$sensorInfo= $em 
			->getRepository('AppBundle:SensorInfo')
			->findOneBy(array('id' => $row->sensorId));
			
			if($sensorInfo !=null)
			{	
				$decoderServersarray = explode(",",$sensorInfo->getDecoderServers());
				if(sizeof($decoderServersarray) > 0){
					if(in_array($row->gatewayMac,$decoderServersarray)){
						unset($decoderServersarray[array_search($row->gatewayMac,$decoderServersarray)]);
					}
					if(sizeof($decoderServersarray)== 0){
						$sensorInfo->setSensorFromPort(null);
					}
				}
				
				$sensorInfo->setDecoderServers(implode(",",$decoderServersarray));			
				$sensorInfo->setUpdatedDt(new \DateTime());			
				$em->persist($sensorInfo);
				array_push($sensors_array,$row->sensorId);
			}
			else{
				array_push($sensors_not_in_Database_array,$row->sensorId);
			}
		}
		$em->flush();
		if(count($sensors_not_in_Database_array) > 0){
			return new JsonResponse(array('status' => 'FAILED','sensor_array'=>$sensors_array,'sensorIdNotInDatabase'=>$sensors_not_in_Database_array,'gateway'=>$row->gatewayMac,'message' => 'Error in updating sensor info Detail No Record found with this Id'));
		}
		else{
		return new JsonResponse(array('status' => 'SUCCESS','sensor_array'=>$sensors_array,'sensorIdNotInDatabase'=>$$sensors_not_in_Database_array,'gateway'=>$row->gatewayMac,'message' => 'Sensor is removed from decoder'));
		}
		
		
		
	}
	/**
     * List
     *                                                                                 
	 * @Route("/listforMapPage", name="sensor_list_formappage")
	 */
	public function SensorInfoForMapPageListApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());
		$userId = $data->userId;
		$underAdmin = $data->underAdmin;
		$permission = $data->permission;
		
		if($permission == 1){
			$sensorInfoList= $em 
			->getRepository('AppBundle:SensorInfo')
			->findAll();	
			/*$query = $em->createQuery(
            'SELECT s , stype
            FROM AppBundle\Entity\SensorInfo s
			LEFT JOIN AppBundle\Entity\SensorTypeInfo s.typeSensor stype
            ORDER BY s.id ASC'
        );
			 
        $result = $query->getResult();*/
		$result = '';
		}
		else if($permission == 2){
			if($underAdmin != null)
			{
				$sensorInfoList= $em 
			->getRepository('AppBundle:SensorInfo')
			->findBy(array('userId'=>$underAdmin));	
			}
			else{
			$sensorInfoList= $em 
			->getRepository('AppBundle:SensorInfo')
			->findBy(array('userId'=>$userId));	
			}
			
		}
		else{
			$user= $em 
			->getRepository('AppBundle:Users')
			->findOneBy(array('id'=>$userId));
			$sensorInfoList= $em 
			->getRepository('AppBundle:SensorInfo')
			->findBy(array('userId' =>$user->getUnderAdmin()));	
		}
		
		$rows = [];
		foreach($sensorInfoList as $row) {
			
			$typeSensorId = $row->getTypeSensor();
			
			if($typeSensorId != '' && $typeSensorId != null){
				$sensorTyeInfo = $em->getRepository('AppBundle:SensorTypeInfo')->findOneBy(array('id'=>$typeSensorId));
				if($sensorTyeInfo){					
					$row->setSensorTypeInfo($sensorTyeInfo);
					 }
			}
			
			$sensorTypeInfo = $row->getSensorTypeInfo();
				 $sensorTypeInfo_arr = [];
				 if($sensorTypeInfo){
					$sensorTypeInfo_arr =  array('id'=>$sensorTypeInfo->getId(),
									'name'=>$sensorTypeInfo->getName(),
									'description'=>$sensorTypeInfo->getDescription(),
									'sensorType'=>$sensorTypeInfo->getSensorType(),
									'componentType'=>$sensorTypeInfo->getComponentType(),
									'applicationName'=>$sensorTypeInfo->getApplicationName());
				 }
				 else{
					$sensorTypeInfo_arr =  array('id'=>null,
									'name'=>null,
									'description'=>null,
									'sensorType'=>null,
									'componentType'=>null,
									'applicationName'=>null); 
				 }
				 
		$rows[] = [
                'id' => $row->getId(),				
                'gatewaysId' => $row->getGatewaysId(),
                'name' => $row->getName(),
                'description' => $row->getDescription(),				
                'provider' => $row->getProvider(),
				'userId' => $row->getUserId(),
                'typeSensor' => $row->getTypeSensor(),
				'sensorTypeInfo' =>$sensorTypeInfo_arr,
				'sensorModelName' => $row->getSensorModelName(),				
				'installationDate' => $row->getInstallationDate()->format('Y-m-d'),
                'applicationName' => $row->getApplicationName(),               
                'latitude' => $row->getLatitude(),
				'longitude' => $row->getLongitude(),
                'deviceEUI' => $row->getDeviceEUI(),               
                'appEUI' => $row->getAppEUI(),				
				'appKEY' => $row->getAppKEY(),
				'encryptionKey' => $row->getEncryptionKey(),
				'sensorFromPort' => $row->getSensorFromPort(),
				'sensorFromChirpstack' => $row->getSensorFromChirpstack(),
                'inputComponentNames' => $row->getInputComponentNames(),               
                'meterComponentNames' => $row->getMeterComponentNames(),
				'decoderServers' => $row->getDecoderServers(),
				'dr' => $row->getDr(),
				'rssi' => $row->getRssi(),
				'frequency' => $row->getFrequency(),
				'firstFrameCounterFcnt' => $row->getFirstFrameCounterFcnt(),
				'prevFrameCounterFcnt' => $row->getPrevFrameCounterFcnt(),
				'latestFrameCounterFcnt' => $row->getLatestFrameCounterFcnt(),
				'lostFcnt' => $row->getLostFcnt(),
				'loraSNR' => $row->getLoraSnr(),
				'networkServerMac' => $row->getNetworkServerMac(),
				'messageTime' => $row->getMesssageTimes()
				
            ];
		}
		
		if($sensorInfoList != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('Y-m-d H:i:s'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			//$json = $serializer->serialize($sensorInfoList, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','sensorinfo_details' => $rows,'result'=>$result));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','sensorinfo_details' => $rows,'result'=>$result));
			//return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in sensor info data'));
	
	}
	
	/**
     * List
     *                                                                                 
	 * @Route("/list", name="sensor_list")
	 */
	public function SensorInfoListApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());
		$userId = $data->userId;
		$underAdmin = $data->underAdmin;
		$permission = $data->permission;
		
		
		
		if($permission == 1){			 
			$sensorInfoList= $em 
			->getRepository('AppBundle:SensorInfo')
			->findAll();
		}
		else if($permission == 2){
			if($underAdmin != null)
			{
				$sensorInfoList= $em 
			->getRepository('AppBundle:SensorInfo')
			->findBy(array('userId'=>$underAdmin));	
			}
			else{
			$sensorInfoList= $em 
			->getRepository('AppBundle:SensorInfo')
			->findBy(array('userId'=>$userId));	
			}
			
		}
		else{
			$user= $em 
			->getRepository('AppBundle:Users')
			->findOneBy(array('id'=>$userId));
			$sensorInfoList= $em 
			->getRepository('AppBundle:SensorInfo')
			->findBy(array('userId' =>$user->getUnderAdmin()));	
		}
		/* new query testing to improve speed end*
			$query = $em->createQuery(
    'SELECT s,soem,sti,sping
    FROM AppBundle:SensorInfo s
	JOIN AppBundle:SensorNamesInWaterOemsensor soem
	JOIN AppBundle:SensorTypeInfo sti
	JOIN AppBundle:SensorPing sping
    WHERE s.userId = :userId
    
)->setParameter('userId', $userId)';
		* new query testing to improve speed end*/

		/*$sensorInfoList= $em 
			->getRepository('AppBundle:SensorInfo')
			->findAll();*/
		
		$json = '';
		//var_dump($user);
		$rows = [];
		foreach($sensorInfoList as $row) {
			$oemsensorarray = [];
			$sensorId = $row->getId();
			$deviceEUI = $row->getDeviceEUI();
			$typeSensorId = $row->getTypeSensor();
			$sensorServerDetail = $em->getRepository('AppBundle:SensorServerDetail')->findOneBy(array('sensorId'=>$sensorId));
			$sensorGatewayPkid = $em->getRepository('AppBundle:SensorGatewayPkid')->findOneBy(array('sensorId'=>$sensorId));
			if($sensorGatewayPkid){
				$sensorPkid =  $sensorGatewayPkid->getPkId();
			}
			else{
				$sensorPkid = null;
			}
			$servers_arr = [];
			$serverName = null;
			if($sensorServerDetail){
			$serverId = $sensorServerDetail->getServerId();
			$Servers = $em->getRepository('AppBundle:Servers')->findOneBy(array('id'=>$serverId));
			//$sensorGatewayPkid = $em->getRepository('AppBundle:SensorGatewayPkid')->findOneBy(array('id'=>$serverId));
			
			if($Servers){
				$serverName = $Servers->getName();
				$servers_arr =array(
			'id'=>$Servers->getId(),
			'url'=>$Servers->getServerUrl(),
			'name'=>$Servers->getName(),
			'provider'=>$Servers->getProviderId(),
			'token'=>$Servers->getAuthorizationToken()
			);
			}
			else{
			$servers_arr =array(
			'id'=>null,
			'url'=>null,
			'name'=>null,
			'provider'=>null,
			'token'=>null
			);
			}
			}
			else{
				$serverId = null;
				$servers_arr =array(
			'id'=>null,
			'url'=>null,
			'name'=>null,
			'provider'=>null,
			'token'=>null
			);
			}
			
			$sensorNamesInWaterOemsensor = $em->getRepository('AppBundle:SensorNamesInWaterOemsensor')->findBy(array('sensorId'=>$sensorId));
			foreach($sensorNamesInWaterOemsensor as $oemsensor){
				$oemsensorarray[] = [
					'id' => $oemsensor->getId(),
					'indexat' => $oemsensor->getIndexat(),
					'sensorName' => $oemsensor->getSensorName(),
					'sensorId' => $oemsensor->getSensorId(),
					'sensorModelName' => $oemsensor->getSensorModelName()
				];
			}
			if($typeSensorId != '' && $typeSensorId != null){
				$sensorTyeInfo = $em->getRepository('AppBundle:SensorTypeInfo')->findOneBy(array('id'=>$typeSensorId));
				if($sensorTyeInfo){					
					$row->setSensorTypeInfo($sensorTyeInfo);
					 }
			}
			else{
				//$row->setSensorTypeInfo(null);
			}
				if($deviceEUI != ''  && $deviceEUI != null)
				{
				 $sensorPing = $em->getRepository('AppBundle:SensorPing')->findOneBy(array('deviceEUI'=>$deviceEUI));
				if($sensorPing){					
					$row->setSensorPing($sensorPing);
					 }
				}
				 $pingInfo = $row->getSensorPing();
				 $status = 'No Status';
				 $messageDatetime = 'No Update';
				 if($pingInfo){
					 $status =  $pingInfo->getStatus();
					 $messageDatetime =  $pingInfo->getMessageDatetime();
				 }
				 $sensorTypeInfo = $row->getSensorTypeInfo();
				 $sensorTypeInfo_arr = [];
				 if($sensorTypeInfo){
					$sensorTypeInfo_arr =  array('id'=>$sensorTypeInfo->getId(),
									'name'=>$sensorTypeInfo->getName(),
									'description'=>$sensorTypeInfo->getDescription(),
									'sensorType'=>$sensorTypeInfo->getSensorType(),
									'componentType'=>$sensorTypeInfo->getComponentType(),
									'applicationName'=>$sensorTypeInfo->getApplicationName());
				 }
				 else{
					$sensorTypeInfo_arr =  array('id'=>null,
									'name'=>null,
									'description'=>null,
									'sensorType'=>null,
									'componentType'=>null,
									'applicationName'=>null); 
				 }
            $rows[] = [
                'id' => $row->getId(),
				'sensorpingSatatus' => $status,	
				'sensorpingMessageDatetime' => $messageDatetime,					
                'sensorUniqueId' => $row->getSensorUniqueId(),
                'gatewaysId' => $row->getGatewaysId(),
                'name' => $row->getName(),
                'description' => $row->getDescription(),				
                'provider' => $row->getProvider(),
				'userId' => $row->getUserId(),
                'typeSensor' => $row->getTypeSensor(),
				'sensorModelName' => $row->getSensorModelName(),
				'typeInfo' =>$sensorTypeInfo_arr,
				'sensorTypeInfo' =>$sensorTypeInfo_arr, 
				'oemsensornames' =>$oemsensorarray,
				'installationDate' => $row->getInstallationDate()->format('Y-m-d'),
                'applicationName' => $row->getApplicationName(),               
                'latitude' => $row->getLatitude(),
				'longitude' => $row->getLongitude(),
                'deviceEUI' => $row->getDeviceEUI(),               
                'appEUI' => $row->getAppEUI(),				
				'appKEY' => $row->getAppKEY(),
				'encryptionKey' => $row->getEncryptionKey(),
				'sensorFromPort' => $row->getSensorFromPort(),
				'sensorFromChirpstack' => $row->getSensorFromChirpstack(),
                'inputComponentNames' => $row->getInputComponentNames(),               
                'meterComponentNames' => $row->getMeterComponentNames(),
				'decoderServers' => $row->getDecoderServers(),
				'dr' => $row->getDr(),
				'rssi' => $row->getRssi(),
				'frequency' => $row->getFrequency(),
				'firstFrameCounterFcnt' => $row->getFirstFrameCounterFcnt(),
				'prevFrameCounterFcnt' => $row->getPrevFrameCounterFcnt(),
				'latestFrameCounterFcnt' => $row->getLatestFrameCounterFcnt(),
				'lostFcnt' => $row->getLostFcnt(),
				'loraSNR' => $row->getLoraSnr(),
				'networkServerMac' => $row->getNetworkServerMac(),
				'messageTime' => $row->getMesssageTimes(),
				'serverName' => $serverName,
				'sensorPkid'=>$sensorPkid,
				'servers'=>$servers_arr
            ];
			
		}		
		
		
		if($sensorInfoList != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('Y-m-d H:i:s'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			//$json = $serializer->serialize($sensorInfoList, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','sensorinfo_details' => $rows));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','sensorinfo_details' => $rows));
			//return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in sensor info data'));
	}
	
	/**
     * List
     *                                                                                 
	 * @Route("/listByPagination", name="sensor_list_by_pagination")
	 */
	public function SensorInfoListByPaginationApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());
		$userId = $data->userId;
		$underAdmin = $data->underAdmin;
		$permission = $data->permission;
		$limit = $data->limit;
		$pageNo = $data->pageNo;
		
		$sortBy =  'id';
		$sortOrder =  'desc';
		$pageNo = $pageNo ? $pageNo : 1;
		$limit = $limit ? $limit : 10;
		
		$q = $em->getRepository('AppBundle:SensorInfo')->createQueryBuilder('d');
		if($permission == 1){ 
			 
			/*$sensorInfoList= $em 
			->getRepository('AppBundle:SensorInfo')
			->findAll();*/	
		}
		else if($permission == 2){
			if($underAdmin != null)
			{
				$q->andWhere('d.userId = :userId') 
            ->setParameter('userId', $underAdmin);
				/*
				$sensorInfoList= $em 
			->getRepository('AppBundle:SensorInfo')
			->findBy(array('userId'=>$underAdmin));	*/
			}
			else{
				$q->andWhere('d.userId = :userId') 
            ->setParameter('userId', $userId);
			/*$sensorInfoList= $em 
			->getRepository('AppBundle:SensorInfo')
			->findBy(array('userId'=>$userId));*/	
			}
			
		}
		else{
			$user= $em 
			->getRepository('AppBundle:Users')
			->findOneBy(array('id'=>$userId));
			$q->andWhere('d.userId = :userId') 
            ->setParameter('userId', $user->getUnderAdmin());
			/*$sensorInfoList= $em 
			->getRepository('AppBundle:SensorInfo')
			->findBy(array('userId' =>$user->getUnderAdmin()));	*/
		}
		$q->orderBy("d.$sortBy", $sortOrder)->getQuery();
		$sensorInfoList = new \Doctrine\ORM\Tools\Pagination\Paginator($q);

			$total = $sensorInfoList->count();
			$pageCount = (int) ceil($total / $limit);

			//$paginator
			$sensorInfoList
			->getQuery()
			->setFirstResult($limit * ($pageNo - 1)) // set the offset
			->setMaxResults($limit); // set the limit
			 
		
		
		$json = '';
		//var_dump($user);
		$rows = [];
		foreach($sensorInfoList as $row) {
			$oemsensorarray = [];
			$sensorId = $row->getId();
			$deviceEUI = $row->getDeviceEUI();
			$typeSensorId = $row->getTypeSensor();
			$sensorServerDetail = $em->getRepository('AppBundle:SensorServerDetail')->findOneBy(array('sensorId'=>$sensorId));
			$sensorGatewayPkid = $em->getRepository('AppBundle:SensorGatewayPkid')->findOneBy(array('sensorId'=>$sensorId));
			if($sensorGatewayPkid){
				$sensorPkid =  $sensorGatewayPkid->getPkId();
			}
			else{
				$sensorPkid = null;
			}
			$servers_arr = [];
			$serverName = null;
			if($sensorServerDetail){
			$serverId = $sensorServerDetail->getServerId();
			$Servers = $em->getRepository('AppBundle:Servers')->findOneBy(array('id'=>$serverId));
			//$sensorGatewayPkid = $em->getRepository('AppBundle:SensorGatewayPkid')->findOneBy(array('id'=>$serverId));
			
			if($Servers){
				$serverName = $Servers->getName();
				$servers_arr =array(
			'id'=>$Servers->getId(),
			'url'=>$Servers->getServerUrl(),
			'name'=>$Servers->getName(),
			'provider'=>$Servers->getProviderId(),
			'token'=>$Servers->getAuthorizationToken()
			);
			}
			else{
			$servers_arr =array(
			'id'=>null,
			'url'=>null,
			'name'=>null,
			'provider'=>null,
			'token'=>null
			);
			}
			}
			else{
				$serverId = null;
				$servers_arr =array(
			'id'=>null,
			'url'=>null,
			'name'=>null,
			'provider'=>null,
			'token'=>null
			);
			}
			
			$sensorNamesInWaterOemsensor = $em->getRepository('AppBundle:SensorNamesInWaterOemsensor')->findBy(array('sensorId'=>$sensorId));
			foreach($sensorNamesInWaterOemsensor as $oemsensor){
				$oemsensorarray[] = [
					'id' => $oemsensor->getId(),
					'indexat' => $oemsensor->getIndexat(),
					'sensorName' => $oemsensor->getSensorName(),
					'sensorId' => $oemsensor->getSensorId(),
					'sensorModelName' => $oemsensor->getSensorModelName()
				];
			}
			if($typeSensorId != '' && $typeSensorId != null){
				$sensorTyeInfo = $em->getRepository('AppBundle:SensorTypeInfo')->findOneBy(array('id'=>$typeSensorId));
				if($sensorTyeInfo){					
					$row->setSensorTypeInfo($sensorTyeInfo);
					 }
			}
			else{
				//$row->setSensorTypeInfo(null);
			}
				if($deviceEUI != ''  && $deviceEUI != null)
				{
				 $sensorPing = $em->getRepository('AppBundle:SensorPing')->findOneBy(array('deviceEUI'=>$deviceEUI));
				if($sensorPing){					
					$row->setSensorPing($sensorPing);
					 }
				}
				 $pingInfo = $row->getSensorPing();
				 $status = 'No Status';
				 $messageDatetime = 'No Update';
				 if($pingInfo){
					 $status =  $pingInfo->getStatus();
					 $messageDatetime =  $pingInfo->getMessageDatetime();
				 }
				 $sensorTypeInfo = $row->getSensorTypeInfo();
				 $sensorTypeInfo_arr = [];
				 if($sensorTypeInfo){
					$sensorTypeInfo_arr =  array('id'=>$sensorTypeInfo->getId(),
									'name'=>$sensorTypeInfo->getName(),
									'description'=>$sensorTypeInfo->getDescription(),
									'sensorType'=>$sensorTypeInfo->getSensorType(),
									'componentType'=>$sensorTypeInfo->getComponentType(),
									'applicationName'=>$sensorTypeInfo->getApplicationName());
				 }
				 else{
					$sensorTypeInfo_arr =  array('id'=>null,
									'name'=>null,
									'description'=>null,
									'sensorType'=>null,
									'componentType'=>null,
									'applicationName'=>null); 
				 }
            $rows[] = [
                'id' => $row->getId(),
				'sensorpingSatatus' => $status,	
				'sensorpingMessageDatetime' => $messageDatetime,					
                'sensorUniqueId' => $row->getSensorUniqueId(),
                'gatewaysId' => $row->getGatewaysId(),
                'name' => $row->getName(),
                'description' => $row->getDescription(),				
                'provider' => $row->getProvider(),
				'userId' => $row->getUserId(),
                'typeSensor' => $row->getTypeSensor(),
				'sensorModelName' => $row->getSensorModelName(),
				'typeInfo' =>$sensorTypeInfo_arr,
				'sensorTypeInfo' =>$sensorTypeInfo_arr, 
				'oemsensornames' =>$oemsensorarray,
				'installationDate' => $row->getInstallationDate()->format('Y-m-d'),
                'applicationName' => $row->getApplicationName(),               
                'latitude' => $row->getLatitude(),
				'longitude' => $row->getLongitude(),
                'deviceEUI' => $row->getDeviceEUI(),               
                'appEUI' => $row->getAppEUI(),				
				'appKEY' => $row->getAppKEY(),
				'encryptionKey' => $row->getEncryptionKey(),
				'sensorFromPort' => $row->getSensorFromPort(),
				'sensorFromChirpstack' => $row->getSensorFromChirpstack(),
                'inputComponentNames' => $row->getInputComponentNames(),               
                'meterComponentNames' => $row->getMeterComponentNames(),
				'decoderServers' => $row->getDecoderServers(),
				'dr' => $row->getDr(),
				'rssi' => $row->getRssi(),
				'frequency' => $row->getFrequency(),
				'firstFrameCounterFcnt' => $row->getFirstFrameCounterFcnt(),
				'prevFrameCounterFcnt' => $row->getPrevFrameCounterFcnt(),
				'latestFrameCounterFcnt' => $row->getLatestFrameCounterFcnt(),
				'lostFcnt' => $row->getLostFcnt(),
				'loraSNR' => $row->getLoraSnr(),
				'networkServerMac' => $row->getNetworkServerMac(),
				'messageTime' => $row->getMesssageTimes(),
				'serverName' => $serverName,
				'sensorPkid'=>$sensorPkid,
				'servers'=>$servers_arr
            ];
			
		}		
		
		
		if($sensorInfoList != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('Y-m-d H:i:s'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			//$json = $serializer->serialize($sensorInfoList, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','sensorinfo_details' => $rows));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','sensorinfo_details' => $rows,'total' => $total, 'pages' => $pageCount? $pageCount : 0, 'pageNo' => (int)$pageNo, 'limit' => (int)$limit));
			//return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in sensor info data'));
	}
	/**
     * List
     *                                                                                 
	 * @Route("/listbyGateway", name="sensor_list_by_gateway")
	 */
	public function SensorInfoListByGatewayApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());
		$gatewaySensorIds = $data->gatewaySensorIds;
		
			$sensorInfoList= $em 
			->getRepository('AppBundle:SensorInfo')
			->findBy(array('id'=>$gatewaySensorIds));	
		
		$json = '';
		
		$rows = [];
		foreach($sensorInfoList as $row) {
			$oemsensorarray = [];
			$sensorId = $row->getId();
			$deviceEUI = $row->getDeviceEUI();
			$typeSensorId = $row->getTypeSensor();
			$sensorNamesInWaterOemsensor = $em->getRepository('AppBundle:SensorNamesInWaterOemsensor')->findBy(array('sensorId'=>$sensorId));
			
			
				if($deviceEUI != ''  && $deviceEUI != null)
				{
				 $sensorPing = $em->getRepository('AppBundle:SensorPing')->findOneBy(array('deviceEUI'=>$deviceEUI));
				if($sensorPing){					
					$row->setSensorPing($sensorPing);
					 }
				}
				 $pingInfo = $row->getSensorPing();
				 $status = 'No Status';
				 $messageDatetime = 'No Update';
				 if($pingInfo){
					 $status =  $pingInfo->getStatus();
					 $messageDatetime =  $pingInfo->getMessageDatetime();
				 }
				 
				 
				 
            $rows[] = [
                'id' => $row->getId(),
				'sensorpingSatatus' => $status,	
				'sensorpingMessageDatetime' => $messageDatetime,					
                'sensorUniqueId' => $row->getSensorUniqueId(),
                'gatewaysId' => $row->getGatewaysId(),
                'name' => $row->getName(),
                'description' => $row->getDescription(),				
                'provider' => $row->getProvider(),
				'userId' => $row->getUserId(),
                'typeSensor' => $row->getTypeSensor(),
				'sensorModelName' => $row->getSensorModelName(),				
				'installationDate' => $row->getInstallationDate()->format('Y-m-d'),
                'applicationName' => $row->getApplicationName(),               
                'latitude' => $row->getLatitude(),
				'longitude' => $row->getLongitude(),
                'deviceEUI' => $row->getDeviceEUI(),               
                'appEUI' => $row->getAppEUI(),				
				'appKEY' => $row->getAppKEY(),
				'encryptionKey' => $row->getEncryptionKey(),
                'inputComponentNames' => $row->getInputComponentNames(),               
                'meterComponentNames' => $row->getMeterComponentNames(),
				'sensorFromPort' => $row->getSensorFromPort(),
				'sensorFromChirpstack' => $row->getSensorFromChirpstack(),
				'dr' => $row->getDr(),
				'rssi' => $row->getRssi(),
				'frequency' => $row->getFrequency(),
				'firstFrameCounterFcnt' => $row->getFirstFrameCounterFcnt(),
				'prevFrameCounterFcnt' => $row->getPrevFrameCounterFcnt(),
				'latestFrameCounterFcnt' => $row->getLatestFrameCounterFcnt(),
				'lostFcnt' => $row->getLostFcnt(),
				'loraSNR' => $row->getLoraSnr(),
				'messageTime' => $row->getMesssageTimes()
				
            ];
			
		}		
		
		
		if($sensorInfoList != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('Y-m-d H:i:s'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			//$json = $serializer->serialize($sensorInfoList, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','sensorinfo_details' => $rows));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','sensorinfo_details' => $rows));
			//return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in sensor info data'));
	}
	
	/**
     * Get SensorInfo by Id
     *                                                                                 
	 * @Route("/getsensorinfobyid", name="sensorinfo_getsensorinfobyid")
	 */
	public function getSensorInfobyidApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$sensorInfoId = $data->id;
		
		$sensorInfo= $em 
			->getRepository('AppBundle:SensorInfo')
			->findBy(array('id' => $sensorInfoId));
			
		$rows = [];
		
		foreach($sensorInfo as $row) {
			$oemsensorarray = [];
			 $sensorId = $row->getId();
			$sensorNamesInWaterOemsensor = $em->getRepository('AppBundle:SensorNamesInWaterOemsensor')->findBy(array('sensorId'=>$sensorId));
			foreach($sensorNamesInWaterOemsensor as $oemsensor){
				$oemsensorarray[] = [
					'id' => $oemsensor->getId(),
					'indexat' => $oemsensor->getIndexat(),
					'sensorName' => $oemsensor->getSensorName(),
					'sensorId' => $oemsensor->getSensorId(),
					'sensorModelName' => $oemsensor->getSensorModelName()
				];
			}
            $rows[] = [
                'id' => $row->getId(),
                'sensorUniqueId' => $row->getSensorUniqueId(),
                'gatewaysId' => $row->getGatewaysId(),
                'name' => $row->getName(),
                'description' => $row->getDescription(),				
                'provider' => $row->getProvider(),
                'typeSensor' => $row->getTypeSensor(),
				'oemsensornames' =>$oemsensorarray,
				'sensorModelName' => $row->getSensorModelName(),
				'installationDate' => $row->getInstallationDate()->format('Y-m-d'),
                'applicationName' => $row->getApplicationName(),               
                'latitude' => $row->getLatitude(),
				'longitude' => $row->getLongitude(),
                'deviceEUI' => $row->getDeviceEUI(),               
                'appEUI' => $row->getAppEUI(),				
				'appKEY' => $row->getAppKEY(),
				'encryptionKey' => $row->getEncryptionKey(),
                'inputComponentNames' => $row->getInputComponentNames(),               
                'meterComponentNames' => $row->getMeterComponentNames()		
				
            ];
		}
		if( $sensorInfo != null)
		{
			$serializer = new Serializer(array(new DateTimeNormalizer('Y-m-d H:i:s'),new GetSetMethodNormalizer()), array('json' => new 
			JsonEncoder()));
			//$json = $serializer->serialize($sensorInfo, 'json');
			
			return new JsonResponse(array('status' => 'Success','sensorinfo_details' => $rows));
		}
		else{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in getting sensor info details!!'));
		} 
		
	}
	
	/**
     * Delete a Sensor Info
     *                                                                                 
	 * @Route("/deletesensorinfo", name="sensorinfo_deletesensorinfo")
	 */
	public function deleteSensorInfoApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());		
		$sensorInfoId = $data->id;
		$sensorUniqueId = $data->sensorUniqueId;
		$sensorInfo= $em 
			->getRepository('AppBundle:SensorInfo')
			->findOneBy(array('id' => $sensorInfoId));
			
			$currentdatetime = new  \DateTime();
			
		if($sensorInfo != null)
		{
			$typeSensor = $sensorInfo->getTypeSensor();
			$em->remove($sensorInfo);
            $em->flush();
			$gatewaymac = 'b827eb98e519' ;//'B827EB7C3500';
			$topic =  $gatewaymac.'/gateway_requests/request';
			$path = "/".$typeSensor."/".$sensorUniqueId;
			$method = "DELETE";
			$port = 4999;
			$timestamp = $currentdatetime->format('c');//"2019-12-08T16:00:02.2805625Z";
			$requestId = "123456790";
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';
			$msg = $msg.',"authentication" : true';
			$msg = $msg.',"body":""';
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$requestId.'"';			
			$msg = $msg.'}';
			

			//$this->publish($topic, $msg);
		return new JsonResponse(array('status' => 'SUCCESS','message' => 'sensor info has been successfully removed!!'));
		}
		else{
			return new JsonResponse(array('status' => 'Failed','message' => 'No sensor info is Present with this Id!!'));
		}
	}
	/**
     * Import Sensors In database SensorInfo
     *                                                                                 
	 * @Route("/importnewsensorinfo", name="sensorinfo_importnewsensorinfo")
	 */
	public function importNewSensorInfoApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
	$datas = json_decode($request->getContent());
	
	$alreadySensorInDatabase =[];
	$insertingCount=0;
	$Totalcount = Count($datas);
	foreach($datas as $data){		
			$deviceEUI = strtolower($data->DEVEUI);
			$description = $data->DESCRIPTION;
			$encryptionKey = $data->ENCRYPTIONKEY;
			$appkey = $data->APPKEY;
			$appEUI = $data->APPEUI;
			$userId = $data->USERID;
			$name = $data->NAME;
			$longitude = $data->LONGITUDE;
			$latitude = $data->LATITUDE;
			$sensorModelName = $data->TYPE;
			$findSensor = $em 
				->getRepository('AppBundle:SensorInfo')
				->findOneBy(array('deviceEUI'=>$data->DEVEUI));			
			if(!$findSensor){
				$sensor = new SensorInfo();			
				$sensor->setUserId($userId);			
				$sensor->setName($name);
				$sensor->setDeviceEUI($deviceEUI);
				$sensor->setDescription($description);
				if($encryptionKey){
					$sensor->setEncryptionKey($encryptionKey);
				}
				else{
					$sensor->setEncryptionKey(null);
				}
				if($latitude != ""){
					$latitudeval = preg_replace('/\s+/', '', $latitude);
				$sensor->setLatitude($latitudeval);
				}
				else{
				$sensor->setLatitude(null);}
				if($longitude != ""){
					$longitudeval = preg_replace('/\s+/', '', $longitude);
				$sensor->setLongitude($longitudeval);}
				else{
				$sensor->setLongitude(null);}
				
				$sensor->setAppKEY($appkey);
				
				if($appEUI != ""){
				$sensor->setAppEUI($appEUI);}
				else{
				$sensor->setAppEUI(null);}
				
				if($sensorModelName != ""){
				$sensor->setSensorModelName($sensorModelName);}
				else {
					$sensor->setSensorModelName(null);}
		
				//$sensor->setSensorFromPort($sensorFromPort);
				$sensor->setInstallationDate(new \DateTime());
				$em->persist($sensor);
				$insertingCount++;
			}
			else{
				array_push($alreadySensorInDatabase,$data);				
				
			}
	}
	
	$em->flush();
		return new JsonResponse(array('status' => 'SUCCESS','datas'=>$datas,'Totalcount'=>$Totalcount,'insertingCount'=>$insertingCount,'alreadySensorInDatabase'=>$alreadySensorInDatabase,'message' => 'This Sensor Downloaded Successfully'));
	}
	
	/**
     * update by Import Sensors In database SensorInfo
     *                                                                                 
	 * @Route("/importupdatesensorinfo", name="sensorinfo_importupdatesensorinfo")
	 */
	public function importUpdateSensorInfoApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
	$datas = json_decode($request->getContent());
	
	$alreadySensorInDatabase =[];
	$updatingCount=0;
	$Totalcount = Count($datas);
	foreach($datas as $data){		
			$deviceEUI = strtolower($data->DEVEUI);
			$description = $data->DESCRIPTION;
			$encryptionKey = $data->ENCRYPTIONKEY;
			$appkey = $data->APPKEY;
			$appEUI = $data->APPEUI;
			
			$name = $data->NAME;
			$longitude = $data->LONGITUDE;
			$latitude = $data->LATITUDE;
			$sensorModelName = $data->TYPE;
			$sensor = $em 
				->getRepository('AppBundle:SensorInfo')
				->findOneBy(array('deviceEUI'=>$deviceEUI));			
			if($sensor){
				if($name != ''){		
				$sensor->setName($name);
				}
				if($description != ''){
				$sensor->setDescription($description);
				}
				
				if($encryptionKey != ''){
					$sensor->setEncryptionKey($encryptionKey);
				}
				
				if($latitude != ""){
					$latitudeval = preg_replace('/\s+/', '', $latitude);
				$sensor->setLatitude($latitudeval);
				}
				
				if($longitude != ""){
					$longitudeval = preg_replace('/\s+/', '', $longitude);
				$sensor->setLongitude($longitudeval);}
				
				if($appkey != ""){
				$sensor->setAppKEY($appkey);
				}
				
				if($appEUI != ""){
				$sensor->setAppEUI($appEUI);}			
				
				$em->persist($sensor);
				$updatingCount++;
			}
			
	}
	
	$em->flush();
		return new JsonResponse(array('status' => 'SUCCESS','datas'=>$datas,'Totalcount'=>$Totalcount,'updatingCount'=>$updatingCount,'message' => 'This Sensor Updated Successfully'));
	}
	
	/**
     * Create New SensorInfo
     *                                                                                 
	 * @Route("/newsensorinfo", name="sensorinfo_newsensorinfo")
	 */
	public function newSensorInfoApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		// var_dump($data);
		
		$sensorUniqueId = $data->sensorUniqueId;		
		$name = $data->name;
		$description = $data->description;
		$provider = $data->provider;
        $userId = $data->userId;		
		$typeSensor = $data->typeSensor;
		
		$installationDate = $data->installationDate;
		$applicationName = $data->applicationName;
		$latitude = $data->latitude;
		$longitude = $data->longitude;
		$deviceEUI = strtolower($data->deviceEUI);
		$appEUI = $data->appEUI;
		$appKEY = $data->appKEY;
		$encryptionKey = $data->encryptionKey;
		$inputComponentNames = $data->inputComponentNames;
		$meterComponentNames = $data->meterComponentNames;
		//oemSensorDetailstart
		$sensorModelName = $data->sensorModelName;
		$indexat = $data->indexat;
		$sensorName = $data->sensorName;
		//oemSensordetailend
		
		$sensorInfoObj= $em 
			->getRepository('AppBundle:SensorInfo')
			->findBy(array('sensorUniqueId' => $sensorUniqueId,'name' => $name,'typeSensor' => $typeSensor));
			
		$currentdatetime = new  \DateTime();	
		if($sensorInfoObj != null)
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Requested sensor info is already exists!!'));
		}
		else{
			
			$sensorInfo = new SensorInfo();
			if($sensorUniqueId != "")
			$sensorInfo->setSensorUniqueId($sensorUniqueId);
			
			$sensorInfo->setName($name);
			$sensorInfo->setDescription($description);
			$sensorInfo->setUserId($userId);
			
			if($encryptionKey){
					$sensorInfo->setEncryptionKey($encryptionKey);
				}
			else{
					$sensorInfo->setEncryptionKey(null);
				}
			
			if($provider != "")
			$sensorInfo->setProvider($provider);
		
			$sensorInfo->setTypeSensor($typeSensor);
			
			if($sensorModelName != "")
			$sensorInfo->setSensorModelName($sensorModelName);
			
			$sensorInfo->setInstallationDate(new \DateTime($installationDate));
			
			if($applicationName != "")
			$sensorInfo->setApplicationName($applicationName);
			else
			$sensorInfo->setApplicationName(null);
			
			if($latitude != "")
			$sensorInfo->setLatitude($latitude);
			else
			$sensorInfo->setLatitude(null);
		
			if($longitude != "")
			$sensorInfo->setLongitude($longitude);
			else
			$sensorInfo->setLongitude(null);
		
			if($deviceEUI != "")
			$sensorInfo->setDeviceEUI($deviceEUI);
			else
			$sensorInfo->setDeviceEUI(null);
			
			if($appEUI != "")
			$sensorInfo->setAppEUI($appEUI);
			else
			$sensorInfo->setAppEUI(null);	
			
			if($appKEY != "")
			$sensorInfo->setAppKEY($appKEY);
			else
			$sensorInfo->setAppKEY(null);
		
			if($inputComponentNames != "")
			$sensorInfo->setInputComponentNames($inputComponentNames);
			if($meterComponentNames != "")
			$sensorInfo->setMeterComponentNames($meterComponentNames);
			
		
			$em->persist($sensorInfo);
			$em->flush();
			$Id = $sensorInfo->getId();
			$sensorNamesInWaterOemsensor = new SensorNamesInWaterOemsensor();
			if($indexat != "")
			$sensorNamesInWaterOemsensor->setIndexat($indexat);
			else
			$sensorNamesInWaterOemsensor->setIndexat(null);
			
			if($sensorName != "")
			$sensorNamesInWaterOemsensor->setSensorName($sensorName);
			else
			$sensorNamesInWaterOemsensor->setSensorName(null);
			
			if($Id != "")
			$sensorNamesInWaterOemsensor->setSensorId($Id);
			else
			$sensorNamesInWaterOemsensor->setSensorId(null);
			
			if($sensorModelName != "")
			$sensorNamesInWaterOemsensor->setSensorModelName($sensorModelName);
			else
			$sensorNamesInWaterOemsensor->setSensorModelName(null);
			
			$sensorNamesInWaterOemsensor->setCreatedDt(new \DateTime());
		
			$em->persist($sensorNamesInWaterOemsensor);			
			$em->flush();
			$applicationName = "app";
			//$sentiloComponentType = "air_quality";//$typeSensor;
			$componentName = $name;//$typeSensor;
			$loraAddress = $deviceEUI;//$typeSensor;
			//$location = "42";//$latitude;
			//$publicAccess ="false";
			$serverIds = 1;
			$hashSensorName = "S02";
			$countSensorName = "S01";			
			$customSensor = 2;
			$gatewaymac = 'b827eb98e519' ;//'B827EB7C3500';
			$topic = $gatewaymac.'/gateway_requests/request';
			$path = "/".$typeSensor;
			$method = "POST";
			$port = 4999;
			$timestamp = $currentdatetime->format('c'); //"2019-12-08T16:00:02.2805625Z";
			$requestId = $Id;
			$body ='{';
			if($typeSensor == 'wifi'){
			$body = $body.'\"applicationName\":\"'.$applicationName.'\"';	
			$body = $body.',\"hashSensorName\":\"'.$hashSensorName.'\"';
			$body = $body.',\"countSensorName\":\"'.$countSensorName.'\"';			
			}
			if($typeSensor == 'ibox'){
			$body = $body.'\"applicationName\":\"'.$applicationName.'\"';	
			$body = $body.',\"hashSensorName\":\"'.$hashSensorName.'\"';
			$body = $body.',\"countSensorName\":\"'.$countSensorName.'\"';
			}
			if($typeSensor == 'customsensordevices'){
			$body = $body.'\"customSensor\":'.$customSensor;
			
			}
			//$body = $body.',\"sentiloComponentType\":\"'.$sentiloComponentType.'\"';
			$body = $body.',\"componentName\":\"'.$componentName.'\"';
			$body = $body.',\"loraAddress\":\"'.$loraAddress.'\"';
			$body = $body.',\"serverIds\":['.$serverIds.']';
			//$body = $body.',\"location\":\"'.$location.'\"';
			//$body = $body.',\"publicAccess\":\"'.$publicAccess.'\"';
			
			
			
			$body = $body.'}';
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';			
			$msg = $msg.',"authentication" : true';
			$msg = $msg.',"body":"'.$body.'"';
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$requestId.'"';			
			$msg = $msg.'}';
			

			//$this->publish($topic, $msg);
			
			if( $Id != '')
			{
				return new JsonResponse(array('status' => 'SUCCESS','msg' => $msg,'message' => 'sensor info has been successfully created!!','id' => $Id));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in registering sensor info registeration!!'));
			}
			
		}
		
	}
	/**
     * Reset Fram Counter
     *                                                                                 
	 * @Route("/resetFrameCounter", name="sensorinfo_resetframecounter")
	 */
	public function resetFrameCounterApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$sensorInfoId = $data->id;
		$sensordeviceEUI = $data->deviceEUI;
		$sensorInfo= $em 
			->getRepository('AppBundle:SensorInfo')
			->findOneBy(array('id' => $sensorInfoId));
		
			$sensorInfo->setFirstFrameCounterFcnt(0);
			$sensorInfo->setPrevFrameCounterFcnt(0);
			$sensorInfo->setLatestFrameCounterFcnt(0);
			$sensorInfo->setLostFcnt(0);
			$sensorInfo->setUpdatedDt(new \DateTime());
			
			$em->persist($sensorInfo);
			$em->flush();
			$sensorInfoId = $sensorInfo->getId();
			if($sensorInfoId != "")
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'Frame Counter is Reset!'));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in reset frame counter!!'));
			}
	
	}
	/**
     * Update a Sensor Info
     *                                                                                 
	 * @Route("/updatesensorinfo", name="sensorinfo_updatesensorinfo")
	 */
	public function updateSensorInfoApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$sensorInfoId = $data->id;
		$sensorUniqueId = $data->sensorUniqueId;		
		$name = $data->name;
		$description = $data->description;
		$provider = $data->provider;		
		$typeSensor = $data->typeSensor;
		$sensorModelName = $data->sensorModelName;
		$installationDate = $data->installationDate;
		//print_r($installationDate);
		$applicationName = $data->applicationName;
		$latitude = $data->latitude;
		$longitude = $data->longitude;
		$deviceEUI = strtolower($data->deviceEUI);
		$appEUI = $data->appEUI;
		$appKEY = $data->appKEY;
		$encryptionKey = $data->encryptionKey;
		$inputComponentNames = $data->inputComponentNames;
		$meterComponentNames = $data->meterComponentNames;	
		
		//oemSensorDetailstart
		$sensorModelName = $data->sensorModelName;
		$indexat = $data->indexat;
		$sensorName = $data->sensorName;
		//oemSensordetailend
		
		$sensorInfo= $em 
			->getRepository('AppBundle:SensorInfo')
			->findOneBy(array('id' => $sensorInfoId));
		$sensorServerObj= $em
		->getRepository('AppBundle:SensorServerDetail')
		->findBy(array('sensorId' => $sensorInfoId));
					
		$serverIds  = [];
		foreach ($sensorServerObj   as $value){ 
		array_push($serverIds,$value->getServerId());
		}	
		$sensorTypeObj= $em 
			->getRepository('AppBundle:SensorTypeInfo')
			->findOneBy(array('id' => $typeSensor));
		$SensorTypeGatewayPkid= $em 
		->getRepository('AppBundle:SensorTypeGatewayPkid')
		->findOneBy(array('sensorTypeId' => $typeSensor));
		$currentdatetime = new  \DateTime();	
			
		if($sensorInfo !=null)
		{
			$SensorGatewayPkids= $em 
				->getRepository('AppBundle:SensorGatewayPkid')
				->findBy(array('sensorId' => $sensorInfoId));
				/*if($SensorGatewayPkids != null){
				foreach ($SensorGatewayPkids   as $SensorGatewayPkid){
						$pkId = $SensorGatewayPkid->getPkId();
						$macNumber = $SensorGatewayPkid->getMacNumber();
						
						$id = $sensorInfoId;	
						$typeSensorName = $sensorTypeObj->getName();							
						$componentName = $name;					
						$hashSensorName="";
						$countSensorName="";
						if($typeSensorName !=  "wifi" && $typeSensorName !=  "ibox")
						{							
							$customSensor=$SensorTypeGatewayPkid->getPkId();					
						}
						else{
							$customSensor="";
						}
						
							$pkId = $SensorGatewayPkid->getPkId();
							if($pkId)
							{
								$this->sensormsg($macNumber, $id,  $typeSensorName, $componentName, $deviceEUI, $serverIds, $hashSensorName, $countSensorName, $customSensor,$pkId);
						
								$this->sensormsgchirpstack($macNumber, $id, $componentName, $deviceEUI, $description);
								sleep(3);
								$this->sensormsgchirpstackkey($macNumber, $id, $componentName, $appKEY, $deviceEUI);
							}
							
						
				}
		}*/
			if($sensorUniqueId != "")
			$sensorInfo->setSensorUniqueId($sensorUniqueId);
		
			if($name != "")
			$sensorInfo->setName($name);
		
			if($description != "")
			$sensorInfo->setDescription($description);
		
			if($provider != "")
			$sensorInfo->setProvider($provider);
		
			if($sensorModelName != "")
			$sensorInfo->setSensorModelName($sensorModelName);
		
			if($typeSensor != "")
			$sensorInfo->setTypeSensor($typeSensor);
		
			if($installationDate != "")
			$sensorInfo->setInstallationDate(new \DateTime($installationDate));
			else
			$sensorInfo->setInstallationDate(null);	
			
			if($applicationName != "")
			$sensorInfo->setApplicationName($applicationName);
			else
			$sensorInfo->setApplicationName(null);	
		
			if($latitude != "")
			$sensorInfo->setLatitude($latitude);
			else
			$sensorInfo->setLatitude(null);	
		
			if($longitude != "")
			$sensorInfo->setLongitude($longitude);
			else
			$sensorInfo->setLongitude(null);	
		
			if($deviceEUI != "")
			$sensorInfo->setDeviceEUI($deviceEUI);
			else
			$sensorInfo->setDeviceEUI(null);	
		
			if($appEUI != "")
			$sensorInfo->setAppEUI($appEUI);
			else
			$sensorInfo->setAppEUI(null);	
		
			if($appKEY != "")
			$sensorInfo->setAppKEY($appKEY);
			else
			$sensorInfo->setAppKEY(null);
		
			if($encryptionKey){
					$sensorInfo->setEncryptionKey($encryptionKey);
				}
			else{
					$sensorInfo->setEncryptionKey(null);
				}
			
			if($inputComponentNames != "")
			$sensorInfo->setInputComponentNames($inputComponentNames);
			if($meterComponentNames != "")
			$sensorInfo->setMeterComponentNames($meterComponentNames);
			
			$sensorInfo->setUpdatedDt(new \DateTime());
			
			$em->persist($sensorInfo);
			$em->flush();
			$sensorInfoId = $sensorInfo->getId();
			/*OEM sensor detail update*/
			$sensorNamesInWaterOemsensor = $em 
			->getRepository('AppBundle:SensorNamesInWaterOemsensor')
			->findOneBy(array('sensorId' => $sensorInfoId,'indexat'=>$indexat));
			if($sensorNamesInWaterOemsensor != null){
				
			if($indexat != "")
			$sensorNamesInWaterOemsensor->setIndexat($indexat);
			else
			$sensorNamesInWaterOemsensor->setIndexat(null);
			
			if($sensorName != "")
			$sensorNamesInWaterOemsensor->setSensorName($sensorName);
			else
			$sensorNamesInWaterOemsensor->setSensorName(null);
			
			if($sensorInfoId != "")
			$sensorNamesInWaterOemsensor->setSensorId($sensorInfoId);
			else
			$sensorNamesInWaterOemsensor->setSensorId(null);
			
			if($sensorModelName != "")
			$sensorNamesInWaterOemsensor->setSensorModelName($sensorModelName);
			else
			$sensorNamesInWaterOemsensor->setSensorModelName(null);
			
			$sensorNamesInWaterOemsensor->setUpdatedDt(new \DateTime());
		
			$em->persist($sensorNamesInWaterOemsensor);			
			$em->flush();
			}
		/* OEM sensor detail update*/
			
			if( $sensorInfoId != "")
			{
				return new JsonResponse(array('status' => 'SUCCESS','msg' => $msg,'message' => 'sensor info has been successfully updated!!'));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating sensor info details!!'));
			}
			
			
		}
		else
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating sensor info Detail No Record found with this Id'));
		}
		
	}
	public function sensormsg($gatewaymac, $id,  $typeSensorName, $componentName, $deviceEUI, $serverIds, $hashSensorName, $countSensorName, $customSensor,$pkId){
			$currentdatetime = new  \DateTime();
			if($typeSensorName!= "wifi" && $typeSensorName!= "ibox")
			{
				$typeSensorName = 'customsensordevices';
		}	
			
			$applicationName = "app";		
			//$componentName = $name;
			$loraAddress = $deviceEUI;
			//$location = "42";//$latitude;
			$serverIds = 1;
			$hashSensorName = "S02";
			$countSensorName = "S01";			
			$customSensor = $customSensor;		
			$topic = $gatewaymac.'/gateway_requests/request';
			$path = "/".$typeSensorName."/".$pkId;
			$method = "PUT";
			$port = 4999;
			$timestamp = $currentdatetime->format('c'); 
			$requestId = $id;
			$body ='{';
			if($typeSensorName == 'wifi'){
			$body = $body.'\"applicationName\":\"'.$applicationName.'\"';	
			$body = $body.',\"hashSensorName\":\"'.$hashSensorName.'\"';
			$body = $body.',\"countSensorName\":\"'.$countSensorName.'\"';
			$body = $body.',\"componentName\":\"'.$componentName.'\"';
			}
			if($typeSensorName == 'ibox'){
			$body = $body.'\"applicationName\":\"'.$applicationName.'\"';	
			$body = $body.',\"hashSensorName\":\"'.$hashSensorName.'\"';
			$body = $body.',\"countSensorName\":\"'.$countSensorName.'\"';
			$body = $body.',\"componentName\":\"'.$componentName.'\"';
			}
			if($typeSensorName != 'wifi' && $typeSensorName != 'ibox'){
			$body = $body.'\"componentName\":\"'.$componentName.'\"';			
			}
			//$body = $body.',\"sentiloComponentType\":\"'.$sentiloComponentType.'\"';			
			$body = $body.',\"loraAddress\":\"'.$loraAddress.'\"';
			$body = $body.',\"serverIds\":['.$serverIds.']';
			if($typeSensorName != 'wifi' && $typeSensorName != 'ibox'){			
			$body = $body.',\"customSensor\":'.$customSensor;			
			}
			//$body = $body.',\"location\":\"'.$location.'\"';
			//$body = $body.',\"publicAccess\":\"'.$publicAccess.'\"';
			
			
			
			$body = $body.'}';
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';			
			$msg = $msg.',"authentication" : true';
			$msg = $msg.',"body":"'.$body.'"';
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$requestId.'"';			
			$msg = $msg.'}';
			//print_r($msg);

			$this->publish($topic, $msg);
	}
	public function sensormsgchirpstack($gatewaymac, $id, $componentName, $deviceEUI, $description){
			$currentdatetime = new  \DateTime();			
			$applicationID = "1";		
			$name = $componentName;
			$devEUI = $deviceEUI;
			$referenceAltitude = 0;
			$skipFCntCheck = "false";
			$deviceProfileID = "9e89a1f2-fbbf-46fa-840d-73f238053bbd";						
			$topic = $gatewaymac.'/gateway_requests/request';
			$path = "/api/devices";
			$method = "PUT";
			$port = 8080;
			$timestamp = $currentdatetime->format('c'); 
			$requestId = $id;
			$body ='{\"device\":{';
			
			$body = $body.'\"applicationID\":\"'.$applicationID.'\"';	
			$body = $body.',\"description\":\"'.$description.'\"';
			$body = $body.',\"devEUI\":\"'.$devEUI.'\"';			
			$body = $body.',\"deviceProfileID\":\"'.$deviceProfileID.'\"';			
			$body = $body.',\"name\":\"'.$name.'\"';
			$body = $body.',\"referenceAltitude\":'.$referenceAltitude;
			$body = $body.',\"skipFCntCheck\":'.$skipFCntCheck;
			$body = $body.',\"tags\":{}';
			$body = $body.',\"variables\":{}';			
			
			$body = $body.'}}';
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';			
			$msg = $msg.',"authentication" : true';
			$msg = $msg.',"body":"'.$body.'"';
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$requestId.'"';			
			$msg = $msg.'}';
			//print_r($msg);

			$this->publish($topic, $msg);
	}
	public function sensormsgchirpstackkey($macAddress, $id, $componentName, $appKEY, $deviceEUI){
			$currentdatetime = new  \DateTime();									
			$topic = $macAddress.'/gateway_requests/request';
			$path = "/api/devices/".$deviceEUI."/keys";
			$method = "PUT";
			$port = 8080;
			$timestamp = $currentdatetime->format('c'); 
			$requestId = $id;
			$body ='{\"deviceKeys\":{';
			
			$body = $body.'\"nwkKey\":\"'.$appKEY.'\"';			
			$body = $body.'}}';
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';			
			$msg = $msg.',"authentication" : true';
			$msg = $msg.',"body":"'.$body.'"';
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$requestId.'"';			
			$msg = $msg.'}';
			//print_r($msg);

			$this->publish($topic, $msg);
	}
	
	/**
     * sensor_type_gateway_pkid list
     *                                                                                 
	 * @Route("/sensortypepkIdlist", name="sensor_type_gatewaypkIdList")
	 */
	public function SensorTypeGatewayPkIdListApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());
		$mac = $data->macNumber;
		$pkid = $data->pkId;		
		$SensorTypeGatewayPkidList= $em 
			->getRepository('AppBundle:SensorTypeGatewayPkid')
			->findOneBy(array('macNumber'=>$mac,'pkId'=>$pkid));
		if($SensorTypeGatewayPkidList != null){
		$sensorTypeId = $SensorTypeGatewayPkidList->getSensorTypeId();
		$SensorTypeGatewayPkid= $em 
			->getRepository('AppBundle:SensorTypeGatewayPkid')
			->findBy(array('sensorTypeId'=>$sensorTypeId));
		$sensorTypeGatewayListArray = [];
		if($SensorTypeGatewayPkid != null){
			$i = 0;
			foreach($SensorTypeGatewayPkid as $sensorType){
				 $pkId = $sensorType->getPkId();
				if($pkId != null){
				$sensorTypeGatewayListArray[$i] = array(
				'macNumber'  => $sensorType->getMacNumber()
				);
				$i++;
				}
			}
		}
		if($sensorTypeGatewayListArray != null){
			return new JsonResponse(array('status' => 'FAILED','message' => 'It is Linked with Some Gateway'));
		}
		else{
			$sensorInfo= $em 
			->getRepository('AppBundle:SensorInfo')
			->findBy(array('typeSensor'=>$sensorTypeId));	
			if($sensorInfo != null){
				return new JsonResponse(array('status' => 'FAILED','message' => 'It is Linked with Some Sensor'));
			}
			else{
				return new JsonResponse(array('status' => 'SUCCESS','gatewaylinked'=>$sensorTypeGatewayListArray,'sensorTypeId'=>$sensorTypeId,'message' => 'It is not Linked with any Gateway and Sensor You can Delete This'));
			}
		}
	}
	else{
		return new JsonResponse(array('status' => 'SUCCESS','outside'=>'this is outside','message' => 'It is not Linked with any Gateway and Sensor You can Delete This'));
	}
		
	}
	
	public function servermsg($gatewaymac, $requestId, $type, $serverName, $url, $provider, $identityKey){
			$currentdatetime = new  \DateTime();
			$topic = $gatewaymac.'/gateway_requests/request';			
			$url= rtrim($url);
			$provider= trim($provider);
			$identityKey= trim($identityKey);
			$serverName= trim($serverName);
			
			$path = "/servers";
			$method = "POST";
			$port = 4999;
			$timestamp = $currentdatetime->format('c'); //"2019-12-08T16:00:02.2805625Z";			
			//$body ='{';			
			$body = '{\"serverName\":\"'.$serverName.'\"';
			$body = $body.',\"url\":\"'.$url.'\"';
			$body = $body.',\"provider\":\"'.$provider.'\"';
			$body = $body.',\"identityKey\":\"'.$identityKey.'\"';
			$body = $body.',\"type\":'.$type;
			$body = $body.'}';
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';			
			$msg = $msg.',"authentication" : true';
			$msg = $msg.',"body":"'.$body.'"';
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$requestId.'"';			
			$msg = $msg.'}';
			//print_r($msg);
		$this->publish($topic, $msg);
	}
	
	public function publish($topic, $msg)
	{
		$str = "./mosquitto_pub -h gesinen.es -p 1882 -u 'gesinen'  -P 'gesinen2110'  -t '".$topic."' -m '".$msg."'";
		
		$process = new Process($str);
		$process->run();

		// executes after the command finishes
		if (!$process->isSuccessful()) {
			throw new ProcessFailedException($process);
		}
	}
}

?>