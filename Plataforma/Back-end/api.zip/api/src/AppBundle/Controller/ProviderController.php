<?php

namespace AppBundle\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use AppBundle\Entity\Providers;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Normalizer\GetSetMethodNormalizer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Normalizer\DateTimeNormalizer;


/**
 * Provider controller.
 *
 * @Route("/provider")
 */
class ProviderController extends Controller
{
	
	/**
     * List
     *                                                                                 
	 * @Route("/list", name="provider_list")
	 */
	public function providerListApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();

		$providersList= $em 
			->getRepository('AppBundle:Providers')
			->findAll();
		
		$json = '';
		//var_dump($user);
		
		 if($providersList != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($providersList, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','details' => $json));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','details' => $json));
			//return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in Providers data'));
	}
	/**
     * Get Provider by Id
     *                                                                                 
	 * @Route("/getproviderbyid", name="provider_getproviderbyid")
	 */
	public function getProviderByIdApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$providerId = $data->id;
		
		$provider= $em 
			->getRepository('AppBundle:Providers')
			->findBy(array('id' => $providerId));
		
		if( $provider != null)
		{
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new GetSetMethodNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($provider, 'json');
			
			return new JsonResponse(array('status' => 'Success','details' => $json));
		}
		else{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in getting provider details!!'));
		} 
		
	}
	/**
     * Delete a Providers
     *                                                                                 
	 * @Route("/deleteprovider", name="provider_deleteprovider")
	 */
	public function deleteProviderApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());		
		$providerId = $data->id;	
		$provider= $em 
			->getRepository('AppBundle:Providers')
			->findOneBy(array('id' => $providerId));
		if($provider != null)
		{
			$em->remove($provider);
            $em->flush();	
		return new JsonResponse(array('status' => 'SUCCESS','message' => 'provider has been successfully removed!!'));
		}
		else{
			return new JsonResponse(array('status' => 'Failed','message' => 'No provider is Present with this Id!!'));
		}
	}
	
	/**
     * Create New Providers
     *                                                                                 
	 * @Route("/newProvider", name="provider_newprovider")
	 */
	public function newProviderApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		// var_dump($data);
		
		$name = $data->name;
		$cif = $data->cif;	
		$address = $data->address;
		$country = $data->country;
		$state = $data->state;
		$city = $data->city;
		$postalCode = $data->postalCode;
		$contactPerson = $data->contactPerson;
		$email = $data->email;
		$telephone = $data->telephone;
		$web = $data->web;
				
		
		$providerObj= $em 
			->getRepository('AppBundle:Providers')
			->findBy(array('name' => $name));
			
			
		if($providerObj != null)
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Requested Providers is already exists!!'));
		}
		else{
			
			$providers = new Providers();
			//$providers->setName($name);
			if($name != "")
			{
				$providers->setName($name);
			}
			
			if($cif != "")
			$providers->setCif($cif);
		
			if($address != "")
			$providers->setAddress($address);
		
			if($country != "")
			$providers->setCountry($country);
		
			if($state != "")
			$providers->setState($state);
		
			if($city != "")
			$providers->setCity($city);
			
			if($postalCode != "")
			$providers->setPostalCode($postalCode);
		
			if($contactPerson != "")
			$providers->setContactPerson($contactPerson);
		
			if($email != "")
			$providers->setEmail($email);
			
			if($telephone != "")
			$providers->setTelephone($telephone);
		
			if($web != "")
			$providers->setWeb($web);			
			
		
			$em->persist($providers);
			$em->flush();
			$Id = $providers->getId();
			
			if( $Id != '')
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'providers has been successfully created!!','id' => $Id));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in registering providers registeration!!'));
			} 
		}
		
	}
	
	/**
     * Update a Providers
     *                                                                                 
	 * @Route("/updateprovider", name="provider_updateprovider")
	 */
	public function updateProviderApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$providerId = $data->id;
		$name = $data->name;
		$cif = $data->cif;
		$address = $data->address;
		$country = $data->country;
		$state = $data->state;
		$city = $data->city;
		$postalCode = $data->postalCode;
		$contactPerson = $data->contactPerson;
		$email = $data->email;
		$telephone = $data->telephone;
		$web = $data->web;	
		
		$porviders= $em 
			->getRepository('AppBundle:Providers')
			->findOneBy(array('id' => $providerId));
			
		if($porviders !=null)
		{
		
			if($name != "")
			{
				$porviders->setName($name);
			}
			
			if($cif != "")
			$porviders->setCif($cif);
		
			if($address != "")
			$porviders->setAddress($address);
		
			if($country != "")
			$porviders->setCountry($country);
		
			if($state != "")
			$porviders->setState($state);
		
			if($city != "")
			$porviders->setCity($city);
			
			if($postalCode != "")
			$porviders->setPostalCode($postalCode);
		
			if($contactPerson != "")
			$porviders->setContactPerson($contactPerson);
		
			if($email != "")
			$porviders->setEmail($email);
			
			if($telephone != "")
			$porviders->setTelephone($telephone);
		
			if($web != "")
			$porviders->setWeb($web);
			
			$porviders->setUpdatedDt(new \DateTime());
			
			$em->persist($porviders);
			$em->flush();
			$councilId = $porviders->getId();
			
			if( $councilId != "")
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'porviders has been successfully updated!!'));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating porviders details!!'));
			}
		}
		else
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating porviders Detail No Record found with this Id'));
		}
		
	}
}
?>