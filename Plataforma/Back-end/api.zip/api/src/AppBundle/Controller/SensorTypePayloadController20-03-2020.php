<?php

namespace AppBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use AppBundle\Entity\SensorTypePayload;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Normalizer\GetSetMethodNormalizer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Normalizer\DateTimeNormalizer;


/**
 * SensorTypePayload controller.
 *
 * @Route("/sensortypepayload")
 */
class SensorTypePayloadController extends Controller
{
	
	/**
     * List
     *                                                                                 
	 * @Route("/list", name="sensortypepayload_list")
	 */
	public function SensorTypePayloadListApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();

		$sensorTypePayloadList= $em 
			->getRepository('AppBundle:SensorTypePayload')
			->findAll();
		
		$json = '';
		//var_dump($user);
		
		 if($sensorTypePayloadList != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($sensorTypePayloadList, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','sensortypepayload_details' => $json));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','sensortypepayload_details' => $json));
			//return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in sensor type payload data'));
	}
	
	/**
     * by type id List
     *                                                                                 
	 * @Route("/listbytypeid", name="sensortypepayload_listbytypeid")
	 */
	public function SensorTypePayloadListByTypeIdApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$sensorTypeId = $data->sensorTypeId;

		$sensorTypePayloadList= $em 
			->getRepository('AppBundle:SensorTypePayload')
			->findBy(array('sensorTypeId'=>$sensorTypeId));
		
		$json = '';
		//var_dump($user);
		
		 if($sensorTypePayloadList != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($sensorTypePayloadList, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','sensortypepayload_details' => $json));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','sensortypepayload_details' => $json));
			//return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in sensor type payload data'));
	}
	
	/**
     * Get SensorTypePayload by Id
     *                                                                                 
	 * @Route("/getsensortypepayloadbyid", name="sensortypepayload_getsensortypepayloadbyid")
	 */
	public function getSensorTypePayloadbyidApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$sensorTypePayloadId = $data->id;
		
		$sensorTypePayload= $em 
			->getRepository('AppBundle:SensorTypePayload')
			->findBy(array('id' => $sensorTypePayloadId));
		
		if( $sensorTypePayload != null)
		{
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new GetSetMethodNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($sensorTypePayload, 'json');
			
			return new JsonResponse(array('status' => 'Success','sensortypepayload_details' => $json));
		}
		else{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in getting sensor type payload details!!'));
		} 
		
	}
	
	/**
     * Delete a Sensor type payload
     *                                                                                 
	 * @Route("/deletesensortypepayload", name="sensortypepayload_deletesensortypepayload")
	 */
	public function deleteSensorTypePayloadApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());		
		$sensorTypePayloadId = $data->id;	
		$sensorTypePayload= $em 
			->getRepository('AppBundle:SensorTypePayload')
			->findOneBy(array('id' => $sensorTypePayloadId));
		if($sensorTypePayload != null)
		{
			$em->remove($sensorTypePayload);
            $em->flush();	
		return new JsonResponse(array('status' => 'SUCCESS','message' => 'sensor type payload has been successfully removed!!'));
		}
		else{
			return new JsonResponse(array('status' => 'Failed','message' => 'No sensor type payload is Present with this Id!!'));
		}
	}
	
	/**
     * Create New SensorTypePayload
     *                                                                                 
	 * @Route("/newsensortypepayload", name="sensortypepayload_newsensortypepayload")
	 */
	public function newSensorTypePayloadApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		// var_dump($data);
		
		$sensorTypeId = $data->sensorTypeId;
		$port = $data->port;
		$timeStraped = $data->timeStraped;	
		$payloadUniqueId = $data->payloadUniqueId;
		$varname = $data->varname;
		$startBit = $data->startBit;
		$lastBit = $data->lastBit;	
		$description = $data->description;
		
		$varnamematch = false;
		$timestrapedforthisport = false;
		$startBitInUse = false;
		$lastBitInUse =  false;
		$newRecord =  false;	
		
		$sensorTypePayloadObj= $em 
			->getRepository('AppBundle:SensorTypePayload')
			->findBy(array('sensorTypeId' => $sensorTypeId,'port' => $port));
			if($sensorTypePayloadObj != null){
				foreach($sensorTypePayloadObj as $payload){
				//echo 'payloadvarmane=='.$payload->varname . '-varname=='.$varname;
					if($payload->getVarname() == $varname){
						$varnamematch = true;						
						break;
						//return new JsonResponse(array('status' => 'FAILED','message' => 'Requested sensor type payload is already exists!!'));
					}
					if($payload->getTimeStraped() == 1){
						$timestrapedforthisport = true;						
						break;
						//return new JsonResponse(array('status' => 'FAILED','message' => 'Requested sensor type payload is already exists!!'));
					}
					if(filter_var($startBit,FILTER_VALIDATE_INT,array('options' => array('min_range' => $payload->getStartBit(),'max_range' => $payload->getLastBit()))))
					{
						$startBitInUse = true;
						break;
						//return new JsonResponse(array('status' => 'FAILED','message' => 'Requested sensor type payload start bit already used !!'));
					}
					if(filter_var($lastBit,FILTER_VALIDATE_INT,array('options' => array('min_range' => $payload->getStartBit(),'max_range' => $payload->getLastBit()))))
					{
						$lastBitInUse = true;
						break;
						//return new JsonResponse(array('status' => 'FAILED','message' => 'Requested sensor type payload lastbit already used!!'));
					}
				}
				if($timestrapedforthisport == true && $timeStraped == 1)
				{
					return new JsonResponse(array('status' => 'FAILED','message' => 'Error Only one Timestraped is allowed for each port!!'));
				}
				if($varnamematch == false && $startBitInUse == false && $lastBitInUse == false )
				{
					$newRecord = true;
				}
		
			}
			else{
				$newRecord = true;
				//$sensorTypePayloadObj= $em 
				//	->getRepository('AppBundle:SensorTypePayload')
				//	->findBy(array('varname' => $varname,'startBit' => $startBit,'lastBit' => $lastBit));
			}	
					
				if($varnamematch == true || $startBitInUse == true || $lastBitInUse == true || 	$newRecord == false)
				{
					return new JsonResponse(array('status' => 'FAILED','message' => 'Requested sensor type payload is already exists!!'));
				}
				else{
			
					$sensorTypePayload = new SensorTypePayload();
					
					if($port != "")
					$sensorTypePayload->setPort($port);
				
					if($timeStraped != "")
					$sensorTypePayload->setTimeStraped($timeStraped);
				
					if($sensorTypeId != "")
					$sensorTypePayload->setSensorTypeId($sensorTypeId);
					
					if($payloadUniqueId != "")
					$sensorTypePayload->setPayloadUniqueId($payloadUniqueId);
				
					if($varname != "")
					$sensorTypePayload->setVarname($varname);
				
					if($startBit != "")
					$sensorTypePayload->setStartBit($startBit);
				
					if($lastBit != "")
					$sensorTypePayload->setLastBit($lastBit);
				
					if($description != "")
					$sensorTypePayload->setDescription($description);
								
					$em->persist($sensorTypePayload);
					$em->flush();
					$Id = $sensorTypePayload->getId();
			
					if( $Id != '')
					{
						return new JsonResponse(array('status' => 'SUCCESS','message' => 'sensor type payload has been successfully created!!','id' => $Id));
					}
					else{
						return new JsonResponse(array('status' => 'FAILED','message' => 'Error in registering sensor type payload registeration!!'));
					} 
				}
			
	}
	
	/**
     * Update a Sensor Type Payload
     *                                                                                 
	 * @Route("/updatesensortypepayload", name="sensortypeinfo_updatesensortypepayload")
	 */
	public function updateSensorTypePayloadApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		
		$port = $data->port;		
		$timeStraped = $data->timeStraped;// == true ? 1 : 0;
		$sensorTypePayloadId = $data->id;
		$sensorTypeId = $data->sensorTypeId;		
		$payloadUniqueId = $data->payloadUniqueId;
		$varname = $data->varname;
		$startBit = $data->startBit;
		$lastBit = $data->lastBit;	
		$description = $data->description;

		$varnamematch = false;
		$timestrapedforthisport = false;
		$startBitInUse = false;
		$lastBitInUse =  false;
			
		
		$sensorTypePayload= $em 
			->getRepository('AppBundle:SensorTypePayload')
			->findOneBy(array('id' => $sensorTypePayloadId));
			
		if($sensorTypePayload !=null)
		{
			$sensorTypePayloadObj= $em 
			->getRepository('AppBundle:SensorTypePayload')
			->findBy(array('sensorTypeId' => $sensorTypeId,'port' => $port));
			
			if($sensorTypePayloadObj != null){
				foreach($sensorTypePayloadObj as $payload){
				//echo 'payloadvarmane=='.$payload->varname . '-varname=='.$varname;
					if($payload->getId() == $sensorTypePayloadId)
					{
						continue;
					}
					else{
						if($payload->getTimeStraped() == 1){
						$timestrapedforthisport = true;						
						break;
						//return new JsonResponse(array('status' => 'FAILED','message' => 'Requested sensor type payload is already exists!!'));
					}
						if($payload->getVarname() == $varname){
							$varnamematch = true;						
							break;
							//return new JsonResponse(array('status' => 'FAILED','message' => 'Requested sensor type payload is already exists!!'));
						}
						if(filter_var($startBit,FILTER_VALIDATE_INT,array('options' => array('min_range' => $payload->getStartBit(),'max_range' => $payload->getLastBit()))))
						{
							$startBitInUse = true;
							break;
							//return new JsonResponse(array('status' => 'FAILED','message' => 'Requested sensor type payload start bit already used !!'));
						}
						if(filter_var($lastBit,FILTER_VALIDATE_INT,array('options' => array('min_range' => $payload->getStartBit(),'max_range' => $payload->getLastBit()))))
						{
							$lastBitInUse = true;
							break;
							//return new JsonResponse(array('status' => 'FAILED','message' => 'Requested sensor type payload lastbit already used!!'));
						}
					}
				}
				if($timestrapedforthisport == true && $timeStraped == 1)
				{
					return new JsonResponse(array('status' => 'FAILED','message' => 'Error Only one Timestraped is allowed for each port!!'));
				}
		
			}
			
				if($varnamematch == true || $startBitInUse == true || $lastBitInUse == true)
				{
					return new JsonResponse(array('status' => 'FAILED','message' => 'Requested sensor type payload is already exists not able to update overlapping !!'));
				}
				else{
			if($port != "")
			$sensorTypePayload->setPort($port);
		
			//if($timeStraped != "")
			$sensorTypePayload->setTimeStraped($timeStraped);
		
			if($sensorTypeId != "" )
			$sensorTypePayload->setSensorTypeId($sensorTypeId);
			
			if($payloadUniqueId != "")
			$sensorTypePayload->setPayloadUniqueId($payloadUniqueId);
		
			if($varname != "" )
			$sensorTypePayload->setVarname($varname);
		
			if($startBit != "" )
			$sensorTypePayload->setStartBit($startBit);
		
			if($lastBit != "" )
			$sensorTypePayload->setLastBit($lastBit);
		
			if($description != "" )
			$sensorTypePayload->setDescription($description);
			
			$sensorTypePayload->setUpdatedDt(new \DateTime());
			
			$em->persist($sensorTypePayload);
			$em->flush();
			$sensorTypePayloadId = $sensorTypePayload->getId();
			
			if( $sensorTypePayloadId != "")
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'sensor type info has been successfully updated!!'));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating sensor type info details!!'));
			}
				}
		}
		else
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating sensor type info Detail No Record found with this Id'));
		}
		
	}
}

?>