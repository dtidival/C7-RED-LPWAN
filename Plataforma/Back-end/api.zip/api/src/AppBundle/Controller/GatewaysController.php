<?php

namespace AppBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use AppBundle\Entity\Gateways;
use AppBundle\Entity\Users;
use AppBundle\Entity\Servers;
use AppBundle\Entity\SensorInfo;
use AppBundle\Entity\SensorTypePayload;
use AppBundle\Entity\SensorTypeInfo;
use AppBundle\Entity\SensorServerDetail;
use AppBundle\Entity\SensorGatewayPkid;
use AppBundle\Entity\GatewayPing;
use AppBundle\Entity\SensorTypeGatewayPkid;
use AppBundle\Entity\ServerGatewayPkid;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Process\Process;
use Symfony\Component\Process\Exception\ProcessFailedException;
use Symfony\Component\Validator\Constraints\DateTime;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Normalizer\GetSetMethodNormalizer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Normalizer\DateTimeNormalizer;


/**
 * Gateways controller.
 *
 * @Route("/gateways")
 */
class GatewaysController extends Controller
{
	
	/**
     * List
     *                                                                                 
	 * @Route("/list", name="gateways_list")
	 */
	public function GatewaysListApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());
		$userId = $data->userId;
		$underAdmin = $data->underAdmin;
		$permission = $data->permission;
		//return new JsonResponse(array('status' => 'FAILED','message' => $permission));
		if($permission == 1){
			$gatewaysList= $em 
			->getRepository('AppBundle:Gateways')
			->findAll();	
		}
		else if($permission == 2){
			if($underAdmin != null)
			{
				$gatewaysList= $em 
			->getRepository('AppBundle:Gateways')
			->findBy(array('userId'=>$underAdmin));	
			}
			else{
			$gatewaysList= $em 
			->getRepository('AppBundle:Gateways')
			->findBy(array('userId'=>$userId));	
			}
		}
		else{
			$user= $em 
			->getRepository('AppBundle:Users')
			->findOneBy(array('id'=>$userId));
			$gatewaysList= $em 
			->getRepository('AppBundle:Gateways')
			->findBy(array('userId' =>$user->getUnderAdmin()));	
		}

		/*$gatewaysList= $em 
			->getRepository('AppBundle:Gateways')
			->findAll();*/
		
		$json = '';
		//var_dump($user);
			
		 if($gatewaysList != null)
		 {
			foreach ($gatewaysList as $row) {
				$macNumber = $row->getMac();
				 $gatewayPing = $em->getRepository('AppBundle:GatewayPing')->findOneBy(array('macNumber'=>$macNumber));
				 
				 if($gatewayPing){					
					$row->setGatewayPing($gatewayPing);
					 }								 
				 }
				 
			
			
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($gatewaysList, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','gateway_details' => $json));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','gateway_details' => $json));
			//return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in gateway data'));
	}
	
	/**
     * check Gateway by mac number
     *                                                                                 
	 * @Route("/checkGatewaymac", name="gateway_checkGatewayMac")
	 */
	public function checkGatewayMacApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$gatewayMac = $data->mac;
		
		$gateway= $em 
			->getRepository('AppBundle:Gateways')
			->findBy(array('mac' => $gatewayMac));
		
		if( $gateway != null)
		{
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new GetSetMethodNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($gateway, 'json');
			
			return new JsonResponse(array('status' => 'Failed','gateways' => $json,'message'=> 'This Mac is Already taken'));
		}
		else{
			return new JsonResponse(array('status' => 'Success','message' => 'This Mac Is Available'));
		} 
		
	}
	
	/**
     * Get Gateway by Id
     *                                                                                 
	 * @Route("/getgatewaybyid", name="gateway_getgatewaybyid")
	 */
	public function getgatewaybyidApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$gatewayId = $data->id;
		
		$gateway= $em 
			->getRepository('AppBundle:Gateways')
			->findBy(array('id' => $gatewayId));
		
		if( $gateway != null)
		{
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new GetSetMethodNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($gateway, 'json');
			
			return new JsonResponse(array('status' => 'Success','gateway_details' => $json));
		}
		else{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in getting gateway details!!'));
		} 
		
	}
	
	/**
     * Delete a Gateway
     *                                                                                 
	 * @Route("/deletegateway", name="gateway_deletegateway")
	 */
	public function deleteGatewayApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());		
		$gatewayId = $data->id;	
		$gateway= $em 
			->getRepository('AppBundle:Gateways')
			->findOneBy(array('id' => $gatewayId));
		if($gateway != null)
		{
			$em->remove($gateway);
            $em->flush();	
		return new JsonResponse(array('status' => 'SUCCESS','message' => 'Gateway has been successfully removed!!'));
		}
		else{
			return new JsonResponse(array('status' => 'Failed','message' => 'No Gateway is Present with this Id!!'));
		}
	}
	
	/**
     * Create New Gateway
     *                                                                                 
	 * @Route("/newGateway", name="gateway_newgateway")
	 */
	public function newGatewayApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		// var_dump($data);
		
		$name = $data->name;		
		$description = $data->description;
		$profileID = $data->profileID;
		$application = $data->application;
		$mac = $data->mac;
		$latitude = $data->latitude;
		$longitude = $data->longitude;
		$radius = $data->radius;
		$town = $data->town;
		$inharitGroup = $data->inharitGroup;
		$serverId = $data->serverId;
		$groupsId = $data->groupsId;
		$userId = $data->userId;
		$sensorsId = $data->sensorsId;
		$projectId = $data->project;
		$status = $data->status;
		$disable = $data->disable;		
		
		$gatewayObj= $em 
			->getRepository('AppBundle:Gateways')
			->findBy(array('name' => $name,'mac' => $mac,'application' => $application));
			
			
		if($gatewayObj != null)
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Requested Gateway is already exists!!'));
		}
		else{
			
			$gateway = new Gateways();
			$gateway->setName($name);
			
			if($description != "")
			$gateway->setDescription($description);
			
			if($profileID != "")
			$gateway->setProfileId($profileID);
		
			if($application != "")
			$gateway->setApplication($application);
		
			if($mac != "")
			$gateway->setMac($mac);
		
			if($userId != "")
			$gateway->setUserId($userId);
		
			if($latitude != "")
			$gateway->setLatitude($latitude);
			
			if($longitude != "")
			$gateway->setLongitude($longitude);
		
			if($radius != "")
			$gateway->setRadius($radius);
		
			if($town != "")
			$gateway->setTown($town);
			
			if($inharitGroup != "")
			$gateway->setInharitGroup($inharitGroup);
		
			if($serverId != "")
			$gateway->setServerId($serverId);
			
			if($groupsId != "")
			$gateway->setGroupsId($groupsId);
		
			if($sensorsId != "")
			$gateway->setSensorsId($sensorsId);
		
			if($projectId != "")
			{
				$gateway->setProjectId($projectId);
			}
		
			if($status != "" )
			$gateway->setStatus($status);
		
			if($disable != "" )
			$gateway->setDisable($disable);
		
			$em->persist($gateway);
			$em->flush();
			$Id = $gateway->getId();
			
			if( $Id != '')
			{
				$this->GetApplicationId($mac);				
				$this->GetProfileId($mac);
				
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'Gateway has been successfully created!!','id' => $Id));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in registering Gateway registeration!!'));
			} 
		}
		
	}
	
	/**
     * Update a Gateway
     *                                                                                 
	 * @Route("/updategateway", name="gateway_updategateway")
	 */
	public function updategatewayApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$gatewayId = $data->id;
		$name = $data->name;
		$profileID = $data->profileID;
		$description = $data->description;
		$application = $data->application;
		$mac = $data->mac;
		$latitude = $data->latitude;
		$longitude = $data->longitude;
		$radius = $data->radius;
		$town = $data->town;
		$inharitGroup = $data->inharitGroup;
		$serverId = $data->serverId;
		$groupsId = $data->groupsId;
		$userId = $data->userId;
		$sensorsId = $data->sensorsId;
		$projectId = $data->project;
		$status = $data->status;
		$disable = $data->disable;
		$linkToGateway = $data->linkToGateway;
		$currentdatetime = new  \DateTime();
		
		//if($linkToGateway == "server")
		//$serverIdArray = explode(',', $serverId);
	
		//if($linkToGateway == "sensor")
		//$sensorIdArray = explode(',', $sensorsId);
		
		$gateway= $em 
			->getRepository('AppBundle:Gateways')
			->findOneBy(array('id' => $gatewayId));
			
		if($gateway !=null)
		{
			/*$macAddress = $gateway->getMac();
			//  message for sensor
			
			if($linkToGateway == "sensor"){
		   $sensorIdfromGateway = $gateway->getSensorsId();
		  // $sensorIdfromGatewayArray = explode(',', $sensorIdfromGateway);
		  // print_r($sensorIdfromGateway);		  
			//print_r('diff1');
			//print_r(array_diff($sensorIdArray,$sensorIdfromGatewayArray));
			//print_r('diff2');
			//print_r(array_diff($sensorIdfromGatewayArray,$sensorIdArray));
		   if($sensorIdfromGateway != "")
			  {
				$sensorIdfromGatewayArray = explode(',', $sensorIdfromGateway);
				$newSensorToAddGateway = $sensorsId != "" ? array_diff($sensorIdArray,$sensorIdfromGatewayArray):[];
				$oldSensorToRemoveGateway =  $sensorsId != "" ?  array_diff($sensorIdfromGatewayArray,$sensorIdArray):$sensorIdfromGatewayArray;
				if(count($newSensorToAddGateway) > 0)
				{
					foreach ($newSensorToAddGateway   as $value){ 
					
					$sensorInfo= $em 
					->getRepository('AppBundle:SensorInfo')
					->findOneBy(array('id' => $value));
					
				$typeSensor = $sensorInfo -> getTypeSensor();
					$sensorTypeObj = $em 
					->getRepository('AppBundle:SensorTypeInfo')
					->findOneBy(array('id' => $typeSensor));
					
				$typeSensorName = $sensorTypeObj->getName();
				$sensorTypeUniqueId = $sensorTypeObj->getSensorTypeUniqueId();
				$id = $sensorTypeObj->getId();
				
				if($typeSensorName !=  "wifi" && $typeSensorName !=  "ibox")
					{
				$sensorTypePayloadObj= $em 
				->getRepository('AppBundle:SensorTypePayload')
				->findBy(array('sensorTypeId' => $typeSensor));
				//print('sensorTypePayloadObj');
				//print_r($sensorTypePayloadObj);
				$sensorFormatString = "";
				$sensorNames = "";
					if(count($sensorTypePayloadObj)  >  0){
					foreach ($sensorTypePayloadObj   as $sensorTypePayload){
						
						$typeOfData = $sensorTypePayload->getTypeOfData();				
					$reverse = $sensorTypePayload->getReverse();					
					$sensorTypeId = $sensorTypePayload->getSensorTypeId();					
					$payloadUniqueId = $sensorTypePayload->getPayloadUniqueId();
					$varname = $sensorTypePayload->getVarname();				
					$start = $sensorTypePayload->getStart();				
					$length = $sensorTypePayload->getLength();
					$description = $sensorTypePayload->getDescription();
					$decimalNumber = $sensorTypePayload->getDecimalNumber();
					$bitNumber = $sensorTypePayload->getBitNumber();
					$any = $sensorTypePayload->getAny();
					
					if($typeOfData == "number")
					{
						if($reverse != ""){
							$sensorFormatString =	$sensorFormatString.'d'.$start.'-'.$length.'.'.$decimalNumber.'R';
						}
						else{
						$sensorFormatString =	$sensorFormatString.'d'.$start.'-'.$length.'.'.$decimalNumber;
						}
					}
					elseif($typeOfData == "string")
					{
						if($reverse != ""){
							$sensorFormatString =	$sensorFormatString.'s'.$start.'-'.$length.'R';
						}
						else{
						$sensorFormatString =	$sensorFormatString.'s'.$start.'-'.$length;
						}
					}
					elseif($typeOfData == "boolean")
					{
						$sensorFormatString =	$sensorFormatString.'b'.$start.'-'.$bitNumber;
					}
					else{
						
					}
					if(strlen($sensorNames)  > 0)
					{
					$sensorNames = $sensorNames.',\"'.$varname.'\"';
					}
					else{
					$sensorNames = '\"'.$varname.'\"';	
					}
					$sensorFormatString = $sensorFormatString." ";
					
					}
					if($sensorTypeUniqueId  == null){
							$this->sensortypemsg($macAddress, $id, $typeSensorName, $sensorFormatString, $sensorNames);
						}
					}
					}
				sleep(5);
				//$em->refresh($sensorTypeObjupdated);
				$sensorTypeObjupdated = $em 
					->getRepository('AppBundle:SensorTypeInfo')
					->findOneBy(array('id' => $typeSensor));
				$em->refresh($sensorTypeObjupdated);	
				$sensorServerObj= $em 
					->getRepository('AppBundle:SensorServerDetail')
					->findBy(array('sensorId' => $value));
					
				$serverIds  = [];
				foreach ($sensorServerObj   as $value){ 
				array_push($serverIds,$value->getServerId());
				}
				$id = $sensorInfo->getId();	
				$typeSensorName = $sensorTypeObjupdated->getName();	
				$sensorUniqueId = $sensorInfo->getSensorUniqueId();			
				$componentName = $sensorInfo->getName();
				$description = $sensorInfo->getDescription();
				$latitude = $sensorInfo->getLatitude();
				$longitude = $sensorInfo->getLongitude();
				$deviceEUI = $sensorInfo->getDeviceEUI();
				$appEUI = $sensorInfo->getAppEUI();
				$appKEY = $sensorInfo->getAppKEY();
				$hashSensorName="";
				$countSensorName="";
				if($typeSensorName !=  "wifi" && $typeSensorName !=  "ibox")
					{				
					$customSensor=$sensorTypeObjupdated->getSensorTypeUniqueId();					
					}
				else{
					$customSensor="";
				}
				
				$this->sensormsg($macAddress, $id,  $typeSensorName, $componentName, $deviceEUI, $serverIds, $hashSensorName, $countSensorName, $customSensor);
				
				$this->sensormsgchirpstack($macAddress, $id, $componentName, $deviceEUI, $description);
				sleep(3);
				$this->sensormsgchirpstackkey($macAddress, $id, $componentName, $appKEY, $deviceEUI);
				}
				}
				if(count($oldSensorToRemoveGateway) > 0)
				{
					foreach ($oldSensorToRemoveGateway   as $value){ 
					$sensorInfo= $em 
					->getRepository('AppBundle:SensorInfo')
					->findOneBy(array('id' => $value));	
					
				$typeSensor = $sensorInfo->getTypeSensor();
					$sensorTypeObj= $em 
					->getRepository('AppBundle:SensorTypeInfo')
					->findOneBy(array('id' => $typeSensor));
					
				$sensorServerObj= $em 
					->getRepository('AppBundle:SensorServerDetail')
					->findBy(array('sensorId' => $value));
					
				$serverIds  = [];
				foreach ($sensorServerObj   as $value){ 
				array_push($serverIds,$value->getServerId());
				}
				$id = $sensorInfo->getId();	
				$typeSensorName = $sensorTypeObj->getName();	
				$sensorUniqueId = $sensorInfo->getSensorUniqueId();			
				$componentName = $sensorInfo->getName();					
				$latitude = $sensorInfo->getLatitude();
				$longitude = $sensorInfo->getLongitude();
				$deviceEUI = $sensorInfo->getDeviceEUI();
				$appEUI = $sensorInfo->getAppEUI();
				$appKEY = $sensorInfo->getAppKEY();
				$hashSensorName="";
				$countSensorName="";
				$customSensor="";
				$this->sensormsgdelete($macAddress, $id, $typeSensorName,$sensorUniqueId);
				}
				}
			  }
			else{
				foreach ($sensorIdArray   as $value){ 
					$sensorInfo= $em 
					->getRepository('AppBundle:SensorInfo')
					->findOneBy(array('id' => $value));	
					
				$typeSensor = $sensorInfo->getTypeSensor();
					$sensorTypeObj= $em 
					->getRepository('AppBundle:SensorTypeInfo')
					->findOneBy(array('id' => $typeSensor));
				$typeSensorName = $sensorTypeObj->getName();
				$sensorTypeUniqueId = $sensorTypeObj->getSensorTypeUniqueId();
				$id = $sensorTypeObj->getId();
				
				if($typeSensorName !=  "wifi" && $typeSensorName !=  "ibox")
					{
				$sensorTypePayloadObj= $em 
				->getRepository('AppBundle:SensorTypePayload')
				->findBy(array('sensorTypeId' => $typeSensor));
				//print('sensorTypePayloadObj');
				//print_r($sensorTypePayloadObj);
				$sensorFormatString = "";
				$sensorNames = "";
					if(count($sensorTypePayloadObj)  >  0){
					foreach ($sensorTypePayloadObj   as $sensorTypePayload){
						
						$typeOfData = $sensorTypePayload->getTypeOfData();				
					$reverse = $sensorTypePayload->getReverse();					
					$sensorTypeId = $sensorTypePayload->getSensorTypeId();					
					$payloadUniqueId = $sensorTypePayload->getPayloadUniqueId();
					$varname = $sensorTypePayload->getVarname();				
					$start = $sensorTypePayload->getStart();				
					$length = $sensorTypePayload->getLength();
					$description = $sensorTypePayload->getDescription();
					$decimalNumber = $sensorTypePayload->getDecimalNumber();
					$bitNumber = $sensorTypePayload->getBitNumber();
					$any = $sensorTypePayload->getAny();
					
						
					
					if($typeOfData == "number")
					{
						if($reverse != ""){
							$sensorFormatString =	$sensorFormatString.'d'.$start.'-'.$length.'.'.$decimalNumber.'R';
						}
						else{
						$sensorFormatString =	$sensorFormatString.'d'.$start.'-'.$length.'.'.$decimalNumber;
						}
					}
					elseif($typeOfData == "string")
					{
						if($reverse != ""){
							$sensorFormatString =	$sensorFormatString.'s'.$start.'-'.$length.'R';
						}
						else{
						$sensorFormatString =	$sensorFormatString.'s'.$start.'-'.$length;
						}
					}
					elseif($typeOfData == "boolean")
					{
						$sensorFormatString =	$sensorFormatString.'b'.$start.'-'.$bitNumber;
					}
					else{
						
					}
					if(strlen($sensorNames)  > 0)
					{
					$sensorNames = $sensorNames.',\"'.$varname.'\"';
					}
					else{
					$sensorNames = '\"'.$varname.'\"';	
					}
					$sensorFormatString = $sensorFormatString." ";
					
					}
					if($sensorTypeUniqueId  == null){
							$this->sensortypemsg($macAddress, $id, $typeSensorName, $sensorFormatString, $sensorNames);
						}
					}
					}
				sleep(5);			
				$sensorTypeObjupdated = $em
					->getRepository('AppBundle:SensorTypeInfo')
					->findOneBy(array('id' => $typeSensor));
				$em->refresh($sensorTypeObjupdated);	
				$sensorServerObj= $em
					->getRepository('AppBundle:SensorServerDetail')
					->findBy(array('sensorId' => $value));
					
				$serverIds  = [];
				foreach ($sensorServerObj   as $value){ 
				array_push($serverIds,$value->getServerId());
				}
				$id = $sensorInfo->getId();	
				$typeSensorName = $sensorTypeObjupdated->getName();
				$description = $sensorInfo->getDescription();
				$sensorUniqueId = $sensorInfo->getSensorUniqueId();			
				$componentName = $sensorInfo->getName();					
				$latitude = $sensorInfo->getLatitude();
				$longitude = $sensorInfo->getLongitude();
				$deviceEUI = $sensorInfo->getDeviceEUI();
				$appEUI = $sensorInfo->getAppEUI();
				$appKEY = $sensorInfo->getAppKEY();
				$hashSensorName="";
				$countSensorName="";
				
				if($typeSensorName !=  "wifi" && $typeSensorName !=  "ibox")
					{
					//for ($i=0; $i <= 10; $i++) {	
					$customSensor=$sensorTypeObjupdated->getSensorTypeUniqueId();
					//if($customSensor != null) {
					//	break;
					///}
					//sleep(2);
					///}

					}
				else{
					$customSensor="";
				}
					
				$this->sensormsg($macAddress, $id,  $typeSensorName, $componentName, $deviceEUI, $serverIds, $hashSensorName, $countSensorName, $customSensor);
				$this->sensormsgchirpstack($macAddress, $id, $componentName, $deviceEUI, $description);
				sleep(3);
				$this->sensormsgchirpstackkey($macAddress, $id, $componentName, $appKEY, $deviceEUI);
				}

			}
		}
			//  message for server
			if($linkToGateway == "server"){
		   $serverIdfromGateway = $gateway->getServerId();
			///print_r($serverIdfromGateway);
			//print_r('diff1');
			//print_r(array_diff($serverIdArray,$serverIdfromGatewayArray));
			///print_r('diff2');
			//print_r(array_diff($serverIdfromGatewayArray,$serverIdArray));
			
		   if($serverIdfromGateway != "")
			  {
				$serverIdfromGatewayArray = explode(',', $serverIdfromGateway);
				$newServerToAddGateway = $serverId != "" ? array_diff($serverIdArray,$serverIdfromGatewayArray):[];
				$oldServerToRemoveGateway = $serverId != "" ? array_diff($serverIdfromGatewayArray,$serverIdArray):$serverIdfromGatewayArray;
				//print_r($newServerToAddGateway);
				//print_r($oldServerToRemoveGateway);
				if(count($newServerToAddGateway) > 0)
				{
					
					foreach ($newServerToAddGateway   as $value){ 
					$serverObj= $em 
					->getRepository('AppBundle:Servers')
					->findOneBy(array('id' => $value)); 					
					//print_r($value);	
					
					$id = $serverObj->getId();
					$type = $serverObj->getType();		
					$serverName  = $serverObj->getName();	
					$url  = $serverObj->getServerUrl();			
					$provider  = $serverObj->getProviderId();	
					$identityKey = $serverObj->getAuthorizationToken();
					
					//print_r($serverName);
					$this->servermsg($macAddress, $id, $type, $serverName, $url, $provider, $identityKey);
				   }
				}
				if(count($oldServerToRemoveGateway) > 0)
				{
					foreach ($oldServerToRemoveGateway   as $value){ 
					$serverObj= $em 
					->getRepository('AppBundle:Servers')
					->findOneBy(array('id' => $value));
					$pkId = $serverObj->getPkId();
					$id = $serverObj->getId();				
					$this->servermsgdelete($macAddress, $id, $pkId);					}
				}
				
				}
			else{
				foreach ($serverIdArray   as $value){ 
				  $serverObj= $em 
					->getRepository('AppBundle:Servers')
					->findOneBy(array('id' => $value));
					
					//	print_r($value);
					//print_r($serverObj);
					$id = $serverObj->getId();
					$type = $serverObj->getType();		
					$serverName  = $serverObj->getName();	
					$url  = $serverObj->getServerUrl();			
					$provider  = $serverObj->getProviderId();	
					$identityKey = $serverObj->getAuthorizationToken();
					$this->servermsg($macAddress, $id, $type, $serverName, $url, $provider, $identityKey);
				}				
			}
			}*/
			if($name != "")
			{
				$gateway->setName($name);
			}
			if($profileID != "")
				$gateway->setProfileId($profileID);
			else
				 $gateway->setProfileId(null);
			 
			if($description != "")
			{
				$gateway->setDescription($description);
			}
			else
				$gateway->setDescription(null);
			
			
			if($application != "")
			{
				$gateway->setApplication($application);
			}
			else
				$gateway->setApplication(null);
			
			if($mac != "")
			{
				$gateway->setMac($mac);
			}
			if($latitude != "")
			{
				$gateway->setLatitude($latitude);
			}
			else
				$gateway->setLatitude(null);
			
			if($longitude != "")
			{
				$gateway->setLongitude($longitude);
			}
			else
				$gateway->setLongitude(null);
			
			if($radius != "")
			$gateway->setRadius($radius);
			else
				$gateway->setRadius(null);
		
			if($town != "")
			$gateway->setTown($town);
			else
				$gateway->setTown("");
			
			if($inharitGroup != "")
			$gateway->setInharitGroup($inharitGroup);
			
			if($userId != "")
			$gateway->setUserId($userId);
		
			//if($serverId != "")
			//{
			//	$gateway->setServerId($serverId);
			//}
			//else
			//	$gateway->setServerId("");
			
			if($groupsId != "")
			{
				$gateway->setGroupsId($groupsId);
			}
			//else
			//	$gateway->setGroupsId("");
			
			//if($sensorsId != "")
			//{
			///	$gateway->setSensorsId($sensorsId);
			//}
			//else
			//	$gateway->setSensorsId("");
			
			if($projectId != "")
			{
				$gateway->setProjectId($projectId);
			}
			else
				$gateway->setProjectId(null);
			
			if($status != "")
			{
				$gateway->setStatus($status);
			}
			if($disable != "")
			{
				$gateway->setDisable($disable);
			}
			
			$gateway->setUpdatedDt(new \DateTime());
			
			$em->persist($gateway);
			$em->flush();
			$gatewayId = $gateway->getId();
			
			if( $gatewayId != "")
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'Gateway has been successfully updated!!'));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating Gateway details!!'));
			}
		}
		else
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating Gateway Detail No Record found with this Id'));
		}
		
	}
	
	/**
     * Update a Gateway sensorType
     *                                                                                 
	 * @Route("/downloadFromGatewayPlatformToSensorType", name="gateway_downloadFromGatewayPlatformToSensorType")
	 */
	public function downloadFromGatewayPlatformToSensorTypeApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		$sensorType = $data->sensorType;
		$applicationName = $data->applicationName;
		$name = $data->name;
		$pkId = $data->pkId;
		$userId = $data->userId;
		$macNumber = $data->macNumber;
		
		$customSensorsDecodeFormat = $data->customSensorsDecodeFormat;
		
		
		$customSensorsValueFilters = $data->customSensorsValueFilters;
		
		$showFilter = count($customSensorsValueFilters) >= 1 ? 1:0;
		/*
		$sensorName =$data->sensorName;
		
		$dataType =$data->dataType;
		$byteOffset =$data->byteOffset;
		$lenght =$data->lenght;
		$decimals =$data->decimals;
		$bitOffset =$data->bitOffset;
		$reversed =$data->reversed;
		$expresion =$data->expresion;
		$componentOverride =$data->componentOverride;
		
		$showFilter =$data->showFilter;
		$sensorToFilter =$data->sensorToFilter;
		$trueValueFilter =$data->trueValueFilter;
		$sensorNameFilter =$data->sensorNameFilter;
		$dataTypeFilter =$data->dataTypeFilter;
		$byteOffsetFilter =$data->byteOffsetFilter;
		$lengthFilter =$data->lengthFilter;
		$decimalsFilter =$data->decimalsFilter;
		$bitOffsetFilter =$data->bitOffsetFilter;
		$reversedFilter =$data->reversedFilter;
		$expresionFilter =$data->expresionFilter;
		$componentOverrideFilter =$data->componentOverrideFilter;
		*/
		
		$sensorTypeGatewayPkid = $em 
					->getRepository('AppBundle:SensorTypeGatewayPkid')
					->findOneBy(array('pkId' => $pkId,'macNumber' => $macNumber));
		if(!$sensorTypeGatewayPkid){			
			
				$sensorTypeInfo = $em 
					->getRepository('AppBundle:SensorTypeInfo')
					->findOneBy(array('name' => $name,'userId'=> $userId,'sensorType' => $sensorType));
				if(!$sensorTypeInfo)
				{
					$sensorTypeInfo = new SensorTypeInfo();
					$sensorTypeInfo->setUserId($userId);
					$sensorTypeInfo->setSensorType($sensorType);
					$sensorTypeInfo->setName($name);
					$sensorTypeInfo->setApplicationName($applicationName);					
					$em->persist($sensorTypeInfo);
					$em->flush();
					$sensorTypeInfoId = $sensorTypeInfo->getId();
					$i = 0;
					foreach ($customSensorsDecodeFormat as $customSensorsDecodeFormatvalue) {
					$sensorName = $customSensorsDecodeFormatvalue->sensorName;
					$dataType =$customSensorsDecodeFormatvalue->dataType;
					switch($dataType)
					  {
						case 0:{
						  $dataType = 'number';
						  $dataTypeFilter = 'number';
						  break;
						}
						
						case 1:{
						  $dataType = 'float';
						  $dataTypeFilter = 'float';
						  break;
						}
						case 2:{
						  $dataType = 'double';
						  $dataTypeFilter = 'double';
						  break;
						}
						case 3:{
						  $dataType = 'string';
						  $dataTypeFilter = 'string';
						  break;
						}
						case 4:{
						  $dataType = 'integer';
						  $dataTypeFilter = 'integer';
						  break;
						}
						case 5:{
						  $dataType = 'boolean';
						  $dataTypeFilter ='boolean';
						  break;
						}
						case 6:{
						  $dataType = 'bitboolean';
						  $dataTypeFilter = 'bitboolean';
						  break;
						}
						case 7:{
						  $dataType = 'hexstring';
						  $dataTypeFilter = 'hexstring';
						  break;
						}
						case 8:{
						  $dataType = 'Timestamp';
						  $dataTypeFilter = 'Timestamp';
						  break;
						}
						default:{
						  $dataType ='string';
						  $dataTypeFilter = 'string';
						  break;
						}
					  }
					$byteOffset =$customSensorsDecodeFormatvalue->byteOffset;
					$lenght =$customSensorsDecodeFormatvalue->lenght;
					$decimals =$customSensorsDecodeFormatvalue->decimals;
					$bitOffset =$customSensorsDecodeFormatvalue->bitOffset;
					$reversed =$customSensorsDecodeFormatvalue->reversed;
					$expresion =$customSensorsDecodeFormatvalue->expresion;
					$componentOverride =$customSensorsDecodeFormatvalue->componentOverride;
					
					$sensorTypePayload = new SensorTypePayload();
					$sensorTypePayload->setSensorTypeId($sensorTypeInfoId);
					
					$sensorTypePayload->setTypeOfData($dataType);
					$sensorTypePayload->setReverse($reversed);
					$sensorTypePayload->setVarname($sensorName);
					//$sensorTypePayload->setStart($sensorTypeInfoId);
					$sensorTypePayload->setLength($lenght);					
					//$sensorTypePayload->setDescription($sensorTypeInfoId);
					$sensorTypePayload->setDecimalNumber($decimals);
					$sensorTypePayload->setBitNumber($bitOffset);
					$sensorTypePayload->setExpresion($expresion);					
					$sensorTypePayload->setComponentOverride($componentOverride);
					
					$sensorTypePayload->setShowFilter($showFilter);
					
					if(count($customSensorsValueFilters))
					{
					$sensorTypePayload->setSensorToFilter($customSensorsValueFilters[$i]->sensorToFilter);
					$sensorTypePayload->setSensorNameFilter($customSensorsValueFilters[$i]->sensorName);
					$sensorTypePayload->setTrueValueFilter($customSensorsValueFilters[$i]->trueValue);
					$sensorTypePayload->setLengthFilter($customSensorsValueFilters[$i]->lenght);
					$sensorTypePayload->setDecimalsFilter($customSensorsValueFilters[$i]->decimals);
					$sensorTypePayload->setBitOffsetFilter($customSensorsValueFilters[$i]->bitOffset);
					$sensorTypePayload->setReversedFilter($customSensorsValueFilters[$i]->reversed == true?1:0);
					$sensorTypePayload->setDataTypeFilter($customSensorsValueFilters[$i]->dataType);
					$sensorTypePayload->setByteOffsetFilter($customSensorsValueFilters[$i]->byteOffset);
					$sensorTypePayload->setExpresionFilter($customSensorsValueFilters[$i]->expresion);
					$sensorTypePayload->setComponentOverrideFilter($customSensorsValueFilters[$i]->componentOverride);
					}
					$em->persist($sensorTypePayload);
					$em->flush();
					$i++;
					}
					
					
					
					
					
					$sensorTypeGatewayPkid = new SensorTypeGatewayPkid();
					$sensorTypeGatewayPkid->setMacNumber($macNumber);
					$sensorTypeGatewayPkid->setSensorTypeId($sensorTypeInfoId);
					$sensorTypeGatewayPkid->setPkId($pkId);
					$em->persist($sensorTypeGatewayPkid);
					$em->flush();
					
					
					return new JsonResponse(array('status' => 'SUCCESS','sensorTypeId'=>$sensorTypeInfoId,'message' => 'This Sesnor Type  Configuration Download and Linked  Successfully!!'));
				}
				else{
					$sensorTypeId = $sensorTypeInfo->getId();
					$sensorTypeGatewayPkid = new sensorTypeGatewayPkid();
					$sensorTypeGatewayPkid->setMacNumber($macNumber);
					$sensorTypeGatewayPkid->setSensorTypeId($sensorTypeId);
					$sensorTypeGatewayPkid->setPkId($pkId);
					$em->persist($sensorTypeGatewayPkid);
					$em->flush();					
					return new JsonResponse(array('status' => 'SUCCESS','message' => 'This Sensor Type  Configuration Already present but Linked with Gateway!!'));
				}
			}
			else{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'This Sensor  Configuration Already Linked With Gateway!!'));
			}
		
	}
	
	
	/**
     * Download Sensors from Decoder
     *                                                                                 
	 * @Route("/downloadSensorsFromDecoder", name="gateway_downloadSensorsFromDecoder")
	 */
	public function downloadSensorsFromDecoderApi(Request $request) {
		$em = $this->getDoctrine()->getManager();
		
		$datas = json_decode($request->getContent());
		
		foreach($datas as $data){
		
			$deviceEUI = strtolower($data->devEUI);
			$macNumber = $data->macNumber;
			$description = $data->description;
			$userId = $data->userId;
			$name = $data->name;
			$pkId = $data->pkId;
			$sensorFromPort = $data->sensorFromPort;
			$sensor = $em 
					->getRepository('AppBundle:SensorInfo')
					->findOneBy(array('deviceEUI' => $deviceEUI));
			if($sensor){
				$sensor->setSensorFromPort($sensorFromPort);
				if($description){
				$sensor->setDescription($description);
				}
				$em->persist($sensor);
				$em->flush();
				$sensorId = $sensor->getId();
				
			}
			else{
			$sensor = new SensorInfo();			
			$sensor->setUserId($userId);			
			$sensor->setName($name);
			$sensor->setDeviceEUI($deviceEUI);
			$sensor->setDescription($description);
			$sensor->setSensorFromPort($sensorFromPort);
			$sensor->setInstallationDate(new \DateTime());
			$em->persist($sensor);
			$em->flush();
			$sensorId = $sensor->getId();
			$gateway = $em 
					->getRepository('AppBundle:Gateways')
					->findOneBy(array('mac' => $macNumber));
					if($gateway){
						$sensorIdsAlreadylinked = $gateway->getSensorsId();
						if($sensorIdsAlreadylinked != ""){
							$updatedSensorIds=$sensorIdsAlreadylinked.','.$sensorId;
							$gateway->setSensorsId($updatedSensorIds);
						}
						else{
							$gateway->setSensorsId($sensorId);
						}
						$em->persist($gateway);
						$em->flush();
					}
			}
			$sensorGatewayPkid = $em 
			->getRepository('AppBundle:SensorGatewayPkid')
			->findOneBy(array('pkId' => $pkId,'macNumber' => $macNumber));
			if($sensorGatewayPkid){
				$sensorGatewayPkid->setSensorId($sensorId);
				$em->persist($sensorGatewayPkid);
				$em->flush();
			}
			else{
			$sensorGatewayPkid = new SensorGatewayPkid();
					$sensorGatewayPkid->setMacNumber($macNumber);
					$sensorGatewayPkid->setSensorId($sensorId);
					$sensorGatewayPkid->setPkId($pkId);
					$em->persist($sensorGatewayPkid);
					$em->flush();
			}
			
		}
		return new JsonResponse(array('status' => 'SUCCESS','datas'=>$datas,'message' => 'This Sensor Downloaded Successfully','sensorId'=>$sensorId));
		
	}
	
	/**
     * Download Sensors from Chirpstack
     *                                                                                 
	 * @Route("/downloadSensorsFromChirpStack", name="gateway_downloadSensorsFromChirpStack")
	 */
	public function downloadSensorsFromChirpStackApi(Request $request) {
		$em = $this->getDoctrine()->getManager();
		
		$datas = json_decode($request->getContent());
		
		foreach($datas as $data){
		
			$deviceEUI = strtolower($data->devEUI);
			$macNumber = $data->macNumber;
			$description = $data->description;
			$userId = $data->userId;
			$name = $data->name;
			$sensorFromChirpstack = $data->sensorFromChirpstack;
			$sensor = $em 
					->getRepository('AppBundle:SensorInfo')
					->findOneBy(array('deviceEUI' => $deviceEUI));
			if($sensor){
				$sensor->setSensorFromChirpstack($sensorFromChirpstack);
				if($description){
				$sensor->setDescription($description);
				}
				$em->persist($sensor);
				$em->flush();
				$sensorId = $sensor->getId();
			}
			else{
				$sensor = new SensorInfo();			
			$sensor->setUserId($userId);			
			$sensor->setName($name);
			$sensor->setDeviceEUI($deviceEUI);
			$sensor->setDescription($description);
			$sensor->setSensorFromChirpstack($sensorFromChirpstack);
			$sensor->setInstallationDate(new \DateTime());
			$em->persist($sensor);
			$em->flush();
			$sensorId = $sensor->getId();			
			}
			$gateway = $em 
					->getRepository('AppBundle:Gateways')
					->findOneBy(array('mac' => $macNumber));
					if($gateway){
						$ListOfSensorsOnGateway = $gateway->getSensorsId();
						if($ListOfSensorsOnGateway != ""){
							$ListOfSensorsOnGatewayArray = array_map('intval', explode(',', $ListOfSensorsOnGateway));
							if( in_array( $sensorId ,$ListOfSensorsOnGatewayArray ) ){
								
							}
							else{
							$updatedSensorIds=$ListOfSensorsOnGateway.','.$sensorId;
							$gateway->setSensorsId($updatedSensorIds);
							}
						}
						else{
							$gateway->setSensorsId($sensorId);
						}
						$em->persist($gateway);
						$em->flush();
						
					}
			
			
		}
		return new JsonResponse(array('status' => 'SUCCESS','datas'=>$datas,'message' => 'This Sensor Downloaded Successfully','sensorId'=>$sensorId));
		
	}
	/**
     * Add Sensor to Gateway and Chirpstack
     *                                                                                 
	 * @Route("/addLoraWANSensorToGatewayAndChirpStack", name="gateway_addLoraWANSensorToGateway")
	 */
	public function addLoraWANSensorToGatewayAndChirpStackApi(Request $request) {
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		//$sensorIdArray = [];
		//foreach($datas as $data){
		
			$macNumber = $data->macNumber;
			//$gatewayId = $data->gatewayId;
			$sensorId = $data->id;
			/*$appEUI = $data->appEUI;
			$appKEY = $data->appKEY;
			$deviceEUI = $data->deviceEUI;
			$description = $data->description;
			$name = $data->name;
			array_push($sensorIdArray,$sensorId);*/
			
		//}
		 //$sensorIdsString = implode(",",$sensorIdArray);
 
		$gateway = $em 
					->getRepository('AppBundle:Gateways')
					->findOneBy(array('mac' => $macNumber));
					if($gateway){
						$ListOfSensorsOnGateway = $gateway->getSensorsId();
						if($ListOfSensorsOnGateway != ""){
							$ListOfSensorsOnGatewayArray = array_map('intval', explode(',', $ListOfSensorsOnGateway));
							if( in_array( $sensorId ,$ListOfSensorsOnGatewayArray ) ){
								
							}
							else{
							$updatedSensorIds=$ListOfSensorsOnGateway.','.$sensorId;
							$gateway->setSensorsId($updatedSensorIds);
							}
						}
						else{
							$gateway->setSensorsId($sensorId);
						}
						$em->persist($gateway);
						$em->flush();
						
						$sensorInfo = $em 
					->getRepository('AppBundle:SensorInfo')
					->findOneBy(array('id' => $sensorId));
					$sensorInfo->setSensorFromChirpstack('chirpstack');
					$em->persist($sensorInfo);
						$em->flush();
					}
		return new JsonResponse(array('status' => 'SUCCESS','gateway'=>$gateway,'message' => 'This Sensor Added To Gateway Successfully'));
	}
	
	/**
     * remove a Sensor from chirpstack
     *                                                                                 
	 * @Route("/removeSensorFromGatewayAndChirpstack", name="gateway_removeSensorFromGatewayAndChirpstack")
	 */
	public function removeSensorFromGatewayAndChirpStackApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		$macNumber = $data->mac;
		$requestedSensors = $data->sensor;//->sensorsFiltered;	
		$sensorIdsArrayToRemove= [];
		$gateway = $em 
					->getRepository('AppBundle:Gateways')
					->findOneBy(array('mac' => $macNumber));
		if($gateway){
		 $sensorIdfromGateway = $gateway->getSensorsId();
		 
			$sensorIdfromGatewayArray = array_map('intval', explode(',', $sensorIdfromGateway));
			
		foreach ($requestedSensors as $row) {
			$sensorInfo= $em 
			->getRepository('AppBundle:SensorInfo')
			->findOneBy(array('id' => $row->id));			
			
			if($sensorInfo !=null)
			{
				array_push($sensorIdsArrayToRemove,$sensorInfo->getId());				
				$sensorInfo->setSensorFromChirpstack(null);			
				$sensorInfo->setUpdatedDt(new \DateTime());			
				$em->persist($sensorInfo);			
			}			
		}
		$em->flush();
		//$sensorIdNotToRemove = array_diff($sensorIdfromGatewayArray,$sensorIdsArrayToRemove);
		//$sensorIdNotToRemoveString = implode(",",$sensorIdNotToRemove);
		//$gateway->setSensorsId($sensorIdNotToRemoveString);
		//$em->persist($gateway);
		//$em->flush();
		
		return new JsonResponse(array('status' => 'SUCCESS','resquestedSensor'=>$requestedSensors,'message' => 'Sensor removed'));
		}
		else{
			return new JsonResponse(array('status' => 'FAILED','message' => 'No Gateway Selected'));	
		}
		
	}	
	
	
	/**
     * Update a Gateway sensorids
     *                                                                                 
	 * @Route("/downloadFromGatewayServerConfigOfSensor", name="gateway_downloadFromGatewayServerConfigOfSensor")
	 */
	public function downloadFromGatewayServerConfigOfSensorApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		
		$sensorType = $data->sensorType; // Ibox,wifi,customsensordevices
		$pkId = $data->pkId; // pkid of sensor
		$userId = $data->userId; // user id of admin
		$serverIds = $data->serverIds; // user id of admin
		$macNumber = $data->macNumber;// gateway macAddress example. b827eb481840
		$deviceEUI = $data->deviceEUI;// device if sensor or loraAddress example. 171fe129d522e001
		$sensorId = $data->id;// if this sensor is already present in database then this is sensorid from database.
		
		//checking if sensor is customsensordevices
		if($sensorType == 'customsensordevices'){
			 $typeInfo = $data->typeInfo; // this is the sensor type info of customsensor 
			 $typeInfo_pkid = $typeInfo->pkId; // pkid of custom sensor
			 $typeInfo_applicationName = $typeInfo->applicationName;// application name of custom sensor example. app, modbus etc
			 $typeInfo_configurationName = $typeInfo->configurationName; // name of the custom sensor
			 $typeInfo_customSensorsDecodeFormat = $typeInfo->customSensorsDecodeFormat; // payload info of custom sensor
			 $typeInfo_customSensorsValueFilters = $typeInfo->customSensorsValueFilters;// payload filter info of custom sensor
			 $showFilter = count($typeInfo_customSensorsValueFilters) >= 1 ? 1:0; // if filter values are present then 1.
			 /****** new code for custom sensor device *******/
			 // findind that sensor type is already linked with gateway or not on table SensorTypeGatewayPkid
			 $sensorTypeGatewayPkid = $em 
					->getRepository('AppBundle:SensorTypeGatewayPkid')
					->findOneBy(array('pkId' => $typeInfo_pkid,'macNumber' => $macNumber));
				// if not liked with gateway.	
				if(!$sensorTypeGatewayPkid){			
					//find sensortype info present in database table for customsensor
					$sensorTypeInfo = $em 
						->getRepository('AppBundle:SensorTypeInfo')
						->findOneBy(array('name' => $typeInfo_configurationName,'sensorType' => 'customsensor'));
					//if sensor type info not present in database	
					if(!$sensorTypeInfo)
					{
						$sensorTypeInfo = new SensorTypeInfo();//instanc for new sensor type info
						$sensorTypeInfo->setUserId($userId); // set user id
						$sensorTypeInfo->setSensorType('customsensor');//$sensorType // set sensor type is customsensor
						$sensorTypeInfo->setName($typeInfo_configurationName); //set sensortype name
						$sensorTypeInfo->setApplicationName($typeInfo_applicationName);	// set sensor type application name like app,modbus etc.				
						$em->persist($sensorTypeInfo);
						$em->flush();
						$sensorTypeInfoId = $sensorTypeInfo->getId();// getting the sensortype id of new created type.
						$i = 0;
						// inserting payload info for sensor type of above created
						foreach ($typeInfo_customSensorsDecodeFormat as $customSensorsDecodeFormatvalue) {
							$sensorName = $customSensorsDecodeFormatvalue->sensorName;
							$dataType =$customSensorsDecodeFormatvalue->dataType;
							switch($dataType)
							{
								case 0:{
									$dataType = 'number';
									$dataTypeFilter = 'number';
									break;
									}
							
								case 1:{
									$dataType = 'float';
									$dataTypeFilter = 'float';
									break;
								}
								case 2:{
									$dataType = 'double';
									$dataTypeFilter = 'double';
									break;
								}
								case 3:{
									$dataType = 'string';
									$dataTypeFilter = 'string';
									break;
								}
								case 4:{
									$dataType = 'integer';
									$dataTypeFilter = 'integer';
									break;
								}
								case 5:{
									$dataType = 'boolean';
									$dataTypeFilter ='boolean';
									break;
								}
								case 6:{
									$dataType = 'bitboolean';
									$dataTypeFilter = 'bitboolean';
									break;
								}
								case 7:{
									$dataType = 'hexstring';
									$dataTypeFilter = 'hexstring';
									break;
								}
								case 8:{
									$dataType = 'Timestamp';
									$dataTypeFilter = 'Timestamp';
									break;
								}
								default:{
									$dataType ='string';
									$dataTypeFilter = 'string';
									break;
								}
							}
							$byteOffset =$customSensorsDecodeFormatvalue->byteOffset;
							$lenght =$customSensorsDecodeFormatvalue->lenght;
							$decimals =$customSensorsDecodeFormatvalue->decimals;
							$bitOffset =$customSensorsDecodeFormatvalue->bitOffset;
							$reversed =$customSensorsDecodeFormatvalue->reversed;
							$expresion =$customSensorsDecodeFormatvalue->expresion;
							$componentOverride =$customSensorsDecodeFormatvalue->componentOverride;
					
							$sensorTypePayload = new SensorTypePayload();
							$sensorTypePayload->setSensorTypeId($sensorTypeInfoId);
					
							$sensorTypePayload->setTypeOfData($dataType);
							$sensorTypePayload->setReverse($reversed);
							$sensorTypePayload->setVarname($sensorName);
							//$sensorTypePayload->setStart($sensorTypeInfoId);
							$sensorTypePayload->setLength($lenght);					
							//$sensorTypePayload->setDescription($sensorTypeInfoId);
							$sensorTypePayload->setDecimalNumber($decimals);
							$sensorTypePayload->setBitNumber($bitOffset);
							$sensorTypePayload->setExpresion($expresion);					
							$sensorTypePayload->setComponentOverride($componentOverride);
					
							$sensorTypePayload->setShowFilter($showFilter);
					
							if(count($typeInfo_customSensorsValueFilters))
							{
								$sensorTypePayload->setSensorToFilter($typeInfo_customSensorsValueFilters[$i]->sensorToFilter);
								$sensorTypePayload->setSensorNameFilter($typeInfo_customSensorsValueFilters[$i]->sensorName);
								$sensorTypePayload->setTrueValueFilter($typeInfo_customSensorsValueFilters[$i]->trueValue);
								$sensorTypePayload->setLengthFilter($typeInfo_customSensorsValueFilters[$i]->lenght);
								$sensorTypePayload->setDecimalsFilter($typeInfo_customSensorsValueFilters[$i]->decimals);
								$sensorTypePayload->setBitOffsetFilter($typeInfo_customSensorsValueFilters[$i]->bitOffset);
								$sensorTypePayload->setReversedFilter($typeInfo_customSensorsValueFilters[$i]->reversed == true?1:0);
								$sensorTypePayload->setDataTypeFilter($typeInfo_customSensorsValueFilters[$i]->dataType);
								$sensorTypePayload->setByteOffsetFilter($typeInfo_customSensorsValueFilters[$i]->byteOffset);
								$sensorTypePayload->setExpresionFilter($typeInfo_customSensorsValueFilters[$i]->expresion);
								$sensorTypePayload->setComponentOverrideFilter($typeInfo_customSensorsValueFilters[$i]->componentOverride);
							}
							$em->persist($sensorTypePayload);
							$em->flush();
							$i++;
						}
						
						// creating new record in sensor type gateway pkid. 
						$sensorTypeGatewayPkid = new SensorTypeGatewayPkid();
						$sensorTypeGatewayPkid->setMacNumber($macNumber);
						$sensorTypeGatewayPkid->setSensorTypeId($sensorTypeInfoId);
						$sensorTypeGatewayPkid->setPkId($typeInfo_pkid);
						$em->persist($sensorTypeGatewayPkid);
						$em->flush();
					
					
						//return new JsonResponse(array('status' => 'SUCCESS','sensorTypeId'=>$sensorTypeInfoId,'message' => 'This Sesnor Type  Configuration Download and Linked  Successfully!!'));
					}
					// if sensor type info present in database table.
					else{
						$sensorTypeId = $sensorTypeInfo->getId(); // getting the sensortype id.
						$sensorTypeGatewayPkid = new sensorTypeGatewayPkid();// creating instance of sensor type gateway pkid.
						$sensorTypeGatewayPkid->setMacNumber($macNumber);
						$sensorTypeGatewayPkid->setSensorTypeId($sensorTypeId);
						$sensorTypeGatewayPkid->setPkId($pkId);
						$em->persist($sensorTypeGatewayPkid);
						$em->flush();					
						//return new JsonResponse(array('status' => 'SUCCESS','message' => 'This Sensor Type  Configuration Already present but Linked with Gateway!!'));
					}
				}
				// if pkid for sensor type is already in database table for that gateway.
				else{
					$sensorTypeInfoId = $sensorTypeGatewayPkid->getSensorTypeId();//getting the sensortype id.
				}
			}
		//return new JsonResponse(array('status' => 'SUCCESS','typeInfo'=>$typeInfo,'message' => 'testing the request'));
		/****** new code for custom sensor device *******/		
		
		if($sensorType == 'oemsensors'){
			$sensorModelName = $data->sensorModelName;
			$sensorNames = $data->sensorNames;
			$sensorTypeName = 	'oemsensors';//$deviceEUI.'_'.$sensorType.'_Type';
			$serverIds = $data->serverIds;
			$sensorServerDetailVarname = $data->componentName;
			$sensorName = $data->componentName;//$data->sensorName == ''?$deviceEUI.'_'.$sensorType :$data->sensorName;
		}
		if($sensorType == 'ibox'){
			$sensorTypeName = 	$deviceEUI.'_'.$sensorType.'_Type';
			$sensorName = $data->sensorName == ''?$deviceEUI.'_'.$sensorType :$data->sensorName;
			$serverIds = $data->serverIds;
			$metersConfiguration = $data->metersConfiguration;
			$versionSensorName = $data->versionSensorName;
			$pingSensorName = $data->pingSensorName;
			$informationComponentName = $data->informationComponentName;
			$sensorServerDetailVarname = $data->informationComponentName;
			$inputsConfiguration = $data->inputsConfiguration;
		}
		
		if($sensorType == 'wifi'){	
			$sensorTypeName = 	$deviceEUI.'_'.$sensorType.'_Type';	
			$sensorName = $data->sensorName == ''?$deviceEUI.'_'.$sensorType :$data->sensorName;
			$wifiComponentName = $data->wifiComponentName;
			$sensorServerDetailVarname = $data->wifiComponentName;
			$wifiCountSensorName = $data->wifiCountSensorName;
			$wifiHashSensorName = $data->wifiHashSensorName;
			$bleComponentName = $data->bleComponentName;
			$bleCountSensorName = $data->bleCountSensorName;
			$bleHashSensorName = $data->bleHashSensorName;		
			$btComponentName = $data->btComponentName;
			$btCountSensorName = $data->btCountSensorName;
			$btHashSensorName = $data->btHashSensorName;
		}		
		
		$SensorGatewayPkid = $em 
			->getRepository('AppBundle:SensorGatewayPkid')
			->findOneBy(array('pkId' => $pkId,'macNumber' => $macNumber));
		$serverGatewayPkid = $em 
			->getRepository('AppBundle:ServerGatewayPkid')
			->findOneBy(array('pkId' => $serverIds,'macNumber' => $macNumber));
		$serverId =  $serverGatewayPkid->getServerId();
		if(!$SensorGatewayPkid){				
			// setting pkid value to null for that gatewaymac
			//$ServerGatewayPkid->setPkId(null);
			//getting gateway information for that gatewaymac Servers
			if($sensorId != ''){
				$sensor = $em 
				->getRepository('AppBundle:SensorInfo')
				->findOneBy(array('id' => $sensorId,'deviceEUI' => $deviceEUI));
			}
			else{
				$sensor = $em 
				->getRepository('AppBundle:SensorInfo')
				->findOneBy(array('deviceEUI' => $deviceEUI));
			}
			if(!$sensor){
				if($sensorType == 'customsensordevices'){
					//$componentName =  $data->componentName;
					$componentName =  $data->componentName;
					$sensorServerDetailVarname = $data->componentName;
					$sensor = new SensorInfo();
					$sensor->setUserId($userId);
					$sensor->setTypeSensor($sensorTypeInfoId);//$sensorTypeId
					$sensor->setName($componentName);//$sensorName previously I was using 
					$sensor->setDeviceEUI($deviceEUI);
					$sensor->setInstallationDate(new \DateTime());
					$em->persist($sensor);
					$em->flush();
					$sensorId = $sensor->getId();
					$sensorGatewayPkid = new SensorGatewayPkid();
					$sensorGatewayPkid->setMacNumber($macNumber);
					$sensorGatewayPkid->setSensorId($sensorId);
					$sensorGatewayPkid->setPkId($pkId);
					$em->persist($sensorGatewayPkid);
					$em->flush();
					
					$gateway = $em 
						->getRepository('AppBundle:Gateways')
						->findOneBy(array('mac' => $macNumber));
						if($gateway){
							$sensorIdsAlreadylinked = $gateway->getSensorsId();
							if($sensorIdsAlreadylinked != ""){
								$updatedSensorIds=$sensorIdsAlreadylinked.','.$sensorId;
								$gateway->setSensorsId($updatedSensorIds);
							}
							else{
								$gateway->setSensorsId($sensorId);
							}
							$em->persist($gateway);
							$em->flush();
						}
						$sensorServerDetail = $em 
						->getRepository('AppBundle:SensorServerDetail')
						->findOneBy(array('serverId' => $serverId,'sensorId' =>$sensorId));
						if(!$sensorServerDetail){
							$sensorServerDetail = new SensorServerDetail();
							$sensorServerDetail->setServerId($serverId);
							$sensorServerDetail->setSensorId($sensorId);							
							$sensorServerDetail->setVarnames($sensorServerDetailVarname);
							$em->persist($sensorServerDetail);
							$em->flush();
						}
					return new JsonResponse(array('status' => 'SUCCESS','message' => 'This Custome Sensor  Configuration Download and Linked with Gateway Successfully!!'));			
				}
				//If not the customsensordevices
				else{
					$sensorTypeInfo = $em 
						->getRepository('AppBundle:SensorTypeInfo')
						->findOneBy(array('name' => $sensorTypeName,'sensorType' => $sensorType,'userId' =>$userId));
					if(!$sensorTypeInfo){
						$sensorTypeInfo = new SensorTypeInfo();
						$sensorTypeInfo->setUserId($userId);
						$sensorTypeInfo->setName($sensorTypeName);
						$sensorTypeInfo->setSensorType($sensorType);
						$em->persist($sensorTypeInfo);
						$em->flush();
						$sensorTypeId = $sensorTypeInfo->getId();
					}
					else{
						$sensorTypeId  = $sensorTypeInfo->getId();
					}
					$sensor = new SensorInfo();
					$sensor->setUserId($userId);
					$sensor->setTypeSensor($sensorTypeId);
					$sensor->setName($sensorName);
					
					if($sensorModelName)
					$sensor->setSensorModelName($sensorModelName);
				
					$sensor->setDeviceEUI($deviceEUI);
					$sensor->setInstallationDate(new \DateTime());
					$em->persist($sensor);
					$em->flush();
					$sensorId = $sensor->getId();
					
					$sensorGatewayPkid = new SensorGatewayPkid();
					$sensorGatewayPkid->setMacNumber($macNumber);
					$sensorGatewayPkid->setSensorId($sensorId);
					$sensorGatewayPkid->setPkId($pkId);
					$em->persist($sensorGatewayPkid);
					$em->flush();
					$gateway = $em 
					->getRepository('AppBundle:Gateways')
					->findOneBy(array('mac' => $macNumber));
					if($gateway){
						$sensorIdsAlreadylinked = $gateway->getSensorsId();
						if($sensorIdsAlreadylinked != ""){
							$updatedSensorIds=$sensorIdsAlreadylinked.','.$sensorId;
							$gateway->setSensorsId($updatedSensorIds);
						}
						else{
							$gateway->setSensorsId($sensorId);
						}
						$em->persist($gateway);
						$em->flush();
					}
					$sensorServerDetail = $em 
						->getRepository('AppBundle:SensorServerDetail')
						->findOneBy(array('serverId' => $serverId,'sensorId' =>$sensorId));
						if(!$sensorServerDetail){
							$sensorServerDetail = new SensorServerDetail();
							$sensorServerDetail->setServerId($serverId);
							$sensorServerDetail->setSensorId($sensorId);							
							$sensorServerDetail->setVarnames($sensorServerDetailVarname);
							$em->persist($sensorServerDetail);
							$em->flush();
						}
					return new JsonResponse(array('status' => 'SUCCESS','message' => 'This Sensor  Configuration Download and Linked with Gateway Successfully!!'));
				}					
			}
			else{
				$sensorId = $sensor->getId();
				$sensorGatewayPkid = new SensorGatewayPkid();
				$sensorGatewayPkid->setMacNumber($macNumber);
				$sensorGatewayPkid->setSensorId($sensorId);
				$sensorGatewayPkid->setPkId($pkId);
				$em->persist($sensorGatewayPkid);
				$em->flush();
					
				$gateway = $em 
					->getRepository('AppBundle:Gateways')
					->findOneBy(array('mac' => $macNumber));
				if($gateway){
					$sensorIdsAlreadylinked = $gateway->getSensorsId();
					if($sensorIdsAlreadylinked != ""){
						$updatedSensorIds=$sensorIdsAlreadylinked.','.$sensorId;
						$gateway->setSensorsId($updatedSensorIds);
					}
					else{
						$gateway->setSensorsId($sensorId);
					}
					$em->persist($gateway);
					$em->flush();
				}
				$sensorServerDetail = $em 
						->getRepository('AppBundle:SensorServerDetail')
						->findOneBy(array('serverId' => $serverId,'sensorId' =>$sensorId));
						if(!$sensorServerDetail){
							$sensorServerDetail = new SensorServerDetail();
							$sensorServerDetail->setServerId($serverId);
							$sensorServerDetail->setSensorId($sensorId);							
							$sensorServerDetail->setVarnames($sensorServerDetailVarname);
							$em->persist($sensorServerDetail);
							$em->flush();
						}
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'This Sensor  Configuration Already present!!'));
			}
		}
		else{
			return new JsonResponse(array('status' => 'SUCCESS','message' => 'This Sensor  Configuration Already Linked With Gateway!!'));
		}	
		
	}
	
	
	/**
     * Update a Gateway Serverids
     *                                                                                 
	 * @Route("/downloadFromGatewayServersToOurServer", name="gateway_downloadFromGatewayServersToOurServer")
	 */
	public function downloadFromGatewayServersToOurServerApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		$authorizationToken = $data->authorizationToken;
		$providerId = $data->providerId;
		$type = $data->type;
		$serverUrl = $data->serverUrl;
		$name = $data->name;
		$pkId = $data->pkId;
		$userId = $data->userId;
		$macNumber = $data->macNumber;
		
		
		$ServerGatewayPkid = $em 
					->getRepository('AppBundle:ServerGatewayPkid')
					->findOneBy(array('pkId' => $pkId,'macNumber' => $macNumber));
		if(!$ServerGatewayPkid){			
				// setting pkid value to null for that gatewaymac
				//$ServerGatewayPkid->setPkId(null);
				//getting gateway information for that gatewaymac Servers
				$servers = $em 
					->getRepository('AppBundle:Servers')
					->findOneBy(array('authorizationToken' => $authorizationToken,'providerId' => $providerId,'type' => $type,'serverUrl' => $serverUrl,'name' => $name));
				if(!$servers)
				{
					$servers = new Servers();
					$servers->setUserId($userId);
					$servers->setType($type);
					$servers->setName($name);
					$servers->setProviderId($providerId);
					$servers->setAuthorizationToken($authorizationToken);
					$servers->setServerUrl($serverUrl);
					$em->persist($servers);
					$em->flush();
					$serverId = $servers->getId();
					
					$serverGatewayPkid = new ServerGatewayPkid();
					$serverGatewayPkid->setMacNumber($macNumber);
					$serverGatewayPkid->setServerId($serverId);
					$serverGatewayPkid->setPkId($pkId);
					$em->persist($serverGatewayPkid);
					$em->flush();
					
					$gateway = $em 
					->getRepository('AppBundle:Gateways')
					->findOneBy(array('mac' => $macNumber));
					if($gateway){
						$serverIdsAlreadylinked = $gateway->getServerId();
						if($serverIdsAlreadylinked != ""){
						$updatedServerIds=$serverIdsAlreadylinked.','.$serverId;
						$gateway->setServerId($updatedServerIds);
						}
						else{
							$gateway->setServerId($serverId);
						}
						$em->persist($gateway);
						$em->flush();
					}
					return new JsonResponse(array('status' => 'SUCCESS','message' => 'This Server  Configuration Download and Linked with Gateway Successfully!!'));
				}
				else{
					$serverId = $servers->getId();
					$serverGatewayPkid = new ServerGatewayPkid();
					$serverGatewayPkid->setMacNumber($macNumber);
					$serverGatewayPkid->setServerId($serverId);
					$serverGatewayPkid->setPkId($pkId);
					$em->persist($serverGatewayPkid);
					$em->flush();
					
					$gateway = $em 
					->getRepository('AppBundle:Gateways')
					->findOneBy(array('mac' => $macNumber));
					if($gateway){
						$serverIdsAlreadylinked = $gateway->getServerId();
						if($serverIdsAlreadylinked != ""){
						$updatedServerIds=$serverIdsAlreadylinked.','.$serverId;
						$gateway->setServerId($updatedServerIds);
						}
						else{
							$gateway->setServerId($serverId);
						}
						$em->persist($gateway);
						$em->flush();
					}
					return new JsonResponse(array('status' => 'SUCCESS','message' => 'This Server  Configuration Already present!!'));
				}
			}
			else{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'This Server  Configuration Already Linked With Gateway!!'));
			}
		
	}
	
	/**
     * Update a Gateway Sensors
     *                                                                                 
	 * @Route("/updategatewayUnlinkSensor", name="gateway_updategatewayUnlinkSensor")
	 */
	public function updategatewayUnlinkSensorApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		$macNumber = $data->macNumber;
		$pkId = $data->pkId;
		
		
		$SensorGatewayPkid= $em 
					->getRepository('AppBundle:SensorGatewayPkid')
					->findOneBy(array('pkId' => $pkId,'macNumber' => $macNumber));
		if($SensorGatewayPkid){
			//getting sensor id linked to gatewaymac pkid
			$sensorId = $SensorGatewayPkid->getSensorId();
			//checking if value if true
			if($sensorId){
				// setting pkid value to null for that gatewaymac
				$SensorGatewayPkid->setPkId(null);
				//getting gateway information for that gatewaymac
				$gateway= $em 
					->getRepository('AppBundle:Gateways')
					->findOneBy(array('mac' => $macNumber));
				//finding the sensor are linked to that gatewaymac	
				$sensorIdsAlreadylinked = $gateway->getSensorsId();
				//checking the gatewaymac linked sensors true
				if($sensorIdsAlreadylinked != ""){
					// converting string to array 
					$sensorIdsAlreadyLinkedArray = explode(',', $sensorIdsAlreadylinked);
					$toRemoveFrom = array($sensorId);
					//find the difference of array and remove the linked array
					$resultArray = array_diff($sensorIdsAlreadyLinkedArray, $toRemoveFrom);
					//check the still some more servers are linked to gatewaymac true
					if(count($resultArray)){
						// make the string from array
						$resultStr =  implode(',',$resultArray);
						//set the gateway server id value to that string
						$gateway->setSensorsId($resultStr);
					
					}
					else{
						//set the gateway server id value to null
						$gateway->setSensorsId(null);
					}
				$gateway->setUpdatedDt(new \DateTime());
				
				$em->persist($gateway);
				
				$em->flush();
				
				$em->persist($SensorGatewayPkid);
				
				$em->flush();
				
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'Gateway sensor has been successfully updated!!'));
				}
				
			}
		}
		else{
			return new JsonResponse(array('status' => 'SUCCESS','message' => 'this sensor is not linked with this gateway!!'));
		}
		
	}
	
	/**
     * Update a Gateway Serverids
     *                                                                                 
	 * @Route("/updategatewayUnlinkServer", name="gateway_updategatewayUnlinkServer")
	 */
	public function updategatewayUnlinkServerApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		$macNumber = $data->macNumber;
		$pkId = $data->pkId;
		
		
		$ServerGatewayPkid= $em 
					->getRepository('AppBundle:ServerGatewayPkid')
					->findOneBy(array('pkId' => $pkId,'macNumber' => $macNumber));
		if($ServerGatewayPkid){
			//getting server id linked to gatewaymac pkid
			$serverId = $ServerGatewayPkid->getServerId();
			//checking if value if true
			if($serverId){
				// setting pkid value to null for that gatewaymac
				$ServerGatewayPkid->setPkId(null);
				//getting gateway information for that gatewaymac
				$gateway= $em 
					->getRepository('AppBundle:Gateways')
					->findOneBy(array('mac' => $macNumber));
				//finding the server are linked to that gatewaymac	
				$serverIdsAlreadylinked = $gateway->getServerId();
				//checking the gatewaymac linked servers true
				if($serverIdsAlreadylinked != ""){
					// converting string to array 
					$serverIdsAlreadyLinkedArray = explode(',', $serverIdsAlreadylinked);
					$toRemoveFrom = array($serverId);
					//find the difference of array and remove the linked array
					$resultArray = array_diff($serverIdsAlreadyLinkedArray, $toRemoveFrom);
					//check the still some more servers are linked to gatewaymac true
					if(count($resultArray)){
						// make the string from array
						$resultStr =  implode(',',$resultArray);
						//set the gateway server id value to that string
						$gateway->setServerId($resultStr);
					
					}
					else{
						//set the gateway server id value to null
						$gateway->setServerId(null);
					}
				$gateway->setUpdatedDt(new \DateTime());
				
				$em->persist($gateway);
				
				$em->flush();
				
				$em->persist($ServerGatewayPkid);
				
				$em->flush();
				
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'Gateway servers has been successfully updated!!'));
				}
				
			}
		}
		else{
			return new JsonResponse(array('status' => 'SUCCESS','message' => 'this server is not linked with this gateway!!'));
		}
		
	}
	
	/**
     * Update a Gateway Serverids
     *                                                                                 
	 * @Route("/updategatewayserverids", name="gateway_updategatewayserverids")
	 */
	public function updategatewayServerIdsApi(Request $request)    
	{
	$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());	
		
		$gatewayId = $data->id;		
		$serverId = $data->serverId;
		$serverIdArray = explode(',', $serverId);
		$gateway= $em 
			->getRepository('AppBundle:Gateways')
			->findOneBy(array('id' => $gatewayId));
			
		
			
		if($gateway !=null)
		{
			$macAddress = $gateway->getMac();
			
			$serverIdfromGateway = $gateway->getServerId();
			if($serverIdfromGateway != "")
			  {
				$serverIdfromGatewayArray = explode(',', $serverIdfromGateway);
				$newServerToAddGateway = $serverId != "" ? array_diff($serverIdArray,$serverIdfromGatewayArray):[];
				$oldServerToRemoveGateway = $serverId != "" ? array_diff($serverIdfromGatewayArray,$serverIdArray):$serverIdfromGatewayArray;
				//print_r($newServerToAddGateway);
				//print_r($oldServerToRemoveGateway);
				if(count($newServerToAddGateway) > 0)
				{
					
					foreach ($newServerToAddGateway   as $value){ 
					$serverObj= $em 
					->getRepository('AppBundle:Servers')
					->findOneBy(array('id' => $value)); 
					
					$ServerGatewayPkid= $em 
					->getRepository('AppBundle:ServerGatewayPkid')
					->findOneBy(array('serverId' => $value,'macNumber' => $macAddress)); 
					//print_r($value);	
					
					$requestId = $serverObj->getId();					
					$type = $serverObj->getType();		
					$serverName  = $serverObj->getName();	
					$url  = $serverObj->getServerUrl();			
					$provider  = $serverObj->getProviderId();	
					$identityKey = $serverObj->getAuthorizationToken();					
					//print_r($serverName);
					if($ServerGatewayPkid  != null)
					{
						$pkId = $ServerGatewayPkid->getPkId();
						if(!$pkId)
						{						
							$this->servermsg($macAddress, $requestId, $type, $serverName, $url, $provider, $identityKey);
						}
					}
					else{						
						$this->servermsg($macAddress, $requestId, $type, $serverName, $url, $provider, $identityKey);
					}
				   }
				}
				if(count($oldServerToRemoveGateway) > 0)
				{
					foreach ($oldServerToRemoveGateway   as $value){ 
					//$serverObj= $em 
					//->getRepository('AppBundle:Servers')
					//->findOneBy(array('id' => $value));
					$ServerGatewayPkid= $em 
					->getRepository('AppBundle:ServerGatewayPkid')
					->findOneBy(array('serverId' => $value,'macNumber' => $macAddress));
					$pkId = $ServerGatewayPkid->getPkId();
					$requestId = $value;
					if($pkId)
					{
					$this->servermsgdelete($macAddress, $requestId, $pkId);	
					}
					}
				}
				
				}
			else{
				foreach ($serverIdArray   as $value){ 
				  $serverObj= $em 
					->getRepository('AppBundle:Servers')
					->findOneBy(array('id' => $value));
					
					$ServerGatewayPkid= $em 
					->getRepository('AppBundle:ServerGatewayPkid')
					->findOneBy(array('serverId' => $value,'macNumber' => $macAddress));
					
					//	print_r($value);
					//print_r($serverObj);
					$requestId = $serverObj->getId();
					$type = $serverObj->getType();
					//$pkId = $serverObj->getPkId();
					$serverName  = $serverObj->getName();	
					$url  = $serverObj->getServerUrl();			
					$provider  = $serverObj->getProviderId();	
					$identityKey = $serverObj->getAuthorizationToken();
					if($ServerGatewayPkid  != null)
					{
						$pkId = $ServerGatewayPkid->getPkId();
						if(!$pkId)
						{						
							$this->servermsg($macAddress, $requestId, $type, $serverName, $url, $provider, $identityKey);
						}
					}
					else{						
						$this->servermsg($macAddress, $requestId, $type, $serverName, $url, $provider, $identityKey);
					}
				}
			}
			if($serverId != "")
				{
					$gateway->setServerId($serverId);
				}
			else
				$gateway->setServerId("");
			
			
			$gateway->setUpdatedDt(new \DateTime());
			
			$em->persist($gateway);
			
			$em->flush();
			$gatewayId = $gateway->getId();
			
			if( $gatewayId != "")
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'Gateway servers has been successfully updated!!'));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating Gateway servers details!!'));
			}
		}
			else
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating Gateway Detail No Record found with this Id'));
		}
	}
	
	/**
     * Update a Gateway Sensorids
     *                                                                                 
	 * @Route("/updategatewaysensorids", name="gateway_updategatewaysensorids")
	 */
	public function updategatewaySensorIdsApi(Request $request)    
	{
	$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());	
		
		$id = $data->id;		
		$sensorsId = $data->sensorsId;
		
		$sensorIdArray = explode(',', $sensorsId);
		$gateway= $em 
			->getRepository('AppBundle:Gateways')
			->findOneBy(array('id' => $id));
			
		if($gateway !=null)
		{
			$macAddress = $gateway->getMac();
			$ApplicationNameId = $gateway->getApplication();
			$sensorIdfromGateway = $gateway->getSensorsId();
		  // $sensorIdfromGatewayArray = explode(',', $sensorIdfromGateway);
		  // print_r($sensorIdfromGateway);		  
			//print_r('diff1');
			//print_r(array_diff($sensorIdArray,$sensorIdfromGatewayArray));
			//print_r('diff2');
			//print_r(array_diff($sensorIdfromGatewayArray,$sensorIdArray));
		   if($sensorIdfromGateway != "")
			{
				$sensorIdfromGatewayArray = explode(',', $sensorIdfromGateway);
				$newSensorToAddGateway = $sensorsId != "" ? array_diff($sensorIdArray,$sensorIdfromGatewayArray):[];
				$oldSensorToRemoveGateway =  $sensorsId != "" ?  array_diff($sensorIdfromGatewayArray,$sensorIdArray):[];//$sensorIdfromGatewayArray;
			//return new JsonResponse(array('status' => 'SUCCESS','oldSensorToRemoveGateway' => $oldSensorToRemoveGateway,'newSensorToAddGateway' => $newSensorToAddGateway,'message' => 'Gateway sensor has been successfully updated!!'));
				if(count($newSensorToAddGateway) > 0)
				{
					foreach ($newSensorToAddGateway   as $value){ 
					
					
						$sensorInfo= $em 
						->getRepository('AppBundle:SensorInfo')
						->findOneBy(array('id' => $value));
					
						$typeSensor = $sensorInfo -> getTypeSensor();
						$sensorTypeObj = $em 
						->getRepository('AppBundle:SensorTypeInfo')
						->findOneBy(array('id' => $typeSensor));
					
						$typeSensorName = $sensorTypeObj->getSensorType();
						$nameofthesensorType= $sensorTypeObj->getName();
						$sensorTypeUniqueId = $sensorTypeObj->getSensorTypeUniqueId();
						$id = $sensorTypeObj->getId();
						
						$SensorTypeGatewayPkid= $em 
						->getRepository('AppBundle:SensorTypeGatewayPkid')
						->findOneBy(array('sensorTypeId' => $id,'macNumber' => $macAddress));
						
						if($typeSensorName !=  "wifi" && $typeSensorName !=  "ibox" && $typeSensorName !=  "oemsensors")
						{
							//return new JsonResponse(array('status' => 'SUCCESS','oldSensorToRemoveGateway' => $oldSensorToRemoveGateway,'newSensorToAddGateway' => $newSensorToAddGateway,'message' => $typeSensorName));
							$sensorTypePayloadObj= $em 
							->getRepository('AppBundle:SensorTypePayload')
							->findBy(array('sensorTypeId' => $typeSensor));
							//print('sensorTypePayloadObj');
							//print_r($sensorTypePayloadObj);
							$sensorFormatString = "";
							$sensorNames = "";
							if(count($sensorTypePayloadObj)  >  0){
								foreach ($sensorTypePayloadObj   as $sensorTypePayload){
						
									$typeOfData = $sensorTypePayload->getTypeOfData();				
									$reverse = $sensorTypePayload->getReverse();					
									$sensorTypeId = $sensorTypePayload->getSensorTypeId();					
									$payloadUniqueId = $sensorTypePayload->getPayloadUniqueId();
									$varname = $sensorTypePayload->getVarname();				
									$start = $sensorTypePayload->getStart();				
									$length = $sensorTypePayload->getLength();
									$description = $sensorTypePayload->getDescription();
									$decimalNumber = $sensorTypePayload->getDecimalNumber();
									$bitNumber = $sensorTypePayload->getBitNumber();
									$any = $sensorTypePayload->getAny();
									$expresion = $sensorTypePayload->getExpresion();
									$componentOverride = $sensorTypePayload->getComponentOverride();
									//filterValues
									$sensorToFilter = $sensorTypePayload->getSensorToFilter();
									$sensorNameFilter = $sensorTypePayload->getSensorNameFilter();
									$trueValueFilter = $sensorTypePayload->getTrueValueFilter();
									$lengthFilter = $sensorTypePayload->getLengthFilter();
									$decimalsFilter = $sensorTypePayload->getDecimalsFilter();
									$bitOffsetFilter = $sensorTypePayload->getBitOffsetFilter();
									$reversedFilter = $sensorTypePayload->getReversedFilter();
									$dataTypeFilter = $sensorTypePayload->getDataTypeFilter();
									$byteOffsetFilter = $sensorTypePayload->getByteOffsetFilter();
									$expresionFilter = $sensorTypePayload->getExpresionFilter();
									$componentOverrideFilter = $sensorTypePayload->getComponentOverrideFilter();
									
									
									$customSensorsDecodeFormat = "{";
					
									if($typeOfData == "number")
									{
										if($reverse != ""){
											$sensorFormatString =	$sensorFormatString.'d'.$start.'-'.$length.'.'.$decimalNumber.'R';
										}
										else{
											$sensorFormatString =	$sensorFormatString.'d'.$start.'-'.$length.'.'.$decimalNumber;
										}
									}
									elseif($typeOfData == "string")
									{
										if($reverse != ""){
											$sensorFormatString =	$sensorFormatString.'s'.$start.'-'.$length.'R';
										}
										else{
											$sensorFormatString =	$sensorFormatString.'s'.$start.'-'.$length;
										}
									}
									elseif($typeOfData == "boolean")
									{
										$sensorFormatString =	$sensorFormatString.'b'.$start.'-'.$bitNumber;
									}
									else{
						
									}
									if(strlen($sensorNames)  > 0)
									{
										$sensorNames = $sensorNames.',\"'.$varname.'\"';
									}
									else{
										$sensorNames = '\"'.$varname.'\"';	
									}
									$sensorFormatString = $sensorFormatString." ";
									
									switch($typeOfData){
									case 'number':{
										$typeOfData = 0;
										$dataTypeFilter = 0;
										break;
									}
									case 'float':{
										$typeOfData = 1;
										$dataTypeFilter = 1;
										break;
									}
									case 'double':{
										$typeOfData = 2;
										$dataTypeFilter = 2;
										break;
									}
									case 'string':{
										$typeOfData = 3;
										$dataTypeFilter = 3;
										break;
									}
									case 'integer':{
										$typeOfData = 4;
										$dataTypeFilter = 4;
										break;
									}
									case 'boolean':{
										$typeOfData = 5;
										$dataTypeFilter = 5;
										break;
									}
									case 'bitboolean':{
										$typeOfData = 6;
										$dataTypeFilter = 6;
										break;
									}
									case 'hexstring':{
										$typeOfData = 7;
										$dataTypeFilter = 7;
										break;
									}
									case 'Timestamp':{
										$typeOfData = 8;
										$dataTypeFilter = 8;
										break;
									}
									default:{
										$typeOfData =0;
										$dataTypeFilter = 0;
										break;
									}
									
								}
									$reverse = $reverse ==1?"true":"false";
									$reversedFilter = $reversedFilter ==1?"true":"false";
									
									//$customSensorsDecodeFormat = '{\"sensorName\":'.$sensorNames.',\"dataType\":'.$typeOfData.',\"byteOffset\":'.$start.',\"lenght\":'.$length.',\"decimals\":'.$decimalNumber.',\"bitOffset\":'.$bitNumber.',\"reversed\":'.$reverse.',\"expresion\":null,\"componentOverride\":null}';
									$customSensorsDecodeFormat ='{';
									$customSensorsDecodeFormat =$customSensorsDecodeFormat.'\"sensorName\":'.$sensorNames;
									$customSensorsDecodeFormat =$customSensorsDecodeFormat.',\"dataType\":'.$typeOfData;
									$customSensorsDecodeFormat =$customSensorsDecodeFormat.',\"byteOffset\":'.$start;
									$customSensorsDecodeFormat =$customSensorsDecodeFormat.',\"lenght\":'.$length;
									$customSensorsDecodeFormat =$customSensorsDecodeFormat.',\"decimals\":'.$decimalNumber;
									
									if($typeOfData == 6){
									$customSensorsDecodeFormat =$customSensorsDecodeFormat.',\"bitOffset\":'.$bitNumber;
									}
								
									$customSensorsDecodeFormat =$customSensorsDecodeFormat.',\"reversed\":'.$reverse;
									$customSensorsDecodeFormat =$customSensorsDecodeFormat.',\"expresion\":null,\"componentOverride\":null}';
									
									//$customSensorsValueFilters = '{\"sensorToFilter\":'.$sensorToFilter.',\"trueValue\":'.$trueValueFilter.',\"sensorName\":'.$sensorNameFilter.',\"dataType\":'.$dataTypeFilter.',\"byteOffset\":'.$byteOffsetFilter.',\"lenght\":'.$lengthFilter.',\"decimals\":'.$decimalsFilter.',\"bitOffset\":'.$bitOffsetFilter.',\"reversed\":'.$reversedFilter.',\"expresion\":null,\"componentOverride\":null}';
									$customSensorsValueFilters = '{';
									$customSensorsValueFilters = $customSensorsValueFilters.'\"sensorToFilter\":\"'.$sensorToFilter.'\"';
									$customSensorsValueFilters = $customSensorsValueFilters.',\"trueValue\":\"'.$trueValueFilter.'\"';
									$customSensorsValueFilters = $customSensorsValueFilters.',\"sensorName\":\"'.$sensorNameFilter.'\"';
									$customSensorsValueFilters = $customSensorsValueFilters.',\"dataType\":'.$dataTypeFilter;
									$customSensorsValueFilters = $customSensorsValueFilters.',\"byteOffset\":'.$byteOffsetFilter;
									$customSensorsValueFilters = $customSensorsValueFilters.',\"lenght\":'.$lengthFilter;
									$customSensorsValueFilters = $customSensorsValueFilters.',\"decimals\":'.$decimalsFilter;
									
									if($typeOfData == 6){
									$customSensorsValueFilters = $customSensorsValueFilters.',\"bitOffset\":'.$bitOffsetFilter;
									}
								
									$customSensorsValueFilters = $customSensorsValueFilters.',\"reversed\":'.$reversedFilter;
									$customSensorsValueFilters = $customSensorsValueFilters.',\"expresion\":null,\"componentOverride\":null}';
								}
								
								if($SensorTypeGatewayPkid  == null){								
									$this->sensortypemsg($macAddress, $id, $typeSensorName, $sensorFormatString, $sensorNames,  $customSensorsDecodeFormat,$customSensorsValueFilters,$nameofthesensorType);
									sleep(10);
								}
								else{
									$pkId = $SensorTypeGatewayPkid->getPkId();
									if(!pkId){
										$this->sensortypemsg($macAddress, $id, $typeSensorName, $sensorFormatString, $sensorNames, $customSensorsDecodeFormat,$customSensorsValueFilters,$nameofthesensorType);
										sleep(10);
									}
								}
							}
						}
				
						//$em->refresh($sensorTypeObjupdated);
						$sensorTypeObjupdated = $em 
						->getRepository('AppBundle:SensorTypeInfo')
						->findOneBy(array('id' => $typeSensor));
						$SensorTypeGatewayPkid= $em 
						->getRepository('AppBundle:SensorTypeGatewayPkid')
						->findOneBy(array('sensorTypeId' => $typeSensor,'macNumber' => $macAddress));
						//$em->refresh($sensorTypeObjupdated);	
						$sensorServerObj= $em 
						->getRepository('AppBundle:SensorServerDetail')
						->findBy(array('sensorId' => $value));
					
						$serverIds  = [];
						foreach ($sensorServerObj   as $value){ 
							array_push($serverIds,$value->getServerId());
						}
				
					
						$ServerGatewayPkids= $em 
						->getRepository('AppBundle:ServerGatewayPkid')
						->findBy(array('serverId' => $serverIds,'macNumber' => $macAddress));
						$serverPkIdarr  = [];
						foreach ($ServerGatewayPkids   as $ServerGatewayPkid){ 
							array_push($serverPkIdarr,$ServerGatewayPkid->getServerId());
						}
						
						$serverPkIds = implode(",",$serverPkIdarr);
						
						
						$SensorGatewayPkid= $em 
						->getRepository('AppBundle:SensorGatewayPkid')
						->findOneBy(array('sensorId' => $value,'macNumber' => $macAddress));
					
					
						$id = $sensorInfo->getId();	
						$typeSensorName = $sensorTypeObjupdated->getSensorType();;	
						$sensorUniqueId = $sensorInfo->getSensorUniqueId();
						//$pkId = $SensorGatewayPkid->getPkId();	
						$componentName = $sensorInfo->getName();
						$description = $sensorInfo->getDescription();
						$latitude = $sensorInfo->getLatitude();
						$longitude = $sensorInfo->getLongitude();
						$deviceEUI = $sensorInfo->getDeviceEUI();
						$appEUI = $sensorInfo->getAppEUI();
						$appKEY = $sensorInfo->getAppKEY();
						$hashSensorName="";
						$countSensorName="";
						if($typeSensorName !=  "wifi" && $typeSensorName !=  "ibox" && $typeSensorName !=  "oemsensors")
						{
							$em->refresh($SensorTypeGatewayPkid);
							$customSensor=$SensorTypeGatewayPkid->getPkId();					
						}
						else{
							$customSensor="";
						}
						if($SensorGatewayPkid != null){
							$pkId = $SensorGatewayPkid->getPkId();
							if(!$pkId)
							{
								$this->sensormsg($macAddress, $ApplicationNameId, $id,  $typeSensorName, $componentName, $deviceEUI, $serverIds, $hashSensorName, $countSensorName, $customSensor,$serverPkIds);
						
								$this->sensormsgchirpstack($macAddress,$ApplicationNameId, $id, $componentName, $deviceEUI, $description);
								sleep(3);
								$this->sensormsgchirpstackkey($macAddress, $ApplicationNameId,$id, $componentName, $appKEY, $deviceEUI);
							}
						}
						else{
							$this->sensormsg($macAddress,$ApplicationNameId, $id,  $typeSensorName, $componentName, $deviceEUI, $serverIds, $hashSensorName, $countSensorName, $customSensor,$serverPkIds);
				
							$this->sensormsgchirpstack($macAddress,$ApplicationNameId, $id, $componentName, $deviceEUI, $description);
							sleep(5);
							$this->sensormsgchirpstackkey($macAddress,$ApplicationNameId, $id, $componentName, $appKEY, $deviceEUI);
						}
					}
				}
				// old record to remove
				if(count($oldSensorToRemoveGateway) > 0)
				{
					
					foreach ($oldSensorToRemoveGateway   as $value){ 
						$sensorInfo= $em 
						->getRepository('AppBundle:SensorInfo')
						->findOneBy(array('id' => $value));	
					
						$typeSensor = $sensorInfo->getTypeSensor();
						$sensorTypeObj= $em 
						->getRepository('AppBundle:SensorTypeInfo')
						->findOneBy(array('id' => $typeSensor));
					
						$sensorServerObj= $em 
						->getRepository('AppBundle:SensorServerDetail')
						->findBy(array('sensorId' => $value));
					
						$serverIds  = [];
						foreach ($sensorServerObj   as $value){ 
							array_push($serverIds,$value->getServerId());
						}
						
						$serverPkIdarr  = [];
						foreach ($ServerGatewayPkids   as $ServerGatewayPkid){ 
							array_push($serverPkIdarr,$ServerGatewayPkid->getServerId());
						}
						$serverPkIds = implode(",",$serverPkIdarr);
						
						$id = $sensorInfo->getId();	
						$SensorGatewayPkid= $em 
						->getRepository('AppBundle:SensorGatewayPkid')
						->findOneBy(array('sensorId' => $id,'macNumber' => $macAddress));
						
						$id = $sensorInfo->getId();	
						$typeSensorName = $sensorTypeObj->getSensorType();	
						$sensorUniqueId = $sensorInfo->getSensorUniqueId();
						$pkId = $SensorGatewayPkid->getPkId();
						$componentName = $sensorInfo->getName();					
						$latitude = $sensorInfo->getLatitude();
						$longitude = $sensorInfo->getLongitude();
						$deviceEUI = $sensorInfo->getDeviceEUI();
						$appEUI = $sensorInfo->getAppEUI();
						$appKEY = $sensorInfo->getAppKEY();
						$hashSensorName="";
						$countSensorName="";
						$customSensor="";
						if($pkId){
							$this->sensormsgdelete($macAddress, $id, $typeSensorName,$pkId);
							$this->sensormsgdeleteFromChirpstack($macAddress, $id, $deviceEUI);
						}
					}
				}
			}
			else{
				foreach ($sensorIdArray   as $value){ 
					$sensorInfo= $em 
					->getRepository('AppBundle:SensorInfo')
					->findOneBy(array('id' => $value));	
					
					$typeSensor = $sensorInfo->getTypeSensor();
					$sensorTypeObj= $em 
					->getRepository('AppBundle:SensorTypeInfo')
					->findOneBy(array('id' => $typeSensor));
					
					$typeSensorName = $sensorTypeObj->getSensorType();
					$nameofthesensorType= $sensorTypeObj->getName();
					$sensorTypeUniqueId = $sensorTypeObj->getSensorTypeUniqueId();
					$id = $sensorTypeObj->getId();
					
					$SensorTypeGatewayPkid= $em 
					->getRepository('AppBundle:SensorTypeGatewayPkid')
					->findOneBy(array('sensorTypeId' => $id,'macNumber' => $macAddress));
					
					
					
					if($typeSensorName !=  "wifi" && $typeSensorName !=  "ibox"  && $typeSensorName !=  "oemsensors")
					{
						$sensorTypePayloadObj= $em 
						->getRepository('AppBundle:SensorTypePayload')
						->findBy(array('sensorTypeId' => $typeSensor));
						//print('sensorTypePayloadObj');
						//print_r($sensorTypePayloadObj);
						$sensorFormatString = "";
						$sensorNames = "";
						if(count($sensorTypePayloadObj)  >  0){
							foreach ($sensorTypePayloadObj   as $sensorTypePayload){
						
								$typeOfData = $sensorTypePayload->getTypeOfData();				
								$reverse = $sensorTypePayload->getReverse();					
								$sensorTypeId = $sensorTypePayload->getSensorTypeId();					
								$payloadUniqueId = $sensorTypePayload->getPayloadUniqueId();
								$varname = $sensorTypePayload->getVarname();				
								$start = $sensorTypePayload->getStart();				
								$length = $sensorTypePayload->getLength();
								$description = $sensorTypePayload->getDescription();
								$decimalNumber = $sensorTypePayload->getDecimalNumber();
								$bitNumber = $sensorTypePayload->getBitNumber();
								$any = $sensorTypePayload->getAny();
								//filterValues
									$sensorToFilter = $sensorTypePayload->getSensorToFilter();
									$sensorNameFilter = $sensorTypePayload->getSensorNameFilter();
									$trueValueFilter = $sensorTypePayload->getTrueValueFilter();
									$lengthFilter = $sensorTypePayload->getLengthFilter();
									$decimalsFilter = $sensorTypePayload->getDecimalsFilter();
									$bitOffsetFilter = $sensorTypePayload->getBitOffsetFilter();
									$reversedFilter = $sensorTypePayload->getReversedFilter();
									$dataTypeFilter = $sensorTypePayload->getDataTypeFilter();
									$byteOffsetFilter = $sensorTypePayload->getByteOffsetFilter();
									$expresionFilter = $sensorTypePayload->getExpresionFilter();
									$componentOverrideFilter = $sensorTypePayload->getComponentOverrideFilter();
					
						
					
								if($typeOfData == "number")
								{
									if($reverse != ""){
										$sensorFormatString =	$sensorFormatString.'d'.$start.'-'.$length.'.'.$decimalNumber.'R';
									}
									else{
										$sensorFormatString =	$sensorFormatString.'d'.$start.'-'.$length.'.'.$decimalNumber;
									}
								}
								elseif($typeOfData == "string")
								{
									if($reverse != ""){
										$sensorFormatString =	$sensorFormatString.'s'.$start.'-'.$length.'R';
									}
									else{
										$sensorFormatString =	$sensorFormatString.'s'.$start.'-'.$length;
									}
								}
								elseif($typeOfData == "boolean")
								{
									$sensorFormatString =	$sensorFormatString.'b'.$start.'-'.$bitNumber;
								}
								else{
						
								}
								if(strlen($sensorNames)  > 0)
								{
									$sensorNames = $sensorNames.',\"'.$varname.'\"';
								}
								else{
									$sensorNames = '\"'.$varname.'\"';	
								}
								$sensorFormatString = $sensorFormatString." ";
								
								switch($typeOfData){
									case 'number':{
										$typeOfData = 0;
										$dataTypeFilter = 0;
										break;
									}
									case 'float':{
										$typeOfData = 1;
										$dataTypeFilter = 1;
										break;
									}
									case 'double':{
										$typeOfData = 2;
										$dataTypeFilter = 2;
										break;
									}
									case 'string':{
										$typeOfData = 3;
										$dataTypeFilter = 3;
										break;
									}
									case 'integer':{
										$typeOfData = 4;
										$dataTypeFilter = 4;
										break;
									}
									case 'boolean':{
										$typeOfData = 5;
										$dataTypeFilter = 5;
										break;
									}
									case 'bitboolean':{
										$typeOfData = 6;
										$dataTypeFilter = 6;
										break;
									}
									case 'hexstring':{
										$typeOfData = 7;
										$dataTypeFilter = 7;
										break;
									}
									case 'Timestamp':{
										$typeOfData = 8;
										$dataTypeFilter = 8;
										break;
									}
									default:{
										$typeOfData =0;
										$dataTypeFilter = 0;
										break;
									}
									
								}
							//custome sensor type message changed 26-11-2020
							$reverse = $reverse ==1?"true":"false";
									$reversedFilter = $reversedFilter ==1?"true":"false";
									
									//$customSensorsDecodeFormat = '{\"sensorName\":'.$sensorNames.',\"dataType\":'.$typeOfData.',\"byteOffset\":'.$start.',\"lenght\":'.$length.',\"decimals\":'.$decimalNumber.',\"bitOffset\":'.$bitNumber.',\"reversed\":'.$reverse.',\"expresion\":null,\"componentOverride\":null}';
									$customSensorsDecodeFormat ='{';
									$customSensorsDecodeFormat =$customSensorsDecodeFormat.'\"sensorName\":'.$sensorNames;
									$customSensorsDecodeFormat =$customSensorsDecodeFormat.',\"dataType\":'.$typeOfData;
									$customSensorsDecodeFormat =$customSensorsDecodeFormat.',\"byteOffset\":'.$start;
									$customSensorsDecodeFormat =$customSensorsDecodeFormat.',\"lenght\":'.$length;
									$customSensorsDecodeFormat =$customSensorsDecodeFormat.',\"decimals\":'.$decimalNumber;
									
									if($typeOfData == 6){
									$customSensorsDecodeFormat =$customSensorsDecodeFormat.',\"bitOffset\":'.$bitNumber;
									}
								
									$customSensorsDecodeFormat =$customSensorsDecodeFormat.',\"reversed\":'.$reverse;
									$customSensorsDecodeFormat =$customSensorsDecodeFormat.',\"expresion\":null,\"componentOverride\":null}';
									
									//$customSensorsValueFilters = '{\"sensorToFilter\":'.$sensorToFilter.',\"trueValue\":'.$trueValueFilter.',\"sensorName\":'.$sensorNameFilter.',\"dataType\":'.$dataTypeFilter.',\"byteOffset\":'.$byteOffsetFilter.',\"lenght\":'.$lengthFilter.',\"decimals\":'.$decimalsFilter.',\"bitOffset\":'.$bitOffsetFilter.',\"reversed\":'.$reversedFilter.',\"expresion\":null,\"componentOverride\":null}';
									$customSensorsValueFilters = '{';
									$customSensorsValueFilters = $customSensorsValueFilters.'\"sensorToFilter\":\"'.$sensorToFilter.'\"';
									$customSensorsValueFilters = $customSensorsValueFilters.',\"trueValue\":\"'.$trueValueFilter.'\"';
									$customSensorsValueFilters = $customSensorsValueFilters.',\"sensorName\":\"'.$sensorNameFilter.'\"';
									$customSensorsValueFilters = $customSensorsValueFilters.',\"dataType\":'.$dataTypeFilter;
									$customSensorsValueFilters = $customSensorsValueFilters.',\"byteOffset\":'.$byteOffsetFilter;
									$customSensorsValueFilters = $customSensorsValueFilters.',\"lenght\":'.$lengthFilter;
									$customSensorsValueFilters = $customSensorsValueFilters.',\"decimals\":'.$decimalsFilter;
									
									if($typeOfData == 6){
									$customSensorsValueFilters = $customSensorsValueFilters.',\"bitOffset\":'.$bitOffsetFilter;
									}
								
									$customSensorsValueFilters = $customSensorsValueFilters.',\"reversed\":'.$reversedFilter;
									$customSensorsValueFilters = $customSensorsValueFilters.',\"expresion\":null,\"componentOverride\":null}';
							}
							
							if($SensorTypeGatewayPkid  == null){								
								$this->sensortypemsg($macAddress, $id, $typeSensorName, $sensorFormatString, $sensorNames,$customSensorsDecodeFormat,$customSensorsValueFilters,$nameofthesensorType);
								sleep(10);
							}
						}
					}
							
					$sensorTypeObjupdated = $em
					->getRepository('AppBundle:SensorTypeInfo')
					->findOneBy(array('id' => $typeSensor));
					$SensorTypeGatewayPkid= $em 
						->getRepository('AppBundle:SensorTypeGatewayPkid')
						->findOneBy(array('sensorTypeId' => $typeSensor,'macNumber' => $macAddress));
					//$em->refresh($sensorTypeObjupdated);	
					$sensorServerObj= $em
					->getRepository('AppBundle:SensorServerDetail')
					->findBy(array('sensorId' => $value));
					
					$serverIds  = [];
					foreach ($sensorServerObj   as $value){ 
						array_push($serverIds,$value->getServerId());
					}
					
						$ServerGatewayPkids= $em 
						->getRepository('AppBundle:ServerGatewayPkid')
						->findBy(array('serverId' => $serverIds,'macNumber' => $macAddress));
						$serverPkIdarr  = [];
						foreach ($ServerGatewayPkids   as $ServerGatewayPkid){ 
							array_push($serverPkIdarr,$ServerGatewayPkid->getServerId());
						}
						
						$serverPkIds = implode(",",$serverPkIdarr);
					
					
					$SensorGatewayPkid= $em 
						->getRepository('AppBundle:SensorGatewayPkid')
						->findOneBy(array('sensorId' => $value,'macNumber' => $macAddress));
						
					$id = $sensorInfo->getId();	
					$typeSensorName = $sensorTypeObjupdated->getSensorType();
					$description = $sensorInfo->getDescription();
					$sensorUniqueId = $sensorInfo->getSensorUniqueId();			
					$componentName = $sensorInfo->getName();					
					$latitude = $sensorInfo->getLatitude();
					$longitude = $sensorInfo->getLongitude();
					$deviceEUI = $sensorInfo->getDeviceEUI();
					$appEUI = $sensorInfo->getAppEUI();
					$appKEY = $sensorInfo->getAppKEY();
					$hashSensorName="";
					$countSensorName="";
				
					if($typeSensorName !=  "wifi" && $typeSensorName !=  "ibox"  && $typeSensorName !=  "oemsensors")
					{
						$em->refresh($SensorTypeGatewayPkid);
							$customSensor=$SensorTypeGatewayPkid->getPkId();
						//for ($i=0; $i <= 10; $i++) {	
						//$customSensor=$sensorTypeObjupdated->getSensorTypeUniqueId();
						//if($customSensor != null) {
						//	break;
						///}
						//sleep(2);
						///}

					}
					else{
						$customSensor="";
					}
					if($SensorGatewayPkid != null){
						$pkId = $SensorGatewayPkid->getPkId();
						if(!$pkId)
						{
							$this->sensormsg($macAddress, $ApplicationNameId, $id,  $typeSensorName, $componentName, $deviceEUI, $serverIds, $hashSensorName, $countSensorName, $customSensor,$serverPkIds);
						
							$this->sensormsgchirpstack($macAddress, $ApplicationNameId ,$id, $componentName, $deviceEUI, $description);
							sleep(5);
							$this->sensormsgchirpstackkey($macAddress,$ApplicationNameId , $id, $componentName, $appKEY, $deviceEUI);
						}
					}
					else{
						$this->sensormsg($macAddress,$ApplicationNameId, $id,  $typeSensorName, $componentName, $deviceEUI, $serverIds, $hashSensorName, $countSensorName, $customSensor,$serverPkIds);
				
						$this->sensormsgchirpstack($macAddress,$ApplicationNameId, $id, $componentName, $deviceEUI, $description);
						sleep(5);
						$this->sensormsgchirpstackkey($macAddress,$ApplicationNameId, $id, $componentName, $appKEY, $deviceEUI);
					}
				}

			}
			if($sensorsId != "")
			{
				$gateway->setSensorsId($sensorsId);
			}
			else
				$gateway->setSensorsId("");
			
			
			$gateway->setUpdatedDt(new \DateTime());
			
			$em->persist($gateway);
			
			$em->flush();
			$gatewayId = $gateway->getId();
			
			if( $gatewayId != "")
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'Gateway sensor has been successfully updated!!'));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating Gateway sensor details!!'));
			}
		}
			else
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating Gateway Detail No Record found with this Id'));
		}
	}
	public function servermsg($gatewaymac, $requestId, $type, $serverName, $url, $provider, $identityKey){
			$currentdatetime = new  \DateTime();
			$topic = $gatewaymac.'/gateway_requests/request';			
			$url= rtrim($url);
			$provider= trim($provider);
			$identityKey= trim($identityKey);
			$serverName= trim($serverName);
			
			$path = "/servers";
			$method = "POST";
			$port = 4999;
			$timestamp = $currentdatetime->format('c'); //"2019-12-08T16:00:02.2805625Z";			
			//$body ='{';			
			$body = '{\"serverName\":\"'.$serverName.'\"';
			$body = $body.',\"url\":\"'.$url.'\"';
			$body = $body.',\"provider\":\"'.$provider.'\"';
			$body = $body.',\"identityKey\":\"'.$identityKey.'\"';
			$body = $body.',\"type\":'.$type;
			$body = $body.'}';
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';			
			$msg = $msg.',"authentication" : true';
			$msg = $msg.',"body":"'.$body.'"';
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$requestId.'"';			
			$msg = $msg.'}';
			//print_r($msg);
		$this->publish($topic, $msg);
	}
	public function servermsgdelete($gatewaymac, $requestId, $pkId){
			$currentdatetime = new  \DateTime();			
			$topic =  $gatewaymac.'/gateway_requests/request';
			$path = "/servers/".$pkId;
			$method = "DELETE";
			$port = 4999;
			$timestamp = $currentdatetime->format('c');//"2019-12-08T16:00:02.2805625Z";			
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';
			$msg = $msg.',"authentication" : true';
			$msg = $msg.',"body":""';
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$requestId.'"';			
			$msg = $msg.'}';
			
			if($pkId != null)
			$this->publish($topic, $msg);
	}
	public function sensormsg($gatewaymac, $ApplicationNameId, $id,  $typeSensorName, $componentName, $deviceEUI, $serverIds, $hashSensorName, $countSensorName, $customSensor,$serverPkIds){
			$currentdatetime = new  \DateTime();
			if($typeSensorName!= "wifi" && $typeSensorName!= "ibox"  && $typeSensorName !=  "oemsensors")
			{
				$typeSensorName = 'customsensordevices';
		}	
			
			$applicationName = "app";		
			//$componentName = $name;
			$loraAddress = $deviceEUI;
			//$location = "42";//$latitude;
			$serverIds = $serverPkIds;//1;
			$hashSensorName = "S02";
			$countSensorName = "S01";			
			$customSensor = $customSensor;		
			$topic = $gatewaymac.'/gateway_requests/request';
			$path = "/".$typeSensorName;
			$method = "POST";
			$port = 4999;
			$timestamp = $currentdatetime->format('c'); 
			$requestId = $id;
			$body ='{';
			if($typeSensorName == 'wifi'){
			$body = $body.'\"applicationName\":\"'.$applicationName.'\"';	
			$body = $body.',\"hashSensorName\":\"'.$hashSensorName.'\"';
			$body = $body.',\"countSensorName\":\"'.$countSensorName.'\"';
			$body = $body.',\"componentName\":\"'.$componentName.'\"';
			}
			if($typeSensorName == 'ibox'){
			$body = $body.'\"applicationName\":\"'.$applicationName.'\"';	
			$body = $body.',\"hashSensorName\":\"'.$hashSensorName.'\"';
			$body = $body.',\"countSensorName\":\"'.$countSensorName.'\"';
			$body = $body.',\"componentName\":\"'.$componentName.'\"';
			}
			if($typeSensorName != 'wifi' && $typeSensorName != 'ibox'){
			$body = $body.'\"componentName\":\"'.$componentName.'\"';			
			}
			//$body = $body.',\"sentiloComponentType\":\"'.$sentiloComponentType.'\"';			
			$body = $body.',\"loraAddress\":\"'.$loraAddress.'\"';
			$body = $body.',\"serverIds\":['.$serverIds.']';
			if($typeSensorName != 'wifi' && $typeSensorName != 'ibox'){			
			//$body = $body.',\"customSensor\":'.$customSensor;		
			$body = $body.',\"sensorTypeId\":'.$customSensor;
			}
			//$body = $body.',\"location\":\"'.$location.'\"';
			//$body = $body.',\"publicAccess\":\"'.$publicAccess.'\"';
			
			
			
			$body = $body.'}';
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';			
			$msg = $msg.',"authentication" : true';
			$msg = $msg.',"body":"'.$body.'"';
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$requestId.'"';			
			$msg = $msg.'}';
			//print_r($msg);

			$this->publish($topic, $msg);
	}
	public function sensormsgchirpstack($gatewaymac, $ApplicationNameId ,$id, $componentName, $deviceEUI, $description){
			$currentdatetime = new  \DateTime();			
			$applicationID = $ApplicationNameId;		
			$name = $componentName;
			$devEUI = $deviceEUI;
			$referenceAltitude = 0;
			$skipFCntCheck = "false";
			$deviceProfileID = "70298761-1bf9-4a6c-bda1-69a0eb04aaaf";						
			$topic = $gatewaymac.'/gateway_requests/request';
			$path = "/api/devices";
			$method = "POST";
			$port = 8080;
			$timestamp = $currentdatetime->format('c'); 
			$requestId = $id;
			$body ='{\"device\":{';
			
			$body = $body.'\"applicationID\":\"'.$applicationID.'\"';	
			$body = $body.',\"description\":\"'.$description.'\"';
			$body = $body.',\"devEUI\":\"'.$devEUI.'\"';			
			$body = $body.',\"deviceProfileID\":\"'.$deviceProfileID.'\"';			
			$body = $body.',\"name\":\"'.$name.'\"';
			$body = $body.',\"referenceAltitude\":'.$referenceAltitude;
			$body = $body.',\"skipFCntCheck\":'.$skipFCntCheck;
			$body = $body.',\"tags\":{}';
			$body = $body.',\"variables\":{}';			
			
			$body = $body.'}}';
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';			
			$msg = $msg.',"authentication" : true';
			$msg = $msg.',"body":"'.$body.'"';
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$requestId.'"';			
			$msg = $msg.'}';
			//print_r($msg);

			$this->publish($topic, $msg);
	}
	public function sensormsgchirpstackkey($macAddress,$ApplicationNameId, $id, $componentName, $appKEY, $deviceEUI){
			$currentdatetime = new  \DateTime();									
			$topic = $macAddress.'/gateway_requests/request';
			$path = "/api/devices/".$deviceEUI."/keys";
			$method = "POST";
			$port = 8080;
			$timestamp = $currentdatetime->format('c'); 
			$requestId = $id;
			$body ='{\"deviceKeys\":{';
			
			$body = $body.'\"nwkKey\":\"'.$appKEY.'\"';			
			$body = $body.'}}';
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';			
			$msg = $msg.',"authentication" : true';
			$msg = $msg.',"body":"'.$body.'"';
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$requestId.'"';			
			$msg = $msg.'}';
			//print_r($msg);

			$this->publish($topic, $msg);
	}
	public function sensormsgdelete($gatewaymac, $id, $typeSensorName,$sensorUniqueId){
			$currentdatetime = new  \DateTime();
			if($typeSensorName!= "wifi" && $typeSensorName!= "ibox"  && $typeSensorName !=  "oemsensors")
			{
				$typeSensorName = 'customsensordevices';
			}
			$topic =  $gatewaymac.'/gateway_requests/request';
			$path = "/".$typeSensorName."/".$sensorUniqueId;
			$method = "DELETE";
			$port = 4999;
			$timestamp = $currentdatetime->format('c');//"2019-12-08T16:00:02.2805625Z";
			$requestId = $id;
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';
			$msg = $msg.',"authentication" : true';
			$msg = $msg.',"body":""';
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$requestId.'"';			
			$msg = $msg.'}';
			

			$this->publish($topic, $msg);
	}
	public function sensormsgdeleteFromChirpstack($gatewaymac, $id, $deviceEUI){
		$currentdatetime = new  \DateTime();
			
			$topic =  $gatewaymac.'/gateway_requests/request';
			$path = "/api/devices/".$deviceEUI;
			$method = "DELETE";
			$port = 8080;
			$timestamp = $currentdatetime->format('c');//"2019-12-08T16:00:02.2805625Z";
			$requestId = $id;
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';
			$msg = $msg.',"authentication" : true';			
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$requestId.'"';			
			$msg = $msg.'}';
			

			$this->publish($topic, $msg);
	}
	public function sensortypemsg($macAddress, $id, $typeSensorName, $sensorFormatString, $sensorNames,$customSensorsDecodeFormat,$customSensorsValueFilters,$nameofthesensorType){
		
				
				$currentdatetime = new  \DateTime();
					$configurationName = $nameofthesensorType;
					
					$sensorFormatString = $sensorFormatString;			
			$applicationName = "app";
			$sensorNames = $sensorNames;			
			$topic = $macAddress.'/gateway_requests/request';
			$path = "/customsensors";
			$method = "POST";
			$port = 4999;
			$timestamp = $currentdatetime->format('c'); //"2019-12-08T16:00:02.2805625Z";
			$requestId = "123456790";
			$body = '{';			
			$body = $body.'\"configurationName\":\"'.$configurationName.'\"';
			$body = $body.',\"customSensorsDecodeFormat\":['.$customSensorsDecodeFormat.']';
			$body = $body.',\"customSensorsValueFilters\":['.$customSensorsValueFilters.']';
			//$body = $body.',\"sensorFormatString\":\"'.$sensorFormatString.'\"';
			$body = $body.',\"applicationName\":\"'.$applicationName.'\"';
			//$body = $body.',\"sensorNames\":['.$sensorNames.']';			
			$body = $body.'}';
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';			
			$msg = $msg.',"authentication" : true';
			$msg = $msg.',"body":"'.$body.'"';
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$id.'"';				
			$msg = $msg.'}';
			//print_r($msg);

			$this->publish($topic, $msg);
	}
	public function GetApplicationId($gatewaymac){
		$currentdatetime = new  \DateTime();
			
			$topic =  $gatewaymac.'/gateway_requests/request';
			$path = "/api/applications?limit=10";
			$method = "GET";
			$port = 8080;
			$timestamp = $currentdatetime->format('c');//"2019-12-08T16:00:02.2805625Z";
			$requestId = 123456790;
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';
			$msg = $msg.',"body" : ""';	
			$msg = $msg.',"authentication" : true';			
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$requestId.'"';			
			$msg = $msg.'}';
			

			$this->publish($topic, $msg);
	}
	
	public function GetProfileId($gatewaymac){
		$currentdatetime = new  \DateTime();
			
			$topic =  $gatewaymac.'/gateway_requests/request';
			$path = "/api/device-profiles?limit=10";
			$method = "GET";
			$port = 8080;
			$timestamp = $currentdatetime->format('c');//"2019-12-08T16:00:02.2805625Z";
			$requestId = 123456790;
			$msg = '{';
			$msg = $msg.'"path":"'.$path.'"';
			$msg = $msg.',"method":"'.$method.'"';
			$msg = $msg.',"body" : ""';	
			$msg = $msg.',"authentication" : true';			
			$msg = $msg.',"port":'.$port;
			$msg = $msg.',"timestamp":"'.$timestamp.'"';
			$msg = $msg.',"requestId":"'.$requestId.'"';			
			$msg = $msg.'}';
			

			$this->publish($topic, $msg);
	}
	public function publish($topic, $msg)
	{
		$str = "./mosquitto_pub -h gesinen.es -p 1882 -u 'gesinen'  -P 'gesinen2110'  -t '".$topic."' -m '".$msg."'";
		
		$process = new Process($str);
		$process->run();

		// executes after the command finishes
		if (!$process->isSuccessful()) {
			throw new ProcessFailedException($process);
		}
	}
}

?>