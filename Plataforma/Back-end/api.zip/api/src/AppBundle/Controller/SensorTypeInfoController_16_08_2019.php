<?php

namespace AppBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use AppBundle\Entity\SensorTypeInfo;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Normalizer\GetSetMethodNormalizer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Normalizer\DateTimeNormalizer;


/**
 * SensorTypeInfo controller.
 *
 * @Route("/sensortype")
 */
class SensorTypeInfoController extends Controller
{
	
	/**
     * List
     *                                                                                 
	 * @Route("/list", name="sensortype_list")
	 */
	public function SensorTypeInfoListApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();

		$sensorTypeInfoList= $em 
			->getRepository('AppBundle:SensorTypeInfo')
			->findAll();
		
		$json = '';
		//var_dump($user);
		
		 if($sensorTypeInfoList != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($sensorTypeInfoList, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','sensortypeinfo_details' => $json));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','sensortypeinfo_details' => $json));
			//return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in sensor type info data'));
	}
	
	/**
     * Get SensorTypeInfo by Id
     *                                                                                 
	 * @Route("/getsensortypeinfobyid", name="sensortypeinfo_getsensortypeinfobyid")
	 */
	public function getSensorTypeInfobyidApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$sensorTypeInfoId = $data->id;
		
		$sensorTypeInfo= $em 
			->getRepository('AppBundle:SensorTypeInfo')
			->findBy(array('id' => $sensorTypeInfoId));
		
		if( $sensorTypeInfo != null)
		{
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new GetSetMethodNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($sensorTypeInfo, 'json');
			
			return new JsonResponse(array('status' => 'Success','sensortypeinfo_details' => $json));
		}
		else{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in getting sensor type info details!!'));
		} 
		
	}
	
	/**
     * Delete a Sensor Info
     *                                                                                 
	 * @Route("/deletesensortypeinfo", name="sensortypeinfo_deletesensortypeinfo")
	 */
	public function deleteSensorTypeInfoApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());		
		$sensorTypeInfoId = $data->id;	
		$sensorTypeInfo= $em 
			->getRepository('AppBundle:SensorTypeInfo')
			->findOneBy(array('id' => $sensorTypeInfoId));
		if($sensorTypeInfo != null)
		{
			$em->remove($sensorTypeInfo);
            $em->flush();	
		return new JsonResponse(array('status' => 'SUCCESS','message' => 'sensor type info has been successfully removed!!'));
		}
		else{
			return new JsonResponse(array('status' => 'Failed','message' => 'No sensor type info is Present with this Id!!'));
		}
	}
	
	/**
     * Create New SensorTypeInfo
     *                                                                                 
	 * @Route("/newsensortypeinfo", name="sensortypeinfo_newsensortypeinfo")
	 */
	public function newSensorTypeInfoApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		// var_dump($data);
		
		$sensorTypeUniqueId = $data->sensorTypeUniqueId;		
		$name = $data->name;
		$description = $data->description;
		$supplier = $data->supplier;		
				
		
		$sensorTypeInfoObj= $em 
			->getRepository('AppBundle:SensorTypeInfo')
			->findBy(array('sensorTypeUniqueId' => $sensorTypeUniqueId,'name' => $name,'supplier' => $supplier));
			
			
		if($sensorTypeInfoObj != null)
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Requested sensor type info is already exists!!'));
		}
		else{
			
			$sensorTypeInfo = new SensorTypeInfo();
			$sensorTypeInfo->setSensorTypeUniqueId($sensorTypeUniqueId);
			$sensorTypeInfo->setName($name);
			$sensorTypeInfo->setDescription($description);
			$sensorTypeInfo->setSupplier($supplier);
						
			$em->persist($sensorTypeInfo);
			$em->flush();
			$Id = $sensorTypeInfo->getId();
			
			if( $Id != '')
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'sensor info has been successfully created!!','id' => $Id));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in registering sensor info registeration!!'));
			} 
		}
		
	}
	
	/**
     * Update a Sensor Type Info
     *                                                                                 
	 * @Route("/updatesensortypeinfo", name="sensortypeinfo_updatesensortypeinfo")
	 */
	public function updateSensorTypeInfoApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$sensorTypeInfoId = $data->id;
		$sensorTypeUniqueId = $data->sensorTypeUniqueId;		
		$name = $data->name;
		$description = $data->description;
		$supplier = $data->supplier;	
		
		$sensorTypeInfo= $em 
			->getRepository('AppBundle:SensorTypeInfo')
			->findOneBy(array('id' => $sensorTypeInfoId));
			
		if($sensorTypeInfo !=null)
		{
			if($sensorTypeUniqueId != "" )
			$sensorTypeInfo->setSensorTypeUniqueId($sensorTypeUniqueId);
			
			if($name != "" )
			$sensorTypeInfo->setName($name);
		
			if($description != "" )
			$sensorTypeInfo->setDescription($description);
		
			if($supplier != "" )
			$sensorTypeInfo->setSupplier($supplier);
			
			$sensorTypeInfo->setUpdatedDt(new \DateTime());
			
			$em->persist($sensorTypeInfo);
			$em->flush();
			$sensorTypeInfoId = $sensorTypeInfo->getId();
			
			if( $sensorTypeInfoId != "")
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'sensor type info has been successfully updated!!'));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating sensor type info details!!'));
			}
		}
		else
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating sensor type info Detail No Record found with this Id'));
		}
		
	}
}

?>