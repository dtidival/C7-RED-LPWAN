<?php

namespace AppBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use AppBundle\Entity\SensorServerDetail;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Normalizer\GetSetMethodNormalizer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Normalizer\DateTimeNormalizer;


/**
 * SensorServerDetail controller.
 *
 * @Route("/sensorserverdetail")
 */
class SensorServerDetailController extends Controller
{
	
	/**
     * List
     *                                                                                 
	 * @Route("/list", name="sensorserverdetail_list")
	 */
	public function SensorServerDetailListApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();

		$sensorServerDetailList= $em 
			->getRepository('AppBundle:SensorServerDetail')
			->findAll();
		
		$json = '';
		//var_dump($user);
		
		 if($sensorServerDetailList != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($sensorServerDetailList, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','sensorserver_details' => $json));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','sensorserver_details' => $json));
			//return new Response($json);
		}
		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in sensorserver data'));
	}
	
	/**
     * Get SensorServer by Id
     *                                                                                 
	 * @Route("/getbyid", name="sensorserverdetail_getbyid")
	 */
	public function getSensorServerDetailByIdApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$sensorServerDetailId = $data->id;
		
		$sensorServerDetail= $em 
			->getRepository('AppBundle:SensorServerDetail')
			->findBy(array('id' => $sensorServerDetailId));
		
		if( $sensorServerDetail != null)
		{
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new GetSetMethodNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($sensorServerDetail, 'json');
			
			return new JsonResponse(array('status' => 'Success','sensorserver_details' => $json));
		}
		else{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in getting sensorServerDetail details!!'));
		} 
		
	}
	
	/**
     * Delete 
     *                                                                                 
	 * @Route("/delete", name="sensorserverdetail_delete")
	 */
	public function deleteSensorServerDetailApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());		
		$sensorServerDetailId = $data->id;	
		$sensorServerDetail= $em 
			->getRepository('AppBundle:SensorServerDetail')
			->findOneBy(array('id' => $sensorServerDetailId));
		if($sensorServerDetail != null)
		{
			$em->remove($sensorServerDetail);
            $em->flush();	
		return new JsonResponse(array('status' => 'SUCCESS','message' => 'SensorServerDetail has been successfully removed!!'));
		}
		else{
			return new JsonResponse(array('status' => 'Failed','message' => 'No SensorServerDetail is Present with this Id!!'));
		}
	}
	
	/**
     * Create New SensorServerDetail
     *                                                                                 
	 * @Route("/new", name="sensorserverdetail_new")
	 */
	public function newSensorServerDetailApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		// var_dump($data);
		
		$serverId = $data->serverId;		
		$sensorId = $data->sensorId;
		$sensorName = $data->sensorName;
		$varnames = implode(",",$data->varnames);				
		
		$sensorServerDetail = new SensorServerDetail();
		$sensorServerDetail->setServerId($serverId);
		$sensorServerDetail->setSensorId($sensorId);
		$sensorServerDetail->setSensorName($sensorName);
		$sensorServerDetail->setVarnames($varnames);
		
		$em->persist($sensorServerDetail);
		$em->flush();
		$Id = $sensorServerDetail->getId();
		
		if( $Id != '')
		{
			return new JsonResponse(array('status' => 'SUCCESS','message' => 'Sensor Server Detail has been successfully created!!','id' => $Id));
		}
		else{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in registering Sensor Server Detail registeration!!'));
		} 
	}
	
	
	/**
     * Update a SensorServerDetail
     *                                                                                 
	 * @Route("/update", name="sensorserverdetail_update")
	 */
	public function updateSensorServerDetailApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$sensorserversetailId = $data->id;
		$serverId = $data->serverId;		
		$sensorId = $data->sensorId;
		$sensorName = $data->sensorName;
		$varnames = implode(",",$data->varnames);	
		
		$sensorserversetail= $em 
			->getRepository('AppBundle:SensorServerDetail')
			->findOneBy(array('id' => $sensorserversetailId));
			
		if($sensorserversetail !=null)
		{
		
			if($serverId != "")
			{
				$sensorserversetail->setServerId($serverId);
			}
			if($sensorId != "")
			{
				$sensorserversetail->setSensorId($sensorId);
			}
			if($sensorName != "")
			{
				$sensorserversetail->setSensorName($sensorName);
			}
			
			if($varnames != "")
			{
				$sensorserversetail->setVarnames($varnames);
			}
			
			
			$sensorserversetail->setUpdatedDt(new \DateTime());
			
			$em->persist($sensorserversetail);
			$em->flush();
			$sensorserversetailId = $sensorserversetail->getId();
			
			if( $sensorserversetailId != "")
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'sensorserversetail has been successfully updated!!'));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating sensorserversetail details!!'));
			}
		}
		else
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating sensorserversetail Detail No Record found with this Id'));
		}
		
	}
		
	
}