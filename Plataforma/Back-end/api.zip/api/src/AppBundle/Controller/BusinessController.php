<?php

namespace AppBundle\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use AppBundle\Entity\Business;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Normalizer\GetSetMethodNormalizer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Normalizer\DateTimeNormalizer;


/**
 * Business controller.
 *
 * @Route("/business")
 */
class BusinessController extends Controller
{
	
	/**
     * List
     *                                                                                 
	 * @Route("/list", name="business_list")
	 */
	public function BusinessListApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());
		$userId = $data->userId;
		$businessId = $data->businessId;
		$permission = $data->permission;
		if($permission == 1){
			$businessList= $em 
			->getRepository('AppBundle:Business')
			->findAll();	
		}
		else if($permission == 2){
			if($businessId != null){
				$businessList= $em 
			->getRepository('AppBundle:Business')
			->findBy(array('id'=>$businessId));
			}
			else
			{
				$businessList = null;
			}
		}
		else{
			return new JsonResponse(array('status' => 'success','message' => 'No Response for normal User'));
		}
		//$businessList= $em 
		//	->getRepository('AppBundle:Business')
		//	->findAll();
		
		$json = '';
		//var_dump($user);
		
		 if($businessList != null)
		 {	
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new ObjectNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($businessList, 'json');
		 }	
		
		if ($request->isXMLHttpRequest()) {         
			return new JsonResponse(array('message' => 'this is a json response','details' => $json));
		}
		else{
			return new JsonResponse(array('message' => 'this is a json response','details' => $json));
			//return new Response($json);
		}

		return new JsonResponse(array('status' => 'FAILED','message' => 'Getting issue in Business data'));
	}
	/**
     * Get Business by Id
     *                                                                                 
	 * @Route("/getbusinessbyid", name="business_getbusinessbyid")
	 */
	public function getBusinessByIdApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$businessId = $data->id;
		
		$business= $em 
			->getRepository('AppBundle:Business')
			->findBy(array('id' => $businessId));
		
		if( $business != null)
		{
			$serializer = new Serializer(array(new DateTimeNormalizer('g:h:s A'),new GetSetMethodNormalizer()), array('json' => new 
			JsonEncoder()));
			$json = $serializer->serialize($business, 'json');
			
			return new JsonResponse(array('status' => 'Success','details' => $json));
		}
		else{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in getting business details!!'));
		} 
		
	}
	/**
     * Delete a Business
     *                                                                                 
	 * @Route("/deletebusiness", name="business_deletebusiness")
	 */
	public function deleteBusinessApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		$data = json_decode($request->getContent());		
		$businessId = $data->id;	
		$business= $em 
			->getRepository('AppBundle:Business')
			->findOneBy(array('id' => $businessId));
		if($business != null)
		{
			$em->remove($business);
            $em->flush();	
		return new JsonResponse(array('status' => 'SUCCESS','message' => 'Business has been successfully removed!!'));
		}
		else{
			return new JsonResponse(array('status' => 'Failed','message' => 'No Business is Present with this Id!!'));
		}
	}
	
	/**
     * Create New Business
     *                                                                                 
	 * @Route("/newBusiness", name="business_newbusiness")
	 */
	public function newBusinessApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());
		// var_dump($data);
		
		$name = $data->name;		
		$address = $data->address;
		$country = $data->country;
		$state = $data->state;
		$city = $data->city;
		$postalCode = $data->postalCode;
		$contactPerson = $data->contactPerson;
		$email = $data->email;
		$telephone = $data->telephone;
		$web = $data->web;
				
		
		$businessObj= $em 
			->getRepository('AppBundle:Business')
			->findBy(array('name' => $name));
			
			
		if($businessObj != null)
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Requested Business is already exists!!'));
		}
		else{
			
			$business = new Business();
			$business->setName($name);
			
			if($address != "")
			$business->setAddress($address);
		
			if($country != "")
			$business->setCountry($country);
		
			if($state != "")
			$business->setState($state);
		
			if($city != "")
			$business->setCity($city);
			
			if($postalCode != "")
			$business->setPostalCode($postalCode);
		
			if($contactPerson != "")
			$business->setContactPerson($contactPerson);
		
			if($email != "")
			$business->setEmail($email);
			
			if($telephone != "")
			$business->setTelephone($telephone);
		
			if($web != "")
			$business->setWeb($web);			
			
		
			$em->persist($business);
			$em->flush();
			$Id = $business->getId();
			
			if( $Id != '')
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'business has been successfully created!!','id' => $Id));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in registering business registeration!!'));
			} 
		}
		
	}
	
	/**
     * Update a Business
     *                                                                                 
	 * @Route("/updatebusiness", name="business_updatebusiness")
	 */
	public function updateBusinessApi(Request $request)    
	{
		$em = $this->getDoctrine()->getManager();
		
		$data = json_decode($request->getContent());		
		
		$businessId = $data->id;
		$name = $data->name;		
		$address = $data->address;
		$country = $data->country;
		$state = $data->state;
		$city = $data->city;
		$postalCode = $data->postalCode;
		$contactPerson = $data->contactPerson;
		$email = $data->email;
		$telephone = $data->telephone;
		$web = $data->web;	
		
		$business= $em 
			->getRepository('AppBundle:Business')
			->findOneBy(array('id' => $businessId));
			
		if($business !=null)
		{
		
			if($name != "")
			{
				$business->setName($name);
			}
			if($address != "")
			$business->setAddress($address);
		
			if($country != "")
			$business->setCountry($country);
		
			if($state != "")
			$business->setState($state);
		
			if($city != "")
			$business->setCity($city);
			
			if($postalCode != "")
			$business->setPostalCode($postalCode);
		
			if($contactPerson != "")
			$business->setContactPerson($contactPerson);
		
			if($email != "")
			$business->setEmail($email);
			
			if($telephone != "")
			$business->setTelephone($telephone);
		
			if($web != "")
			$business->setWeb($web);
			
			$business->setUpdatedDt(new \DateTime());
			
			$em->persist($business);
			$em->flush();
			$businessId = $business->getId();
			
			if( $businessId != "")
			{
				return new JsonResponse(array('status' => 'SUCCESS','message' => 'business has been successfully updated!!'));
			}
			else{
				return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating business details!!'));
			}
		}
		else
		{
			return new JsonResponse(array('status' => 'FAILED','message' => 'Error in updating business Detail No Record found with this Id'));
		}
		
	}
}
?>