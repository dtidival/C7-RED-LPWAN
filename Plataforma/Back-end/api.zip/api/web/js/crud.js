$( document ).ready(function() {
    
    //Inicializo tooltips bootstrap
    $(".tooltips").tooltip();
});

/**
*   Borra una entidad no sin antes pedir confirmación
*   @Param id
*/
function borrar(id){

    bootbox.confirm("Sure delete this record?",function(result){		
        if(result){
            //var deleteURL = "borrar/" + id;(previously this was true but now I(shesh 22-05-2018)have changed this due to routing issue)
			var deleteURL = id;			
            $.ajax({url:deleteURL,type:'DELETE',
                success: function() {
                    window.location.reload(true);
                 },
                error: function(){
                        bootbox.alert("Error when trying to delete the record.");
                }

            });
        }
    });
}
