	google.charts.load('current', {'packages':['corechart']});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {

      var data =  google.visualization.arrayToDataTable([
        ['TimeDevision', 'Hours per Day'],
        ['Franja Supervalle(1am to 7am)',6],
		['Franja Valle(7am to 1pm)', 6],
		['Franja punta (1pm to 11pm)', 10],
		['Franja Valle(11pm to 1am)', 2]		       
        
		
        ]);

      var options = {        
		width: 700,
		is3D: true,
		//pieSliceText: 'label',
		height: 400,		
		legend:{position:'left'},
		slices: {
            0: { color: 'green' },
            1: { color: 'lightblue' },			
			2: { color: 'red' },
			3: { color: 'lightblue' }
          }
      };

      var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
      chart.draw(data, options);
    }