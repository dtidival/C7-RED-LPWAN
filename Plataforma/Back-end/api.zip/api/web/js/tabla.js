/*
*   Inicializa tablas DataTables que tengan nombre table-*
*   Se agregarán los campos para filtrar en una de las filas del header que contenga el id "filtrosTabla".
*   El tipo de filtro es establecido por el selector usado en la clase de cada <th>; ej:
*   <th class="string></th> ====> Corresponde a un filtro de texto
*   <th class="date"></th> ====> Corresponde a un filtro de fecha
*   hay un plugin de JQuery  para hacer esto, habría que integrarlo con este script.(https://code.google.com/p/jquery-datatables-column-filter/)
*/

$( document ).ready(function() {
    $("[id^=table]").each(function(lista,tabla){
        initTabla(tabla.id);   
    })
});

function initTabla(selectorTabla,config){

                                 //tablaObars = dt_datatable($("#table-obras"));
                                 //tablaObars.DataTable();

    tableOptions = {
        "aoColumnDefs" : [{  // define columns sorting options(by default all columns are sortable extept the first checkbox column)
            'bSortable' : false
//            'aTargets' : [ 4 ]
        }],
        "bAutoWidth": false,   // disable fixed width and enable fluid table
        "bSortCellsTop": true, // make sortable only the first row in thead
        //"sPaginationType": "bootstrap_extended", // pagination type(bootstrap, bootstrap_full_number or bootstrap_extended)
        //"sPaginationType": "bootstrap_full_number", // pagination type(bootstrap, bootstrap_full_number or bootstrap_extended)
   //   "sDom" : "<'row'<'col-md-8 col-sm-12'pli><'col-md-4 col-sm-12'<'table-group-actions pull-right'>>r><'table-scrollable't><'row'<'col-md-8 col-sm-12'pli><'col-md-4 col-sm-12'>r>>", // datatable layout
        //"dom": '<"top"fl>rt<"bottom"ip><"clear">',
        "oLanguage": {  // language settings
            "sProcessing": '<img src="theme/img/loading-spinner-grey.gif"/><span>&nbsp;&nbsp;Cargando...</span>',
            "sLengthMenu": "View _MENU_ row",
            "sInfo": "Found total _TOTAL_ rows.",
            "sSearch": "Search",
            "sInfoEmpty": "There are no records to display.",
            "sGroupActions": "_TOTAL_ registros seleccionados:  ",
            "sAjaxRequestGeneralError": "Could not complete request. Please check your internet connection",
            "sEmptyTable":  "There is no data available in the table.",
            "sZeroRecords": "We found no records that match filters.",
            "sInfoFiltered": "(The total of _MAX_ rows)",
            "oPaginate": {
                "sPrevious": "Prev",
                "sNext": "Next",
                "sPage": "P&aacute;gina",
                "sPageOf": "de"
            }
        },
        "aLengthMenu": [
            [10,15,20,50],
            [10,15,20,50] 
        ],
        "iDisplayLength": 10, 
        "aaSorting": [[ 0, "asc"]],
        "bFilter" : true,
        "initComplete": function(){
                            var api = this.api();
                            var idTabla = this.selector.replace("#","");
                            initFiltrosTabla(api,idTabla)
                            }
    };
    //Override de las opciones
    if(undefined === config){
        opciones = tableOptions;
    }else{
        opciones = $.extend( true, tableOptions, config );
    }

    tabla = $("#"+selectorTabla).dataTable(tableOptions);
}

/**
*   Inicializa los filtros por columna de la tabla de obras
*/
function initFiltrosTabla(api,idTabla){

 
   api.columns().indexes().flatten().each( function ( i ) {
   
        var column = api.column( i );
        var headerFiltro = $("#filtrosTabla th")[i];
        var filtro;

        var clasesFiltro_ = headerFiltro.getAttribute("class");
        var textoFiltro = headerFiltro.innerText;
        headerFiltro.innerText = "";

        if(null != clasesFiltro_)
            var clasesFiltro = clasesFiltro_.split(" ");
        else
            return true;
        //Filtro tipo comboBox para columna i
        //if(filtros[i] == 'select'){
        if(clasesFiltro.indexOf('select') != -1){
             filtro = $('<select class="form-control form-filter input-sm select2" style="width:100%;"><option value="">Todas</option></select>');
             column.data().unique().sort().each( function ( d, j ) {
                             filtro.append( "<option value='"+d+"'>"+d+"</option>" )
             });
             filtro.appendTo( headerFiltro ).on( 'change', function () {
                             valRaw = $(this).val();
                             //Si la celda tiene un span con estilo el valor está dentro del mismo
                             if(valRaw.indexOf("span") >= 0){
                                   var val = $(valRaw).text();
                             }else{
                                   var val = valRaw;
                             }
                             column.search( val , true, false ).draw();
             } );
         //Filtro tipo texto plano para columna i
         //}else if(filtros[i] == 'text'){ 
         }else if(clasesFiltro.indexOf('string') != -1){ 
             filtro = $('<input class="form-control form-filter input-sm" style="width:100%;" type="text" placeholder="'+textoFiltro+'" />');
             filtro.appendTo( headerFiltro ).on( 'change', function () {
                             val = $(this).val();
                             column.search( val , true, false ).draw();
             } );
         //Filtro rango de fechas para columna i
         //}else if(filtros[i] == 'fecha'){
         }else if(clasesFiltro.indexOf('datetime') != -1 || clasesFiltro.indexOf('date') != -1 ){
             //https://datatables.net/examples/plug-ins/range_filtering.html 
             var idDde = idTabla+'-col-'+i+'dde';
             var idHta = idTabla+'-col-'+i+'hta';
             filtro_dde = $('<input  id="'+idDde+'" class="form-control form-filter input-sm" style="width:100%;" type="text" />');
             filtro_hta = $('<input  id="'+idHta+'" class="form-control form-filter input-sm" style="width:100%;margin-top:5px;" type="text" />');
             //filtro_dde.datepicker({"format":"yyyy-mm-dd",  language: "es", autoclose: true,disableTouchKeyboard: true, clearBtn: true});
             //filtro_hta.datepicker({"format":"yyyy-mm-dd",  language: "es", autoclose: true,disableTouchKeyboard: true, clearBtn: true});
             filtro_dde.datetimepicker({locale:"es", format: "YYYY/MM/DD HH:mm"/*format: "DD-MM-YYYY HH:mm"*/});
             filtro_hta.datetimepicker({locale:"es", format: "YYYY/MM/DD HH:mm"/*format: "DD-MM-YYYY HH:mm"*/});
             filtro_dde.appendTo( headerFiltro );
             filtro_hta.appendTo( headerFiltro );
            
             $.fn.dataTable.ext.search.push(function( settings, data, dataIndex ) {
                    //var min = new Date( $('#'+idDde).val() );
                    var minMoment = moment($('#'+idDde).val(),"YYYY/MM/DD HH:mm"/*"DD-MM-YYYY HH:mm"*/);
                    var maxMoment = moment($('#'+idHta).val(),"YYYY/MM/DD HH:mm"/*"DD-MM-YYYY HH:mm"*/);
                    var min,max;

                    if(minMoment.isValid())
                        min = minMoment.toDate(); //moment($('#'+idDde).val(),"DD-MM-YYYY HH:mm").toDate();
                    //var max = new Date( $('#'+idHta).val());
                    if(maxMoment.isValid())
                        max = maxMoment.toDate(); //moment($('#'+idHta).val(),"DD-MM-YYYY HH:mm").toDate();
                    //var fecha = new Date( data[i] ); // use data for the age column
                    var fecha = moment(data[i],"YYYY/MM/DD HH:mm"/*"DD-MM-YYYY HH:mm"*/).toDate();
             
                    //if ( ( isNaN( min.getDate() ) && isNaN( max.getDate() ) ) ||
                     //    ( isNaN( min.getDate() ) && fecha <= max ) ||
                    //     ( min <= fecha   && isNaN( max.getDate() ) ) ||
                    //     ( min <= fecha   && fecha <= max ) )
                    if ( ( isNaN( min ) && isNaN( max ) ) ||
                         ( isNaN( min ) && fecha <= max ) ||
                         ( min <= fecha   && isNaN( max ) ) ||
                         ( min <= fecha   && fecha <= max ) )
                    {
                        return true;
                    }
                    return false;
            });  


             $('#'+idDde+', '+'#'+idHta).on('dp.change', function() {
                         api.draw();
             } );
         //Filtro rango de valores numericos  para columna i
         //}else if(filtros[i] == 'rango_numerico'){
         }else if(clasesFiltro.indexOf('integer') != -1){
             var idDde = idTabla+'-col-'+i+'dde';
             var idHta = idTabla+'-col-'+i+'hta';
             filtro_dde = $('<input  id="'+idDde+'" class="form-control form-filter input-sm" style="width:100%;" type="number" />');
             filtro_hta = $('<input  id="'+idHta+'" class="form-control form-filter input-sm" style="width:100%;" type="number" />');
             filtro_dde.appendTo( headerFiltro );
             filtro_hta.appendTo( headerFiltro );
            
             $.fn.dataTable.ext.search.push(function( settings, data, dataIndex ) {
                    var min = parseFloat( $('#'+idDde).val() );
                    var max = parseFloat( $('#'+idHta).val());
                    var valor = parseFloat( data[i] ); // use data for the age column
             
                    if ( ( isNaN( min ) && isNaN( max ) ) ||
                         ( isNaN( min ) && valor <= max ) ||
                         ( min <= valor   && isNaN( max ) ) ||
                         ( min <= valor   && valor <= max ) )
                    {
                        return true;
                    }
                    return false;
            });  


             $('#'+idDde+', '+'#'+idHta).change( function() {
                         api.draw();
             } );
         }
                 


   } ); 


}
