<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/business')) {
            // business_list
            if ($pathinfo === '/business/list') {
                return array (  '_controller' => 'AppBundle\\Controller\\BusinessController::BusinessListApi',  '_route' => 'business_list',);
            }

            // business_getbusinessbyid
            if ($pathinfo === '/business/getbusinessbyid') {
                return array (  '_controller' => 'AppBundle\\Controller\\BusinessController::getBusinessByIdApi',  '_route' => 'business_getbusinessbyid',);
            }

            // business_deletebusiness
            if ($pathinfo === '/business/deletebusiness') {
                return array (  '_controller' => 'AppBundle\\Controller\\BusinessController::deleteBusinessApi',  '_route' => 'business_deletebusiness',);
            }

            // business_newbusiness
            if ($pathinfo === '/business/newBusiness') {
                return array (  '_controller' => 'AppBundle\\Controller\\BusinessController::newBusinessApi',  '_route' => 'business_newbusiness',);
            }

            // business_updatebusiness
            if ($pathinfo === '/business/updatebusiness') {
                return array (  '_controller' => 'AppBundle\\Controller\\BusinessController::updateBusinessApi',  '_route' => 'business_updatebusiness',);
            }

        }

        if (0 === strpos($pathinfo, '/councils')) {
            // councils_list
            if ($pathinfo === '/councils/list') {
                return array (  '_controller' => 'AppBundle\\Controller\\CouncilsController::CouncilsListApi',  '_route' => 'councils_list',);
            }

            // council_getcouncilbyid
            if ($pathinfo === '/councils/getcouncilbyid') {
                return array (  '_controller' => 'AppBundle\\Controller\\CouncilsController::getCouncilByIdApi',  '_route' => 'council_getcouncilbyid',);
            }

            // council_deletecouncil
            if ($pathinfo === '/councils/deletecouncil') {
                return array (  '_controller' => 'AppBundle\\Controller\\CouncilsController::deleteCouncilApi',  '_route' => 'council_deletecouncil',);
            }

            // council_newcouncil
            if ($pathinfo === '/councils/newCouncil') {
                return array (  '_controller' => 'AppBundle\\Controller\\CouncilsController::newCouncilApi',  '_route' => 'council_newcouncil',);
            }

            // council_updatecouncil
            if ($pathinfo === '/councils/updatecouncil') {
                return array (  '_controller' => 'AppBundle\\Controller\\CouncilsController::updateCouncilApi',  '_route' => 'council_updatecouncil',);
            }

        }

        // swatgesinen
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'swatgesinen');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'swatgesinen',);
        }

        if (0 === strpos($pathinfo, '/g')) {
            if (0 === strpos($pathinfo, '/gateways')) {
                // gateways_list
                if ($pathinfo === '/gateways/list') {
                    return array (  '_controller' => 'AppBundle\\Controller\\GatewaysController::GatewaysListApi',  '_route' => 'gateways_list',);
                }

                // gateway_checkGatewayMac
                if ($pathinfo === '/gateways/checkGatewaymac') {
                    return array (  '_controller' => 'AppBundle\\Controller\\GatewaysController::checkGatewayMacApi',  '_route' => 'gateway_checkGatewayMac',);
                }

                // gateway_getgatewaybyid
                if ($pathinfo === '/gateways/getgatewaybyid') {
                    return array (  '_controller' => 'AppBundle\\Controller\\GatewaysController::getgatewaybyidApi',  '_route' => 'gateway_getgatewaybyid',);
                }

                // gateway_deletegateway
                if ($pathinfo === '/gateways/deletegateway') {
                    return array (  '_controller' => 'AppBundle\\Controller\\GatewaysController::deleteGatewayApi',  '_route' => 'gateway_deletegateway',);
                }

                // gateway_newgateway
                if ($pathinfo === '/gateways/newGateway') {
                    return array (  '_controller' => 'AppBundle\\Controller\\GatewaysController::newGatewayApi',  '_route' => 'gateway_newgateway',);
                }

                // gateway_updategateway
                if ($pathinfo === '/gateways/updategateway') {
                    return array (  '_controller' => 'AppBundle\\Controller\\GatewaysController::updategatewayApi',  '_route' => 'gateway_updategateway',);
                }

                if (0 === strpos($pathinfo, '/gateways/download')) {
                    // gateway_downloadFromGatewayPlatformToSensorType
                    if ($pathinfo === '/gateways/downloadFromGatewayPlatformToSensorType') {
                        return array (  '_controller' => 'AppBundle\\Controller\\GatewaysController::downloadFromGatewayPlatformToSensorTypeApi',  '_route' => 'gateway_downloadFromGatewayPlatformToSensorType',);
                    }

                    if (0 === strpos($pathinfo, '/gateways/downloadSensorsFrom')) {
                        // gateway_downloadSensorsFromDecoder
                        if ($pathinfo === '/gateways/downloadSensorsFromDecoder') {
                            return array (  '_controller' => 'AppBundle\\Controller\\GatewaysController::downloadSensorsFromDecoderApi',  '_route' => 'gateway_downloadSensorsFromDecoder',);
                        }

                        // gateway_downloadSensorsFromChirpStack
                        if ($pathinfo === '/gateways/downloadSensorsFromChirpStack') {
                            return array (  '_controller' => 'AppBundle\\Controller\\GatewaysController::downloadSensorsFromChirpStackApi',  '_route' => 'gateway_downloadSensorsFromChirpStack',);
                        }

                    }

                }

                // gateway_addLoraWANSensorToGateway
                if ($pathinfo === '/gateways/addLoraWANSensorToGatewayAndChirpStack') {
                    return array (  '_controller' => 'AppBundle\\Controller\\GatewaysController::addLoraWANSensorToGatewayAndChirpStackApi',  '_route' => 'gateway_addLoraWANSensorToGateway',);
                }

                // gateway_removeSensorFromGatewayAndChirpstack
                if ($pathinfo === '/gateways/removeSensorFromGatewayAndChirpstack') {
                    return array (  '_controller' => 'AppBundle\\Controller\\GatewaysController::removeSensorFromGatewayAndChirpStackApi',  '_route' => 'gateway_removeSensorFromGatewayAndChirpstack',);
                }

                if (0 === strpos($pathinfo, '/gateways/downloadFromGatewayServer')) {
                    // gateway_downloadFromGatewayServerConfigOfSensor
                    if ($pathinfo === '/gateways/downloadFromGatewayServerConfigOfSensor') {
                        return array (  '_controller' => 'AppBundle\\Controller\\GatewaysController::downloadFromGatewayServerConfigOfSensorApi',  '_route' => 'gateway_downloadFromGatewayServerConfigOfSensor',);
                    }

                    // gateway_downloadFromGatewayServersToOurServer
                    if ($pathinfo === '/gateways/downloadFromGatewayServersToOurServer') {
                        return array (  '_controller' => 'AppBundle\\Controller\\GatewaysController::downloadFromGatewayServersToOurServerApi',  '_route' => 'gateway_downloadFromGatewayServersToOurServer',);
                    }

                }

                if (0 === strpos($pathinfo, '/gateways/updategateway')) {
                    if (0 === strpos($pathinfo, '/gateways/updategatewayUnlinkSe')) {
                        // gateway_updategatewayUnlinkSensor
                        if ($pathinfo === '/gateways/updategatewayUnlinkSensor') {
                            return array (  '_controller' => 'AppBundle\\Controller\\GatewaysController::updategatewayUnlinkSensorApi',  '_route' => 'gateway_updategatewayUnlinkSensor',);
                        }

                        // gateway_updategatewayUnlinkServer
                        if ($pathinfo === '/gateways/updategatewayUnlinkServer') {
                            return array (  '_controller' => 'AppBundle\\Controller\\GatewaysController::updategatewayUnlinkServerApi',  '_route' => 'gateway_updategatewayUnlinkServer',);
                        }

                    }

                    if (0 === strpos($pathinfo, '/gateways/updategatewayse')) {
                        // gateway_updategatewayserverids
                        if ($pathinfo === '/gateways/updategatewayserverids') {
                            return array (  '_controller' => 'AppBundle\\Controller\\GatewaysController::updategatewayServerIdsApi',  '_route' => 'gateway_updategatewayserverids',);
                        }

                        // gateway_updategatewaysensorids
                        if ($pathinfo === '/gateways/updategatewaysensorids') {
                            return array (  '_controller' => 'AppBundle\\Controller\\GatewaysController::updategatewaySensorIdsApi',  '_route' => 'gateway_updategatewaysensorids',);
                        }

                    }

                }

            }

            if (0 === strpos($pathinfo, '/group')) {
                // group_list
                if ($pathinfo === '/group/list') {
                    return array (  '_controller' => 'AppBundle\\Controller\\GroupController::GroupListApi',  '_route' => 'group_list',);
                }

                // group_newgroup
                if ($pathinfo === '/group/newGroup') {
                    return array (  '_controller' => 'AppBundle\\Controller\\GroupController::newGroupApi',  '_route' => 'group_newgroup',);
                }

                if (0 === strpos($pathinfo, '/group/g')) {
                    // group_getgroupbyid
                    if ($pathinfo === '/group/getgroupbyid') {
                        return array (  '_controller' => 'AppBundle\\Controller\\GroupController::getgroupbyidApi',  '_route' => 'group_getgroupbyid',);
                    }

                    // group_groupparentlist
                    if ($pathinfo === '/group/groupparentlist') {
                        return array (  '_controller' => 'AppBundle\\Controller\\GroupController::getgroupparentlistApi',  '_route' => 'group_groupparentlist',);
                    }

                }

                // group_updategroup
                if ($pathinfo === '/group/updategroup') {
                    return array (  '_controller' => 'AppBundle\\Controller\\GroupController::updategroupApi',  '_route' => 'group_updategroup',);
                }

                // group_deletegroup
                if ($pathinfo === '/group/deletegroup') {
                    return array (  '_controller' => 'AppBundle\\Controller\\GroupController::deleteGroupApi',  '_route' => 'group_deletegroup',);
                }

            }

        }

        if (0 === strpos($pathinfo, '/pro')) {
            if (0 === strpos($pathinfo, '/projects')) {
                // projects_list
                if ($pathinfo === '/projects/list') {
                    return array (  '_controller' => 'AppBundle\\Controller\\ProjectsController::ProjectsListApi',  '_route' => 'projects_list',);
                }

                // projects_getprojectsbyid
                if ($pathinfo === '/projects/getprojectsbyid') {
                    return array (  '_controller' => 'AppBundle\\Controller\\ProjectsController::getProjectsByIdApi',  '_route' => 'projects_getprojectsbyid',);
                }

                // project_deleteproject
                if ($pathinfo === '/projects/deleteproject') {
                    return array (  '_controller' => 'AppBundle\\Controller\\ProjectsController::deleteProjectApi',  '_route' => 'project_deleteproject',);
                }

                // project_newproject
                if ($pathinfo === '/projects/newProject') {
                    return array (  '_controller' => 'AppBundle\\Controller\\ProjectsController::newProjectApi',  '_route' => 'project_newproject',);
                }

                // project_updateproject
                if ($pathinfo === '/projects/updateproject') {
                    return array (  '_controller' => 'AppBundle\\Controller\\ProjectsController::updateProjectsApi',  '_route' => 'project_updateproject',);
                }

            }

            if (0 === strpos($pathinfo, '/provider')) {
                // provider_list
                if ($pathinfo === '/provider/list') {
                    return array (  '_controller' => 'AppBundle\\Controller\\ProviderController::providerListApi',  '_route' => 'provider_list',);
                }

                // provider_getproviderbyid
                if ($pathinfo === '/provider/getproviderbyid') {
                    return array (  '_controller' => 'AppBundle\\Controller\\ProviderController::getProviderByIdApi',  '_route' => 'provider_getproviderbyid',);
                }

                // provider_deleteprovider
                if ($pathinfo === '/provider/deleteprovider') {
                    return array (  '_controller' => 'AppBundle\\Controller\\ProviderController::deleteProviderApi',  '_route' => 'provider_deleteprovider',);
                }

                // provider_newprovider
                if ($pathinfo === '/provider/newProvider') {
                    return array (  '_controller' => 'AppBundle\\Controller\\ProviderController::newProviderApi',  '_route' => 'provider_newprovider',);
                }

                // provider_updateprovider
                if ($pathinfo === '/provider/updateprovider') {
                    return array (  '_controller' => 'AppBundle\\Controller\\ProviderController::updateProviderApi',  '_route' => 'provider_updateprovider',);
                }

            }

        }

        if (0 === strpos($pathinfo, '/se')) {
            if (0 === strpos($pathinfo, '/sensor')) {
                // update_sentilo
                if ($pathinfo === '/sensor/updateSentilo') {
                    return array (  '_controller' => 'AppBundle\\Controller\\SensorInfoController::UpdateSentiloSensorApi',  '_route' => 'update_sentilo',);
                }

                if (0 === strpos($pathinfo, '/sensor/decoderSensor')) {
                    // decoder_sensor_new
                    if ($pathinfo === '/sensor/decoderSensorNew') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorInfoController::CreateDecoderSensorNewApi',  '_route' => 'decoder_sensor_new',);
                    }

                    // decoder_sensor
                    if ($pathinfo === '/sensor/decoderSensor') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorInfoController::CreateDecoderSensorApi',  '_route' => 'decoder_sensor',);
                    }

                }

                // sensorinfo_removeFromDecoder
                if ($pathinfo === '/sensor/removeFromDecoder') {
                    return array (  '_controller' => 'AppBundle\\Controller\\SensorInfoController::removeFromDecoderApi',  '_route' => 'sensorinfo_removeFromDecoder',);
                }

                if (0 === strpos($pathinfo, '/sensor/list')) {
                    // sensor_list_formappage
                    if ($pathinfo === '/sensor/listforMapPage') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorInfoController::SensorInfoForMapPageListApi',  '_route' => 'sensor_list_formappage',);
                    }

                    // sensor_list
                    if ($pathinfo === '/sensor/list') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorInfoController::SensorInfoListApi',  '_route' => 'sensor_list',);
                    }

                    // sensor_list_by_pagination
                    if ($pathinfo === '/sensor/listByPagination') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorInfoController::SensorInfoListByPaginationApi',  '_route' => 'sensor_list_by_pagination',);
                    }

                    // sensor_list_by_gateway
                    if ($pathinfo === '/sensor/listbyGateway') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorInfoController::SensorInfoListByGatewayApi',  '_route' => 'sensor_list_by_gateway',);
                    }

                }

                // sensorinfo_getsensorinfobyid
                if ($pathinfo === '/sensor/getsensorinfobyid') {
                    return array (  '_controller' => 'AppBundle\\Controller\\SensorInfoController::getSensorInfobyidApi',  '_route' => 'sensorinfo_getsensorinfobyid',);
                }

                // sensorinfo_deletesensorinfo
                if ($pathinfo === '/sensor/deletesensorinfo') {
                    return array (  '_controller' => 'AppBundle\\Controller\\SensorInfoController::deleteSensorInfoApi',  '_route' => 'sensorinfo_deletesensorinfo',);
                }

                if (0 === strpos($pathinfo, '/sensor/import')) {
                    // sensorinfo_importnewsensorinfo
                    if ($pathinfo === '/sensor/importnewsensorinfo') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorInfoController::importNewSensorInfoApi',  '_route' => 'sensorinfo_importnewsensorinfo',);
                    }

                    // sensorinfo_importupdatesensorinfo
                    if ($pathinfo === '/sensor/importupdatesensorinfo') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorInfoController::importUpdateSensorInfoApi',  '_route' => 'sensorinfo_importupdatesensorinfo',);
                    }

                }

                // sensorinfo_newsensorinfo
                if ($pathinfo === '/sensor/newsensorinfo') {
                    return array (  '_controller' => 'AppBundle\\Controller\\SensorInfoController::newSensorInfoApi',  '_route' => 'sensorinfo_newsensorinfo',);
                }

                // sensorinfo_resetframecounter
                if ($pathinfo === '/sensor/resetFrameCounter') {
                    return array (  '_controller' => 'AppBundle\\Controller\\SensorInfoController::resetFrameCounterApi',  '_route' => 'sensorinfo_resetframecounter',);
                }

                // sensorinfo_updatesensorinfo
                if ($pathinfo === '/sensor/updatesensorinfo') {
                    return array (  '_controller' => 'AppBundle\\Controller\\SensorInfoController::updateSensorInfoApi',  '_route' => 'sensorinfo_updatesensorinfo',);
                }

                // sensor_type_gatewaypkIdList
                if ($pathinfo === '/sensor/sensortypepkIdlist') {
                    return array (  '_controller' => 'AppBundle\\Controller\\SensorInfoController::SensorTypeGatewayPkIdListApi',  '_route' => 'sensor_type_gatewaypkIdList',);
                }

                if (0 === strpos($pathinfo, '/sensorserverdetail')) {
                    // sensorserverdetail_list
                    if ($pathinfo === '/sensorserverdetail/list') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorServerDetailController::SensorServerDetailListApi',  '_route' => 'sensorserverdetail_list',);
                    }

                    // sensorserverdetail_getbyid
                    if ($pathinfo === '/sensorserverdetail/getbyid') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorServerDetailController::getSensorServerDetailByIdApi',  '_route' => 'sensorserverdetail_getbyid',);
                    }

                    // sensorserverdetail_delete
                    if ($pathinfo === '/sensorserverdetail/delete') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorServerDetailController::deleteSensorServerDetailApi',  '_route' => 'sensorserverdetail_delete',);
                    }

                    // sensorserverdetail_new
                    if ($pathinfo === '/sensorserverdetail/new') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorServerDetailController::newSensorServerDetailApi',  '_route' => 'sensorserverdetail_new',);
                    }

                    // sensorserverdetail_update
                    if ($pathinfo === '/sensorserverdetail/update') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorServerDetailController::updateSensorServerDetailApi',  '_route' => 'sensorserverdetail_update',);
                    }

                }

                if (0 === strpos($pathinfo, '/sensoriboxtypepayload')) {
                    // sensortypeiboxpayload_list
                    if ($pathinfo === '/sensoriboxtypepayload/list') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorTypeIboxPayloadController::SensorTypeIboxPayloadListApi',  '_route' => 'sensortypeiboxpayload_list',);
                    }

                    if (0 === strpos($pathinfo, '/sensoriboxtypepayload/inputlist')) {
                        // sensortypeiboxinputpayload_list
                        if ($pathinfo === '/sensoriboxtypepayload/inputlist') {
                            return array (  '_controller' => 'AppBundle\\Controller\\SensorTypeIboxPayloadController::SensorTypeIboxInputPayloadListApi',  '_route' => 'sensortypeiboxinputpayload_list',);
                        }

                        // sensortypeiboxinputbysensortypepayload_list
                        if ($pathinfo === '/sensoriboxtypepayload/inputlistbysensortype') {
                            return array (  '_controller' => 'AppBundle\\Controller\\SensorTypeIboxPayloadController::SensorTypeIboxInputPayloadBySensorTypeListApi',  '_route' => 'sensortypeiboxinputbysensortypepayload_list',);
                        }

                    }

                    if (0 === strpos($pathinfo, '/sensoriboxtypepayload/meterlist')) {
                        // sensortypeiboxmeterpayload_list
                        if ($pathinfo === '/sensoriboxtypepayload/meterlist') {
                            return array (  '_controller' => 'AppBundle\\Controller\\SensorTypeIboxPayloadController::SensorTypeIboxMeterPayloadListApi',  '_route' => 'sensortypeiboxmeterpayload_list',);
                        }

                        // sensortypeiboxmeterbysensortypepayload_list
                        if ($pathinfo === '/sensoriboxtypepayload/meterlistbysensortype') {
                            return array (  '_controller' => 'AppBundle\\Controller\\SensorTypeIboxPayloadController::SensorTypeIboxMeterPayloadBySensorTypeListApi',  '_route' => 'sensortypeiboxmeterbysensortypepayload_list',);
                        }

                    }

                    // sensortypeiboxpayload_getsensortypeiboxpayloadbyid
                    if ($pathinfo === '/sensoriboxtypepayload/getsensortypeiboxpayloadbyid') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorTypeIboxPayloadController::getSensorTypeIboxPayloadbyidApi',  '_route' => 'sensortypeiboxpayload_getsensortypeiboxpayloadbyid',);
                    }

                    // sensortypeiboxpayload_deletesensortypeiboxpayload
                    if ($pathinfo === '/sensoriboxtypepayload/deletesensortypeiboxpayload') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorTypeIboxPayloadController::deleteSensorTypeIboxPayloadApi',  '_route' => 'sensortypeiboxpayload_deletesensortypeiboxpayload',);
                    }

                    // sensorinputtypeiboxpayload_newsensortypeiboxpayload
                    if ($pathinfo === '/sensoriboxtypepayload/newinputsensortypeiboxpayload') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorTypeIboxPayloadController::newInputSensorTypeIboxPayloadApi',  '_route' => 'sensorinputtypeiboxpayload_newsensortypeiboxpayload',);
                    }

                    // sensorinputtypeiboxpayload_updatesensortypeiboxpayload
                    if ($pathinfo === '/sensoriboxtypepayload/updateinputsensortypeiboxpayload') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorTypeIboxPayloadController::updateInputSensorTypeIboxPayloadApi',  '_route' => 'sensorinputtypeiboxpayload_updatesensortypeiboxpayload',);
                    }

                    // sensormetertypeiboxpayload_newsensortypeiboxpayload
                    if ($pathinfo === '/sensoriboxtypepayload/newmetersensortypeiboxpayload') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorTypeIboxPayloadController::newMeterSensorTypeIboxPayloadApi',  '_route' => 'sensormetertypeiboxpayload_newsensortypeiboxpayload',);
                    }

                    // sensormetertypeiboxpayload_updatesensortypeiboxpayload
                    if ($pathinfo === '/sensoriboxtypepayload/updatemetersensortypeiboxpayload') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorTypeIboxPayloadController::updateMeterSensorTypeIboxPayloadApi',  '_route' => 'sensormetertypeiboxpayload_updatesensortypeiboxpayload',);
                    }

                }

                if (0 === strpos($pathinfo, '/sensortype')) {
                    // sensortype_list
                    if ($pathinfo === '/sensortype/list') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorTypeInfoController::SensorTypeInfoListApi',  '_route' => 'sensortype_list',);
                    }

                    // sensortypeinfo_getsensortypeinfobyid
                    if ($pathinfo === '/sensortype/getsensortypeinfobyid') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorTypeInfoController::getSensorTypeInfobyidApi',  '_route' => 'sensortypeinfo_getsensortypeinfobyid',);
                    }

                    // sensortypeinfo_deletesensortypeinfo
                    if ($pathinfo === '/sensortype/deletesensortypeinfo') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorTypeInfoController::deleteSensorTypeInfoApi',  '_route' => 'sensortypeinfo_deletesensortypeinfo',);
                    }

                    // sensortypeinfo_newsensortypeinfo
                    if ($pathinfo === '/sensortype/newsensortypeinfo') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorTypeInfoController::newSensorTypeInfoApi',  '_route' => 'sensortypeinfo_newsensortypeinfo',);
                    }

                    // sensortypeinfo_updatesensortypeinfo
                    if ($pathinfo === '/sensortype/updatesensortypeinfo') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorTypeInfoController::updateSensorTypeInfoApi',  '_route' => 'sensortypeinfo_updatesensortypeinfo',);
                    }

                    // sensortype_gateway_pkid
                    if ($pathinfo === '/sensortype/sensortypegatewaypkidlist') {
                        return array (  '_controller' => 'AppBundle\\Controller\\SensorTypeInfoController::SensorTypeGatewayPkidListApi',  '_route' => 'sensortype_gateway_pkid',);
                    }

                    if (0 === strpos($pathinfo, '/sensortypepayload')) {
                        if (0 === strpos($pathinfo, '/sensortypepayload/list')) {
                            // sensortypepayload_list
                            if ($pathinfo === '/sensortypepayload/list') {
                                return array (  '_controller' => 'AppBundle\\Controller\\SensorTypePayloadController::SensorTypePayloadListApi',  '_route' => 'sensortypepayload_list',);
                            }

                            // sensortypepayload_listbytypeid
                            if ($pathinfo === '/sensortypepayload/listbytypeid') {
                                return array (  '_controller' => 'AppBundle\\Controller\\SensorTypePayloadController::SensorTypePayloadListByTypeIdApi',  '_route' => 'sensortypepayload_listbytypeid',);
                            }

                        }

                        // sensortypepayload_getsensortypepayloadbyid
                        if ($pathinfo === '/sensortypepayload/getsensortypepayloadbyid') {
                            return array (  '_controller' => 'AppBundle\\Controller\\SensorTypePayloadController::getSensorTypePayloadbyidApi',  '_route' => 'sensortypepayload_getsensortypepayloadbyid',);
                        }

                        // sensortypepayload_deletesensortypepayload
                        if ($pathinfo === '/sensortypepayload/deletesensortypepayload') {
                            return array (  '_controller' => 'AppBundle\\Controller\\SensorTypePayloadController::deleteSensorTypePayloadApi',  '_route' => 'sensortypepayload_deletesensortypepayload',);
                        }

                        // sensortypepayload_newsensortypepayload
                        if ($pathinfo === '/sensortypepayload/newsensortypepayload') {
                            return array (  '_controller' => 'AppBundle\\Controller\\SensorTypePayloadController::newSensorTypePayloadApi',  '_route' => 'sensortypepayload_newsensortypepayload',);
                        }

                        // sensortypeinfo_updatesensortypepayload
                        if ($pathinfo === '/sensortypepayload/updatesensortypepayload') {
                            return array (  '_controller' => 'AppBundle\\Controller\\SensorTypePayloadController::updateSensorTypePayloadApi',  '_route' => 'sensortypeinfo_updatesensortypepayload',);
                        }

                    }

                }

            }

            if (0 === strpos($pathinfo, '/servers')) {
                // servers_list
                if ($pathinfo === '/servers/list') {
                    return array (  '_controller' => 'AppBundle\\Controller\\ServersController::ServersListApi',  '_route' => 'servers_list',);
                }

                // server_getserverbyid
                if ($pathinfo === '/servers/getserverbyid') {
                    return array (  '_controller' => 'AppBundle\\Controller\\ServersController::getserverbyidApi',  '_route' => 'server_getserverbyid',);
                }

                // server_deleteserver
                if ($pathinfo === '/servers/deleteserver') {
                    return array (  '_controller' => 'AppBundle\\Controller\\ServersController::deleteServerApi',  '_route' => 'server_deleteserver',);
                }

                // server_newserver
                if ($pathinfo === '/servers/newserver') {
                    return array (  '_controller' => 'AppBundle\\Controller\\ServersController::newServerApi',  '_route' => 'server_newserver',);
                }

                // server_updateserver
                if ($pathinfo === '/servers/updateserver') {
                    return array (  '_controller' => 'AppBundle\\Controller\\ServersController::updateserverApi',  '_route' => 'server_updateserver',);
                }

                // servers_mqqtlist
                if ($pathinfo === '/servers/mqqtlist') {
                    return array (  '_controller' => 'AppBundle\\Controller\\ServersController::ServersmqqtListApi',  '_route' => 'servers_mqqtlist',);
                }

                // server_getservermqqtbyid
                if ($pathinfo === '/servers/getservermqqtbyid') {
                    return array (  '_controller' => 'AppBundle\\Controller\\ServersController::getservermqqtbyidApi',  '_route' => 'server_getservermqqtbyid',);
                }

                // server_deleteservermqqt
                if ($pathinfo === '/servers/deleteservermqqt') {
                    return array (  '_controller' => 'AppBundle\\Controller\\ServersController::deleteServerMqqtApi',  '_route' => 'server_deleteservermqqt',);
                }

                // server_newservermqqt
                if ($pathinfo === '/servers/newservermqqt') {
                    return array (  '_controller' => 'AppBundle\\Controller\\ServersController::newServerMqqtApi',  '_route' => 'server_newservermqqt',);
                }

                // server_updateservermqqt
                if ($pathinfo === '/servers/updateservermqqt') {
                    return array (  '_controller' => 'AppBundle\\Controller\\ServersController::updateServerMqqtApi',  '_route' => 'server_updateservermqqt',);
                }

                // servers_gatewaypkIdList
                if ($pathinfo === '/servers/serverpkIdlist') {
                    return array (  '_controller' => 'AppBundle\\Controller\\ServersController::ServerpkIdListApi',  '_route' => 'servers_gatewaypkIdList',);
                }

            }

        }

        if (0 === strpos($pathinfo, '/user')) {
            // user_login
            if ($pathinfo === '/user/login') {
                return array (  '_controller' => 'AppBundle\\Controller\\UserController::loginApi',  '_route' => 'user_login',);
            }

            // user_getuserbyid
            if ($pathinfo === '/user/getuserbyid') {
                return array (  '_controller' => 'AppBundle\\Controller\\UserController::getuserbyidApi',  '_route' => 'user_getuserbyid',);
            }

            // user_deleteuser
            if ($pathinfo === '/user/deleteuser') {
                return array (  '_controller' => 'AppBundle\\Controller\\UserController::deleteUserApi',  '_route' => 'user_deleteuser',);
            }

            if (0 === strpos($pathinfo, '/user/get')) {
                if (0 === strpos($pathinfo, '/user/getalluser')) {
                    // user_getalluser
                    if ($pathinfo === '/user/getalluser') {
                        return array (  '_controller' => 'AppBundle\\Controller\\UserController::getalluserbyApi',  '_route' => 'user_getalluser',);
                    }

                    // user_getalluserCompleteList
                    if ($pathinfo === '/user/getalluserCompleteList') {
                        return array (  '_controller' => 'AppBundle\\Controller\\UserController::getalluserCompleteListbyApi',  '_route' => 'user_getalluserCompleteList',);
                    }

                    // user_getalluserofdoormodule
                    if ($pathinfo === '/user/getalluserofdoormodule') {
                        return array (  '_controller' => 'AppBundle\\Controller\\UserController::getalluserordoormodulebyApi',  '_route' => 'user_getalluserofdoormodule',);
                    }

                    // user_getalluserpagination
                    if ($pathinfo === '/user/getalluserpagination') {
                        return array (  '_controller' => 'AppBundle\\Controller\\UserController::getalluserpaginationbyApi',  '_route' => 'user_getalluserpagination',);
                    }

                }

                // user_getuserbyemailapi
                if ($pathinfo === '/user/getuserbyemailapi') {
                    return array (  '_controller' => 'AppBundle\\Controller\\UserController::getuserbyemailApi',  '_route' => 'user_getuserbyemailapi',);
                }

            }

            // user_registerapi
            if ($pathinfo === '/user/registerapi') {
                return array (  '_controller' => 'AppBundle\\Controller\\UserController::registerApi',  '_route' => 'user_registerapi',);
            }

            // user_updateuser
            if ($pathinfo === '/user/updateuser') {
                return array (  '_controller' => 'AppBundle\\Controller\\UserController::updateUserApi',  '_route' => 'user_updateuser',);
            }

            // user_resetpasswordapi
            if ($pathinfo === '/user/resetpasswordapi') {
                return array (  '_controller' => 'AppBundle\\Controller\\UserController::resetpasswordApi',  '_route' => 'user_resetpasswordapi',);
            }

            // user_contactrequestapi
            if ($pathinfo === '/user/contactrequestapi') {
                return array (  '_controller' => 'AppBundle\\Controller\\UserController::contactrequestApi',  '_route' => 'user_contactrequestapi',);
            }

        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
