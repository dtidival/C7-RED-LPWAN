<?php

/* :user:signup.html.twig */
class __TwigTemplate_6ebb9a64df8c403cdfbf5254084d8ab04679dec18fe82515fb4b672b17f4695b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
  <meta charset=\"utf-8\">
  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
  <title>Gesinen Signup</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content=\"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no\" name=\"viewport\">
 <link href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/bootstrap/dist/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>\t\t
 <link href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/fontawesome/css/font-awesome.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
 <link href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/admin-lte/dist/css/AdminLTE.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
 <link href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/admin-lte/checkboxjs/blue.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
 <link href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/admin-lte/checkboxjs/ionicons.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
 

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src=\"https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js\"></script>
  <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic\">
<link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css?family=Questrial\">
 <style>
 .wordpressRelatedFont{font-family:Questrial,sans-serif;}
 #map-canvas {
  height: 30em;
  width: 23em;
}
 </style>
  </head>
<body class=\"hold-transition login-page\">
<div class=\"login-box\">
  <div class=\"login-logo\">
    <a href=\"http://www.app.gesinen.es/\"><b><img src=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/logo_nombre_der.png"), "html", null, true);
        echo "\" alt=\"Loading\" height=\"50\"></a>
  </div>
  <!-- /.login-logo -->
  <div class=\"login-box-body\">
    <p class=\"login-box-msg wordpressRelatedFont\">";
        // line 41
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Register a new membership"), "html", null, true);
        echo "</p>";
        // line 42
        if (((isset($context["status"]) ? $context["status"] : null) == "FAILED")) {
            // line 43
            echo "\t\t    <small><font color=red class=\"wordpressRelatedFont\">";
            echo twig_escape_filter($this->env, (isset($context["error"]) ? $context["error"] : null), "html", null, true);
            echo "</font></small>";
        } else {
            // line 45
            echo "\t\t    <small></small>";
        }
        // line 47
        echo "    <form action=\"";
        echo $this->env->getExtension('routing')->getPath("user_new");
        echo "\" method=\"post\">
      <div class=\"form-group has-feedback\">
        <input type=\"text\" class=\"form-control wordpressRelatedFont\" placeholder=\"";
        // line 49
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("First name"), "html", null, true);
        echo "\" name=\"first_name\" required=\"\" data-form-field=\"Name\" id=\"first_name\" value=\"";
        echo twig_escape_filter($this->env, (isset($context["first_name"]) ? $context["first_name"] : null), "html", null, true);
        echo "\">
        <span class=\"glyphicon glyphicon-user form-control-feedback\"></span>
      </div>
\t  <div class=\"form-group has-feedback\">
        <input type=\"text\" class=\"form-control wordpressRelatedFont\" placeholder=\"";
        // line 53
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Last name"), "html", null, true);
        echo "\" name=\"last_name\" required=\"\" data-form-field=\"Name\" id=\"last_name\" value=\"";
        echo twig_escape_filter($this->env, (isset($context["last_name"]) ? $context["last_name"] : null), "html", null, true);
        echo "\">
        <span class=\"glyphicon glyphicon-user form-control-feedback\"></span>
      </div>
      <div class=\"form-group has-feedback\">
        <input type=\"email\" class=\"form-control wordpressRelatedFont\" placeholder=\"";
        // line 57
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Email"), "html", null, true);
        echo "\" name=\"e_mail\" required=\"\" data-form-field=\"Name\" id=\"e_mail\" value=\"";
        echo twig_escape_filter($this->env, (isset($context["e_mail"]) ? $context["e_mail"] : null), "html", null, true);
        echo "\">
        <span class=\"glyphicon glyphicon-envelope form-control-feedback\"></span>
      </div>
\t  <div class=\"form-group has-feedback\">
\t  <!--<select class=\"form-control has-feedback\" id=\"location\" name=\"location\" required=\"\" data-form-field=\"Name\">
\t\t<option class=\"form-group\" value=\"-1\">";
        // line 62
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Location"), "html", null, true);
        echo "</option>
        <option class=\"form-group\" value=\"Andalucia\" >Andalucia</option>
\t\t<option class=\"form-group\" value=\"Aragon\">Aragon</option>
\t\t<option class=\"form-group\" value=\"Asturias\">Asturias</option>
\t\t<option class=\"form-group\" value=\"Canarias\">Canarias</option>
\t\t<option class=\"form-group\" value=\"Cantabria\">Cantabria</option>
\t\t<option class=\"form-group\" value=\"Castilla y Leon\">Castilla y Leon</option>
\t\t<option class=\"form-group\" value=\"Castilla-La Mancha\">Castilla-La Mancha</option>
\t\t<option class=\"form-group\" value=\"Cataluna\">Cataluna</option>
\t\t<option class=\"form-group\" value=\"Ceuta\">Ceuta</option>
\t\t<option class=\"form-group\" value=\"Extremadura\">Extremadura</option>
\t\t<option class=\"form-group\" value=\"Galicia\">Galicia</option>
\t\t<option class=\"form-group\" value=\"Isles Baleares\">Isles Baleares</option>
\t\t<option class=\"form-group\" value=\"La Rioja\">La Rioja</option>
\t\t<option class=\"form-group\" value=\"Madrid\">Madrid</option>
\t\t<option class=\"form-group\" value=\"Melilla\">Melilla</option>
\t\t<option class=\"form-group\" value=\"Murcia\">Murcia</option>
\t\t<option class=\"form-group\" value=\"Navarra\">Navarra</option>
\t\t<option class=\"form-group\" value=\"Pais Vasco\">Pais Vasco</option>
\t\t<option class=\"form-group\" value=\"Valenciana\">Valenciana</option>-->
\t\t\t<input type=\"text\" class=\"form-control wordpressRelatedFont\" placeholder=\"";
        // line 82
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Location"), "html", null, true);
        echo "\" name=\"location\" required=\"\" data-form-field=\"Name\" id=\"location\" value=\"\">       
      </select>
\t  <span class=\"glyphicon glyphicon-home form-control-feedback\"></span>
\t  </div>
\t  <div id=\"map_canvas\" style=\"display:none;height:200px;\">\t\t
\t  </div>\t 
\t<div class=\"form-group has-feedback\">
        <input type=\"hidden\" class=\"form-control wordpressRelatedFont\" placeholder=\"";
        // line 89
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Password"), "html", null, true);
        echo "\" name=\"pwd\" required=\"\" data-form-field=\"Name\" id=\"pwd\" value=\"\">
        <!--<span class=\"glyphicon glyphicon-lock form-control-feedback\"></span>-->
      </div>
     <!-- <div class=\"form-group has-feedback\">
        <input type=\"password\" class=\"form-control wordpressRelatedFont\" placeholder=\"";
        // line 93
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Retype password"), "html", null, true);
        echo "\" name=\"re_pwd\" required=\"\" data-form-field=\"Name\" id=\"re_pwd\">
        <span class=\"glyphicon glyphicon-log-in form-control-feedback\"></span>
      </div>--->
\t  <div class=\"form-group has-feedback\">
        <input type=\"text\" class=\"form-control wordpressRelatedFont\" required=\"\" data-form-field=\"Name\" name=\"phone\" id=\"phone\" value=\"";
        // line 97
        echo twig_escape_filter($this->env, (isset($context["phone"]) ? $context["phone"] : null), "html", null, true);
        echo "\" placeholder=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Phone Number"), "html", null, true);
        echo "\">
        <span class=\"glyphicon glyphicon-earphone form-control-feedback\"></span>
      </div>
      <div class=\"row\">
        <div class=\"col-xs-8\">
          <div class=\"checkbox icheck\">
            <label class=\"wordpressRelatedFont\" style=\"font-size:11.5px\">
              <input type=\"checkbox\" required=\"\" data-form-field=\"Name\" name=\"termCondition\">";
        // line 104
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("I agree to the"), "html", null, true);
        echo " <a href=\"#\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("terms"), "html", null, true);
        echo "</a>
            </label>
          </div>
        </div>
        <!-- /.col -->
        <div class=\"col-xs-4\" style=\"padding:0 14px 0 0 ;\">
          <button type=\"submit\" class=\"btn btn-primary btn-block btn-flat wordpressRelatedFont\" >";
        // line 110
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Register"), "html", null, true);
        echo "</button>
        </div>
        <!-- /.col -->
      </div>
    </form>
   

    
    <a href=\"";
        // line 118
        echo $this->env->getExtension('routing')->getPath("user_login");
        echo "\" class=\"text-center wordpressRelatedFont\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("I already have a membership"), "html", null, true);
        echo "</a>

  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 3 -->
<script src=\"";
        // line 126
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/web/assets/jquery/jquery.min.js"), "html", null, true);
        echo "\"></script> 
<script src=\"";
        // line 127
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/tether/tether.min.js"), "html", null, true);
        echo "\"></script>
  <script src=\"";
        // line 128
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/bootstrap/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
  <script src=\"";
        // line 129
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/admin-lte/checkboxjs/icheck.min.js"), "html", null, true);
        echo "\"></script>
 <!-- <script type=\"text/javascript\" src=\"http://maps.google.com/maps/api/js?key=AIzaSyBeT3BR8lTrMes-ABH-i0CdCN1lNuYDrpM\"></script>-->
  <script type=\"text/javascript\" src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyDMkzcFoTPgUNInOBpbHBfMq2Vn0I5xPhU&libraries=places\"></script>
<script>
  \$(function () {
    \$('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });   
  /*var showMap = \$('#show-map');
  
var map;
var marker;
function placeMarker(location) {
    if (marker) {
        //if marker already was created change positon
        marker.setPosition(location);
    } else {
        //create a marker
        marker = new google.maps.Marker({          
            position: location,
            map: map,
            draggable: true
        });
    }
}

function initialize() {\t
\tvar location  = document.getElementById('location').value;
\tif(location)
\t{
\tlocationval = location.split(\",\");
\tconsole.log(locationval);
\tvar location = {lat:parseFloat(locationval[0]), lng:parseFloat(locationval[1])}\t
\t}
\t else
\t var location = {lat:40.451538, lng:-3.745556};
\t 
  var mapOptions = {
        zoom: 10,
        center: location,
        scrollwheel: false,
        mapTypeId: google.maps.MapTypeId.ROADMAP,
        mapTypeControl: true,
        mapTypeControlOptions: {
            style: google.maps.MapTypeControlStyle.DEFAULT
        },
        navigationControl: true,
        navigationControlOptions: {
            style: google.maps.NavigationControlStyle.DEFAULT
        }
    };
\tmap = new google.maps.Map(document.getElementById(\"map-canvas\"), mapOptions);
\tmarker = new google.maps.Marker({          
            position: location,
            map: map,
            draggable: true
        });
  
  google.maps.event.addListener(map, \"click\", function(event) {
  placeMarker(event.latLng);
   var curLatLng = marker.getPosition();
   console.log(curLatLng.lat()+','+curLatLng.lng()); 
document.getElementById('location').value = curLatLng.lat()+','+curLatLng.lng();   
});
}

\$(document).ready(function(){
    //\$('#location').on('click',initialize);
\t
\t//Uncomment if we need map
\t//\$(\"#location\").click(function(){
    //\$(\"#map-canvas\").toggle();
\t//initialize();
//});
\t
});*/

function initialize() {

    var placeSearch;
    var componentForm = {
        street_number: 'long_name'        
    };

    var mapOptions = {
        center: new google.maps.LatLng(40.451538, -3.745556),
        zoom: 8,
        mapTypeId: google.maps.MapTypeId.ROADMAP,
        scrollwheel: false,
        disableDefaultUI: true,
        streetViewControl: false,
        panControl: false,
\t\tnavigationControl: true,
\t\tmapTypeControl: true,
        mapTypeControlOptions: {
            style: google.maps.MapTypeControlStyle.DEFAULT
        },
\t\tnavigationControlOptions: {
            style: google.maps.NavigationControlStyle.DEFAULT
        }
    };

    var map = new google.maps.Map(document.getElementById('map_canvas'),
    mapOptions);

    var input = /** @type {HTMLInputElement} */
    (
    document.getElementById('location'));

    var autocomplete = new google.maps.places.Autocomplete(input);
    autocomplete.bindTo('bounds', map);

    var infowindow = new google.maps.InfoWindow();

    var marker = new google.maps.Marker({
        map: map,
        anchorPoint: new google.maps.Point(0, -29)
    });

    google.maps.event.addListener(autocomplete, 'place_changed', function () {
        infowindow.close();
        marker.setVisible(false);

        var place = autocomplete.getPlace();

        if (!place.geometry) {
            window.alert(\"Autocomplete's returned place contains no geometry\");
            return;
        }

        // If the place has a geometry, then present it on a map.
        if (place.geometry.viewport) {
            map.fitBounds(place.geometry.viewport);
        } else {
            map.setCenter(place.geometry.location);
            map.setZoom(12); // Why 17? Because it looks good.
        }
        marker.setIcon( /** @type {google.maps.Icon} */ ({
            url: place.icon,
            size: new google.maps.Size(71, 71),
            origin: new google.maps.Point(0, 0),
            anchor: new google.maps.Point(25, 34),
            scaledSize: new google.maps.Size(50, 50)
        }));
        marker.setPosition(place.geometry.location);
        marker.setVisible(true);

        var address = '';
        if (place.address_components) {
            address = [
            (place.address_components[0] && place.address_components[0].short_name || ''), (place.address_components[1] && place.address_components[1].short_name || ''), (place.address_components[2] && place.address_components[2].short_name || '')].join(' ');
        }

        infowindow.setContent('<div id=\"infowindow\"><strong>' + place.name + '</strong><br>' +
        place.formatted_address);
        infowindow.open(map, marker);
    });

    google.maps.event.addListener(autocomplete, 'place_changed', function () {
        //fillInAddress();
    });

    function fillInAddress() {
        // Get the place details from the autocomplete object.
       // var place = autocomplete.getPlace();

       // document.getElementById('place_id').value = place.place_id;
       // document.getElementById('latitude').value = place.geometry.location.lat();
       // document.getElementById('longitude').value = place.geometry.location.lng();

       // var formatted_address = place.formatted_address;
        //document.getElementById(\"formatted_address\").value = formatted_address;

       /* for (var component in componentForm) {
            //document.getElementById(component).value = '';
            //document.getElementById(component).disabled = false;
        }*/

        // Get each component of the address from the place details
        // and fill the corresponding field on the form.
       /* for (var i = 0; i < place.address_components.length; i++) {
            var addressType = place.address_components[i].types[0];
            if (componentForm[addressType]) {
                var val = place.address_components[i][componentForm[addressType]];
                document.getElementById(addressType).value = val;
            }
        }*/
    }

    // Bias the autocomplete object to the user's geographical location,
    // as supplied by the browser's 'navigator.geolocation' object.
    function geolocate() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function (position) {
                var geolocation = new google.maps.LatLng(
                position.coords.latitude, position.coords.longitude);

                var latitude = position.coords.latitude;
                var longitude = position.coords.longitude;

               // document.getElementById('latitude').value = latitude;
               /// document.getElementById('longitude').value = longitude;

                autocomplete.setBounds(new google.maps.LatLngBounds(geolocation, geolocation));
            });
        }
    }

}
\$(document).ready(function(){
\$(\"#location\").click(function(){ 
    \$(\"#map_canvas\").toggle();\t 
\t\tinitialize();\t\t 
});
});
</script>
</body>
</html>
";
    }

    public function getTemplateName()
    {
        return ":user:signup.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  232 => 129,  228 => 128,  224 => 127,  220 => 126,  207 => 118,  196 => 110,  185 => 104,  173 => 97,  166 => 93,  159 => 89,  149 => 82,  126 => 62,  116 => 57,  107 => 53,  98 => 49,  92 => 47,  89 => 45,  84 => 43,  82 => 42,  79 => 41,  72 => 37,  45 => 13,  41 => 12,  37 => 11,  33 => 10,  29 => 9,  19 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/* <head>*/
/*   <meta charset="utf-8">*/
/*   <meta http-equiv="X-UA-Compatible" content="IE=edge">*/
/*   <title>Gesinen Signup</title>*/
/*   <!-- Tell the browser to be responsive to screen width -->*/
/*   <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">*/
/*  <link href="{{ asset('vendor/bootstrap/dist/css/bootstrap.min.css') }}" rel="stylesheet"/>		*/
/*  <link href="{{ asset('vendor/fontawesome/css/font-awesome.min.css') }}" rel="stylesheet"/>*/
/*  <link href="{{ asset('vendor/admin-lte/dist/css/AdminLTE.min.css') }}" rel="stylesheet"/>*/
/*  <link href="{{ asset('vendor/admin-lte/checkboxjs/blue.css') }}" rel="stylesheet"/>*/
/*  <link href="{{ asset('vendor/admin-lte/checkboxjs/ionicons.min.css') }}" rel="stylesheet"/>*/
/*  */
/* */
/*   <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->*/
/*   <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->*/
/*   <!--[if lt IE 9]>*/
/*   <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>*/
/*   <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>*/
/*   <![endif]-->*/
/* */
/*   <!-- Google Font -->*/
/*   <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">*/
/* <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Questrial">*/
/*  <style>*/
/*  .wordpressRelatedFont{font-family:Questrial,sans-serif;}*/
/*  #map-canvas {*/
/*   height: 30em;*/
/*   width: 23em;*/
/* }*/
/*  </style>*/
/*   </head>*/
/* <body class="hold-transition login-page">*/
/* <div class="login-box">*/
/*   <div class="login-logo">*/
/*     <a href="http://www.app.gesinen.es/"><b><img src="{{ asset('assets/images/logo_nombre_der.png') }}" alt="Loading" height="50"></a>*/
/*   </div>*/
/*   <!-- /.login-logo -->*/
/*   <div class="login-box-body">*/
/*     <p class="login-box-msg wordpressRelatedFont">{{ 'Register a new membership'|trans }}</p>*/
/* 	{% if status == 'FAILED' %}*/
/* 		    <small><font color=red class="wordpressRelatedFont">{{ error }}</font></small>*/
/* 		    {% else %}*/
/* 		    <small></small>*/
/* 		    {% endif %}*/
/*     <form action="{{ path('user_new') }}" method="post">*/
/*       <div class="form-group has-feedback">*/
/*         <input type="text" class="form-control wordpressRelatedFont" placeholder="{{ 'First name'|trans }}" name="first_name" required="" data-form-field="Name" id="first_name" value="{{ first_name }}">*/
/*         <span class="glyphicon glyphicon-user form-control-feedback"></span>*/
/*       </div>*/
/* 	  <div class="form-group has-feedback">*/
/*         <input type="text" class="form-control wordpressRelatedFont" placeholder="{{ 'Last name'|trans }}" name="last_name" required="" data-form-field="Name" id="last_name" value="{{ last_name }}">*/
/*         <span class="glyphicon glyphicon-user form-control-feedback"></span>*/
/*       </div>*/
/*       <div class="form-group has-feedback">*/
/*         <input type="email" class="form-control wordpressRelatedFont" placeholder="{{ 'Email'|trans }}" name="e_mail" required="" data-form-field="Name" id="e_mail" value="{{ e_mail }}">*/
/*         <span class="glyphicon glyphicon-envelope form-control-feedback"></span>*/
/*       </div>*/
/* 	  <div class="form-group has-feedback">*/
/* 	  <!--<select class="form-control has-feedback" id="location" name="location" required="" data-form-field="Name">*/
/* 		<option class="form-group" value="-1">{{ 'Location'|trans }}</option>*/
/*         <option class="form-group" value="Andalucia" >Andalucia</option>*/
/* 		<option class="form-group" value="Aragon">Aragon</option>*/
/* 		<option class="form-group" value="Asturias">Asturias</option>*/
/* 		<option class="form-group" value="Canarias">Canarias</option>*/
/* 		<option class="form-group" value="Cantabria">Cantabria</option>*/
/* 		<option class="form-group" value="Castilla y Leon">Castilla y Leon</option>*/
/* 		<option class="form-group" value="Castilla-La Mancha">Castilla-La Mancha</option>*/
/* 		<option class="form-group" value="Cataluna">Cataluna</option>*/
/* 		<option class="form-group" value="Ceuta">Ceuta</option>*/
/* 		<option class="form-group" value="Extremadura">Extremadura</option>*/
/* 		<option class="form-group" value="Galicia">Galicia</option>*/
/* 		<option class="form-group" value="Isles Baleares">Isles Baleares</option>*/
/* 		<option class="form-group" value="La Rioja">La Rioja</option>*/
/* 		<option class="form-group" value="Madrid">Madrid</option>*/
/* 		<option class="form-group" value="Melilla">Melilla</option>*/
/* 		<option class="form-group" value="Murcia">Murcia</option>*/
/* 		<option class="form-group" value="Navarra">Navarra</option>*/
/* 		<option class="form-group" value="Pais Vasco">Pais Vasco</option>*/
/* 		<option class="form-group" value="Valenciana">Valenciana</option>-->*/
/* 			<input type="text" class="form-control wordpressRelatedFont" placeholder="{{ 'Location'|trans }}" name="location" required="" data-form-field="Name" id="location" value="">       */
/*       </select>*/
/* 	  <span class="glyphicon glyphicon-home form-control-feedback"></span>*/
/* 	  </div>*/
/* 	  <div id="map_canvas" style="display:none;height:200px;">		*/
/* 	  </div>	 */
/* 	<div class="form-group has-feedback">*/
/*         <input type="hidden" class="form-control wordpressRelatedFont" placeholder="{{ 'Password'|trans }}" name="pwd" required="" data-form-field="Name" id="pwd" value="">*/
/*         <!--<span class="glyphicon glyphicon-lock form-control-feedback"></span>-->*/
/*       </div>*/
/*      <!-- <div class="form-group has-feedback">*/
/*         <input type="password" class="form-control wordpressRelatedFont" placeholder="{{ 'Retype password'|trans }}" name="re_pwd" required="" data-form-field="Name" id="re_pwd">*/
/*         <span class="glyphicon glyphicon-log-in form-control-feedback"></span>*/
/*       </div>--->*/
/* 	  <div class="form-group has-feedback">*/
/*         <input type="text" class="form-control wordpressRelatedFont" required="" data-form-field="Name" name="phone" id="phone" value="{{ phone }}" placeholder="{{ 'Phone Number'|trans }}">*/
/*         <span class="glyphicon glyphicon-earphone form-control-feedback"></span>*/
/*       </div>*/
/*       <div class="row">*/
/*         <div class="col-xs-8">*/
/*           <div class="checkbox icheck">*/
/*             <label class="wordpressRelatedFont" style="font-size:11.5px">*/
/*               <input type="checkbox" required="" data-form-field="Name" name="termCondition"> {{ 'I agree to the'|trans }} <a href="#">{{ 'terms'|trans }}</a>*/
/*             </label>*/
/*           </div>*/
/*         </div>*/
/*         <!-- /.col -->*/
/*         <div class="col-xs-4" style="padding:0 14px 0 0 ;">*/
/*           <button type="submit" class="btn btn-primary btn-block btn-flat wordpressRelatedFont" >{{ 'Register'|trans }}</button>*/
/*         </div>*/
/*         <!-- /.col -->*/
/*       </div>*/
/*     </form>*/
/*    */
/* */
/*     */
/*     <a href="{{ path('user_login') }}" class="text-center wordpressRelatedFont">{{ 'I already have a membership'|trans }}</a>*/
/* */
/*   </div>*/
/*   <!-- /.login-box-body -->*/
/* </div>*/
/* <!-- /.login-box -->*/
/* */
/* <!-- jQuery 3 -->*/
/* <script src="{{ asset('assets/web/assets/jquery/jquery.min.js') }}"></script> */
/* <script src="{{ asset('assets/tether/tether.min.js') }}"></script>*/
/*   <script src="{{ asset('assets/bootstrap/js/bootstrap.min.js') }}"></script>*/
/*   <script src="{{ asset('vendor/admin-lte/checkboxjs/icheck.min.js') }}"></script>*/
/*  <!-- <script type="text/javascript" src="http://maps.google.com/maps/api/js?key=AIzaSyBeT3BR8lTrMes-ABH-i0CdCN1lNuYDrpM"></script>-->*/
/*   <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDMkzcFoTPgUNInOBpbHBfMq2Vn0I5xPhU&libraries=places"></script>*/
/* <script>*/
/*   $(function () {*/
/*     $('input').iCheck({*/
/*       checkboxClass: 'icheckbox_square-blue',*/
/*       radioClass: 'iradio_square-blue',*/
/*       increaseArea: '20%' // optional*/
/*     });*/
/*   });   */
/*   /*var showMap = $('#show-map');*/
/*   */
/* var map;*/
/* var marker;*/
/* function placeMarker(location) {*/
/*     if (marker) {*/
/*         //if marker already was created change positon*/
/*         marker.setPosition(location);*/
/*     } else {*/
/*         //create a marker*/
/*         marker = new google.maps.Marker({          */
/*             position: location,*/
/*             map: map,*/
/*             draggable: true*/
/*         });*/
/*     }*/
/* }*/
/* */
/* function initialize() {	*/
/* 	var location  = document.getElementById('location').value;*/
/* 	if(location)*/
/* 	{*/
/* 	locationval = location.split(",");*/
/* 	console.log(locationval);*/
/* 	var location = {lat:parseFloat(locationval[0]), lng:parseFloat(locationval[1])}	*/
/* 	}*/
/* 	 else*/
/* 	 var location = {lat:40.451538, lng:-3.745556};*/
/* 	 */
/*   var mapOptions = {*/
/*         zoom: 10,*/
/*         center: location,*/
/*         scrollwheel: false,*/
/*         mapTypeId: google.maps.MapTypeId.ROADMAP,*/
/*         mapTypeControl: true,*/
/*         mapTypeControlOptions: {*/
/*             style: google.maps.MapTypeControlStyle.DEFAULT*/
/*         },*/
/*         navigationControl: true,*/
/*         navigationControlOptions: {*/
/*             style: google.maps.NavigationControlStyle.DEFAULT*/
/*         }*/
/*     };*/
/* 	map = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);*/
/* 	marker = new google.maps.Marker({          */
/*             position: location,*/
/*             map: map,*/
/*             draggable: true*/
/*         });*/
/*   */
/*   google.maps.event.addListener(map, "click", function(event) {*/
/*   placeMarker(event.latLng);*/
/*    var curLatLng = marker.getPosition();*/
/*    console.log(curLatLng.lat()+','+curLatLng.lng()); */
/* document.getElementById('location').value = curLatLng.lat()+','+curLatLng.lng();   */
/* });*/
/* }*/
/* */
/* $(document).ready(function(){*/
/*     //$('#location').on('click',initialize);*/
/* 	*/
/* 	//Uncomment if we need map*/
/* 	//$("#location").click(function(){*/
/*     //$("#map-canvas").toggle();*/
/* 	//initialize();*/
/* //});*/
/* 	*/
/* });*//* */
/* */
/* function initialize() {*/
/* */
/*     var placeSearch;*/
/*     var componentForm = {*/
/*         street_number: 'long_name'        */
/*     };*/
/* */
/*     var mapOptions = {*/
/*         center: new google.maps.LatLng(40.451538, -3.745556),*/
/*         zoom: 8,*/
/*         mapTypeId: google.maps.MapTypeId.ROADMAP,*/
/*         scrollwheel: false,*/
/*         disableDefaultUI: true,*/
/*         streetViewControl: false,*/
/*         panControl: false,*/
/* 		navigationControl: true,*/
/* 		mapTypeControl: true,*/
/*         mapTypeControlOptions: {*/
/*             style: google.maps.MapTypeControlStyle.DEFAULT*/
/*         },*/
/* 		navigationControlOptions: {*/
/*             style: google.maps.NavigationControlStyle.DEFAULT*/
/*         }*/
/*     };*/
/* */
/*     var map = new google.maps.Map(document.getElementById('map_canvas'),*/
/*     mapOptions);*/
/* */
/*     var input = /** @type {HTMLInputElement} *//* */
/*     (*/
/*     document.getElementById('location'));*/
/* */
/*     var autocomplete = new google.maps.places.Autocomplete(input);*/
/*     autocomplete.bindTo('bounds', map);*/
/* */
/*     var infowindow = new google.maps.InfoWindow();*/
/* */
/*     var marker = new google.maps.Marker({*/
/*         map: map,*/
/*         anchorPoint: new google.maps.Point(0, -29)*/
/*     });*/
/* */
/*     google.maps.event.addListener(autocomplete, 'place_changed', function () {*/
/*         infowindow.close();*/
/*         marker.setVisible(false);*/
/* */
/*         var place = autocomplete.getPlace();*/
/* */
/*         if (!place.geometry) {*/
/*             window.alert("Autocomplete's returned place contains no geometry");*/
/*             return;*/
/*         }*/
/* */
/*         // If the place has a geometry, then present it on a map.*/
/*         if (place.geometry.viewport) {*/
/*             map.fitBounds(place.geometry.viewport);*/
/*         } else {*/
/*             map.setCenter(place.geometry.location);*/
/*             map.setZoom(12); // Why 17? Because it looks good.*/
/*         }*/
/*         marker.setIcon( /** @type {google.maps.Icon} *//*  ({*/
/*             url: place.icon,*/
/*             size: new google.maps.Size(71, 71),*/
/*             origin: new google.maps.Point(0, 0),*/
/*             anchor: new google.maps.Point(25, 34),*/
/*             scaledSize: new google.maps.Size(50, 50)*/
/*         }));*/
/*         marker.setPosition(place.geometry.location);*/
/*         marker.setVisible(true);*/
/* */
/*         var address = '';*/
/*         if (place.address_components) {*/
/*             address = [*/
/*             (place.address_components[0] && place.address_components[0].short_name || ''), (place.address_components[1] && place.address_components[1].short_name || ''), (place.address_components[2] && place.address_components[2].short_name || '')].join(' ');*/
/*         }*/
/* */
/*         infowindow.setContent('<div id="infowindow"><strong>' + place.name + '</strong><br>' +*/
/*         place.formatted_address);*/
/*         infowindow.open(map, marker);*/
/*     });*/
/* */
/*     google.maps.event.addListener(autocomplete, 'place_changed', function () {*/
/*         //fillInAddress();*/
/*     });*/
/* */
/*     function fillInAddress() {*/
/*         // Get the place details from the autocomplete object.*/
/*        // var place = autocomplete.getPlace();*/
/* */
/*        // document.getElementById('place_id').value = place.place_id;*/
/*        // document.getElementById('latitude').value = place.geometry.location.lat();*/
/*        // document.getElementById('longitude').value = place.geometry.location.lng();*/
/* */
/*        // var formatted_address = place.formatted_address;*/
/*         //document.getElementById("formatted_address").value = formatted_address;*/
/* */
/*        /* for (var component in componentForm) {*/
/*             //document.getElementById(component).value = '';*/
/*             //document.getElementById(component).disabled = false;*/
/*         }*//* */
/* */
/*         // Get each component of the address from the place details*/
/*         // and fill the corresponding field on the form.*/
/*        /* for (var i = 0; i < place.address_components.length; i++) {*/
/*             var addressType = place.address_components[i].types[0];*/
/*             if (componentForm[addressType]) {*/
/*                 var val = place.address_components[i][componentForm[addressType]];*/
/*                 document.getElementById(addressType).value = val;*/
/*             }*/
/*         }*//* */
/*     }*/
/* */
/*     // Bias the autocomplete object to the user's geographical location,*/
/*     // as supplied by the browser's 'navigator.geolocation' object.*/
/*     function geolocate() {*/
/*         if (navigator.geolocation) {*/
/*             navigator.geolocation.getCurrentPosition(function (position) {*/
/*                 var geolocation = new google.maps.LatLng(*/
/*                 position.coords.latitude, position.coords.longitude);*/
/* */
/*                 var latitude = position.coords.latitude;*/
/*                 var longitude = position.coords.longitude;*/
/* */
/*                // document.getElementById('latitude').value = latitude;*/
/*                /// document.getElementById('longitude').value = longitude;*/
/* */
/*                 autocomplete.setBounds(new google.maps.LatLngBounds(geolocation, geolocation));*/
/*             });*/
/*         }*/
/*     }*/
/* */
/* }*/
/* $(document).ready(function(){*/
/* $("#location").click(function(){ */
/*     $("#map_canvas").toggle();	 */
/* 		initialize();		 */
/* });*/
/* });*/
/* </script>*/
/* </body>*/
/* </html>*/
/* */
