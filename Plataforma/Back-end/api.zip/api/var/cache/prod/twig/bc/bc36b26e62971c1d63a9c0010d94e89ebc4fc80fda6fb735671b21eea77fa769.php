<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_7f7aceb1b20e3ce6295492424821c5266eb654e807a0312c4e181455dec70a00 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
