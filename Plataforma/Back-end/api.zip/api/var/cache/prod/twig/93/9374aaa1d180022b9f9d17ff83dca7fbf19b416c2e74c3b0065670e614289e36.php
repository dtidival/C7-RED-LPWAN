<?php

/* :user:resetpassword.html.twig */
class __TwigTemplate_b2730e8c049494abed2d993a5f4104fbf7e49c1a6c469766cdd6e2e82eb0c2aa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
  <meta charset=\"utf-8\">
  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
  <title>Gesinen";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Log in"), "html", null, true);
        echo "</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content=\"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no\" name=\"viewport\">
 <link href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/bootstrap/dist/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>\t\t
 <link href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/fontawesome/css/font-awesome.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
 <link href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/admin-lte/dist/css/AdminLTE.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
 <link href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/admin-lte/checkboxjs/blue.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
 <link href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/admin-lte/checkboxjs/ionicons.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
 

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src=\"https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js\"></script>
  <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic\">
<link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css?family=Questrial\">
 <style>
 .wordpressRelatedFont{font-family:Questrial,sans-serif;}
 </style>
  </head>
<body class=\"hold-transition login-page\">
<div class=\"login-box\">
  <div class=\"login-logo\">
    <a href=\"http://www.app.gesinen.es/\"><b><img src=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/logo_nombre_der.png"), "html", null, true);
        echo "\" alt=\"Loading\" height=\"50\"></a>
  </div>
  <!-- /.login-logo -->
  <div class=\"login-box-body\">
    <p class=\"login-box-msg wordpressRelatedFont\">";
        // line 37
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("RESET PASSWORD"), "html", null, true);
        echo "</p>";
        // line 38
        if (((isset($context["status"]) ? $context["status"] : null) == "FAILED")) {
            // line 39
            echo "\t\t    <small class=\"mbr-section-subtitle wordpressRelatedFont\"><font color=red>";
            echo twig_escape_filter($this->env, (isset($context["error"]) ? $context["error"] : null), "html", null, true);
            echo "</font></small>";
        } else {
            // line 41
            echo "\t\t    <p  class=\"login-box-msg wordpressRelatedFont\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Please reset your password in gesinen site"), "html", null, true);
            echo ".</p>";
        }
        // line 43
        echo "    <form action=\"";
        echo $this->env->getExtension('routing')->getPath("user_resetpassword");
        echo "\" method=\"post\">
      <div class=\"form-group has-feedback\">
        <input type=\"email\" class=\"form-control wordpressRelatedFont\"  name=\"e_mail\" required=\"\" data-form-field=\"Name\" id=\"e_mail\" value=\"";
        // line 45
        echo twig_escape_filter($this->env, (isset($context["e_mail"]) ? $context["e_mail"] : null), "html", null, true);
        echo "\" placeholder=\"Email\">
        <span class=\"glyphicon glyphicon-envelope form-control-feedback\"></span>
      </div>
      
      <div class=\"row\">
        
        <!-- /.col -->
        <div class=\"col-xs-4\">
          <button type=\"submit wordpressRelatedFont\" class=\"btn btn-primary btn-block btn-flat\">";
        // line 53
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Submit"), "html", null, true);
        echo "</button>
        </div>
        <!-- /.col -->
      </div>
    </form>   

  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 3 -->
<script src=\"";
        // line 65
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/web/assets/jquery/jquery.min.js"), "html", null, true);
        echo "\"></script> 
<script src=\"";
        // line 66
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/tether/tether.min.js"), "html", null, true);
        echo "\"></script>
  <script src=\"";
        // line 67
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/bootstrap/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
  <script src=\"";
        // line 68
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/admin-lte/checkboxjs/icheck.min.js"), "html", null, true);
        echo "\"></script>
  
<script>
  \$(function () {
    \$('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
</body>
</html>
";
    }

    public function getTemplateName()
    {
        return ":user:resetpassword.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 68,  133 => 67,  129 => 66,  125 => 65,  110 => 53,  99 => 45,  93 => 43,  88 => 41,  83 => 39,  81 => 38,  78 => 37,  71 => 33,  48 => 13,  44 => 12,  40 => 11,  36 => 10,  32 => 9,  26 => 6,  19 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/* <head>*/
/*   <meta charset="utf-8">*/
/*   <meta http-equiv="X-UA-Compatible" content="IE=edge">*/
/*   <title>Gesinen {{ 'Log in'|trans }}</title>*/
/*   <!-- Tell the browser to be responsive to screen width -->*/
/*   <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">*/
/*  <link href="{{ asset('vendor/bootstrap/dist/css/bootstrap.min.css') }}" rel="stylesheet"/>		*/
/*  <link href="{{ asset('vendor/fontawesome/css/font-awesome.min.css') }}" rel="stylesheet"/>*/
/*  <link href="{{ asset('vendor/admin-lte/dist/css/AdminLTE.min.css') }}" rel="stylesheet"/>*/
/*  <link href="{{ asset('vendor/admin-lte/checkboxjs/blue.css') }}" rel="stylesheet"/>*/
/*  <link href="{{ asset('vendor/admin-lte/checkboxjs/ionicons.min.css') }}" rel="stylesheet"/>*/
/*  */
/* */
/*   <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->*/
/*   <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->*/
/*   <!--[if lt IE 9]>*/
/*   <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>*/
/*   <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>*/
/*   <![endif]-->*/
/* */
/*   <!-- Google Font -->*/
/*   <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">*/
/* <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Questrial">*/
/*  <style>*/
/*  .wordpressRelatedFont{font-family:Questrial,sans-serif;}*/
/*  </style>*/
/*   </head>*/
/* <body class="hold-transition login-page">*/
/* <div class="login-box">*/
/*   <div class="login-logo">*/
/*     <a href="http://www.app.gesinen.es/"><b><img src="{{ asset('assets/images/logo_nombre_der.png') }}" alt="Loading" height="50"></a>*/
/*   </div>*/
/*   <!-- /.login-logo -->*/
/*   <div class="login-box-body">*/
/*     <p class="login-box-msg wordpressRelatedFont">{{ 'RESET PASSWORD'| trans }}</p>*/
/* 	 {% if status == 'FAILED' %}*/
/* 		    <small class="mbr-section-subtitle wordpressRelatedFont"><font color=red>{{ error }}</font></small>*/
/* 		    {% else %}*/
/* 		    <p  class="login-box-msg wordpressRelatedFont">{{ 'Please reset your password in gesinen site'| trans }}.</p>*/
/* 		    {% endif %}*/
/*     <form action="{{ path('user_resetpassword') }}" method="post">*/
/*       <div class="form-group has-feedback">*/
/*         <input type="email" class="form-control wordpressRelatedFont"  name="e_mail" required="" data-form-field="Name" id="e_mail" value="{{ e_mail }}" placeholder="Email">*/
/*         <span class="glyphicon glyphicon-envelope form-control-feedback"></span>*/
/*       </div>*/
/*       */
/*       <div class="row">*/
/*         */
/*         <!-- /.col -->*/
/*         <div class="col-xs-4">*/
/*           <button type="submit wordpressRelatedFont" class="btn btn-primary btn-block btn-flat">{{ 'Submit'| trans }}</button>*/
/*         </div>*/
/*         <!-- /.col -->*/
/*       </div>*/
/*     </form>   */
/* */
/*   </div>*/
/*   <!-- /.login-box-body -->*/
/* </div>*/
/* <!-- /.login-box -->*/
/* */
/* <!-- jQuery 3 -->*/
/* <script src="{{ asset('assets/web/assets/jquery/jquery.min.js') }}"></script> */
/* <script src="{{ asset('assets/tether/tether.min.js') }}"></script>*/
/*   <script src="{{ asset('assets/bootstrap/js/bootstrap.min.js') }}"></script>*/
/*   <script src="{{ asset('vendor/admin-lte/checkboxjs/icheck.min.js') }}"></script>*/
/*   */
/* <script>*/
/*   $(function () {*/
/*     $('input').iCheck({*/
/*       checkboxClass: 'icheckbox_square-blue',*/
/*       radioClass: 'iradio_square-blue',*/
/*       increaseArea: '20%' // optional*/
/*     });*/
/*   });*/
/* </script>*/
/* </body>*/
/* </html>*/
/* */
