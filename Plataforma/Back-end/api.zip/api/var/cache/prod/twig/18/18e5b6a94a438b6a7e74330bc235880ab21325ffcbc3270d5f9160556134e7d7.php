<?php

/* ::index.html.twig */
class __TwigTemplate_bb12d307f0da934e1a293a98aad570306236e5b72e7e587699c23b25d20d8ea1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "::index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "DeviceOutputs";
    }

    // line 5
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 6
        echo "        
        <link href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/datatables-bootstrap3-plugin/media/css/datatables-bootstrap3.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
\t<link href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
        <link href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("css/crud.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>";
    }

    // line 13
    public function block_body($context, array $blocks = array())
    {
        // line 14
        echo "<style>
th {

   text-align: left;
}
</style>

<table width=\"100%\">
\t<tr>
\t\t<td width=\"20%\" style=\"padding-right:50px\" valign=\"top\">
\t\t\t<div class=\"row\">
\t\t\t    <div class=\"col-md-12\">
\t\t\t\t<div class=\"box box-solid box-primary\">
\t\t\t\t    <div class=\"box-header with-border\">
\t\t\t\t\t<table width=\"100%\">
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td colspan=2><h3 class=\"box-title\">Devices</h3></td>
\t\t\t\t\t\t\t<td align=\"center\">View:
\t\t\t\t\t\t\t\t<select id=\"device_view\" name=\"device_view\" style=\"color:black\" onchange=\"initDeviceTable();\">
\t\t\t\t\t\t\t\t\t<option value=\"10\">10</option>
\t\t\t\t\t\t\t\t\t<option value=\"15\">15</option>
\t\t\t\t\t\t\t\t\t<option value=\"20\">20</option>
\t\t\t\t\t\t\t\t\t<option value=\"50\">50</option>
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\trow
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t</table>
\t\t\t\t    </div>
\t\t\t\t    <div class=\"box-body\" style=\"padding:0px\">
\t\t\t\t\t<table width=\"100%\">
\t\t\t\t\t    <thead>
\t\t\t\t\t\t<tr class=\"headers\">
\t\t\t\t\t\t    <th class=\"row entity_id\" style=\"text-align:center\">#</th>
\t\t\t\t\t\t    <th><input type=\"checkbox\" onclick=\"clickDeviceAll(this);\"></th>
\t\t\t\t\t\t    <th>ID</th>
\t\t\t\t\t\t    <th style=\"text-align:center\">Status</th>
\t\t\t\t\t\t</tr>
\t\t\t\t\t    </thead>
\t\t\t\t\t    <form id=\"device_form\" name=\"device_form\" action=\"";
        // line 53
        echo $this->env->getExtension('routing')->getPath("deviceoutput_list");
        echo "\" method=\"post\" target=\"list\">
\t\t\t\t\t    <tbody id=\"device_scan\">";
        // line 55
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["devices"]) ? $context["devices"] : null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["device"]) {
            // line 56
            echo "\t\t\t\t\t\t<tr id=\"device_";
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "\" style=\"display:none\">
\t\t\t\t\t\t    <td id=\"device_index_";
            // line 57
            echo twig_escape_filter($this->env, $this->getAttribute($context["device"], "id", array()), "html", null, true);
            echo "\" style=\"text-align:center\" width=\"15%\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo " </td>
\t\t\t\t\t\t    <td><input id=\"check_";
            // line 58
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "\" name=\"check_";
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "\" type=\"checkbox\" width=\"10%\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["device"], "deviceId", array()), "html", null, true);
            echo "\" onclick=\"clickDevice(this);\"></td>
\t\t\t\t\t\t    <td id=\"device_id_";
            // line 59
            echo twig_escape_filter($this->env, $this->getAttribute($context["device"], "id", array()), "html", null, true);
            echo "\" width=\"40%\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["device"], "deviceId", array()), "html", null, true);
            echo "</td>
\t\t\t\t\t\t    <td width=\"35%\">
\t\t\t\t\t\t\t<table align=\"center\">
\t\t\t\t\t\t\t  <tr>
\t\t\t\t\t\t\t    <td style=\"width:10px; height:10px\" id=\"device_status_";
            // line 63
            echo twig_escape_filter($this->env, $this->getAttribute($context["device"], "id", array()), "html", null, true);
            echo "\"";
            if ($this->getAttribute($context["device"], "deviceStatus", array())) {
                echo " bgcolor=\"#00cc00\"";
            } else {
                echo " bgcolor=\"#cc0000\"";
            }
            echo "></td>
\t\t\t\t\t\t\t  </tr>
\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t    </td>
\t\t\t\t\t\t</tr>";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['device'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 69
        echo "\t\t\t\t\t    </tbody>
\t\t\t\t\t    </form>
\t\t\t\t\t</table>
 \t\t\t\t\t<div align=\"center\" id=\"device_pages\"></div>
\t\t\t\t    </div>
\t\t\t    </div>
\t\t\t</div>
\t\t    </div>
\t\t</div>
\t\t</td>
\t\t<td width=\"80%\" valign=\"top\">
\t\t\t<iframe id=\"list\" name=\"list\" src=\"";
        // line 80
        echo $this->env->getExtension('routing')->getPath("deviceoutput_list");
        echo "\" frameborder=\"0\" scrolling=\"no\" onload=\"resizeIframe(this);\" width=\"100%\"></iframe>
\t\t</td>
\t</tr>
</table>";
    }

    // line 86
    public function block_javascripts($context, array $blocks = array())
    {
        // line 87
        echo "        
        <script src=\"";
        // line 88
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/datatables/media/js/jquery.dataTables.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 89
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/datatables-bootstrap3-plugin/media/js/datatables-bootstrap3.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 90
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/moment/min/moment-with-locales.min.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 91
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 92
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/bootbox/bootbox.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 93
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/tabla.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 94
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/crud.js"), "html", null, true);
        echo "\"></script>

\t<!--jquery just to call ajax-->
\t<script type=\"text/javascript\" src=\"js/jquery-1.4.2.min.js\"></script>
\t<script>
\tfunction resizeIframe(obj) {
\t\tobj.style.height = obj.contentWindow.document.body.scrollHeight + 'px';
\t\t//obj.style.width = obj.contentWindow.document.body.scrollWidth + 'px';
\t}
\t</script>
\t<script>
\tvar deviceCount =";
        // line 105
        echo twig_escape_filter($this->env, (isset($context["device_count"]) ? $context["device_count"] : null), "html", null, true);
        echo ";
\tvar devicePageNumber = 1;
\tfunction getDeviceScan() 
\t{
\t\tvar url = \"";
        // line 109
        echo $this->env->getExtension('routing')->getPath("device_scan");
        echo "\";
\t\t\$.ajax(url, {
\t\t\tdata : null,
\t\t\ttype : \"GET\",
\t\t\tsuccess : function (response) {
\t\t\t\t//3.2 Check to see if connection is successful
\t\t\t\t\$.each(response, function (key, value) {
\t\t\t\t\tvar id = value[\"id\"];
\t\t\t\t\tvar device_id = value[\"device_id\"];
\t\t\t\t\tvar status = value[\"status\"];
\t\t\t\t\tvar alarm = value[\"alarm\"];

\t\t\t\t\tvar deviceStatusObj = document.getElementById(\"device_status_\"+id);
\t\t\t\t\tif (deviceStatusObj)
\t\t\t\t\t{
\t\t\t\t\t\tif (status == \"1\")
\t\t\t\t\t\t\tdeviceStatusObj.style.backgroundColor = \"#00cc00\";
\t\t\t\t\t\telse
\t\t\t\t\t\t\tdeviceStatusObj.style.backgroundColor = \"#cc0000\";
\t\t\t\t\t}
\t\t\t\t\tvar deviceIdObj = document.getElementById(\"device_id_\"+id);
\t\t\t\t\tif (deviceIdObj)
\t\t\t\t\t\tdeviceIdObj.innerHTML = device_id;
\t\t\t\t})
\t\t\t\t
\t\t\t\tconsole.dir(response);
\t\t\t}
\t\t});
\t}
\tfunction clickPageNumber(page_number) 
\t{
\t\tdevicePageNumber = page_number;
\t\tinitDeviceTable();
\t}
\tfunction initDeviceTable()
\t{
\t\tvar countPerPage = document.getElementById(\"device_view\").value;
\t\tvar pageCount = parseInt(deviceCount / countPerPage);
\t\tif (deviceCount % countPerPage > 0)
\t\t\tpageCount++;
\t\tif (devicePageNumber > pageCount) 
\t\t\tdevicePageNumber = pageCount;

\t\t// display
\t\tfor (i = 1; i <= deviceCount; i++)
\t\t{
\t\t\tvar obj = document.getElementById(\"device_\"+i);
\t\t\tif ((i > (devicePageNumber-1)*countPerPage) && (i <= devicePageNumber*countPerPage))
\t\t\t{
\t\t\t\tobj.style.display = \"\";
\t\t\t}
\t\t\telse
\t\t\t\tobj.style.display = \"none\";
\t\t}

\t\t// page number
\t\tvar pageObj = document.getElementById(\"device_pages\");
\t\tvar html = \"\";
\t\tfor (i = 1; i <= pageCount; i++)
\t\t{
\t\t\tif (i == devicePageNumber)
\t\t\t\thtml += i + \"&nbsp;&nbsp\";
\t\t\telse
\t\t\t\thtml += \"<a href='#' onclick='clickPageNumber(\"+i+\");'>\"+i+\"</a>&nbsp;&nbsp\";
\t\t}
\t\tpageObj.innerHTML = html;
\t}
\tinitDeviceTable();

\tfunction autoRefresh () {
\t     //var count_per_page = document.getElementById(\"deviceview_row\").value;
\t     //\$(\"#scan\").load(\"";
        // line 180
        echo $this->env->getExtension('routing')->getPath("device_scan");
        echo "?count_per_page=\"+count_per_page+\"&cur_page=\"+pageNumber, function() {
\t     //});
\t     getDeviceScan();
\t     setTimeout(autoRefresh, 1000);
\t}
        autoRefresh();

\tfunction clickDeviceAll(obj)
\t{
\t\tfor (i = 1; i <= deviceCount; i++)
\t\t\tdocument.getElementById(\"check_\"+i).checked = obj.checked;

\t\tvar iframeObj = document.getElementById(\"list\");


\t\tdevice_form.submit();
\t}

\tfunction clickDevice(obj)
\t{
\t\tvar iframeObj = document.getElementById(\"list\");

\t\tdevice_form.submit();
\t}

\t</script>";
    }

    public function getTemplateName()
    {
        return "::index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  320 => 180,  246 => 109,  239 => 105,  225 => 94,  221 => 93,  217 => 92,  213 => 91,  209 => 90,  205 => 89,  201 => 88,  198 => 87,  195 => 86,  187 => 80,  174 => 69,  149 => 63,  140 => 59,  132 => 58,  126 => 57,  121 => 56,  104 => 55,  100 => 53,  59 => 14,  56 => 13,  51 => 9,  47 => 8,  43 => 7,  40 => 6,  37 => 5,  31 => 3,  11 => 1,);
    }
}
/* {% extends '::base.html.twig' %}  */
/* */
/* {% block title %}DeviceOutputs{% endblock %}*/
/* */
/* {% block stylesheets %}*/
/*         */
/*         <link href="{{ asset('vendor/datatables-bootstrap3-plugin/media/css/datatables-bootstrap3.min.css') }}" rel="stylesheet"/>*/
/* 	<link href="{{ asset('vendor/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css') }}" rel="stylesheet"/>*/
/*         <link href="{{ asset('css/crud.css') }}" rel="stylesheet"/>*/
/* */
/* {% endblock %}*/
/*  */
/* {% block body -%}*/
/* <style>*/
/* th {*/
/* */
/*    text-align: left;*/
/* }*/
/* </style>*/
/* */
/* <table width="100%">*/
/* 	<tr>*/
/* 		<td width="20%" style="padding-right:50px" valign="top">*/
/* 			<div class="row">*/
/* 			    <div class="col-md-12">*/
/* 				<div class="box box-solid box-primary">*/
/* 				    <div class="box-header with-border">*/
/* 					<table width="100%">*/
/* 						<tr>*/
/* 							<td colspan=2><h3 class="box-title">Devices</h3></td>*/
/* 							<td align="center">View:*/
/* 								<select id="device_view" name="device_view" style="color:black" onchange="initDeviceTable();">*/
/* 									<option value="10">10</option>*/
/* 									<option value="15">15</option>*/
/* 									<option value="20">20</option>*/
/* 									<option value="50">50</option>*/
/* 								</select>*/
/* 								row*/
/* 							</td>*/
/* 						</tr>*/
/* 					</table>*/
/* 				    </div>*/
/* 				    <div class="box-body" style="padding:0px">*/
/* 					<table width="100%">*/
/* 					    <thead>*/
/* 						<tr class="headers">*/
/* 						    <th class="row entity_id" style="text-align:center">#</th>*/
/* 						    <th><input type="checkbox" onclick="clickDeviceAll(this);"></th>*/
/* 						    <th>ID</th>*/
/* 						    <th style="text-align:center">Status</th>*/
/* 						</tr>*/
/* 					    </thead>*/
/* 					    <form id="device_form" name="device_form" action="{{ path('deviceoutput_list') }}" method="post" target="list">*/
/* 					    <tbody id="device_scan">*/
/* 						{% for device in devices %}*/
/* 						<tr id="device_{{loop.index}}" style="display:none">*/
/* 						    <td id="device_index_{{device.id}}" style="text-align:center" width="15%"> {{ loop.index }} </td>*/
/* 						    <td><input id="check_{{loop.index}}" name="check_{{loop.index}}" type="checkbox" width="10%" value="{{device.deviceId}}" onclick="clickDevice(this);"></td>*/
/* 						    <td id="device_id_{{device.id}}" width="40%">{{ device.deviceId }}</td>*/
/* 						    <td width="35%">*/
/* 							<table align="center">*/
/* 							  <tr>*/
/* 							    <td style="width:10px; height:10px" id="device_status_{{device.id}}" {% if device.deviceStatus %} bgcolor="#00cc00" {% else %} bgcolor="#cc0000" {% endif %}></td>*/
/* 							  </tr>*/
/* 							</table>*/
/* 						    </td>*/
/* 						</tr>*/
/* 						{% endfor %}*/
/* 					    </tbody>*/
/* 					    </form>*/
/* 					</table>*/
/*  					<div align="center" id="device_pages"></div>*/
/* 				    </div>*/
/* 			    </div>*/
/* 			</div>*/
/* 		    </div>*/
/* 		</div>*/
/* 		</td>*/
/* 		<td width="80%" valign="top">*/
/* 			<iframe id="list" name="list" src="{{path('deviceoutput_list')}}" frameborder="0" scrolling="no" onload="resizeIframe(this);" width="100%"></iframe>*/
/* 		</td>*/
/* 	</tr>*/
/* </table>*/
/* {% endblock %} */
/* */
/* {% block javascripts %}*/
/*         */
/*         <script src="{{ asset('vendor/datatables/media/js/jquery.dataTables.js') }}"></script>*/
/*         <script src="{{ asset('vendor/datatables-bootstrap3-plugin/media/js/datatables-bootstrap3.js') }}"></script>*/
/* 	<script src="{{ asset('vendor/moment/min/moment-with-locales.min.js') }}"></script>*/
/* 	<script src="{{ asset('vendor/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js') }}"></script>*/
/*         <script src="{{ asset('vendor/bootbox/bootbox.js') }}"></script>*/
/*         <script src="{{ asset('js/tabla.js') }}"></script>*/
/*         <script src="{{ asset('js/crud.js') }}"></script>*/
/* */
/* 	<!--jquery just to call ajax-->*/
/* 	<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>*/
/* 	<script>*/
/* 	function resizeIframe(obj) {*/
/* 		obj.style.height = obj.contentWindow.document.body.scrollHeight + 'px';*/
/* 		//obj.style.width = obj.contentWindow.document.body.scrollWidth + 'px';*/
/* 	}*/
/* 	</script>*/
/* 	<script>*/
/* 	var deviceCount = {{device_count}};*/
/* 	var devicePageNumber = 1;*/
/* 	function getDeviceScan() */
/* 	{*/
/* 		var url = "{{ path('device_scan') }}";*/
/* 		$.ajax(url, {*/
/* 			data : null,*/
/* 			type : "GET",*/
/* 			success : function (response) {*/
/* 				//3.2 Check to see if connection is successful*/
/* 				$.each(response, function (key, value) {*/
/* 					var id = value["id"];*/
/* 					var device_id = value["device_id"];*/
/* 					var status = value["status"];*/
/* 					var alarm = value["alarm"];*/
/* */
/* 					var deviceStatusObj = document.getElementById("device_status_"+id);*/
/* 					if (deviceStatusObj)*/
/* 					{*/
/* 						if (status == "1")*/
/* 							deviceStatusObj.style.backgroundColor = "#00cc00";*/
/* 						else*/
/* 							deviceStatusObj.style.backgroundColor = "#cc0000";*/
/* 					}*/
/* 					var deviceIdObj = document.getElementById("device_id_"+id);*/
/* 					if (deviceIdObj)*/
/* 						deviceIdObj.innerHTML = device_id;*/
/* 				})*/
/* 				*/
/* 				console.dir(response);*/
/* 			}*/
/* 		});*/
/* 	}*/
/* 	function clickPageNumber(page_number) */
/* 	{*/
/* 		devicePageNumber = page_number;*/
/* 		initDeviceTable();*/
/* 	}*/
/* 	function initDeviceTable()*/
/* 	{*/
/* 		var countPerPage = document.getElementById("device_view").value;*/
/* 		var pageCount = parseInt(deviceCount / countPerPage);*/
/* 		if (deviceCount % countPerPage > 0)*/
/* 			pageCount++;*/
/* 		if (devicePageNumber > pageCount) */
/* 			devicePageNumber = pageCount;*/
/* */
/* 		// display*/
/* 		for (i = 1; i <= deviceCount; i++)*/
/* 		{*/
/* 			var obj = document.getElementById("device_"+i);*/
/* 			if ((i > (devicePageNumber-1)*countPerPage) && (i <= devicePageNumber*countPerPage))*/
/* 			{*/
/* 				obj.style.display = "";*/
/* 			}*/
/* 			else*/
/* 				obj.style.display = "none";*/
/* 		}*/
/* */
/* 		// page number*/
/* 		var pageObj = document.getElementById("device_pages");*/
/* 		var html = "";*/
/* 		for (i = 1; i <= pageCount; i++)*/
/* 		{*/
/* 			if (i == devicePageNumber)*/
/* 				html += i + "&nbsp;&nbsp";*/
/* 			else*/
/* 				html += "<a href='#' onclick='clickPageNumber("+i+");'>"+i+"</a>&nbsp;&nbsp";*/
/* 		}*/
/* 		pageObj.innerHTML = html;*/
/* 	}*/
/* 	initDeviceTable();*/
/* */
/* 	function autoRefresh () {*/
/* 	     //var count_per_page = document.getElementById("deviceview_row").value;*/
/* 	     //$("#scan").load("{{ path('device_scan') }}?count_per_page="+count_per_page+"&cur_page="+pageNumber, function() {*/
/* 	     //});*/
/* 	     getDeviceScan();*/
/* 	     setTimeout(autoRefresh, 1000);*/
/* 	}*/
/*         autoRefresh();*/
/* */
/* 	function clickDeviceAll(obj)*/
/* 	{*/
/* 		for (i = 1; i <= deviceCount; i++)*/
/* 			document.getElementById("check_"+i).checked = obj.checked;*/
/* */
/* 		var iframeObj = document.getElementById("list");*/
/* */
/* */
/* 		device_form.submit();*/
/* 	}*/
/* */
/* 	function clickDevice(obj)*/
/* 	{*/
/* 		var iframeObj = document.getElementById("list");*/
/* */
/* 		device_form.submit();*/
/* 	}*/
/* */
/* 	</script>*/
/* */
/* {% endblock %}*/
/* */
