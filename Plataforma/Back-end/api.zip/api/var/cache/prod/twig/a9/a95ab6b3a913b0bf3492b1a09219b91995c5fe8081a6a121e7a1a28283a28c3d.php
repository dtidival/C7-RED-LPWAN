<?php

/* :user:updatepasswordsuccess.html.twig */
class __TwigTemplate_ca2810a84ea7f41704a0f741b3b3b55141a990e0da14a44f1feafc1980232391 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
  <meta charset=\"utf-8\">
  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
  <title>Gesinen Updated Password</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content=\"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no\" name=\"viewport\">
 <link href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/bootstrap/dist/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>\t\t
 <link href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/fontawesome/css/font-awesome.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
 <link href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/admin-lte/dist/css/AdminLTE.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
 <!--<link href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/admin-lte/checkboxjs/blue.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>-->
 <link href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/admin-lte/checkboxjs/ionicons.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
 

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src=\"https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js\"></script>
  <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic\">
<link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css?family=Questrial\">
 <style>
 .wordpressRelatedFont{font-family:Questrial,sans-serif;}
 </style>
  </head>
<body class=\"hold-transition login-page\">
<div class=\"login-box\">
  <div class=\"login-logo\">
    <a href=\"http://www.app.gesinen.es/\"><b><img src=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/logo_nombre_der.png"), "html", null, true);
        echo "\" alt=\"Gesinen\" height=\"50\"></a>
  </div>
  <!-- /.login-logo -->
  <div class=\"login-box-body row \">   
\t\t<p class=\"login-box-msg wordpressRelatedFont\">";
        // line 37
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Your password has been changed"), "html", null, true);
        echo "</p>
\t\t<p class=\"login-box-msg wordpressRelatedFont\">";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Enjoy with gesinen, please"), "html", null, true);
        echo "!</p>
\t\t 
        
        <!-- /.col -->
        <div class=\"col-xs-4 col-xs-offset-4 \">
          <a href=\"";
        // line 43
        echo $this->env->getExtension('routing')->getPath("user_login");
        echo "\" class=\"btn btn-primary wordpressRelatedFont\" role=\"button\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("LOG IN"), "html", null, true);
        echo "</a>
        </div>
        <!-- /.col -->
       
  </div>
  
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 3 -->
<script src=\"";
        // line 54
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/web/assets/jquery/jquery.min.js"), "html", null, true);
        echo "\"></script> 
<script src=\"";
        // line 55
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/tether/tether.min.js"), "html", null, true);
        echo "\"></script>
  <script src=\"";
        // line 56
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/bootstrap/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>  
</body>
</html>
";
    }

    public function getTemplateName()
    {
        return ":user:updatepasswordsuccess.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  111 => 56,  107 => 55,  103 => 54,  87 => 43,  79 => 38,  75 => 37,  68 => 33,  45 => 13,  41 => 12,  37 => 11,  33 => 10,  29 => 9,  19 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/* <head>*/
/*   <meta charset="utf-8">*/
/*   <meta http-equiv="X-UA-Compatible" content="IE=edge">*/
/*   <title>Gesinen Updated Password</title>*/
/*   <!-- Tell the browser to be responsive to screen width -->*/
/*   <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">*/
/*  <link href="{{ asset('vendor/bootstrap/dist/css/bootstrap.min.css') }}" rel="stylesheet"/>		*/
/*  <link href="{{ asset('vendor/fontawesome/css/font-awesome.min.css') }}" rel="stylesheet"/>*/
/*  <link href="{{ asset('vendor/admin-lte/dist/css/AdminLTE.min.css') }}" rel="stylesheet"/>*/
/*  <!--<link href="{{ asset('vendor/admin-lte/checkboxjs/blue.css') }}" rel="stylesheet"/>-->*/
/*  <link href="{{ asset('vendor/admin-lte/checkboxjs/ionicons.min.css') }}" rel="stylesheet"/>*/
/*  */
/* */
/*   <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->*/
/*   <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->*/
/*   <!--[if lt IE 9]>*/
/*   <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>*/
/*   <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>*/
/*   <![endif]-->*/
/* */
/*   <!-- Google Font -->*/
/*   <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">*/
/* <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Questrial">*/
/*  <style>*/
/*  .wordpressRelatedFont{font-family:Questrial,sans-serif;}*/
/*  </style>*/
/*   </head>*/
/* <body class="hold-transition login-page">*/
/* <div class="login-box">*/
/*   <div class="login-logo">*/
/*     <a href="http://www.app.gesinen.es/"><b><img src="{{ asset('assets/images/logo_nombre_der.png') }}" alt="Gesinen" height="50"></a>*/
/*   </div>*/
/*   <!-- /.login-logo -->*/
/*   <div class="login-box-body row ">   */
/* 		<p class="login-box-msg wordpressRelatedFont">{{ 'Your password has been changed'|trans }}</p>*/
/* 		<p class="login-box-msg wordpressRelatedFont">{{ 'Enjoy with gesinen, please'|trans }}!</p>*/
/* 		 */
/*         */
/*         <!-- /.col -->*/
/*         <div class="col-xs-4 col-xs-offset-4 ">*/
/*           <a href="{{ path('user_login') }}" class="btn btn-primary wordpressRelatedFont" role="button">{{ 'LOG IN'|trans }}</a>*/
/*         </div>*/
/*         <!-- /.col -->*/
/*        */
/*   </div>*/
/*   */
/*   <!-- /.login-box-body -->*/
/* </div>*/
/* <!-- /.login-box -->*/
/* */
/* <!-- jQuery 3 -->*/
/* <script src="{{ asset('assets/web/assets/jquery/jquery.min.js') }}"></script> */
/* <script src="{{ asset('assets/tether/tether.min.js') }}"></script>*/
/*   <script src="{{ asset('assets/bootstrap/js/bootstrap.min.js') }}"></script>  */
/* </body>*/
/* </html>*/
/* */
