<?php

/* :user:manage.html.twig */
class __TwigTemplate_740183a1b4a9d505cb0090c789bce4a0d247f4b14a79fceb8620f4839413d69e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::basetrans_es.html.twig", ":user:manage.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::basetrans_es.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Devices";
    }

    // line 4
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 5
        echo "        
        <link href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/datatables-bootstrap3-plugin/media/css/datatables-bootstrap3.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
        <link href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("css/crud.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>";
    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        // line 12
        echo "<style>
th {
   width:15px;
   text-align: left;
}
.accordion-toggle{cursor:pointer;}
</style>
\t<div class=\"row\">
\t    <div class=\"col-md-12\">
\t\t<div class=\"box box-solid box-primary\">
\t\t    <div class=\"box-header with-border\">
\t\t\t<h3 class=\"box-title\">";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Manage Users"), "html", null, true);
        echo "</h3>
\t\t    </div>
\t\t    <div class=\"box-body\">
\t\t\t<div class=\"table-toolbar\">
\t\t\t\t<div class=\"btn-group\">
\t\t\t\t\t<a class=\"btn btn-success tooltips\" data-placement=\"right\" data-toggle=\"tooltip\" title=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Print"), "html", null, true);
        echo "\" href=\"#\" onclick=\"contentPrint();\"> <i class=\"fa fa-lg fa-print\"></i>
\t\t\t\t\t</a>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"accordion\" id=\"accordion\">
\t\t\t\t\t\t  <!-- Áreas -->
\t\t\t\t\t\t<div class=\"accordion-group\">
\t\t\t\t\t\t\t<!-- Área -->\t
\t\t\t<table  class=\"table table-bordered table-striped table-condensed flip-content datatable dt-multiselect export-excel\" 
\t\t\t    id=\"table-device\" 
\t\t\t    dataexport-title=\"device\">
\t\t\t    <thead>
\t\t\t\t <tr class=\"headers\">
\t\t\t\t\t<th class=\"no-order entity_id\">#</th>
\t\t\t\t\t<th>";
        // line 42
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("User"), "html", null, true);
        echo "</th>
\t\t\t\t\t<th>";
        // line 43
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("E-mail"), "html", null, true);
        echo "</th>
\t\t\t\t\t<th>";
        // line 44
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Phone"), "html", null, true);
        echo "</th>
\t\t\t\t\t<th>";
        // line 45
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Registry time"), "html", null, true);
        echo "</th>
\t\t\t\t\t<th>";
        // line 46
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Login time"), "html", null, true);
        echo "</th>
\t\t\t\t\t<th>";
        // line 47
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Permission"), "html", null, true);
        echo "</th>
\t\t\t\t\t<th>";
        // line 48
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Under"), "html", null, true);
        echo "</th>
\t\t\t\t\t<th>";
        // line 49
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Disable"), "html", null, true);
        echo "</th>
\t\t\t\t\t<th>";
        // line 50
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Temp. Allow"), "html", null, true);
        echo "</th>
\t\t\t\t\t<th class=\"text-center no-order ctn_acciones\">";
        // line 51
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Actions"), "html", null, true);
        echo "</th>
\t\t\t\t </tr>
\t\t\t    </thead>";
        // line 56
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["entities"]) ? $context["entities"] : null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["entity"]) {
            // line 57
            echo "\t\t\t\t\t
\t\t\t\t<tbody>\t
\t\t\t\t<tr id=\"status_";
            // line 59
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "id", array()), "html", null, true);
            echo "\" value=\"0\">
\t\t\t\t<form id=\"form_edit_";
            // line 60
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "id", array()), "html", null, true);
            echo "\" action=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("user_edit", array("id" => $this->getAttribute($context["entity"], "id", array()))), "html", null, true);
            echo "\" method=\"post\">
\t\t\t\t\t<td>";
            // line 61
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "</td>
\t\t\t\t\t<td class=\"\">
\t\t\t\t\t\t<div class=\"accordion-heading area\" id=\"test\">
\t\t\t\t\t\t\t<a class=\"accordion-toggle\" id=\"linkarea1";
            // line 64
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "\" data-toggle=\"collapse\" data-target=\"#area1";
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "firstName", array()), "html", null, true);
            echo "&nbsp;";
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "lastName", array()), "html", null, true);
            echo "</a>";
            // line 65
            if (($this->getAttribute($context["entity"], "permission", array()) == 2)) {
                // line 66
                echo "\t\t\t\t\t\t\t<div class=\"glyphicon glyphicon-plus\" style=\"float:left;position:relative;\"></div>";
            }
            // line 68
            echo "\t\t\t\t\t\t</div>\t\t\t\t\t
\t\t\t\t\t</td>\t\t\t\t\t
\t\t\t\t\t<td id=\"email_";
            // line 70
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "email", array()), "html", null, true);
            echo "</td>
\t\t\t\t\t<td id=\"phone_";
            // line 71
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "phone", array()), "html", null, true);
            echo "</td>
\t\t\t\t\t<td>";
            // line 72
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["entity"], "regDate", array()), "Y/m/d H:i"), "html", null, true);
            echo "</td>
\t\t\t\t\t<td>";
            // line 73
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["entity"], "lastTime", array()), "Y/m/d H:i"), "html", null, true);
            echo "</td>
\t\t\t\t\t<td id=\"permission_";
            // line 74
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "id", array()), "html", null, true);
            echo "\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "permission", array()), "html", null, true);
            echo "\">";
            // line 75
            if (($this->getAttribute($context["entity"], "permission", array()) == 0)) {
                echo "User";
            }
            // line 76
            if (($this->getAttribute($context["entity"], "permission", array()) == 1)) {
                echo "Administrator";
            }
            // line 77
            if (($this->getAttribute($context["entity"], "permission", array()) == 2)) {
                echo "Manager";
            }
            // line 78
            echo "\t\t\t\t\t</td>
\t\t\t\t\t<td id=\"under_";
            // line 79
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "id", array()), "html", null, true);
            echo "\" value=\"\"></td>
\t\t\t\t\t<td><input id=\"disable_";
            // line 80
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "id", array()), "html", null, true);
            echo "\" type=\"checkbox\" value=1";
            if (($this->getAttribute($context["entity"], "disable", array()) == 1)) {
                echo "checked";
            }
            echo " disabled readonly></td>
\t\t\t\t\t<td><input id=\"temp_allow_";
            // line 81
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "id", array()), "html", null, true);
            echo "\" type=\"checkbox\" value=1";
            if (($this->getAttribute($context["entity"], "temp_allow", array()) == 1)) {
                echo "checked";
            }
            echo " disabled readonly ></td>
\t\t\t\t\t<td class=\"ctn_acciones text-center nowrap\" width=\"10%\">
\t\t\t\t\t\t<a href=\"#\" onclick=\"clickEdit(";
            // line 83
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "id", array()), "html", null, true);
            echo ");\" class=\"btn btn-xs btn-success tooltips\" data-toggle=\"tooltip\" title=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Modify"), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t<i class=\"fa fa-pencil\"></i></a>
\t\t\t\t\t\t<a href=\"#\" onclick=\"borrar('";
            // line 85
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("user_delete", array("id" => $this->getAttribute($context["entity"], "id", array()))), "html", null, true);
            echo "')\" class=\"btn btn-xs btn-danger tooltips\" data-toggle=\"tooltip\" title=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Delete"), "html", null, true);
            echo "\">
\t\t\t\t\t\t<i class=\"fa fa-remove\"></i></a>
\t\t\t\t\t</td>
\t\t\t\t</form>
\t\t\t\t</tr>\t\t\t\t
\t\t\t    </tbody>
\t\t\t\t
\t\t\t\t<tbody  class=\"accordion-body collapse\" id=\"area1";
            // line 92
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "\">";
            // line 93
            $context["index"] = 0;
            // line 94
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["Onlyusers"]) ? $context["Onlyusers"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["Onlyuser"]) {
                // line 95
                if (($this->getAttribute($context["Onlyuser"], "under", array()) == $this->getAttribute($context["entity"], "id", array()))) {
                    // line 96
                    echo "\t\t\t\t\t<form id=\"form_edit_";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["Onlyuser"], "id", array()), "html", null, true);
                    echo "\" action=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("user_edit", array("id" => $this->getAttribute($context["Onlyuser"], "id", array()))), "html", null, true);
                    echo "\" method=\"post\">\t\t\t
\t\t\t\t\t<tr id=\"status_";
                    // line 97
                    echo twig_escape_filter($this->env, $this->getAttribute($context["Onlyuser"], "id", array()), "html", null, true);
                    echo "\" value=\"0\">
\t\t\t\t\t<td>";
                    // line 98
                    $context["index"] = ((isset($context["index"]) ? $context["index"] : null) + 1);
                    echo twig_escape_filter($this->env, (isset($context["index"]) ? $context["index"] : null), "html", null, true);
                    echo "</td>
\t\t\t\t\t<td>";
                    // line 99
                    echo twig_escape_filter($this->env, $this->getAttribute($context["Onlyuser"], "firstName", array()), "html", null, true);
                    echo "&nbsp;";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["Onlyuser"], "lastName", array()), "html", null, true);
                    echo "</td>
\t\t\t\t\t<td id=\"email_";
                    // line 100
                    echo twig_escape_filter($this->env, $this->getAttribute($context["Onlyuser"], "id", array()), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["Onlyuser"], "email", array()), "html", null, true);
                    echo "</td>
\t\t\t\t\t<td id=\"phone_";
                    // line 101
                    echo twig_escape_filter($this->env, $this->getAttribute($context["Onlyuser"], "id", array()), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["Onlyuser"], "phone", array()), "html", null, true);
                    echo "</td>
\t\t\t\t\t<td>";
                    // line 102
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["Onlyuser"], "regDate", array()), "Y/m/d H:i"), "html", null, true);
                    echo "</td>
\t\t\t\t\t<td>";
                    // line 103
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["Onlyuser"], "lastTime", array()), "Y/m/d H:i"), "html", null, true);
                    echo "</td>
\t\t\t\t\t<td id=\"permission_";
                    // line 104
                    echo twig_escape_filter($this->env, $this->getAttribute($context["Onlyuser"], "id", array()), "html", null, true);
                    echo "\" value=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["Onlyuser"], "permission", array()), "html", null, true);
                    echo "\">";
                    // line 105
                    if (($this->getAttribute($context["Onlyuser"], "permission", array()) == 0)) {
                        echo "User";
                    }
                    // line 106
                    if (($this->getAttribute($context["Onlyuser"], "permission", array()) == 1)) {
                        echo "Administrator";
                    }
                    // line 107
                    if (($this->getAttribute($context["Onlyuser"], "permission", array()) == 2)) {
                        echo "Manager";
                    }
                    // line 108
                    echo "\t\t\t\t\t</td>
\t\t\t\t\t<td id=\"under_";
                    // line 109
                    echo twig_escape_filter($this->env, $this->getAttribute($context["Onlyuser"], "id", array()), "html", null, true);
                    echo "\" value=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "id", array()), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "firstName", array()), "html", null, true);
                    echo "&nbsp;";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "lastName", array()), "html", null, true);
                    echo "</td>
\t\t\t\t\t<td><input id=\"disable_";
                    // line 110
                    echo twig_escape_filter($this->env, $this->getAttribute($context["Onlyuser"], "id", array()), "html", null, true);
                    echo "\" type=\"checkbox\" value=1";
                    if (($this->getAttribute($context["Onlyuser"], "disable", array()) == 1)) {
                        echo "checked";
                    }
                    echo " disabled readonly></td>
\t\t\t\t\t<td><input id=\"temp_allow_";
                    // line 111
                    echo twig_escape_filter($this->env, $this->getAttribute($context["Onlyuser"], "id", array()), "html", null, true);
                    echo "\" type=\"checkbox\" value=1";
                    if (($this->getAttribute($context["Onlyuser"], "temp_allow", array()) == 1)) {
                        echo "checked";
                    }
                    echo " disabled readonly ></td>
\t\t\t\t\t<td class=\"ctn_acciones text-center nowrap\" width=\"10%\">
\t\t\t\t\t\t<a href=\"#\" onclick=\"clickEdit(";
                    // line 113
                    echo twig_escape_filter($this->env, $this->getAttribute($context["Onlyuser"], "id", array()), "html", null, true);
                    echo ");\" class=\"btn btn-xs btn-success tooltips\" data-toggle=\"tooltip\" title=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Modify"), "html", null, true);
                    echo "\">
\t\t\t\t\t\t\t<i class=\"fa fa-pencil\"></i></a>
\t\t\t\t\t\t<a href=\"#\" onclick=\"borrar('";
                    // line 115
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("user_delete", array("id" => $this->getAttribute($context["Onlyuser"], "id", array()))), "html", null, true);
                    echo "')\" class=\"btn btn-xs btn-danger tooltips\" data-toggle=\"tooltip\" title=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Delete"), "html", null, true);
                    echo "\">
\t\t\t\t\t\t<i class=\"fa fa-remove\"></i></a>
\t\t\t\t\t</td>
\t\t\t\t</tr>
\t\t\t\t</form>";
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['Onlyuser'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 122
            echo "\t\t\t\t</tbody>";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['entity'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 125
        echo "\t\t\t\t
\t\t\t</table>
\t\t\t</div>
\t\t\t\t</div>
\t\t\t<!---------------------------------- Print ------------------------------------------------------------------->
\t\t\t<table 
\t\t\t    class=\"table table-bordered table-striped table-condensed flip-content datatable dt-multiselect 
\t\t\t    export-excel\" 
\t\t\t    dataexport-title=\"device\" 
\t\t\t    id=\"table-print\" name=\"table-print\" 
\t\t\t    style=\"display:none\">
\t\t\t\t<tr>
\t\t\t\t\t<td colspan=9><h3><i>&nbsp;&nbsp;GESINEN</i></h3>
\t\t\t\t\t\t<h4>&nbsp;&nbsp;Ardumaster Manager 1.0</h4>
\t\t\t\t\t\t<h4 align=\"right\">User Report&nbsp;&nbsp;</h4>
\t\t\t\t\t</td>
\t\t\t\t</tr>
\t\t\t\t <tr class=\"headers\">
\t\t\t\t\t<th class=\"no-order entity_id\">#</th>
\t\t\t\t\t<th>User</th>
\t\t\t\t\t<th>E-mail</th>
\t\t\t\t\t<th>Phone</th>
\t\t\t\t\t<th>Registry time</th>
\t\t\t\t\t<th>Login time</th>
\t\t\t\t\t<th>Permission</th>
\t\t\t\t\t<th>";
        // line 150
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Under"), "html", null, true);
        echo "</th>
\t\t\t\t\t<th>Disable</th>
\t\t\t\t\t<th>Temp. Allow</th>
\t\t\t\t </tr>";
        // line 154
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["entities"]) ? $context["entities"] : null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["entity"]) {
            // line 155
            echo "\t\t\t\t<tr>
\t\t\t\t\t<td>";
            // line 156
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "</td>
\t\t\t\t\t<td>";
            // line 157
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "firstName", array()), "html", null, true);
            echo "&nbsp;";
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "lastName", array()), "html", null, true);
            echo "</td>
\t\t\t\t\t<td>";
            // line 158
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "email", array()), "html", null, true);
            echo "</td>
\t\t\t\t\t<td class=\"phone-number-formate\">";
            // line 159
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "phone", array()), "html", null, true);
            echo "</td>
\t\t\t\t\t<td>";
            // line 160
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["entity"], "regDate", array()), "Y/m/d H:i"), "html", null, true);
            echo "</td>
\t\t\t\t\t<td>";
            // line 161
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["entity"], "lastTime", array()), "Y/m/d H:i"), "html", null, true);
            echo "</td>
\t\t\t\t\t<td>";
            // line 163
            if (($this->getAttribute($context["entity"], "permission", array()) == 0)) {
                echo "User";
            }
            // line 164
            if (($this->getAttribute($context["entity"], "permission", array()) == 1)) {
                echo "Administrator";
            }
            // line 165
            if (($this->getAttribute($context["entity"], "permission", array()) == 2)) {
                echo "Manager";
            }
            // line 166
            echo "\t\t\t\t\t</td>
\t\t\t\t\t<td></td>
\t\t\t\t\t<td><input id=\"disable_";
            // line 168
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "id", array()), "html", null, true);
            echo "\" type=\"checkbox\" value=1";
            if (($this->getAttribute($context["entity"], "disable", array()) == 1)) {
                echo "checked";
            }
            echo " disabled readonly></td>
\t\t\t\t\t<td><input id=\"temp_allow_";
            // line 169
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "id", array()), "html", null, true);
            echo "\" type=\"checkbox\" value=1";
            if (($this->getAttribute($context["entity"], "temp_allow", array()) == 1)) {
                echo "checked";
            }
            echo " disabled readonly></td>
\t\t\t\t<!--</form>-->
\t\t\t\t</tr>";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['entity'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 173
        echo "\t\t\t</table>
\t\t\t<!----------------------------------// Print ------------------------------------------------------------------->

\t\t    </div>
\t\t</div>
\t    </div>
\t</div>
<iframe src=\"\" name=\"edit_frame\" id=\"edit_frame\" style=\"width:1500px;height:800px;display:none\"></iframe>
<form id=\"edit_form\" name=\"edit_form\" target=\"edit_frame\" style=\"display:none\" method=\"post\">
\t<input id=\"email\" name=\"email\" type=\"text\">
\t<input id=\"phone\" name=\"phone\" type=\"text\">
\t<input id=\"permission\" name=\"permission\" type=\"text\">
\t<input id=\"under\" name=\"under\" type=\"text\">
\t<input id=\"disable\" name=\"disable\" type=\"checkbox\" value=\"1\">
\t<input id=\"temp_allow\" name=\"temp_allow\" type=\"checkbox\" value=\"1\">
</form>";
    }

    // line 191
    public function block_javascripts($context, array $blocks = array())
    {
        // line 192
        echo "        
        <script src=\"";
        // line 193
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/datatables/media/js/jquery.dataTables.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 194
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/datatables-bootstrap3-plugin/media/js/datatables-bootstrap3.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 195
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/bootbox/bootbox.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 196
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/tabla.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 197
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/crud.js"), "html", null, true);
        echo "\"></script>

\t<!--jquery just to call ajax-->

\t
\t  \t<script>
\t//for phone number format
\t
\t \$(\".phone-number-formate\").text(function(i, text) {
        text = text.replace(/(\\d\\d)(\\d\\d\\d)(\\d\\d)(\\d\\d)(\\d\\d)/, \"\$1 \$2 \$3 \$4 \$5\");
        return text;
    });
\t</script>
\t<script>
\t// for print

\t    function contentPrint() {
\t\twindow.print();
\t    }
\t    var initBody = \"\";
\t    var beforePrint = function() {
\t\tif (initBody == \"\")
\t\t\tinitBody = document.body.innerHTML;
\t\tvar obj = document.getElementById(\"table-print\");
\t\tobj.style.display = \"\";
\t\tdocument.body.innerHTML = obj.outerHTML;
\t    };
\t    var afterPrint = function() {
\t\tdocument.body.innerHTML = initBody;
\t\tinitBody = \"\";
\t    };

\t    if (window.matchMedia) {
\t\tvar mediaQueryList = window.matchMedia('print');
\t\tmediaQueryList.addListener(function(mql) {
\t\t    if (mql.matches) {
\t\t\tbeforePrint();
\t\t    } else {
\t\t\tafterPrint();
\t\t    }
\t\t});
\t    }

\t    window.onbeforeprint = beforePrint;
\t    window.onafterprint = afterPrint;
\t</script>
\t<script>
\tfunction clickEdit(uid)
\t{
\t\tdocument.getElementById(\"disable_\"+uid).disabled = false;
\t\tdocument.getElementById(\"temp_allow_\"+uid).disabled = false;
\t\t
\t\tvar statusObj = document.getElementById(\"status_\"+uid);

\t\tvar email_Obj = document.getElementById(\"email_\"+uid);
\t\tvar phone_Obj = document.getElementById(\"phone_\"+uid);
\t\tvar permission_Obj = document.getElementById(\"permission_\"+uid);
\t\tvar under_Obj = document.getElementById(\"under_\"+uid);\t\t
\t\tvar disable_Obj = document.getElementById(\"disable_\"+uid);
\t\tvar tempAllow_Obj = document.getElementById(\"temp_allow_\"+uid);
\t\tif (statusObj.getAttribute(\"value\") == 0)
\t\t{
\t\t\tif (confirm(\"";
        // line 259
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Are you really change this data"), "html", null, true);
        echo "?.\") == false) 
\t\t\t\treturn;

\t\t\tstatusObj.setAttribute(\"value\", 1);

\t\t\temail_Obj.innerHTML = '<input type=\"text\" style=\"width:100%\" value=\"'+email_Obj.innerText+'\">';
\t\t\tphone_Obj.innerHTML = '<input type=\"text\" style=\"width:100%\" value=\"'+phone_Obj.innerText+'\">';
\t\t\t
\t\t\tvar html = '<select>';
\t\t\t
\t\t\tif (permission_Obj.getAttribute(\"value\") == 0)
\t\t\t\thtml += '<option value=\"0\" selected>User</option>';
\t\t\telse
\t\t\t\thtml += '<option value=\"0\">User</option>';
\t\t\tif (permission_Obj.getAttribute(\"value\") == 1)
\t\t\t\thtml += '<option value=\"1\" selected>Administrator</option>';
\t\t\telse
\t\t\t\thtml += '<option value=\"1\">Administrator</option>';
\t\t\tif (permission_Obj.getAttribute(\"value\") == 2)
\t\t\t\thtml += '<option value=\"2\" selected>Manager</option>';
\t\t\telse
\t\t\t\thtml += '<option value=\"2\">Manager</option>';
\t\t\thtml += \"</select>\";

\t\t\tpermission_Obj.innerHTML = html;\t\t\t
\t\t\tif (permission_Obj.getAttribute(\"value\") == 0)
\t\t\t{
\t\t\tvar html = '<select>';
\t\t\thtml += '<option value=\"-1\">Select Manager</option>';";
        // line 288
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["unders"]) ? $context["unders"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["under"]) {
            echo "\t\t
\t\t\t\thtml += '<option value=\"";
            // line 289
            echo twig_escape_filter($this->env, $this->getAttribute($context["under"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["under"], "firstName", array()), "html", null, true);
            echo "&nbsp;";
            echo twig_escape_filter($this->env, $this->getAttribute($context["under"], "lastName", array()), "html", null, true);
            echo "</option>';";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['under'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 291
        echo "\t\t\thtml += \"</select>\";
\t\t\tunder_Obj.innerHTML = html;
\t\t\t}
\t\t}
\t\telse
\t\t{
\t\t\tdocument.getElementById(\"disable_\"+uid).disabled = true;
\t\t\tdocument.getElementById(\"temp_allow_\"+uid).disabled = true;
\t\t\t
\t\t\tstatusObj.setAttribute(\"value\", 0);

\t\t\tedit_form.action = document.getElementById(\"form_edit_\"+uid).action;
\t\t\tedit_form.email.value = email_Obj.childNodes[0]['value'];
\t\t\tedit_form.phone.value = phone_Obj.childNodes[0]['value'];
\t\t\tedit_form.permission.value = permission_Obj.childNodes[0]['value'];
\t\t\tif (permission_Obj.getAttribute(\"value\") == 0)
\t\t\t{
\t\t\tedit_form.under.value = under_Obj.childNodes[0]['value'];
\t\t\t}
\t\t\tedit_form.disable.checked = disable_Obj.checked;
\t\t\tedit_form.temp_allow.checked = tempAllow_Obj.checked;\t
\t\t\t
\t\t\tedit_form.submit();


\t\t\temail_Obj.innerHTML = email_Obj.childNodes[0]['value'];\t
\t\t\tphone_Obj.innerHTML = phone_Obj.childNodes[0]['value'];\t
\t\t\tif (permission_Obj.getAttribute(\"value\") == 0)
\t\t\t{
\t\t\tunder_Obj.innerHTML\t= under_Obj.childNodes[0]['value'];
\t\t\t}
\t\t\tpermission_Obj.setAttribute(\"value\", permission_Obj.childNodes[0]['value']);
\t\t\tif (permission_Obj.childNodes[0]['value'] == 0)
\t\t\t\tpermission_Obj.innerHTML = 'User';
\t\t\tif (permission_Obj.childNodes[0]['value'] == 1)
\t\t\t\tpermission_Obj.innerHTML = 'Administrator';
\t\t\tif (permission_Obj.childNodes[0]['value'] == 2)
\t\t\t\tpermission_Obj.innerHTML = 'Manager';
\t\t\t\tconsole.log(under_Objval);
\t\t\t\tconsole.log(edit_form.under.value);
\t\t\t\t
\t\t}
\t} 

\t
\$('#accordion')
  .on('show.bs.collapse', function(e) {
\t  changePluseMinus = 'link'+(e.target.id);
    \$(\"#\"+changePluseMinus).parent('.accordion-heading').find('div').addClass('glyphicon glyphicon-minus');    
  })
  .on('hide.bs.collapse', function(e) {
   \$(\"#\"+changePluseMinus).parent('.accordion-heading').find('div').removeClass('glyphicon glyphicon-minus');

 \$(\"#\"+changePluseMinus).parent('.accordion-heading').find('div').addClass('glyphicon glyphicon-plus');   
  });
\t</script>";
    }

    public function getTemplateName()
    {
        return ":user:manage.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  682 => 291,  671 => 289,  665 => 288,  634 => 259,  569 => 197,  565 => 196,  561 => 195,  557 => 194,  553 => 193,  550 => 192,  547 => 191,  528 => 173,  507 => 169,  499 => 168,  495 => 166,  491 => 165,  487 => 164,  483 => 163,  479 => 161,  475 => 160,  471 => 159,  467 => 158,  461 => 157,  457 => 156,  454 => 155,  437 => 154,  431 => 150,  404 => 125,  390 => 122,  376 => 115,  369 => 113,  360 => 111,  352 => 110,  342 => 109,  339 => 108,  335 => 107,  331 => 106,  327 => 105,  322 => 104,  318 => 103,  314 => 102,  308 => 101,  302 => 100,  296 => 99,  291 => 98,  287 => 97,  280 => 96,  278 => 95,  274 => 94,  272 => 93,  269 => 92,  257 => 85,  250 => 83,  241 => 81,  233 => 80,  229 => 79,  226 => 78,  222 => 77,  218 => 76,  214 => 75,  209 => 74,  205 => 73,  201 => 72,  195 => 71,  189 => 70,  185 => 68,  182 => 66,  180 => 65,  171 => 64,  165 => 61,  159 => 60,  155 => 59,  151 => 57,  134 => 56,  129 => 51,  125 => 50,  121 => 49,  117 => 48,  113 => 47,  109 => 46,  105 => 45,  101 => 44,  97 => 43,  93 => 42,  76 => 28,  68 => 23,  55 => 12,  52 => 11,  47 => 7,  43 => 6,  40 => 5,  37 => 4,  31 => 3,  11 => 1,);
    }
}
/*  {% extends '::basetrans_es.html.twig' %}  */
/* */
/* {% block title %}Devices{% endblock %}*/
/* {% block stylesheets %}*/
/*         */
/*         <link href="{{ asset('vendor/datatables-bootstrap3-plugin/media/css/datatables-bootstrap3.min.css') }}" rel="stylesheet"/>*/
/*         <link href="{{ asset('css/crud.css') }}" rel="stylesheet"/>*/
/* */
/* {% endblock %}*/
/* */
/* {% block body -%}*/
/* <style>*/
/* th {*/
/*    width:15px;*/
/*    text-align: left;*/
/* }*/
/* .accordion-toggle{cursor:pointer;}*/
/* </style>*/
/* 	<div class="row">*/
/* 	    <div class="col-md-12">*/
/* 		<div class="box box-solid box-primary">*/
/* 		    <div class="box-header with-border">*/
/* 			<h3 class="box-title">{{ 'Manage Users'|trans }}</h3>*/
/* 		    </div>*/
/* 		    <div class="box-body">*/
/* 			<div class="table-toolbar">*/
/* 				<div class="btn-group">*/
/* 					<a class="btn btn-success tooltips" data-placement="right" data-toggle="tooltip" title="{{ 'Print'|trans }}" href="#" onclick="contentPrint();"> <i class="fa fa-lg fa-print"></i>*/
/* 					</a>*/
/* 				</div>*/
/* 			</div>*/
/* 			<div class="accordion" id="accordion">*/
/* 						  <!-- Áreas -->*/
/* 						<div class="accordion-group">*/
/* 							<!-- Área -->	*/
/* 			<table  class="table table-bordered table-striped table-condensed flip-content datatable dt-multiselect export-excel" */
/* 			    id="table-device" */
/* 			    dataexport-title="device">*/
/* 			    <thead>*/
/* 				 <tr class="headers">*/
/* 					<th class="no-order entity_id">#</th>*/
/* 					<th>{{ 'User'|trans }}</th>*/
/* 					<th>{{ 'E-mail'|trans }}</th>*/
/* 					<th>{{ 'Phone'|trans }}</th>*/
/* 					<th>{{ 'Registry time'|trans }}</th>*/
/* 					<th>{{ 'Login time'|trans }}</th>*/
/* 					<th>{{ 'Permission'|trans }}</th>*/
/* 					<th>{{ 'Under'|trans }}</th>*/
/* 					<th>{{ 'Disable'|trans }}</th>*/
/* 					<th>{{ 'Temp. Allow'|trans }}</th>*/
/* 					<th class="text-center no-order ctn_acciones">{{ 'Actions'|trans }}</th>*/
/* 				 </tr>*/
/* 			    </thead>*/
/* 								*/
/* 			    			*/
/* 				{% for entity in entities %}*/
/* 					*/
/* 				<tbody>	*/
/* 				<tr id="status_{{entity.id}}" value="0">*/
/* 				<form id="form_edit_{{entity.id}}" action="{{ path( 'user_edit', { 'id': entity.id }) }}" method="post">*/
/* 					<td>{{loop.index}}</td>*/
/* 					<td class="">*/
/* 						<div class="accordion-heading area" id="test">*/
/* 							<a class="accordion-toggle" id="linkarea1{{loop.index}}" data-toggle="collapse" data-target="#area1{{loop.index}}">{{entity.firstName}}&nbsp;{{entity.lastName}}</a>*/
/* 							{% if entity.permission == 2 %}*/
/* 							<div class="glyphicon glyphicon-plus" style="float:left;position:relative;"></div>*/
/* 							{% endif %}*/
/* 						</div>					*/
/* 					</td>					*/
/* 					<td id="email_{{entity.id}}">{{entity.email}}</td>*/
/* 					<td id="phone_{{entity.id}}">{{entity.phone}}</td>*/
/* 					<td>{{ entity.regDate|date('Y/m/d H:i') }}</td>*/
/* 					<td>{{ entity.lastTime|date('Y/m/d H:i') }}</td>*/
/* 					<td id="permission_{{entity.id}}" value="{{entity.permission}}">*/
/* 						{% if entity.permission == 0 %}{{'User'}}{% endif %}*/
/* 						{% if entity.permission == 1 %}{{'Administrator'}}{% endif %}*/
/* 						{% if entity.permission == 2 %}{{'Manager'}}{% endif %}*/
/* 					</td>*/
/* 					<td id="under_{{entity.id}}" value=""></td>*/
/* 					<td><input id="disable_{{entity.id}}" type="checkbox" value=1 {% if entity.disable == 1 %} {{'checked'}} {% endif %} disabled readonly></td>*/
/* 					<td><input id="temp_allow_{{entity.id}}" type="checkbox" value=1 {% if entity.temp_allow == 1 %} {{'checked'}} {% endif %} disabled readonly ></td>*/
/* 					<td class="ctn_acciones text-center nowrap" width="10%">*/
/* 						<a href="#" onclick="clickEdit({{entity.id}});" class="btn btn-xs btn-success tooltips" data-toggle="tooltip" title="{{ 'Modify'|trans }}">*/
/* 							<i class="fa fa-pencil"></i></a>*/
/* 						<a href="#" onclick="borrar('{{ path('user_delete', {'id': entity.id}) }}')" class="btn btn-xs btn-danger tooltips" data-toggle="tooltip" title="{{ 'Delete'|trans }}">*/
/* 						<i class="fa fa-remove"></i></a>*/
/* 					</td>*/
/* 				</form>*/
/* 				</tr>				*/
/* 			    </tbody>*/
/* 				*/
/* 				<tbody  class="accordion-body collapse" id="area1{{loop.index}}">*/
/* 					{% set index = 0 %}*/
/* 					{% for Onlyuser in Onlyusers %}*/
/* 						{% if Onlyuser.under == entity.id %}*/
/* 					<form id="form_edit_{{Onlyuser.id}}" action="{{ path( 'user_edit', { 'id': Onlyuser.id }) }}" method="post">			*/
/* 					<tr id="status_{{Onlyuser.id}}" value="0">*/
/* 					<td>{% set index = index + 1 %}{{ index }}</td>*/
/* 					<td>{{Onlyuser.firstName}}&nbsp;{{Onlyuser.lastName}}</td>*/
/* 					<td id="email_{{Onlyuser.id}}">{{Onlyuser.email}}</td>*/
/* 					<td id="phone_{{Onlyuser.id}}">{{Onlyuser.phone}}</td>*/
/* 					<td>{{ Onlyuser.regDate|date('Y/m/d H:i') }}</td>*/
/* 					<td>{{ Onlyuser.lastTime|date('Y/m/d H:i') }}</td>*/
/* 					<td id="permission_{{Onlyuser.id}}" value="{{Onlyuser.permission}}">*/
/* 						{% if Onlyuser.permission == 0 %}{{'User'}}{% endif %}*/
/* 						{% if Onlyuser.permission == 1 %}{{'Administrator'}}{% endif %}*/
/* 						{% if Onlyuser.permission == 2 %}{{'Manager'}}{% endif %}*/
/* 					</td>*/
/* 					<td id="under_{{Onlyuser.id}}" value="{{entity.id}}">{{entity.firstName}}&nbsp;{{entity.lastName}}</td>*/
/* 					<td><input id="disable_{{Onlyuser.id}}" type="checkbox" value=1 {% if Onlyuser.disable == 1 %} {{'checked'}} {% endif %} disabled readonly></td>*/
/* 					<td><input id="temp_allow_{{Onlyuser.id}}" type="checkbox" value=1 {% if Onlyuser.temp_allow == 1 %} {{'checked'}} {% endif %} disabled readonly ></td>*/
/* 					<td class="ctn_acciones text-center nowrap" width="10%">*/
/* 						<a href="#" onclick="clickEdit({{Onlyuser.id}});" class="btn btn-xs btn-success tooltips" data-toggle="tooltip" title="{{ 'Modify'|trans }}">*/
/* 							<i class="fa fa-pencil"></i></a>*/
/* 						<a href="#" onclick="borrar('{{ path('user_delete', {'id': Onlyuser.id}) }}')" class="btn btn-xs btn-danger tooltips" data-toggle="tooltip" title="{{ 'Delete'|trans }}">*/
/* 						<i class="fa fa-remove"></i></a>*/
/* 					</td>*/
/* 				</tr>*/
/* 				</form>*/
/* 					{% endif %}*/
/* 					{% endfor %}*/
/* 				</tbody>*/
/* 				*/
/* 				{% endfor %}*/
/* 				*/
/* 			</table>*/
/* 			</div>*/
/* 				</div>*/
/* 			<!---------------------------------- Print ------------------------------------------------------------------->*/
/* 			<table */
/* 			    class="table table-bordered table-striped table-condensed flip-content datatable dt-multiselect */
/* 			    export-excel" */
/* 			    dataexport-title="device" */
/* 			    id="table-print" name="table-print" */
/* 			    style="display:none">*/
/* 				<tr>*/
/* 					<td colspan=9><h3><i>&nbsp;&nbsp;GESINEN</i></h3>*/
/* 						<h4>&nbsp;&nbsp;Ardumaster Manager 1.0</h4>*/
/* 						<h4 align="right">User Report&nbsp;&nbsp;</h4>*/
/* 					</td>*/
/* 				</tr>*/
/* 				 <tr class="headers">*/
/* 					<th class="no-order entity_id">#</th>*/
/* 					<th>User</th>*/
/* 					<th>E-mail</th>*/
/* 					<th>Phone</th>*/
/* 					<th>Registry time</th>*/
/* 					<th>Login time</th>*/
/* 					<th>Permission</th>*/
/* 					<th>{{ 'Under'|trans }}</th>*/
/* 					<th>Disable</th>*/
/* 					<th>Temp. Allow</th>*/
/* 				 </tr>*/
/* 				{% for entity in entities %}*/
/* 				<tr>*/
/* 					<td>{{loop.index}}</td>*/
/* 					<td>{{entity.firstName}}&nbsp;{{entity.lastName}}</td>*/
/* 					<td>{{entity.email}}</td>*/
/* 					<td class="phone-number-formate">{{entity.phone}}</td>*/
/* 					<td>{{ entity.regDate|date('Y/m/d H:i') }}</td>*/
/* 					<td>{{ entity.lastTime|date('Y/m/d H:i') }}</td>*/
/* 					<td>*/
/* 						{% if entity.permission == 0 %}{{'User'}}{% endif %}*/
/* 						{% if entity.permission == 1 %}{{'Administrator'}}{% endif %}*/
/* 						{% if entity.permission == 2 %}{{'Manager'}}{% endif %}*/
/* 					</td>*/
/* 					<td></td>*/
/* 					<td><input id="disable_{{entity.id}}" type="checkbox" value=1 {% if entity.disable == 1 %} {{'checked'}} {% endif %} disabled readonly></td>*/
/* 					<td><input id="temp_allow_{{entity.id}}" type="checkbox" value=1 {% if entity.temp_allow == 1 %} {{'checked'}} {% endif %} disabled readonly></td>*/
/* 				<!--</form>-->*/
/* 				</tr>*/
/* 				{% endfor %}*/
/* 			</table>*/
/* 			<!----------------------------------// Print ------------------------------------------------------------------->*/
/* */
/* 		    </div>*/
/* 		</div>*/
/* 	    </div>*/
/* 	</div>*/
/* <iframe src="" name="edit_frame" id="edit_frame" style="width:1500px;height:800px;display:none"></iframe>*/
/* <form id="edit_form" name="edit_form" target="edit_frame" style="display:none" method="post">*/
/* 	<input id="email" name="email" type="text">*/
/* 	<input id="phone" name="phone" type="text">*/
/* 	<input id="permission" name="permission" type="text">*/
/* 	<input id="under" name="under" type="text">*/
/* 	<input id="disable" name="disable" type="checkbox" value="1">*/
/* 	<input id="temp_allow" name="temp_allow" type="checkbox" value="1">*/
/* </form>*/
/* */
/* {% endblock %} */
/* {% block javascripts %}*/
/*         */
/*         <script src="{{ asset('vendor/datatables/media/js/jquery.dataTables.js') }}"></script>*/
/*         <script src="{{ asset('vendor/datatables-bootstrap3-plugin/media/js/datatables-bootstrap3.js') }}"></script>*/
/*         <script src="{{ asset('vendor/bootbox/bootbox.js') }}"></script>*/
/*         <script src="{{ asset('js/tabla.js') }}"></script>*/
/*         <script src="{{ asset('js/crud.js') }}"></script>*/
/* */
/* 	<!--jquery just to call ajax-->*/
/* */
/* 	*/
/* 	  	<script>*/
/* 	//for phone number format*/
/* 	*/
/* 	 $(".phone-number-formate").text(function(i, text) {*/
/*         text = text.replace(/(\d\d)(\d\d\d)(\d\d)(\d\d)(\d\d)/, "$1 $2 $3 $4 $5");*/
/*         return text;*/
/*     });*/
/* 	</script>*/
/* 	<script>*/
/* 	// for print*/
/* */
/* 	    function contentPrint() {*/
/* 		window.print();*/
/* 	    }*/
/* 	    var initBody = "";*/
/* 	    var beforePrint = function() {*/
/* 		if (initBody == "")*/
/* 			initBody = document.body.innerHTML;*/
/* 		var obj = document.getElementById("table-print");*/
/* 		obj.style.display = "";*/
/* 		document.body.innerHTML = obj.outerHTML;*/
/* 	    };*/
/* 	    var afterPrint = function() {*/
/* 		document.body.innerHTML = initBody;*/
/* 		initBody = "";*/
/* 	    };*/
/* */
/* 	    if (window.matchMedia) {*/
/* 		var mediaQueryList = window.matchMedia('print');*/
/* 		mediaQueryList.addListener(function(mql) {*/
/* 		    if (mql.matches) {*/
/* 			beforePrint();*/
/* 		    } else {*/
/* 			afterPrint();*/
/* 		    }*/
/* 		});*/
/* 	    }*/
/* */
/* 	    window.onbeforeprint = beforePrint;*/
/* 	    window.onafterprint = afterPrint;*/
/* 	</script>*/
/* 	<script>*/
/* 	function clickEdit(uid)*/
/* 	{*/
/* 		document.getElementById("disable_"+uid).disabled = false;*/
/* 		document.getElementById("temp_allow_"+uid).disabled = false;*/
/* 		*/
/* 		var statusObj = document.getElementById("status_"+uid);*/
/* */
/* 		var email_Obj = document.getElementById("email_"+uid);*/
/* 		var phone_Obj = document.getElementById("phone_"+uid);*/
/* 		var permission_Obj = document.getElementById("permission_"+uid);*/
/* 		var under_Obj = document.getElementById("under_"+uid);		*/
/* 		var disable_Obj = document.getElementById("disable_"+uid);*/
/* 		var tempAllow_Obj = document.getElementById("temp_allow_"+uid);*/
/* 		if (statusObj.getAttribute("value") == 0)*/
/* 		{*/
/* 			if (confirm("{{ 'Are you really change this data'|trans }}?.") == false) */
/* 				return;*/
/* */
/* 			statusObj.setAttribute("value", 1);*/
/* */
/* 			email_Obj.innerHTML = '<input type="text" style="width:100%" value="'+email_Obj.innerText+'">';*/
/* 			phone_Obj.innerHTML = '<input type="text" style="width:100%" value="'+phone_Obj.innerText+'">';*/
/* 			*/
/* 			var html = '<select>';*/
/* 			*/
/* 			if (permission_Obj.getAttribute("value") == 0)*/
/* 				html += '<option value="0" selected>User</option>';*/
/* 			else*/
/* 				html += '<option value="0">User</option>';*/
/* 			if (permission_Obj.getAttribute("value") == 1)*/
/* 				html += '<option value="1" selected>Administrator</option>';*/
/* 			else*/
/* 				html += '<option value="1">Administrator</option>';*/
/* 			if (permission_Obj.getAttribute("value") == 2)*/
/* 				html += '<option value="2" selected>Manager</option>';*/
/* 			else*/
/* 				html += '<option value="2">Manager</option>';*/
/* 			html += "</select>";*/
/* */
/* 			permission_Obj.innerHTML = html;			*/
/* 			if (permission_Obj.getAttribute("value") == 0)*/
/* 			{*/
/* 			var html = '<select>';*/
/* 			html += '<option value="-1">Select Manager</option>';	*/
/* 			{% for under in unders %}		*/
/* 				html += '<option value="{{under.id}}">{{under.firstName}}&nbsp;{{under.lastName}}</option>';			*/
/* 			{% endfor %}*/
/* 			html += "</select>";*/
/* 			under_Obj.innerHTML = html;*/
/* 			}*/
/* 		}*/
/* 		else*/
/* 		{*/
/* 			document.getElementById("disable_"+uid).disabled = true;*/
/* 			document.getElementById("temp_allow_"+uid).disabled = true;*/
/* 			*/
/* 			statusObj.setAttribute("value", 0);*/
/* */
/* 			edit_form.action = document.getElementById("form_edit_"+uid).action;*/
/* 			edit_form.email.value = email_Obj.childNodes[0]['value'];*/
/* 			edit_form.phone.value = phone_Obj.childNodes[0]['value'];*/
/* 			edit_form.permission.value = permission_Obj.childNodes[0]['value'];*/
/* 			if (permission_Obj.getAttribute("value") == 0)*/
/* 			{*/
/* 			edit_form.under.value = under_Obj.childNodes[0]['value'];*/
/* 			}*/
/* 			edit_form.disable.checked = disable_Obj.checked;*/
/* 			edit_form.temp_allow.checked = tempAllow_Obj.checked;	*/
/* 			*/
/* 			edit_form.submit();*/
/* */
/* */
/* 			email_Obj.innerHTML = email_Obj.childNodes[0]['value'];	*/
/* 			phone_Obj.innerHTML = phone_Obj.childNodes[0]['value'];	*/
/* 			if (permission_Obj.getAttribute("value") == 0)*/
/* 			{*/
/* 			under_Obj.innerHTML	= under_Obj.childNodes[0]['value'];*/
/* 			}*/
/* 			permission_Obj.setAttribute("value", permission_Obj.childNodes[0]['value']);*/
/* 			if (permission_Obj.childNodes[0]['value'] == 0)*/
/* 				permission_Obj.innerHTML = 'User';*/
/* 			if (permission_Obj.childNodes[0]['value'] == 1)*/
/* 				permission_Obj.innerHTML = 'Administrator';*/
/* 			if (permission_Obj.childNodes[0]['value'] == 2)*/
/* 				permission_Obj.innerHTML = 'Manager';*/
/* 				console.log(under_Objval);*/
/* 				console.log(edit_form.under.value);*/
/* 				*/
/* 		}*/
/* 	} */
/* */
/* 	*/
/* $('#accordion')*/
/*   .on('show.bs.collapse', function(e) {*/
/* 	  changePluseMinus = 'link'+(e.target.id);*/
/*     $("#"+changePluseMinus).parent('.accordion-heading').find('div').addClass('glyphicon glyphicon-minus');    */
/*   })*/
/*   .on('hide.bs.collapse', function(e) {*/
/*    $("#"+changePluseMinus).parent('.accordion-heading').find('div').removeClass('glyphicon glyphicon-minus');*/
/* */
/*  $("#"+changePluseMinus).parent('.accordion-heading').find('div').addClass('glyphicon glyphicon-plus');   */
/*   });*/
/* 	</script>*/
/* {% endblock %}*/
/* */
