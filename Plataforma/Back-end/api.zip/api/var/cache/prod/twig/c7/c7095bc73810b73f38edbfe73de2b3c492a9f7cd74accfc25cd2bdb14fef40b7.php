<?php

/* :user:updatepassword.html.twig */
class __TwigTemplate_656dd1c6b3c4ef3c6097d791f0a1d28859e2f0abd6bf6ebfa6e929ad3c3aa0e7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
  <meta charset=\"utf-8\">
  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
  <title>Gesinen Update Password</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content=\"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no\" name=\"viewport\">
 <link href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/bootstrap/dist/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>\t\t
 <link href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/fontawesome/css/font-awesome.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
 <link href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/admin-lte/dist/css/AdminLTE.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
 <!--<link href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/admin-lte/checkboxjs/blue.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>-->
 <link href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("vendor/admin-lte/checkboxjs/ionicons.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
 

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src=\"https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js\"></script>
  <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic\">
<link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css?family=Questrial\">
 <style>
 .wordpressRelatedFont{font-family:Questrial,sans-serif;}
 </style>
  </head>
<body class=\"hold-transition login-page\">
<div class=\"login-box\">
  <div class=\"login-logo\">
    <a href=\"http://www.app.gesinen.es/\"><b><img src=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/logo_nombre_der.png"), "html", null, true);
        echo "\" alt=\"Gesinen\" height=\"50\"></a>
  </div>
  <!-- /.login-logo -->
  <div class=\"login-box-body\">
    <p class=\"login-box-msg\">";
        // line 37
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Change PASSWORD"), "html", null, true);
        echo "</p>";
        // line 38
        if (((isset($context["status"]) ? $context["status"] : null) == "FAILED")) {
            // line 39
            echo "\t\t    <small><font color=red class=\"wordpressRelatedFont\">";
            echo twig_escape_filter($this->env, (isset($context["error"]) ? $context["error"] : null), "html", null, true);
            echo "</font></small>";
        } else {
            // line 41
            echo "\t\t    <p class=\"wordpressRelatedFont\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Please enter your new password"), "html", null, true);
            echo ".</p>";
        }
        // line 43
        echo "\t\t\t<form action=\"";
        echo $this->env->getExtension('routing')->getPath("user_updatepassword");
        echo "\" method=\"post\">
      <div class=\"form-group has-feedback\">
        <input type=\"password\" class=\"form-control wordpressRelatedFont\"  name=\"pwd\" required=\"\" data-form-field=\"Name\" id=\"pwd\" value=\"\" placeholder=\"";
        // line 45
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("New Password"), "html", null, true);
        echo "\">
        <span class=\"glyphicon glyphicon-envelope form-control-feedback\"></span>
\t\t<input type=\"hidden\" class=\"form-control wordpressRelatedFont\" name=\"id\" required=\"\" data-form-field=\"Name\" id=\"id\" value=\"";
        // line 47
        echo twig_escape_filter($this->env, (isset($context["id"]) ? $context["id"] : null), "html", null, true);
        echo "\">
\t\t<input type=\"hidden\" class=\"form-control wordpressRelatedFont\" name=\"email\" required=\"\" data-form-field=\"Name\" id=\"email\" value=\"";
        // line 48
        echo twig_escape_filter($this->env, (isset($context["e_mail"]) ? $context["e_mail"] : null), "html", null, true);
        echo "\">
      </div>
      
      <div class=\"row\">        
        <!-- /.col -->
        <div class=\"col-xs-4\">
          <button type=\"submit\" class=\"btn btn-primary btn-block btn-flat wordpressRelatedFont\">";
        // line 54
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("SUBMIT"), "html", null, true);
        echo "</button>
        </div>
        <!-- /.col -->
      </div>
    </form>
  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 3 -->
<script src=\"";
        // line 65
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/web/assets/jquery/jquery.min.js"), "html", null, true);
        echo "\"></script> 
<script src=\"";
        // line 66
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/tether/tether.min.js"), "html", null, true);
        echo "\"></script>
  <script src=\"";
        // line 67
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/bootstrap/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>  
</body>
</html>
";
    }

    public function getTemplateName()
    {
        return ":user:updatepassword.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  136 => 67,  132 => 66,  128 => 65,  114 => 54,  105 => 48,  101 => 47,  96 => 45,  90 => 43,  85 => 41,  80 => 39,  78 => 38,  75 => 37,  68 => 33,  45 => 13,  41 => 12,  37 => 11,  33 => 10,  29 => 9,  19 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/* <head>*/
/*   <meta charset="utf-8">*/
/*   <meta http-equiv="X-UA-Compatible" content="IE=edge">*/
/*   <title>Gesinen Update Password</title>*/
/*   <!-- Tell the browser to be responsive to screen width -->*/
/*   <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">*/
/*  <link href="{{ asset('vendor/bootstrap/dist/css/bootstrap.min.css') }}" rel="stylesheet"/>		*/
/*  <link href="{{ asset('vendor/fontawesome/css/font-awesome.min.css') }}" rel="stylesheet"/>*/
/*  <link href="{{ asset('vendor/admin-lte/dist/css/AdminLTE.min.css') }}" rel="stylesheet"/>*/
/*  <!--<link href="{{ asset('vendor/admin-lte/checkboxjs/blue.css') }}" rel="stylesheet"/>-->*/
/*  <link href="{{ asset('vendor/admin-lte/checkboxjs/ionicons.min.css') }}" rel="stylesheet"/>*/
/*  */
/* */
/*   <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->*/
/*   <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->*/
/*   <!--[if lt IE 9]>*/
/*   <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>*/
/*   <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>*/
/*   <![endif]-->*/
/* */
/*   <!-- Google Font -->*/
/*   <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">*/
/* <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Questrial">*/
/*  <style>*/
/*  .wordpressRelatedFont{font-family:Questrial,sans-serif;}*/
/*  </style>*/
/*   </head>*/
/* <body class="hold-transition login-page">*/
/* <div class="login-box">*/
/*   <div class="login-logo">*/
/*     <a href="http://www.app.gesinen.es/"><b><img src="{{ asset('assets/images/logo_nombre_der.png') }}" alt="Gesinen" height="50"></a>*/
/*   </div>*/
/*   <!-- /.login-logo -->*/
/*   <div class="login-box-body">*/
/*     <p class="login-box-msg">{{ 'Change PASSWORD'|trans }}</p>*/
/* 	{% if status == 'FAILED' %}*/
/* 		    <small><font color=red class="wordpressRelatedFont">{{ error }}</font></small>*/
/* 		    {% else %}*/
/* 		    <p class="wordpressRelatedFont">{{ 'Please enter your new password'|trans }}.</p>*/
/* 		    {% endif %}*/
/* 			<form action="{{ path('user_updatepassword') }}" method="post">*/
/*       <div class="form-group has-feedback">*/
/*         <input type="password" class="form-control wordpressRelatedFont"  name="pwd" required="" data-form-field="Name" id="pwd" value="" placeholder="{{ 'New Password'|trans }}">*/
/*         <span class="glyphicon glyphicon-envelope form-control-feedback"></span>*/
/* 		<input type="hidden" class="form-control wordpressRelatedFont" name="id" required="" data-form-field="Name" id="id" value="{{id}}">*/
/* 		<input type="hidden" class="form-control wordpressRelatedFont" name="email" required="" data-form-field="Name" id="email" value="{{e_mail}}">*/
/*       </div>*/
/*       */
/*       <div class="row">        */
/*         <!-- /.col -->*/
/*         <div class="col-xs-4">*/
/*           <button type="submit" class="btn btn-primary btn-block btn-flat wordpressRelatedFont">{{ 'SUBMIT'|trans }}</button>*/
/*         </div>*/
/*         <!-- /.col -->*/
/*       </div>*/
/*     </form>*/
/*   </div>*/
/*   <!-- /.login-box-body -->*/
/* </div>*/
/* <!-- /.login-box -->*/
/* */
/* <!-- jQuery 3 -->*/
/* <script src="{{ asset('assets/web/assets/jquery/jquery.min.js') }}"></script> */
/* <script src="{{ asset('assets/tether/tether.min.js') }}"></script>*/
/*   <script src="{{ asset('assets/bootstrap/js/bootstrap.min.js') }}"></script>  */
/* </body>*/
/* </html>*/
/* */
