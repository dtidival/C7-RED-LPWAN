<?php

/* :default:index.html.twig */
class __TwigTemplate_f4a50676c6e3c002e0ce264344b6ed40e78817cdb20c57274170a930ee5ed10d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
  <!-- Site made with Mobirise Website Builder v3.6, https://mobirise.com -->
  <meta charset=\"UTF-8\">
  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
  <meta name=\"generator\" content=\"Mobirise v3.6, mobirise.com\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
  <link rel=\"shortcut icon\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/logo.png"), "html", null, true);
        echo "\" type=\"image/x-icon\">
  <meta name=\"description\" content=\"\">
  
  <link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic&amp;subset=latin\">
  <link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css?family=Montserrat:400,700\">
  <link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900\">
  <link rel=\"stylesheet\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/et-line-font-plugin/style.css"), "html", null, true);
        echo "\">
  <link rel=\"stylesheet\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/bootstrap-material-design-font/css/material.css"), "html", null, true);
        echo "\">
  <link rel=\"stylesheet\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/tether/tether.min.css"), "html", null, true);
        echo "\">
  <link rel=\"stylesheet\" href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\">
  <link rel=\"stylesheet\" href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/socicon/css/socicon.min.css"), "html", null, true);
        echo "\">
  <link rel=\"stylesheet\" href=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/animate.css/animate.min.css"), "html", null, true);
        echo "\">
  <link rel=\"stylesheet\" href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/dropdown/css/style.css"), "html", null, true);
        echo "\">
  <link rel=\"stylesheet\" href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/theme/css/style.css"), "html", null, true);
        echo "\">
  <link rel=\"stylesheet\" href=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/mobirise/css/mbr-additional.css"), "html", null, true);
        echo "\" type=\"text/css\">
  
  
  
</head>
<body>
<section id=\"menu-0\">

    <nav class=\"navbar navbar-dropdown bg-color transparent navbar-fixed-top\">
        <div class=\"container\">

            <div class=\"mbr-table\">
                <div class=\"mbr-table-cell\">

                    <div class=\"navbar-brand\">
                        <a href=\"http://www.clevertechnik.com\" class=\"navbar-logo\"><img src=\"";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/logo.png"), "html", null, true);
        echo "\" alt=\"Mobirise\"></a>
                        <a class=\"navbar-caption\" href=\"http://www.clevertechnik.com\">Clevertechnik</a>
                    </div>

                </div>
\t\t
                <div class=\"mbr-table-cell\">

                    <button class=\"navbar-toggler pull-xs-right hidden-md-up\" type=\"button\" data-toggle=\"collapse\" data-target=\"#exCollapsingNavbar\">
                        <div class=\"hamburger-icon\"></div>
                    </button>

                    <ul class=\"nav-dropdown collapse pull-xs-right nav navbar-nav navbar-toggleable-sm\" id=\"exCollapsingNavbar\"><li class=\"nav-item dropdown\"><a class=\"nav-link link\" href=\"https://mobirise.com/\" aria-expanded=\"false\">CONTACT US</a></li><li class=\"nav-item nav-btn\"><a class=\"nav-link btn btn-white btn-white-outline\" href=\"";
        // line 50
        echo $this->env->getExtension('routing')->getPath("user_login");
        echo "\">LOG IN</a></li></ul>
                    <button hidden=\"\" class=\"navbar-toggler navbar-close\" type=\"button\" data-toggle=\"collapse\" data-target=\"#exCollapsingNavbar\">
                        <div class=\"close-icon\"></div>
                    </button>

                </div>
\t\t
            </div>

        </div>
    </nav>

</section>

<section class=\"engine\"><a rel=\"external\" href=\"http://www.clevertechnik.com\">top wysiwyg web site builder software download</a></section><section class=\"mbr-section mbr-section-hero mbr-section-full mbr-section-with-arrow mbr-after-navbar\" id=\"header4-0\" data-bg-video=\"https://www.youtube.com/watch?v=uNCr7NdOJgw\">

    <div class=\"mbr-overlay\" style=\"opacity: 0.5; background-color: rgb(0, 0, 0);\"></div>

    <div class=\"mbr-table-cell\">

        <div class=\"container\">
            <div class=\"row\">
                <div class=\"mbr-section col-md-10 col-md-offset-2 text-xs-right\">

                    <h1 class=\"mbr-section-title display-1\">GESTIÓN &nbsp;INTELIGENTE DEL ENTORNO</h1>
                    <p class=\"mbr-section-lead lead\">CLEVERTECHNIK ha desarrollado una solución que permite la gestión sostenible e inteligente del alumbrado público. &nbsp;<br><br></p>
                    <div class=\"mbr-section-btn\"><a class=\"btn btn-lg btn-success\" href=\"http://www.clevertechnik.com\">MORE INFORMATION</a> <a class=\"btn btn-lg btn-warning\" href=\"http://www.clevertechnik.com\">CONTACT US</a></div>
                </div>
            </div>
        </div>
    </div>

    <div class=\"mbr-arrow mbr-arrow-floating\" aria-hidden=\"true\"><a href=\"#msg-box5-0\"><i class=\"mbr-arrow-icon\"></i></a></div>

</section>

<section class=\"mbr-section\" id=\"msg-box5-0\" style=\"background-color: rgb(255, 255, 255); padding-top: 0px; padding-bottom: 0px;\">

    
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"mbr-table-md-up\">

              

              <div class=\"mbr-table-cell mbr-right-padding-md-up col-md-5 text-xs-center text-md-right\">
                  <h3 class=\"mbr-section-title display-2\">SOLID COLOR INTRO WITH IMAGE</h3>
                  <div class=\"lead\">

                    <p>Solid color intro with an image on the right side. Also this block has no paddings.</p>

                  </div>

                  <div><a class=\"btn btn-primary\" href=\"http://www.clevertechnik.com\">MORE</a></div>
              </div>


              


              <div class=\"mbr-table-cell mbr-valign-top col-md-7\">
                  <div class=\"mbr-figure\"><img src=\"";
        // line 111
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/desktop.jpg"), "html", null, true);
        echo "\"></div>
              </div>

            </div>
        </div>
    </div>

</section>

<section class=\"mbr-section mbr-parallax-background\" id=\"content5-0\" style=\"background-image: url(";
        // line 120
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/desert2.jpg"), "html", null, true);
        echo "); padding-top: 120px; padding-bottom: 120px;\">

    <div class=\"mbr-overlay\" style=\"opacity: 0.5; background-color: rgb(0, 0, 0);\">
    </div>

    <div class=\"container\">
        <h3 class=\"mbr-section-title display-2\">BACKGROUND IMAGE</h3>
        <div class=\"lead\"><p>Background image with solid color overlay and parallax effect. Develop fully responsive, mobile-ready websites that look amazing on any devices and browsers. Preview how your website will appear on phones, tablets and desktops directly in the visual editor.</p></div>
    </div>

</section>

<section class=\"mbr-info mbr-info-extra mbr-section mbr-section-md-padding\" id=\"msg-box1-0\" style=\"background-color: rgb(242, 242, 242); padding-top: 90px; padding-bottom: 90px;\">

    <div class=\"container\">
        <div class=\"row\">

            <div class=\"mbr-table-md-up\">
                <div class=\"mbr-table-cell mbr-right-padding-md-up col-md-8 text-xs-center text-md-left\">
                    <h2 class=\"mbr-info-subtitle mbr-section-subtitle\">Create awesome mobile-friendly websites. No coding and free.</h2>
                    <h3 class=\"mbr-info-title mbr-section-title display-2\">PRE MADE BLOCKS</h3>
                </div>

                <div class=\"mbr-table-cell col-md-4\">
                    <div class=\"text-xs-center\"><a class=\"btn btn-primary\" href=\"http://www.clevertechnik.com\">SEE LIVE DEMO</a></div>
                </div>
            </div>


        </div>
    </div>
</section>

<section class=\"mbr-section mbr-section-md-padding mbr-footer footer1\" id=\"contacts1-0\" style=\"background-color: rgb(46, 46, 46); padding-top: 90px; padding-bottom: 90px;\">
    
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"mbr-footer-content col-xs-12 col-md-3\">
                <div><img src=\"";
        // line 158
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/logo.png"), "html", null, true);
        echo "\"></div>
            </div>
            <div class=\"mbr-footer-content col-xs-12 col-md-3\">
                <p><strong>Address</strong><br>
\t\t1234 Street Name<br>
\t\tCity, AA 99999</p>
            </div>
            <div class=\"mbr-footer-content col-xs-12 col-md-3\">
                <p><strong>Contacts</strong><br>
\t\tEmail: support@mobirise.com<br>
\t\tPhone: +1 (0) 000 0000 001<br>
\t\tFax: +1 (0) 000 0000 002</p>
            </div>
            <div class=\"mbr-footer-content col-xs-12 col-md-3\">
                <p><strong>Links</strong><br>
\t\t<a class=\"text-primary\" href=\"https://mobirise.com/\">Website builder</a><br>
\t\t<a class=\"text-primary\" href=\"https://mobirise.com/mobirise-free-win.zip\">Download for Windows</a><br>
\t\t<a class=\"text-primary\" href=\"https://mobirise.com/mobirise-free-mac.zip\">Download for Mac</a></p>
            </div>

        </div>
    </div>
</section>

<footer class=\"mbr-small-footer mbr-section mbr-section-nopadding\" id=\"footer1-2\" style=\"background-color: rgb(50, 50, 50); padding-top: 1.75rem; padding-bottom: 1.75rem;\">
    
    <div class=\"container\">
        <p class=\"text-xs-center\">Copyright (c) 2016 Mobirise.</p>
    </div>
</footer>


  <script src=\"";
        // line 190
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/web/assets/jquery/jquery.min.js"), "html", null, true);
        echo "\"></script>
  <script src=\"";
        // line 191
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/tether/tether.min.js"), "html", null, true);
        echo "\"></script>
  <script src=\"";
        // line 192
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/bootstrap/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
  <script src=\"";
        // line 193
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/smooth-scroll/SmoothScroll.js"), "html", null, true);
        echo "\"></script>
  <script src=\"";
        // line 194
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/viewportChecker/jquery.viewportchecker.js"), "html", null, true);
        echo "\"></script>
  <script src=\"";
        // line 195
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/dropdown/js/script.min.js"), "html", null, true);
        echo "\"></script>
  <script src=\"";
        // line 196
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/touchSwipe/jquery.touchSwipe.min.js"), "html", null, true);
        echo "\"></script>
  <script src=\"";
        // line 197
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/jquery-mb-ytplayer/jquery.mb.YTPlayer.min.js"), "html", null, true);
        echo "\"></script>
  <script src=\"";
        // line 198
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/jarallax/jarallax.js"), "html", null, true);
        echo "\"></script>
  <script src=\"";
        // line 199
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/theme/js/script.js"), "html", null, true);
        echo "\"></script>
  
  
  <input name=\"animation\" type=\"hidden\">
  </body>
</html>";
    }

    public function getTemplateName()
    {
        return ":default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  291 => 199,  287 => 198,  283 => 197,  279 => 196,  275 => 195,  271 => 194,  267 => 193,  263 => 192,  259 => 191,  255 => 190,  220 => 158,  179 => 120,  167 => 111,  103 => 50,  88 => 38,  70 => 23,  66 => 22,  62 => 21,  58 => 20,  54 => 19,  50 => 18,  46 => 17,  42 => 16,  38 => 15,  29 => 9,  19 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/* <head>*/
/*   <!-- Site made with Mobirise Website Builder v3.6, https://mobirise.com -->*/
/*   <meta charset="UTF-8">*/
/*   <meta http-equiv="X-UA-Compatible" content="IE=edge">*/
/*   <meta name="generator" content="Mobirise v3.6, mobirise.com">*/
/*   <meta name="viewport" content="width=device-width, initial-scale=1">*/
/*   <link rel="shortcut icon" href="{{ asset('assets/images/logo.png') }}" type="image/x-icon">*/
/*   <meta name="description" content="">*/
/*   */
/*   <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic&amp;subset=latin">*/
/*   <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,700">*/
/*   <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900">*/
/*   <link rel="stylesheet" href="{{ asset('assets/et-line-font-plugin/style.css') }}">*/
/*   <link rel="stylesheet" href="{{ asset('assets/bootstrap-material-design-font/css/material.css') }}">*/
/*   <link rel="stylesheet" href="{{ asset('assets/tether/tether.min.css') }}">*/
/*   <link rel="stylesheet" href="{{ asset('assets/bootstrap/css/bootstrap.min.css') }}">*/
/*   <link rel="stylesheet" href="{{ asset('assets/socicon/css/socicon.min.css') }}">*/
/*   <link rel="stylesheet" href="{{ asset('assets/animate.css/animate.min.css') }}">*/
/*   <link rel="stylesheet" href="{{ asset('assets/dropdown/css/style.css') }}">*/
/*   <link rel="stylesheet" href="{{ asset('assets/theme/css/style.css') }}">*/
/*   <link rel="stylesheet" href="{{ asset('assets/mobirise/css/mbr-additional.css') }}" type="text/css">*/
/*   */
/*   */
/*   */
/* </head>*/
/* <body>*/
/* <section id="menu-0">*/
/* */
/*     <nav class="navbar navbar-dropdown bg-color transparent navbar-fixed-top">*/
/*         <div class="container">*/
/* */
/*             <div class="mbr-table">*/
/*                 <div class="mbr-table-cell">*/
/* */
/*                     <div class="navbar-brand">*/
/*                         <a href="http://www.clevertechnik.com" class="navbar-logo"><img src="{{ asset('assets/images/logo.png') }}" alt="Mobirise"></a>*/
/*                         <a class="navbar-caption" href="http://www.clevertechnik.com">Clevertechnik</a>*/
/*                     </div>*/
/* */
/*                 </div>*/
/* 		*/
/*                 <div class="mbr-table-cell">*/
/* */
/*                     <button class="navbar-toggler pull-xs-right hidden-md-up" type="button" data-toggle="collapse" data-target="#exCollapsingNavbar">*/
/*                         <div class="hamburger-icon"></div>*/
/*                     </button>*/
/* */
/*                     <ul class="nav-dropdown collapse pull-xs-right nav navbar-nav navbar-toggleable-sm" id="exCollapsingNavbar"><li class="nav-item dropdown"><a class="nav-link link" href="https://mobirise.com/" aria-expanded="false">CONTACT US</a></li><li class="nav-item nav-btn"><a class="nav-link btn btn-white btn-white-outline" href="{{ path('user_login') }}">LOG IN</a></li></ul>*/
/*                     <button hidden="" class="navbar-toggler navbar-close" type="button" data-toggle="collapse" data-target="#exCollapsingNavbar">*/
/*                         <div class="close-icon"></div>*/
/*                     </button>*/
/* */
/*                 </div>*/
/* 		*/
/*             </div>*/
/* */
/*         </div>*/
/*     </nav>*/
/* */
/* </section>*/
/* */
/* <section class="engine"><a rel="external" href="http://www.clevertechnik.com">top wysiwyg web site builder software download</a></section><section class="mbr-section mbr-section-hero mbr-section-full mbr-section-with-arrow mbr-after-navbar" id="header4-0" data-bg-video="https://www.youtube.com/watch?v=uNCr7NdOJgw">*/
/* */
/*     <div class="mbr-overlay" style="opacity: 0.5; background-color: rgb(0, 0, 0);"></div>*/
/* */
/*     <div class="mbr-table-cell">*/
/* */
/*         <div class="container">*/
/*             <div class="row">*/
/*                 <div class="mbr-section col-md-10 col-md-offset-2 text-xs-right">*/
/* */
/*                     <h1 class="mbr-section-title display-1">GESTIÓN &nbsp;INTELIGENTE DEL ENTORNO</h1>*/
/*                     <p class="mbr-section-lead lead">CLEVERTECHNIK ha desarrollado una solución que permite la gestión sostenible e inteligente del alumbrado público. &nbsp;<br><br></p>*/
/*                     <div class="mbr-section-btn"><a class="btn btn-lg btn-success" href="http://www.clevertechnik.com">MORE INFORMATION</a> <a class="btn btn-lg btn-warning" href="http://www.clevertechnik.com">CONTACT US</a></div>*/
/*                 </div>*/
/*             </div>*/
/*         </div>*/
/*     </div>*/
/* */
/*     <div class="mbr-arrow mbr-arrow-floating" aria-hidden="true"><a href="#msg-box5-0"><i class="mbr-arrow-icon"></i></a></div>*/
/* */
/* </section>*/
/* */
/* <section class="mbr-section" id="msg-box5-0" style="background-color: rgb(255, 255, 255); padding-top: 0px; padding-bottom: 0px;">*/
/* */
/*     */
/*     <div class="container">*/
/*         <div class="row">*/
/*             <div class="mbr-table-md-up">*/
/* */
/*               */
/* */
/*               <div class="mbr-table-cell mbr-right-padding-md-up col-md-5 text-xs-center text-md-right">*/
/*                   <h3 class="mbr-section-title display-2">SOLID COLOR INTRO WITH IMAGE</h3>*/
/*                   <div class="lead">*/
/* */
/*                     <p>Solid color intro with an image on the right side. Also this block has no paddings.</p>*/
/* */
/*                   </div>*/
/* */
/*                   <div><a class="btn btn-primary" href="http://www.clevertechnik.com">MORE</a></div>*/
/*               </div>*/
/* */
/* */
/*               */
/* */
/* */
/*               <div class="mbr-table-cell mbr-valign-top col-md-7">*/
/*                   <div class="mbr-figure"><img src="{{ asset('assets/images/desktop.jpg') }}"></div>*/
/*               </div>*/
/* */
/*             </div>*/
/*         </div>*/
/*     </div>*/
/* */
/* </section>*/
/* */
/* <section class="mbr-section mbr-parallax-background" id="content5-0" style="background-image: url({{ asset('assets/images/desert2.jpg') }}); padding-top: 120px; padding-bottom: 120px;">*/
/* */
/*     <div class="mbr-overlay" style="opacity: 0.5; background-color: rgb(0, 0, 0);">*/
/*     </div>*/
/* */
/*     <div class="container">*/
/*         <h3 class="mbr-section-title display-2">BACKGROUND IMAGE</h3>*/
/*         <div class="lead"><p>Background image with solid color overlay and parallax effect. Develop fully responsive, mobile-ready websites that look amazing on any devices and browsers. Preview how your website will appear on phones, tablets and desktops directly in the visual editor.</p></div>*/
/*     </div>*/
/* */
/* </section>*/
/* */
/* <section class="mbr-info mbr-info-extra mbr-section mbr-section-md-padding" id="msg-box1-0" style="background-color: rgb(242, 242, 242); padding-top: 90px; padding-bottom: 90px;">*/
/* */
/*     <div class="container">*/
/*         <div class="row">*/
/* */
/*             <div class="mbr-table-md-up">*/
/*                 <div class="mbr-table-cell mbr-right-padding-md-up col-md-8 text-xs-center text-md-left">*/
/*                     <h2 class="mbr-info-subtitle mbr-section-subtitle">Create awesome mobile-friendly websites. No coding and free.</h2>*/
/*                     <h3 class="mbr-info-title mbr-section-title display-2">PRE MADE BLOCKS</h3>*/
/*                 </div>*/
/* */
/*                 <div class="mbr-table-cell col-md-4">*/
/*                     <div class="text-xs-center"><a class="btn btn-primary" href="http://www.clevertechnik.com">SEE LIVE DEMO</a></div>*/
/*                 </div>*/
/*             </div>*/
/* */
/* */
/*         </div>*/
/*     </div>*/
/* </section>*/
/* */
/* <section class="mbr-section mbr-section-md-padding mbr-footer footer1" id="contacts1-0" style="background-color: rgb(46, 46, 46); padding-top: 90px; padding-bottom: 90px;">*/
/*     */
/*     <div class="container">*/
/*         <div class="row">*/
/*             <div class="mbr-footer-content col-xs-12 col-md-3">*/
/*                 <div><img src="{{ asset('assets/images/logo.png') }}"></div>*/
/*             </div>*/
/*             <div class="mbr-footer-content col-xs-12 col-md-3">*/
/*                 <p><strong>Address</strong><br>*/
/* 		1234 Street Name<br>*/
/* 		City, AA 99999</p>*/
/*             </div>*/
/*             <div class="mbr-footer-content col-xs-12 col-md-3">*/
/*                 <p><strong>Contacts</strong><br>*/
/* 		Email: support@mobirise.com<br>*/
/* 		Phone: +1 (0) 000 0000 001<br>*/
/* 		Fax: +1 (0) 000 0000 002</p>*/
/*             </div>*/
/*             <div class="mbr-footer-content col-xs-12 col-md-3">*/
/*                 <p><strong>Links</strong><br>*/
/* 		<a class="text-primary" href="https://mobirise.com/">Website builder</a><br>*/
/* 		<a class="text-primary" href="https://mobirise.com/mobirise-free-win.zip">Download for Windows</a><br>*/
/* 		<a class="text-primary" href="https://mobirise.com/mobirise-free-mac.zip">Download for Mac</a></p>*/
/*             </div>*/
/* */
/*         </div>*/
/*     </div>*/
/* </section>*/
/* */
/* <footer class="mbr-small-footer mbr-section mbr-section-nopadding" id="footer1-2" style="background-color: rgb(50, 50, 50); padding-top: 1.75rem; padding-bottom: 1.75rem;">*/
/*     */
/*     <div class="container">*/
/*         <p class="text-xs-center">Copyright (c) 2016 Mobirise.</p>*/
/*     </div>*/
/* </footer>*/
/* */
/* */
/*   <script src="{{ asset('assets/web/assets/jquery/jquery.min.js') }}"></script>*/
/*   <script src="{{ asset('assets/tether/tether.min.js') }}"></script>*/
/*   <script src="{{ asset('assets/bootstrap/js/bootstrap.min.js') }}"></script>*/
/*   <script src="{{ asset('assets/smooth-scroll/SmoothScroll.js') }}"></script>*/
/*   <script src="{{ asset('assets/viewportChecker/jquery.viewportchecker.js') }}"></script>*/
/*   <script src="{{ asset('assets/dropdown/js/script.min.js') }}"></script>*/
/*   <script src="{{ asset('assets/touchSwipe/jquery.touchSwipe.min.js') }}"></script>*/
/*   <script src="{{ asset('assets/jquery-mb-ytplayer/jquery.mb.YTPlayer.min.js') }}"></script>*/
/*   <script src="{{ asset('assets/jarallax/jarallax.js') }}"></script>*/
/*   <script src="{{ asset('assets/theme/js/script.js') }}"></script>*/
/*   */
/*   */
/*   <input name="animation" type="hidden">*/
/*   </body>*/
/* </html>*/
