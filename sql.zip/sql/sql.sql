-- MySQL dump 10.13  Distrib 5.7.33, for Linux (x86_64)
--
-- Host: localhost    Database: swat_gesinen
-- ------------------------------------------------------
-- Server version	5.7.33-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `boiler_device`
--

DROP TABLE IF EXISTS `boiler_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `boiler_device` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `mode` varchar(100) NOT NULL,
  `schedule` varchar(100) DEFAULT NULL,
  `sensorId` int(15) NOT NULL,
  `releStatus` tinyint(1) NOT NULL,
  `lastLongitude` decimal(10,0) NOT NULL,
  `lastTemperature` decimal(10,0) NOT NULL,
  `lastUpdateTime` datetime NOT NULL,
  `scheduleWeekend` varchar(255) NOT NULL,
  `boilerModel` varchar(255) NOT NULL,
  `height` float NOT NULL,
  `width` float NOT NULL,
  `length` float NOT NULL,
  `shape` varchar(255) NOT NULL,
  `unit` varchar(255) NOT NULL,
  `filling` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `boiler_device`
--

LOCK TABLES `boiler_device` WRITE;
/*!40000 ALTER TABLE `boiler_device` DISABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `business`
--

DROP TABLE IF EXISTS `business`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postal_code` int(11) DEFAULT NULL,
  `contact_person` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telephone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `web` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business`
--

LOCK TABLES `business` WRITE;
/*!40000 ALTER TABLE `business` DISABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `capacity_cartel`
--

DROP TABLE IF EXISTS `capacity_cartel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capacity_cartel` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `sensorId` int(15) NOT NULL,
  `name` varchar(125) NOT NULL,
  `description` varchar(250) NOT NULL,
  `latitude` float NOT NULL,
  `longitude` float NOT NULL,
  `userId` int(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capacity_cartel`
--

LOCK TABLES `capacity_cartel` WRITE;
/*!40000 ALTER TABLE `capacity_cartel` DISABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `capacity_cartel_line`
--

DROP TABLE IF EXISTS `capacity_cartel_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capacity_cartel_line` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `cartelId` int(15) NOT NULL,
  `parkingId` int(15) DEFAULT NULL,
  `lineNum` int(15) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cartelIdFkFromCartelLine` (`cartelId`),
  KEY `parkingIdFkFromCartelLine` (`parkingId`),
  CONSTRAINT `cartelIdFkFromCartelLine` FOREIGN KEY (`cartelId`) REFERENCES `capacity_cartel` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `parkingIdFkFromCartelLine` FOREIGN KEY (`parkingId`) REFERENCES `capacity_parking` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capacity_cartel_line`
--

LOCK TABLES `capacity_cartel_line` WRITE;
/*!40000 ALTER TABLE `capacity_cartel_line` DISABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `capacity_devices`
--

DROP TABLE IF EXISTS `capacity_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capacity_devices` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `sensorId` int(15) NOT NULL,
  `name` varchar(125) NOT NULL,
  `description` varchar(250) NOT NULL,
  `latitude` float NOT NULL,
  `longitude` float NOT NULL,
  `authToken` varchar(250) NOT NULL,
  `provider` varchar(125) NOT NULL,
  `userId` int(15) NOT NULL,
  `type` varchar(125) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capacity_devices`
--

LOCK TABLES `capacity_devices` WRITE;
/*!40000 ALTER TABLE `capacity_devices` DISABLE KEYS */;

UNLOCK TABLES;

--
-- Table structure for table `capacity_devices_log`
--

DROP TABLE IF EXISTS `capacity_devices_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capacity_devices_log` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `messageHex` varchar(255) NOT NULL,
  `messageInt` varchar(255) NOT NULL,
  `capacityDeviceEUI` varchar(255) NOT NULL,
  `parkingId` int(15) NOT NULL,
  `currentCapacity` int(15) NOT NULL,
  `maxCapacity` int(15) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capacity_devices_log`
--

LOCK TABLES `capacity_devices_log` WRITE;
/*!40000 ALTER TABLE `capacity_devices_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `capacity_devices_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capacity_parking`
--

DROP TABLE IF EXISTS `capacity_parking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capacity_parking` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `name` varchar(125) NOT NULL,
  `description` varchar(250) NOT NULL,
  `currentCapacity` int(15) NOT NULL,
  `maxCapacity` int(15) NOT NULL,
  `address` varchar(250) NOT NULL,
  `userId` int(15) NOT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `authToken` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capacity_parking`
--

LOCK TABLES `capacity_parking` WRITE;
/*!40000 ALTER TABLE `capacity_parking` DISABLE KEYS */;
/*!40000 ALTER TABLE `capacity_parking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capacity_type_ribbon`
--

DROP TABLE IF EXISTS `capacity_type_ribbon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capacity_type_ribbon` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `capacityDeviceId` int(15) NOT NULL,
  `parkingId` int(15) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `capacityDeviceIdFkFromRibbon` (`capacityDeviceId`),
  CONSTRAINT `capacityDeviceIdFkFromRibbon` FOREIGN KEY (`capacityDeviceId`) REFERENCES `capacity_devices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capacity_type_ribbon`
--

LOCK TABLES `capacity_type_ribbon` WRITE;
/*!40000 ALTER TABLE `capacity_type_ribbon` DISABLE KEYS */;
/*!40000 ALTER TABLE `capacity_type_ribbon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capacity_type_spot`
--

DROP TABLE IF EXISTS `capacity_type_spot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capacity_type_spot` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `capacityDeviceId` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `parkingId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `capacityDeviceIdFkFromSpot` (`capacityDeviceId`),
  CONSTRAINT `capacityDeviceIdFkFromSpot` FOREIGN KEY (`capacityDeviceId`) REFERENCES `capacity_devices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capacity_type_spot`
--

LOCK TABLES `capacity_type_spot` WRITE;
/*!40000 ALTER TABLE `capacity_type_spot` DISABLE KEYS */;
/*!40000 ALTER TABLE `capacity_type_spot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `councils`
--

DROP TABLE IF EXISTS `councils`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `councils` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postal_code` int(11) DEFAULT NULL,
  `contact_person` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telephone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `web` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `councils`
--

LOCK TABLES `councils` WRITE;
/*!40000 ALTER TABLE `councils` DISABLE KEYS */;
/*!40000 ALTER TABLE `councils` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_module_device_mobile_connection`
--

DROP TABLE IF EXISTS `device_module_device_mobile_connection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_module_device_mobile_connection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) DEFAULT NULL,
  `sensorId` int(11) NOT NULL,
  `mac` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime DEFAULT NULL,
  `gap` bigint(20) DEFAULT NULL,
  `from_sensor_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_62A1BFEF94A4C7D4` (`device_id`),
  CONSTRAINT `FK_62A1BFEF94A4C7D4` FOREIGN KEY (`device_id`) REFERENCES `device_module_devices` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_module_device_mobile_connection`
--

LOCK TABLES `device_module_device_mobile_connection` WRITE;
/*!40000 ALTER TABLE `device_module_device_mobile_connection` DISABLE KEYS */;
/*!40000 ALTER TABLE `device_module_device_mobile_connection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_module_devices`
--

DROP TABLE IF EXISTS `device_module_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_module_devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sensor_id` int(11) NOT NULL,
  `hash_variable` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `counter_variable` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `salt` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `sensitivity` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_92FB68E5E237E06` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_module_devices`
--

LOCK TABLES `device_module_devices` WRITE;
/*!40000 ALTER TABLE `device_module_devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `device_module_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `door`
--

DROP TABLE IF EXISTS `door`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `door` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `sensor_id` int(11) NOT NULL,
  `variable` varchar(255) NOT NULL,
  `output` int(11) DEFAULT NULL,
  `command` varchar(255) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `admin_to_approve` int(11) DEFAULT NULL,
  `time_block` varchar(255) NOT NULL,
  `last_user` varchar(255) DEFAULT NULL,
  `last_opening` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8AE5542D5E237E06` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `door`
--

LOCK TABLES `door` WRITE;
/*!40000 ALTER TABLE `door` DISABLE KEYS */;
/*!40000 ALTER TABLE `door` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `door_close_open_record`
--

DROP TABLE IF EXISTS `door_close_open_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `door_close_open_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `door_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `requested_datetime` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `door_close_open_record`
--

LOCK TABLES `door_close_open_record` WRITE;
/*!40000 ALTER TABLE `door_close_open_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `door_close_open_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `energy_device_alarm_notification`
--

DROP TABLE IF EXISTS `energy_device_alarm_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_device_alarm_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sensor_id` int(11) DEFAULT NULL,
  `deviceEUI` varchar(255) DEFAULT NULL,
  `alarm_type` varchar(64) DEFAULT NULL,
  `variable_one` varchar(64) DEFAULT NULL,
  `variable_two` varchar(64) DEFAULT NULL,
  `define_alarm_id` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` varchar(64) DEFAULT NULL,
  `value_received` varchar(64) DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `energy_device_alarm_notification`
--

LOCK TABLES `energy_device_alarm_notification` WRITE;
/*!40000 ALTER TABLE `energy_device_alarm_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `energy_device_alarm_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `energy_device_config`
--

DROP TABLE IF EXISTS `energy_device_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_device_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `energy_id` int(11) DEFAULT NULL,
  `accessRate` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hiredPotency` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cppTip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cppFlat` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cppValley` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `measureEquipmentRental` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `electricityTax` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `energyPriceTip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `energyPriceFlat` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `energyPriceValley` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `festivalTip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `festivalFlat` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `festivalValley` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `co2_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company_factor` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_8AF41F99EDDF52D` (`energy_id`),
  CONSTRAINT `FK_8AF41F99EDDF52D` FOREIGN KEY (`energy_id`) REFERENCES `energy_devices` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `energy_device_config`
--

LOCK TABLES `energy_device_config` WRITE;
/*!40000 ALTER TABLE `energy_device_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `energy_device_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `energy_device_define_alarms`
--

DROP TABLE IF EXISTS `energy_device_define_alarms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_device_define_alarms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sensor_id` int(11) NOT NULL,
  `deviceEUI` varchar(255) DEFAULT NULL,
  `energy_device_id` int(11) DEFAULT NULL,
  `alarm_type` varchar(64) DEFAULT NULL,
  `from_time` varchar(32) DEFAULT NULL,
  `to_time` varchar(32) DEFAULT NULL,
  `alarm_email` varchar(255) DEFAULT NULL,
  `subject` varchar(64) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `variable_one` varchar(64) DEFAULT NULL,
  `variable_2` varchar(64) DEFAULT NULL,
  `over_value` int(11) DEFAULT NULL,
  `lower_value` int(11) DEFAULT NULL,
  `alarm_flag` tinyint(1) DEFAULT '0',
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `energy_device_define_alarms`
--

LOCK TABLES `energy_device_define_alarms` WRITE;
/*!40000 ALTER TABLE `energy_device_define_alarms` DISABLE KEYS */;
/*!40000 ALTER TABLE `energy_device_define_alarms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `energy_device_input`
--

DROP TABLE IF EXISTS `energy_device_input`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_device_input` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `energy_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `input` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `input_status` int(11) DEFAULT NULL,
  `input_on_color` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_off_color` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_78E1D9AFEDDF52D` (`energy_id`),
  CONSTRAINT `FK_78E1D9AFEDDF52D` FOREIGN KEY (`energy_id`) REFERENCES `energy_devices` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `energy_device_input`
--

LOCK TABLES `energy_device_input` WRITE;
/*!40000 ALTER TABLE `energy_device_input` DISABLE KEYS */;
/*!40000 ALTER TABLE `energy_device_input` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `energy_device_output`
--

DROP TABLE IF EXISTS `energy_device_output`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_device_output` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `energy_id` int(11) DEFAULT NULL,
  `output` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `command` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_92A0247BEDDF52D` (`energy_id`),
  CONSTRAINT `FK_92A0247BEDDF52D` FOREIGN KEY (`energy_id`) REFERENCES `energy_devices` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `energy_device_output`
--

LOCK TABLES `energy_device_output` WRITE;
/*!40000 ALTER TABLE `energy_device_output` DISABLE KEYS */;
/*!40000 ALTER TABLE `energy_device_output` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `energy_device_output_plan`
--

DROP TABLE IF EXISTS `energy_device_output_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_device_output_plan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `energy_device_output_id` int(11) DEFAULT NULL,
  `energy_id` int(11) DEFAULT NULL,
  `plan_type` int(11) NOT NULL,
  `month_alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `day_date` datetime DEFAULT NULL,
  `ignition_sequence` tinyint(4) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `sunset_delay` int(11) DEFAULT NULL,
  `sunrise_delay` int(11) DEFAULT NULL,
  `energy_device_input_on_sun_id` int(11) DEFAULT NULL,
  `energy_device_input_on_mon_id` int(11) DEFAULT NULL,
  `energy_device_input_on_tue_id` int(11) DEFAULT NULL,
  `energy_device_input_on_wed_id` int(11) DEFAULT NULL,
  `energy_device_input_on_thu_id` int(11) DEFAULT NULL,
  `energy_device_input_on_fri_id` int(11) DEFAULT NULL,
  `energy_device_input_on_sat_id` int(11) DEFAULT NULL,
  `energy_device_input_sun_off_id` int(11) DEFAULT NULL,
  `energy_device_input_mon_off_id` int(11) DEFAULT NULL,
  `energy_device_input_tue_off_id` int(11) DEFAULT NULL,
  `energy_device_input_wed_off_id` int(11) DEFAULT NULL,
  `energy_device_input_thu_off_id` int(11) DEFAULT NULL,
  `energy_device_input_fri_off_id` int(11) DEFAULT NULL,
  `energy_device_input_sat_off_id` int(11) DEFAULT NULL,
  `is_light_on` tinyint(1) NOT NULL,
  `is_force_on` tinyint(1) NOT NULL,
  `is_switch_with_astro_mon` tinyint(1) NOT NULL,
  `is_switch_with_astro_tue` tinyint(1) NOT NULL,
  `is_switch_with_astro_wed` tinyint(1) NOT NULL,
  `is_switch_with_astro_thu` tinyint(1) NOT NULL,
  `is_switch_with_astro_fri` tinyint(1) NOT NULL,
  `is_switch_with_astro_sat` tinyint(1) NOT NULL,
  `is_switch_with_astro_sun` tinyint(1) NOT NULL,
  `is_switch_on_with_astro_sun` tinyint(1) NOT NULL,
  `is_switch_on_with_astro_mon` tinyint(1) NOT NULL,
  `is_switch_on_with_astro_tue` tinyint(1) NOT NULL,
  `is_switch_on_with_astro_wed` tinyint(1) NOT NULL,
  `is_switch_on_with_astro_thu` tinyint(1) NOT NULL,
  `is_switch_on_with_astro_fri` tinyint(1) NOT NULL,
  `is_switch_on_with_astro_sat` tinyint(1) NOT NULL,
  `is_switch_off_with_astro_sun` tinyint(1) NOT NULL,
  `is_switch_off_with_astro_mon` tinyint(1) NOT NULL,
  `is_switch_off_with_astro_tue` tinyint(1) NOT NULL,
  `is_switch_off_with_astro_wed` tinyint(1) NOT NULL,
  `is_switch_off_with_astro_thu` tinyint(1) NOT NULL,
  `is_switch_off_with_astro_fri` tinyint(1) NOT NULL,
  `is_switch_off_with_astro_sat` tinyint(1) NOT NULL,
  `switch_on_time_sun` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `switch_on_time_mon` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `switch_on_time_tue` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `switch_on_time_wed` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `switch_on_time_thu` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `switch_on_time_fri` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `switch_on_time_sat` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `switch_off_time_sun` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `switch_off_time_mon` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `switch_off_time_tue` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `switch_off_time_wed` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `switch_off_time_thu` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `switch_off_time_fri` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `switch_off_time_sat` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `for_year` int(11) DEFAULT NULL,
  `for_month` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_for_output_year_month` (`energy_device_output_id`,`for_year`,`for_month`,`plan_type`,`day_date`) USING BTREE,
  KEY `IDX_BB22772919DB005D` (`energy_device_output_id`),
  KEY `IDX_BB227729EDDF52D` (`energy_id`),
  KEY `IDX_BB227729B6C4415E` (`energy_device_input_on_sun_id`),
  KEY `IDX_BB227729A548AD96` (`energy_device_input_on_mon_id`),
  KEY `IDX_BB2277297CC0F6E7` (`energy_device_input_on_tue_id`),
  KEY `IDX_BB227729220874AE` (`energy_device_input_on_wed_id`),
  KEY `IDX_BB227729B4A9F24B` (`energy_device_input_on_thu_id`),
  KEY `IDX_BB227729CA2836DF` (`energy_device_input_on_fri_id`),
  KEY `IDX_BB2277291C00C7E7` (`energy_device_input_on_sat_id`),
  KEY `IDX_BB227729CC9375C7` (`energy_device_input_sun_off_id`),
  KEY `IDX_BB227729CC1A0C73` (`energy_device_input_mon_off_id`),
  KEY `IDX_BB227729732572E8` (`energy_device_input_tue_off_id`),
  KEY `IDX_BB227729F8788B04` (`energy_device_input_wed_off_id`),
  KEY `IDX_BB2277295211E6E5` (`energy_device_input_thu_off_id`),
  KEY `IDX_BB22772963B05BBB` (`energy_device_input_fri_off_id`),
  KEY `IDX_BB227729D0C44B59` (`energy_device_input_sat_off_id`),
  CONSTRAINT `FK_BB22772919DB005D` FOREIGN KEY (`energy_device_output_id`) REFERENCES `energy_device_output` (`id`),
  CONSTRAINT `FK_BB2277291C00C7E7` FOREIGN KEY (`energy_device_input_on_sat_id`) REFERENCES `energy_device_input` (`id`),
  CONSTRAINT `FK_BB227729220874AE` FOREIGN KEY (`energy_device_input_on_wed_id`) REFERENCES `energy_device_input` (`id`),
  CONSTRAINT `FK_BB2277295211E6E5` FOREIGN KEY (`energy_device_input_thu_off_id`) REFERENCES `energy_device_input` (`id`),
  CONSTRAINT `FK_BB22772963B05BBB` FOREIGN KEY (`energy_device_input_fri_off_id`) REFERENCES `energy_device_input` (`id`),
  CONSTRAINT `FK_BB227729732572E8` FOREIGN KEY (`energy_device_input_tue_off_id`) REFERENCES `energy_device_input` (`id`),
  CONSTRAINT `FK_BB2277297CC0F6E7` FOREIGN KEY (`energy_device_input_on_tue_id`) REFERENCES `energy_device_input` (`id`),
  CONSTRAINT `FK_BB227729A548AD96` FOREIGN KEY (`energy_device_input_on_mon_id`) REFERENCES `energy_device_input` (`id`),
  CONSTRAINT `FK_BB227729B4A9F24B` FOREIGN KEY (`energy_device_input_on_thu_id`) REFERENCES `energy_device_input` (`id`),
  CONSTRAINT `FK_BB227729B6C4415E` FOREIGN KEY (`energy_device_input_on_sun_id`) REFERENCES `energy_device_input` (`id`),
  CONSTRAINT `FK_BB227729CA2836DF` FOREIGN KEY (`energy_device_input_on_fri_id`) REFERENCES `energy_device_input` (`id`),
  CONSTRAINT `FK_BB227729CC1A0C73` FOREIGN KEY (`energy_device_input_mon_off_id`) REFERENCES `energy_device_input` (`id`),
  CONSTRAINT `FK_BB227729CC9375C7` FOREIGN KEY (`energy_device_input_sun_off_id`) REFERENCES `energy_device_input` (`id`),
  CONSTRAINT `FK_BB227729D0C44B59` FOREIGN KEY (`energy_device_input_sat_off_id`) REFERENCES `energy_device_input` (`id`),
  CONSTRAINT `FK_BB227729EDDF52D` FOREIGN KEY (`energy_id`) REFERENCES `energy_devices` (`id`),
  CONSTRAINT `FK_BB227729F8788B04` FOREIGN KEY (`energy_device_input_wed_off_id`) REFERENCES `energy_device_input` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `energy_device_output_plan`
--

LOCK TABLES `energy_device_output_plan` WRITE;
/*!40000 ALTER TABLE `energy_device_output_plan` DISABLE KEYS */;
/*!40000 ALTER TABLE `energy_device_output_plan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `energy_devices`
--

DROP TABLE IF EXISTS `energy_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sensor_id` int(11) NOT NULL,
  `sensor_meter_id` int(11) DEFAULT NULL,
  `total_active_energy` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `input_list` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `energy_ap_t` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `energy_exp_total` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `reactive_power` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phase_r` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phase_t` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phase_s` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `voltage_s` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `voltage_t` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `voltage_r` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `active_power` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `aparent_power` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `energy_group_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_971179915E237E06` (`name`),
  KEY `IDX_971179917FAFF160` (`energy_group_id`),
  CONSTRAINT `FK_971179917FAFF160` FOREIGN KEY (`energy_group_id`) REFERENCES `energy_devices_group` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `energy_devices`
--

LOCK TABLES `energy_devices` WRITE;
/*!40000 ALTER TABLE `energy_devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `energy_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `energy_devices_group`
--

DROP TABLE IF EXISTS `energy_devices_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_devices_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_D5F9718E5E237E06` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `energy_devices_group`
--

LOCK TABLES `energy_devices_group` WRITE;
/*!40000 ALTER TABLE `energy_devices_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `energy_devices_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `energy_meter_value`
--

DROP TABLE IF EXISTS `energy_meter_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_meter_value` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` varchar(128) DEFAULT NULL,
  `cuadro_id` varchar(64) DEFAULT NULL,
  `counter_number` int(11) DEFAULT NULL,
  `phase` int(11) DEFAULT NULL,
  `current_ir` float DEFAULT NULL,
  `current_is` float DEFAULT NULL,
  `current_it` float DEFAULT NULL,
  `volt_in_ver` float DEFAULT NULL,
  `volt_in_ves` float DEFAULT NULL,
  `volt_in_vet` float DEFAULT NULL,
  `power_pfr` float DEFAULT NULL,
  `power_pfs` float DEFAULT NULL,
  `power_pft` float DEFAULT NULL,
  `active_par` float DEFAULT NULL,
  `active_pas` float DEFAULT NULL,
  `active_pat` float DEFAULT NULL,
  `reactive_prr` float DEFAULT NULL,
  `reactive_prs` float DEFAULT NULL,
  `reactive_prt` float DEFAULT NULL,
  `qat` float DEFAULT NULL,
  `qr_one_t` float DEFAULT NULL,
  `error_info` int(11) DEFAULT NULL,
  `created_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `energy_meter_value`
--

LOCK TABLES `energy_meter_value` WRITE;
/*!40000 ALTER TABLE `energy_meter_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `energy_meter_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gateway_mqtt_messages_log`
--

DROP TABLE IF EXISTS `gateway_mqtt_messages_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateway_mqtt_messages_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `complete_message` varchar(600) DEFAULT NULL,
  `gateway_mac` varchar(255) DEFAULT NULL,
  `topic` varchar(500) DEFAULT NULL,
  `message_datetime` datetime DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gateway_mqtt_messages_log`
--

LOCK TABLES `gateway_mqtt_messages_log` WRITE;
/*!40000 ALTER TABLE `gateway_mqtt_messages_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `gateway_mqtt_messages_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gateway_ping`
--

DROP TABLE IF EXISTS `gateway_ping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateway_ping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mac_number` varchar(255) DEFAULT NULL,
  `status` varchar(64) DEFAULT NULL,
  `message_datetime` varchar(64) DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gateway_ping`
--

LOCK TABLES `gateway_ping` WRITE;
/*!40000 ALTER TABLE `gateway_ping` DISABLE KEYS */;
/*!40000 ALTER TABLE `gateway_ping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gateways`
--

DROP TABLE IF EXISTS `gateways`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateways` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `application` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `application_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `profileId` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mac` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `town` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `radius` float DEFAULT NULL,
  `inharit_group` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `server_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `groups_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sensors_id` varchar(16000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `project_id` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `project_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `disable` int(11) NOT NULL DEFAULT '0',
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gateways`
--

LOCK TABLES `gateways` WRITE;
/*!40000 ALTER TABLE `gateways` DISABLE KEYS */;
/*!40000 ALTER TABLE `gateways` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generic_alarm_notification`
--

DROP TABLE IF EXISTS `generic_alarm_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generic_alarm_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alarm_type` varchar(64) DEFAULT NULL,
  `deviceEUI` varchar(255) DEFAULT NULL,
  `gatewayMac` varchar(255) DEFAULT NULL,
  `sensor_id` int(11) DEFAULT NULL,
  `device_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `variable_one` varchar(64) DEFAULT NULL,
  `variable_two` varchar(64) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` varchar(64) DEFAULT NULL,
  `observed_value` varchar(128) DEFAULT NULL,
  `alarm_value` varchar(128) DEFAULT NULL,
  `define_alarm_id` int(11) DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generic_alarm_notification`
--

LOCK TABLES `generic_alarm_notification` WRITE;
/*!40000 ALTER TABLE `generic_alarm_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `generic_alarm_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generic_define_alarm`
--

DROP TABLE IF EXISTS `generic_define_alarm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generic_define_alarm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sensor_id` int(11) NOT NULL,
  `generic_device_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `deviceEUI` varchar(255) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `alarm_type` varchar(64) DEFAULT NULL,
  `over_value` int(11) DEFAULT NULL,
  `lower_value` int(11) DEFAULT NULL,
  `variable_one` varchar(64) DEFAULT NULL,
  `variable_two` varchar(64) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generic_define_alarm`
--

LOCK TABLES `generic_define_alarm` WRITE;
/*!40000 ALTER TABLE `generic_define_alarm` DISABLE KEYS */;
/*!40000 ALTER TABLE `generic_define_alarm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generic_define_device`
--

DROP TABLE IF EXISTS `generic_define_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generic_define_device` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `sensor_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `generic_provider` varchar(64) DEFAULT NULL,
  `generic_token` varchar(128) DEFAULT NULL,
  `generic_url` varchar(128) DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generic_define_device`
--

LOCK TABLES `generic_define_device` WRITE;
/*!40000 ALTER TABLE `generic_define_device` DISABLE KEYS */;
/*!40000 ALTER TABLE `generic_define_device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generic_device_variables`
--

DROP TABLE IF EXISTS `generic_device_variables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generic_device_variables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `generic_device` int(11) DEFAULT NULL,
  `variable_name` varchar(128) DEFAULT NULL,
  `variable_unit` varchar(64) DEFAULT NULL,
  `variable_varname` varchar(64) DEFAULT NULL,
  `variable_type` varchar(128) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `device_eui` varchar(64) DEFAULT NULL,
  `last_observation` varchar(128) DEFAULT NULL,
  `observation_time` datetime DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generic_device_variables`
--

LOCK TABLES `generic_device_variables` WRITE;
/*!40000 ALTER TABLE `generic_device_variables` DISABLE KEYS */;
/*!40000 ALTER TABLE `generic_device_variables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generic_observations`
--

DROP TABLE IF EXISTS `generic_observations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generic_observations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_eui` varchar(64) DEFAULT NULL,
  `gateway_mac` varchar(64) DEFAULT NULL,
  `device_id` int(11) DEFAULT NULL,
  `observation` varchar(128) DEFAULT NULL,
  `observation_time` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `variable_var_name` varchar(64) DEFAULT NULL,
  `variable_id` int(11) DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generic_observations`
--

LOCK TABLES `generic_observations` WRITE;
/*!40000 ALTER TABLE `generic_observations` DISABLE KEYS */;
/*!40000 ALTER TABLE `generic_observations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `group_type` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `server_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sensor_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hydric_balance_temp_observation`
--

DROP TABLE IF EXISTS `hydric_balance_temp_observation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hydric_balance_temp_observation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) NOT NULL,
  `sensor_id` int(11) NOT NULL,
  `var_id` int(11) DEFAULT NULL,
  `device_name` varchar(64) NOT NULL,
  `device_eui` varchar(128) NOT NULL,
  `var_name` varchar(64) NOT NULL,
  `gateway_mac` varchar(64) CHARACTER SET utf8mb4 DEFAULT NULL,
  `sensor_type_id` int(11) DEFAULT NULL,
  `observation_value` double NOT NULL,
  `message_timestamp` timestamp NULL DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `alert_type` varchar(64) DEFAULT NULL,
  `observation_type` varchar(64) DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hydric_balance_temp_observation`
--

LOCK TABLES `hydric_balance_temp_observation` WRITE;
/*!40000 ALTER TABLE `hydric_balance_temp_observation` DISABLE KEYS */;
/*!40000 ALTER TABLE `hydric_balance_temp_observation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `irrigation_device`
--

DROP TABLE IF EXISTS `irrigation_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `irrigation_device` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `nameSentilo` varchar(255) NOT NULL,
  `userId` int(11) NOT NULL,
  `latitude` float DEFAULT NULL,
  `longitude` float DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `deviceTypeId` int(11) NOT NULL,
  `sensorId` int(11) DEFAULT NULL,
  `authToken` varchar(125) DEFAULT NULL,
  `provider` varchar(125) DEFAULT NULL,
  `parametersSensorDevEui` varchar(255) DEFAULT NULL,
  `humidityLimit` decimal(10,2) DEFAULT NULL,
  `humidityLimitInferior` decimal(10,2) DEFAULT NULL,
  `intervalHours` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `irregation_device_user_id_fk` (`userId`),
  KEY `irregation_device_device_type_id_fk` (`deviceTypeId`),
  CONSTRAINT `irregation_device_device_type_id_fk` FOREIGN KEY (`deviceTypeId`) REFERENCES `irrigation_device_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `irregation_device_user_id_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `irrigation_device`
--

LOCK TABLES `irrigation_device` WRITE;
/*!40000 ALTER TABLE `irrigation_device` DISABLE KEYS */;
/*!40000 ALTER TABLE `irrigation_device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `irrigation_device_input`
--

DROP TABLE IF EXISTS `irrigation_device_input`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `irrigation_device_input` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `irrigationDeviceId` int(16) NOT NULL,
  `sensorId` int(16) NOT NULL,
  `lastHumidity` varchar(255) NOT NULL,
  `lastTemperature` varchar(255) NOT NULL,
  `sensorIndex` int(16) NOT NULL,
  `name` varchar(125) DEFAULT NULL,
  `connectionType` varchar(125) NOT NULL,
  `authToken` varchar(125) DEFAULT NULL,
  `provider` varchar(125) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `irregation_device_input_irregation_device_id_fk` (`irrigationDeviceId`),
  KEY `irregation_device_input_sensor_id_fk` (`sensorId`),
  CONSTRAINT `deleteIrrigationDeviceId` FOREIGN KEY (`irrigationDeviceId`) REFERENCES `irrigation_device` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `irregation_device_input_irregation_device_id_fk` FOREIGN KEY (`irrigationDeviceId`) REFERENCES `irrigation_device` (`id`),
  CONSTRAINT `irregation_device_input_sensor_id_fk` FOREIGN KEY (`sensorId`) REFERENCES `sensor_info` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `irrigation_device_input`
--

LOCK TABLES `irrigation_device_input` WRITE;
/*!40000 ALTER TABLE `irrigation_device_input` DISABLE KEYS */;
/*!40000 ALTER TABLE `irrigation_device_input` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `irrigation_device_input_history`
--

DROP TABLE IF EXISTS `irrigation_device_input_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `irrigation_device_input_history` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `irrigationDeviceInputId` int(15) NOT NULL,
  `humidity` float NOT NULL,
  `temperature` float NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `irrigation_device_input_history`
--

LOCK TABLES `irrigation_device_input_history` WRITE;
/*!40000 ALTER TABLE `irrigation_device_input_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `irrigation_device_input_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `irrigation_device_input_history_lora`
--

DROP TABLE IF EXISTS `irrigation_device_input_history_lora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `irrigation_device_input_history_lora` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `irrigationDeviceId` int(15) NOT NULL,
  `humidity` float NOT NULL,
  `temperature` float NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `irrigation_device_input_history_lora`
--

LOCK TABLES `irrigation_device_input_history_lora` WRITE;
/*!40000 ALTER TABLE `irrigation_device_input_history_lora` DISABLE KEYS */;
/*!40000 ALTER TABLE `irrigation_device_input_history_lora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `irrigation_device_link`
--

DROP TABLE IF EXISTS `irrigation_device_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `irrigation_device_link` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `irrigationDeviceInputId` int(11) DEFAULT NULL,
  `irrigationDeviceOutputId` int(11) DEFAULT NULL,
  `irrigationDeviceId` int(15) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `outputFk` (`irrigationDeviceOutputId`),
  KEY `inputFk` (`irrigationDeviceInputId`),
  KEY `devFk` (`irrigationDeviceId`),
  CONSTRAINT `devFk` FOREIGN KEY (`irrigationDeviceId`) REFERENCES `irrigation_device` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `inputFk` FOREIGN KEY (`irrigationDeviceInputId`) REFERENCES `irrigation_device_input` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `outputFk` FOREIGN KEY (`irrigationDeviceOutputId`) REFERENCES `irrigation_device_output` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `irrigation_device_link`
--

LOCK TABLES `irrigation_device_link` WRITE;
/*!40000 ALTER TABLE `irrigation_device_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `irrigation_device_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `irrigation_device_output`
--

DROP TABLE IF EXISTS `irrigation_device_output`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `irrigation_device_output` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `irrigationDeviceId` int(16) NOT NULL,
  `sensorId` int(16) NOT NULL,
  `sensorIndex` int(16) NOT NULL,
  `intervals` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `name` varchar(128) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `sensorIdInput` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `irregation_device_output_irregation_device_id_fk` (`irrigationDeviceId`),
  KEY `irregation_device_output_sensor_id_fk` (`sensorId`),
  CONSTRAINT `irregation_device_output_irregation_device_id_fk` FOREIGN KEY (`irrigationDeviceId`) REFERENCES `irrigation_device` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `irregation_device_output_sensor_id_fk` FOREIGN KEY (`sensorId`) REFERENCES `sensor_info` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `irrigation_device_output`
--

LOCK TABLES `irrigation_device_output` WRITE;
/*!40000 ALTER TABLE `irrigation_device_output` DISABLE KEYS */;
/*!40000 ALTER TABLE `irrigation_device_output` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `irrigation_device_type`
--

DROP TABLE IF EXISTS `irrigation_device_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `irrigation_device_type` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `irrigation_device_type`
--

LOCK TABLES `irrigation_device_type` WRITE;
/*!40000 ALTER TABLE `irrigation_device_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `irrigation_device_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lorawan_message_record`
--

DROP TABLE IF EXISTS `lorawan_message_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lorawan_message_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gateway` varchar(128) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `sensor_name` varchar(255) DEFAULT NULL,
  `device_eui` varchar(128) DEFAULT NULL,
  `sensor_type` varchar(128) DEFAULT NULL,
  `message_type` varchar(128) DEFAULT NULL,
  `message_data` varchar(255) DEFAULT NULL,
  `request_type` varchar(64) DEFAULT NULL,
  `message_datetime` datetime DEFAULT NULL,
  `message_topic` varchar(255) DEFAULT NULL,
  `full_message` varchar(500) DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lorawan_message_record`
--

LOCK TABLES `lorawan_message_record` WRITE;
/*!40000 ALTER TABLE `lorawan_message_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `lorawan_message_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mqtt_log_defined`
--

DROP TABLE IF EXISTS `mqtt_log_defined`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mqtt_log_defined` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `description` varchar(128) DEFAULT NULL,
  `gateway` varchar(64) DEFAULT NULL,
  `sensor` varchar(64) DEFAULT NULL,
  `from_period` datetime DEFAULT NULL,
  `to_period` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mqtt_log_defined`
--

LOCK TABLES `mqtt_log_defined` WRITE;
/*!40000 ALTER TABLE `mqtt_log_defined` DISABLE KEYS */;
/*!40000 ALTER TABLE `mqtt_log_defined` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `municipality_canon_fee`
--

DROP TABLE IF EXISTS `municipality_canon_fee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `municipality_canon_fee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year` int(11) DEFAULT NULL,
  `municipality_id` int(11) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `tariff` double DEFAULT NULL,
  `is_taxable` tinyint(1) DEFAULT NULL,
  `tax_rate` double DEFAULT NULL,
  `conon_use_for` varchar(64) DEFAULT NULL,
  `type` varchar(64) DEFAULT NULL,
  `diameter_id` int(11) DEFAULT NULL,
  `diameter_from` int(11) DEFAULT NULL,
  `diameter_to` int(11) DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `municipality_canon_fee`
--

LOCK TABLES `municipality_canon_fee` WRITE;
/*!40000 ALTER TABLE `municipality_canon_fee` DISABLE KEYS */;
/*!40000 ALTER TABLE `municipality_canon_fee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `municipality_consumption_block`
--

DROP TABLE IF EXISTS `municipality_consumption_block`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `municipality_consumption_block` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year` int(11) NOT NULL,
  `municipality_id` int(11) NOT NULL,
  `blocknumber` int(11) NOT NULL,
  `limitfrom` double NOT NULL,
  `limitto` double NOT NULL,
  `tariff` double NOT NULL,
  `is_taxable` tinyint(1) DEFAULT NULL,
  `tax_rate` double DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `municipality_consumption_block`
--

LOCK TABLES `municipality_consumption_block` WRITE;
/*!40000 ALTER TABLE `municipality_consumption_block` DISABLE KEYS */;
/*!40000 ALTER TABLE `municipality_consumption_block` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `municipality_contador`
--

DROP TABLE IF EXISTS `municipality_contador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `municipality_contador` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year` int(11) NOT NULL,
  `municipality_id` int(11) NOT NULL,
  `diameter_from` int(11) NOT NULL,
  `diameter_to` int(11) NOT NULL,
  `tariff` double NOT NULL,
  `diameter_id` int(11) DEFAULT NULL,
  `is_taxable` tinyint(1) DEFAULT NULL,
  `tax_rate` double DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `municipality_contador`
--

LOCK TABLES `municipality_contador` WRITE;
/*!40000 ALTER TABLE `municipality_contador` DISABLE KEYS */;
/*!40000 ALTER TABLE `municipality_contador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `municipality_diameters`
--

DROP TABLE IF EXISTS `municipality_diameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `municipality_diameters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `municipality_id` int(11) DEFAULT NULL,
  `diameter_from` int(11) DEFAULT NULL,
  `diameter_to` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `municipality_diameters`
--

LOCK TABLES `municipality_diameters` WRITE;
/*!40000 ALTER TABLE `municipality_diameters` DISABLE KEYS */;
/*!40000 ALTER TABLE `municipality_diameters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `municipality_inversiones`
--

DROP TABLE IF EXISTS `municipality_inversiones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `municipality_inversiones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year` int(11) NOT NULL,
  `municipality_id` int(11) NOT NULL,
  `tariff` double NOT NULL,
  `is_taxable` tinyint(1) DEFAULT NULL,
  `tax_rate` double DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `municipality_inversiones`
--

LOCK TABLES `municipality_inversiones` WRITE;
/*!40000 ALTER TABLE `municipality_inversiones` DISABLE KEYS */;
/*!40000 ALTER TABLE `municipality_inversiones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `municipality_service_fee`
--

DROP TABLE IF EXISTS `municipality_service_fee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `municipality_service_fee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year` int(11) NOT NULL,
  `municipality_id` int(11) NOT NULL,
  `diameter_from` int(11) NOT NULL,
  `diameter_to` int(11) NOT NULL,
  `tariff` double NOT NULL,
  `diameter_id` int(11) DEFAULT NULL,
  `is_taxable` tinyint(1) DEFAULT NULL,
  `tax_rate` double DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `municipality_service_fee`
--

LOCK TABLES `municipality_service_fee` WRITE;
/*!40000 ALTER TABLE `municipality_service_fee` DISABLE KEYS */;
/*!40000 ALTER TABLE `municipality_service_fee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `municipality_sewer_rate`
--

DROP TABLE IF EXISTS `municipality_sewer_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `municipality_sewer_rate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year` int(11) NOT NULL,
  `municipality_id` int(11) NOT NULL,
  `usefor` varchar(64) NOT NULL,
  `cuotafija` double DEFAULT NULL,
  `shareconsume` double NOT NULL,
  `is_taxable` tinyint(1) DEFAULT NULL,
  `tax_rate` double DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `municipality_sewer_rate`
--

LOCK TABLES `municipality_sewer_rate` WRITE;
/*!40000 ALTER TABLE `municipality_sewer_rate` DISABLE KEYS */;
/*!40000 ALTER TABLE `municipality_sewer_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `network_servers`
--

DROP TABLE IF EXISTS `network_servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `network_servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `description` varchar(128) DEFAULT NULL,
  `type` varchar(64) DEFAULT NULL,
  `network_type` varchar(64) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `network_servers`
--

LOCK TABLES `network_servers` WRITE;
/*!40000 ALTER TABLE `network_servers` DISABLE KEYS */;
/*!40000 ALTER TABLE `network_servers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateofstart` datetime DEFAULT NULL,
  `councils` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `business` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `providers`
--

DROP TABLE IF EXISTS `providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `providers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `cif` varchar(64) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `country` varchar(64) DEFAULT NULL,
  `state` varchar(64) DEFAULT NULL,
  `city` varchar(128) DEFAULT NULL,
  `postal_code` int(11) DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `web` varchar(255) DEFAULT NULL,
  `created_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `providers`
--

LOCK TABLES `providers` WRITE;
/*!40000 ALTER TABLE `providers` DISABLE KEYS */;
/*!40000 ALTER TABLE `providers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `request`
--

DROP TABLE IF EXISTS `request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `door_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `request_date` datetime NOT NULL,
  `start_time` varchar(255) DEFAULT NULL,
  `end_time` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `request`
--

LOCK TABLES `request` WRITE;
/*!40000 ALTER TABLE `request` DISABLE KEYS */;
/*!40000 ALTER TABLE `request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `door_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `start_time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `end_time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `week_days` longtext COLLATE utf8_unicode_ci NOT NULL COMMENT '(DC2Type:array)',
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `is_approved` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_5A3811FB58639EAE` (`door_id`),
  CONSTRAINT `FK_5A3811FB58639EAE` FOREIGN KEY (`door_id`) REFERENCES `door` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sensor_gateway_pkid`
--

DROP TABLE IF EXISTS `sensor_gateway_pkid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sensor_gateway_pkid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mac_number` varchar(255) DEFAULT NULL,
  `sensor_id` int(11) DEFAULT NULL,
  `pk_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensor_gateway_pkid`
--

LOCK TABLES `sensor_gateway_pkid` WRITE;
/*!40000 ALTER TABLE `sensor_gateway_pkid` DISABLE KEYS */;
/*!40000 ALTER TABLE `sensor_gateway_pkid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sensor_info`
--

DROP TABLE IF EXISTS `sensor_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sensor_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sensor_unique_id` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gateways_id` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sensor_model_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `provider` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_sensor` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `installation_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `application_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `device_EUI` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `app_EUI` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `app_KEY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `encryption_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_component_names` longtext COLLATE utf8_unicode_ci COMMENT '(DC2Type:array)',
  `meter_component_names` longtext COLLATE utf8_unicode_ci COMMENT '(DC2Type:array)',
  `dr` int(11) DEFAULT NULL,
  `rssi` int(11) DEFAULT NULL,
  `frequency` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_frame_counter_fCnt` int(11) DEFAULT NULL,
  `prev_frame_counter_fCnt` int(11) DEFAULT NULL,
  `latest_frame_counter_fCnt` int(11) DEFAULT NULL,
  `lost_fCnt` int(11) DEFAULT NULL,
  `sensor_from_port` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sensor_from_chirpstack` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lora_snr` int(11) DEFAULT NULL,
  `network_server_mac` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `messsageTimes` datetime DEFAULT NULL,
  `decoder_servers` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensor_info`
--

LOCK TABLES `sensor_info` WRITE;
/*!40000 ALTER TABLE `sensor_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `sensor_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sensor_mqtt_messages_log`
--

DROP TABLE IF EXISTS `sensor_mqtt_messages_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sensor_mqtt_messages_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `complete_message` mediumtext CHARACTER SET utf8mb4,
  `topic` varchar(500) DEFAULT NULL,
  `gateway_mac` varchar(255) DEFAULT NULL,
  `device_eui` varchar(255) DEFAULT NULL,
  `dr_value` varchar(32) DEFAULT NULL,
  `message_datetime` datetime DEFAULT NULL,
  `rssi_value` varchar(32) DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensor_mqtt_messages_log`
--

LOCK TABLES `sensor_mqtt_messages_log` WRITE;
/*!40000 ALTER TABLE `sensor_mqtt_messages_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `sensor_mqtt_messages_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sensor_names_in_water_oemsensor`
--

DROP TABLE IF EXISTS `sensor_names_in_water_oemsensor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sensor_names_in_water_oemsensor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indexat` varchar(128) DEFAULT NULL,
  `sensor_name` varchar(64) DEFAULT NULL,
  `sensor_id` int(11) DEFAULT NULL,
  `sensor_model_name` varchar(128) DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensor_names_in_water_oemsensor`
--

LOCK TABLES `sensor_names_in_water_oemsensor` WRITE;
/*!40000 ALTER TABLE `sensor_names_in_water_oemsensor` DISABLE KEYS */;
/*!40000 ALTER TABLE `sensor_names_in_water_oemsensor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sensor_ping`
--

DROP TABLE IF EXISTS `sensor_ping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sensor_ping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_EUI` varchar(64) DEFAULT NULL,
  `mac_number` varchar(255) DEFAULT NULL,
  `status` varchar(64) DEFAULT NULL,
  `message_datetime` varchar(255) DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensor_ping`
--

LOCK TABLES `sensor_ping` WRITE;
/*!40000 ALTER TABLE `sensor_ping` DISABLE KEYS */;
/*!40000 ALTER TABLE `sensor_ping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sensor_server_detail`
--

DROP TABLE IF EXISTS `sensor_server_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sensor_server_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_id` int(11) DEFAULT NULL,
  `sensor_id` int(11) DEFAULT NULL,
  `sensor_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `varnames` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensor_server_detail`
--

LOCK TABLES `sensor_server_detail` WRITE;
/*!40000 ALTER TABLE `sensor_server_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `sensor_server_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sensor_type_gateway_pkid`
--

DROP TABLE IF EXISTS `sensor_type_gateway_pkid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sensor_type_gateway_pkid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mac_number` varchar(255) DEFAULT NULL,
  `sensor_type_id` int(11) DEFAULT NULL,
  `pk_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensor_type_gateway_pkid`
--

LOCK TABLES `sensor_type_gateway_pkid` WRITE;
/*!40000 ALTER TABLE `sensor_type_gateway_pkid` DISABLE KEYS */;
/*!40000 ALTER TABLE `sensor_type_gateway_pkid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sensor_type_ibox_payload`
--

DROP TABLE IF EXISTS `sensor_type_ibox_payload`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sensor_type_ibox_payload` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sensor_type_info_id` int(11) DEFAULT NULL,
  `is_input` tinyint(1) NOT NULL,
  `is_meter` tinyint(1) NOT NULL,
  `input_number` int(11) DEFAULT NULL,
  `input_name` varchar(64) DEFAULT NULL,
  `input_description` varchar(255) DEFAULT NULL,
  `meter_number` int(11) DEFAULT NULL,
  `volt_r_sensor_name` varchar(64) DEFAULT NULL,
  `volt_r_sensor_name_desc` varchar(64) DEFAULT NULL,
  `volt_s_sensor_name` varchar(64) DEFAULT NULL,
  `volt_s_sensor_name_desc` varchar(64) DEFAULT NULL,
  `volt_t_sensor_name` varchar(64) DEFAULT NULL,
  `volt_t_sensor_name_desc` varchar(64) DEFAULT NULL,
  `current_r_sensor_name` varchar(64) DEFAULT NULL,
  `current_r_sensor_name_desc` varchar(64) DEFAULT NULL,
  `current_s_sensor_name` varchar(64) DEFAULT NULL,
  `current_s_sensor_name_desc` varchar(64) DEFAULT NULL,
  `current_t_sensor_name` varchar(64) DEFAULT NULL,
  `current_t_sensor_name_desc` varchar(64) DEFAULT NULL,
  `power_all_name` varchar(64) DEFAULT NULL,
  `power_all_name_desc` varchar(64) DEFAULT NULL,
  `power_r_name` varchar(64) DEFAULT NULL,
  `power_r_name_desc` varchar(64) DEFAULT NULL,
  `power_s_name` varchar(64) DEFAULT NULL,
  `power_s_name_desc` varchar(64) DEFAULT NULL,
  `power_t_name` varchar(64) DEFAULT NULL,
  `power_t_name_desc` varchar(64) DEFAULT NULL,
  `pf_all_name` varchar(64) DEFAULT NULL,
  `pf_all_name_desc` varchar(64) DEFAULT NULL,
  `pf_r_name` varchar(64) DEFAULT NULL,
  `pf_r_name_desc` varchar(64) DEFAULT NULL,
  `pf_s_name` varchar(64) DEFAULT NULL,
  `pf_s_name_desc` varchar(64) DEFAULT NULL,
  `pf_t_name` varchar(64) DEFAULT NULL,
  `pf_t_name_desc` varchar(64) DEFAULT NULL,
  `reactive_power_all_name` varchar(64) DEFAULT NULL,
  `reactive_power_all_name_desc` varchar(64) DEFAULT NULL,
  `reactive_power_r_name` varchar(64) DEFAULT NULL,
  `reactive_power_r_name_desc` varchar(64) DEFAULT NULL,
  `reactive_power_s_name` varchar(64) DEFAULT NULL,
  `reactive_power_s_name_desc` varchar(64) DEFAULT NULL,
  `reactive_power_t_name` varchar(64) DEFAULT NULL,
  `reactive_power_t_name_desc` varchar(64) DEFAULT NULL,
  `q1_sensor_name` varchar(64) DEFAULT NULL,
  `q1_sensor_name_desc` varchar(64) DEFAULT NULL,
  `q2_sensor_name` varchar(64) DEFAULT NULL,
  `q2_sensor_name_desc` varchar(64) DEFAULT NULL,
  `q3_sensor_name` varchar(64) DEFAULT NULL,
  `q3_sensor_name_desc` varchar(64) DEFAULT NULL,
  `q4_sensor_name` varchar(64) DEFAULT NULL,
  `q4_sensor_name_desc` varchar(64) DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensor_type_ibox_payload`
--

LOCK TABLES `sensor_type_ibox_payload` WRITE;
/*!40000 ALTER TABLE `sensor_type_ibox_payload` DISABLE KEYS */;
/*!40000 ALTER TABLE `sensor_type_ibox_payload` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sensor_type_info`
--

DROP TABLE IF EXISTS `sensor_type_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sensor_type_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sensor_type_unique_id` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gateways_id` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `supplier` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sensor_type` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `component_type` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `application_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensor_type_info`
--

LOCK TABLES `sensor_type_info` WRITE;
/*!40000 ALTER TABLE `sensor_type_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `sensor_type_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sensor_type_payload`
--

DROP TABLE IF EXISTS `sensor_type_payload`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sensor_type_payload` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_of_data` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reverse` int(11) DEFAULT NULL,
  `sensor_type_id` int(11) DEFAULT NULL,
  `payload_unique_id` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `var_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `start` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `length` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `decimal_number` int(11) DEFAULT NULL,
  `bit_number` int(11) DEFAULT NULL,
  `any` int(11) DEFAULT NULL,
  `expresion` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `component_override` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `show_filter` int(11) DEFAULT NULL,
  `sensor_to_filter` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `true_value_filter` int(11) DEFAULT NULL,
  `sensor_name_filter` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data_type_filter` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `byte_offset_filter` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `length_filter` int(11) DEFAULT NULL,
  `decimals_filter` int(11) DEFAULT NULL,
  `bit_offset_filter` int(11) DEFAULT NULL,
  `reversed_filter` int(11) DEFAULT NULL,
  `expresion_filter` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `component_override_filter` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensor_type_payload`
--

LOCK TABLES `sensor_type_payload` WRITE;
/*!40000 ALTER TABLE `sensor_type_payload` DISABLE KEYS */;
/*!40000 ALTER TABLE `sensor_type_payload` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `server_gateway_pkid`
--

DROP TABLE IF EXISTS `server_gateway_pkid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server_gateway_pkid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mac_number` varchar(255) DEFAULT NULL,
  `server_id` int(11) DEFAULT NULL,
  `pk_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server_gateway_pkid`
--

LOCK TABLES `server_gateway_pkid` WRITE;
/*!40000 ALTER TABLE `server_gateway_pkid` DISABLE KEYS */;
/*!40000 ALTER TABLE `server_gateway_pkid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `server_mqtt`
--

DROP TABLE IF EXISTS `server_mqtt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server_mqtt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profile_name` varchar(255) DEFAULT NULL,
  `broker_address` varchar(255) DEFAULT NULL,
  `broker_port` varchar(255) DEFAULT NULL,
  `topic` varchar(255) DEFAULT NULL,
  `server_id` int(11) DEFAULT NULL,
  `is_transparent_mode` int(11) NOT NULL DEFAULT '0',
  `created_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server_mqtt`
--

LOCK TABLES `server_mqtt` WRITE;
/*!40000 ALTER TABLE `server_mqtt` DISABLE KEYS */;
/*!40000 ALTER TABLE `server_mqtt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servers`
--

DROP TABLE IF EXISTS `servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pk_id` int(11) DEFAULT NULL,
  `gateways_id` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `type` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `server_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `provider_id` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `authorization_token` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `profile_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `broker_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `broker_port` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `topic` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_transparent_mode` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `disable` int(11) NOT NULL DEFAULT '0',
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servers`
--

LOCK TABLES `servers` WRITE;
/*!40000 ALTER TABLE `servers` DISABLE KEYS */;
/*!40000 ALTER TABLE `servers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `pwd` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `permission` int(11) NOT NULL DEFAULT '0',
  `under_admin` int(11) DEFAULT NULL,
  `user_created_by` int(11) DEFAULT NULL,
  `define_view` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_time` datetime DEFAULT NULL,
  `disable` int(11) DEFAULT '0',
  `reset_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `temp_allow` int(11) NOT NULL DEFAULT '0',
  `temp_allow_time` datetime DEFAULT NULL,
  `auth_token` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_provider` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(32) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL,
  `location` int(11) DEFAULT NULL,
  `profile_image_path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `councils` varchar(65) COLLATE utf8_unicode_ci DEFAULT NULL,
  `business` varchar(65) COLLATE utf8_unicode_ci DEFAULT NULL,
  `projects` varchar(65) COLLATE utf8_unicode_ci DEFAULT NULL,
  `only_door_module_user` tinyint(4) NOT NULL DEFAULT '0',
  `door_module_access` int(11) NOT NULL DEFAULT '0',
  `door_module_usertype` int(11) NOT NULL DEFAULT '0',
  `energy_module_access` int(11) NOT NULL DEFAULT '0',
  `energy_module_usertype` int(11) NOT NULL DEFAULT '0',
  `device_module_access` int(11) NOT NULL DEFAULT '0',
  `device_module_usertype` int(11) NOT NULL DEFAULT '0',
  `water_module_access` int(11) NOT NULL DEFAULT '0',
  `water_module_usertype` int(11) NOT NULL DEFAULT '0',
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `capacity_module_access` int(11) NOT NULL DEFAULT '0',
  `capacity_module_usertype` int(11) NOT NULL DEFAULT '0',
  `irrigation_module_access` int(11) NOT NULL DEFAULT '0',
  `irrigation_module_usertype` int(11) NOT NULL DEFAULT '0',
  `generic_module_access` int(11) DEFAULT NULL,
  `generic_module_usertype` int(11) DEFAULT NULL,
  `boiler_module_access` int(11) DEFAULT NULL,
  `boiler_module_usertype` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `water_alarm_notification`
--

DROP TABLE IF EXISTS `water_alarm_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `water_alarm_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alarm_type` varchar(64) DEFAULT NULL,
  `deviceEUI` varchar(255) DEFAULT NULL,
  `gatewayMac` varchar(255) DEFAULT NULL,
  `sensor_id` int(11) DEFAULT NULL,
  `device_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `variable_one` varchar(64) DEFAULT NULL,
  `variable_two` varchar(64) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` varchar(64) DEFAULT NULL,
  `define_alarm_id` int(11) DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `water_alarm_notification`
--

LOCK TABLES `water_alarm_notification` WRITE;
/*!40000 ALTER TABLE `water_alarm_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `water_alarm_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `water_define_alarm`
--

DROP TABLE IF EXISTS `water_define_alarm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `water_define_alarm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sensor_id` int(11) DEFAULT NULL,
  `water_device_id` int(11) NOT NULL,
  `deviceEUI` varchar(255) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `alarm_type` varchar(64) DEFAULT NULL,
  `over_value` double DEFAULT NULL,
  `lower_value` double DEFAULT NULL,
  `reverse_mounting_value` int(11) DEFAULT NULL,
  `daily_value` double DEFAULT NULL,
  `weekly_value` double DEFAULT NULL,
  `monthly_value` double DEFAULT NULL,
  `variable_one` varchar(64) DEFAULT NULL,
  `variable_two` varchar(64) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `water_define_alarm`
--

LOCK TABLES `water_define_alarm` WRITE;
/*!40000 ALTER TABLE `water_define_alarm` DISABLE KEYS */;
/*!40000 ALTER TABLE `water_define_alarm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `water_devices`
--

DROP TABLE IF EXISTS `water_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `water_devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `sensor_id` int(11) DEFAULT NULL,
  `variable_name` varchar(64) DEFAULT NULL,
  `water_group_id` int(11) DEFAULT NULL,
  `water_user_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `municipality_id` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `units` varchar(32) DEFAULT NULL,
  `contract_number` varchar(64) DEFAULT NULL,
  `device_diameter` int(11) DEFAULT NULL,
  `sewer_rate_id` int(11) DEFAULT NULL,
  `installation_address` varchar(500) DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  `last_observation` double DEFAULT NULL,
  `last_message` datetime DEFAULT NULL,
  `numContador` varchar(125) DEFAULT NULL,
  `numModuleLora` varchar(125) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `authToken` varchar(255) DEFAULT NULL,
  `coeficiente_corrector` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `water_devices`
--

LOCK TABLES `water_devices` WRITE;
/*!40000 ALTER TABLE `water_devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `water_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `water_group`
--

DROP TABLE IF EXISTS `water_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `water_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `device_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `created_dt` datetime NOT NULL,
  `updated_dt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_D5F9718E5E237E06` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `water_group`
--

LOCK TABLES `water_group` WRITE;
/*!40000 ALTER TABLE `water_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `water_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `water_module_bills`
--

DROP TABLE IF EXISTS `water_module_bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `water_module_bills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bill_no` int(11) NOT NULL,
  `device_id` int(11) NOT NULL,
  `device_name` varchar(128) DEFAULT NULL,
  `water_user_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `from_date` datetime NOT NULL,
  `to_date` datetime NOT NULL,
  `period_from` datetime DEFAULT NULL,
  `period_to` datetime DEFAULT NULL,
  `days_faction` float DEFAULT NULL,
  `municipality_id` int(11) NOT NULL,
  `bill_status` varchar(64) DEFAULT NULL,
  `final_observed_value` double NOT NULL,
  `first_observation_value` double DEFAULT NULL,
  `last_observation_value` double DEFAULT NULL,
  `fixed_factura` varchar(64) DEFAULT NULL,
  `variable_factura` int(11) DEFAULT NULL,
  `service_fee_tariff` double DEFAULT NULL,
  `service_fee_is_taxable` tinyint(1) DEFAULT NULL,
  `service_fee_tax_rate` double DEFAULT NULL,
  `service_fee_tax_amount` double DEFAULT NULL,
  `service_fee_amount` double DEFAULT NULL,
  `consumption_block_1_quantity` double DEFAULT NULL,
  `consumption_block_2_quantity` double DEFAULT NULL,
  `consumption_block_3_quantity` double DEFAULT NULL,
  `consumption_block_1_tariff` double DEFAULT NULL,
  `consumption_block_1_is_taxable` tinyint(1) DEFAULT NULL,
  `consumption_block_1_tax_rate` double DEFAULT NULL,
  `consumption_block_1_amount` double DEFAULT NULL,
  `consumption_block_2_tariff` double DEFAULT NULL,
  `consumption_block_2_is_taxable` tinyint(1) DEFAULT NULL,
  `consumption_block_2_tax_rate` double DEFAULT NULL,
  `consumption_block_2_amount` double DEFAULT NULL,
  `consumption_block_3_tariff` double DEFAULT NULL,
  `consumption_block_3_tax_rate` double DEFAULT NULL,
  `consumption_block_3_is_taxable` tinyint(1) DEFAULT NULL,
  `consumption_block_3_amount` double DEFAULT NULL,
  `consumption_block_1_tax_amount` double DEFAULT NULL,
  `consumption_block_2_tax_amount` double DEFAULT NULL,
  `consumption_block_3_tax_amount` double DEFAULT NULL,
  `consumption_block_1_import_amount` double DEFAULT NULL,
  `consumption_block_2_import_amount` double DEFAULT NULL,
  `consumption_block_3_import_amount` double DEFAULT NULL,
  `comptador_tariff` double DEFAULT NULL,
  `comptador_tax_rate` double DEFAULT NULL,
  `comptador_is_taxable` tinyint(1) DEFAULT NULL,
  `comptador_amount` double DEFAULT NULL,
  `inversions_tariff` double DEFAULT NULL,
  `inversions_tax_rate` double DEFAULT NULL,
  `inversions_is_taxable` tinyint(1) DEFAULT NULL,
  `inversions_amount` double DEFAULT NULL,
  `sewer_rate_use_for` varchar(64) DEFAULT NULL,
  `sewer_rate_quota_fija` double DEFAULT NULL,
  `sewer_rate_quota_fija_is_taxable` tinyint(1) DEFAULT NULL,
  `sewer_rate_quota_fija_tax_rate` double DEFAULT NULL,
  `sewer_rate_quota_fija_amount` double DEFAULT NULL,
  `sewer_rate_consumed` double DEFAULT NULL,
  `sewer_rate_consumed_is_taxable` tinyint(1) DEFAULT NULL,
  `sewer_rate_consumed_tax_rate` double DEFAULT NULL,
  `sewer_rate_consumed_amount` double DEFAULT NULL,
  `canon_consume_tariff` double DEFAULT NULL,
  `canon_consume_is_taxable` tinyint(1) DEFAULT NULL,
  `canon_consume_tax_rate` double DEFAULT NULL,
  `canon_consume_amount` double DEFAULT NULL,
  `canon_service_tariff` double DEFAULT NULL,
  `canon_service_is_taxable` tinyint(1) DEFAULT NULL,
  `canon_service_tax_rate` double DEFAULT NULL,
  `canon_service_amount` double DEFAULT NULL,
  `total_amount` double DEFAULT NULL,
  `total_import_amount` double DEFAULT NULL,
  `total_tax_amount` double DEFAULT NULL,
  `device_diameter` varchar(64) DEFAULT NULL,
  `device_contract_number` varchar(64) DEFAULT NULL,
  `device_eui` varchar(128) DEFAULT NULL,
  `device_counter_number` varchar(64) DEFAULT NULL,
  `municipality_address` varchar(500) DEFAULT NULL,
  `municipality_name` varchar(128) DEFAULT NULL,
  `municipality_tax_number` varchar(128) DEFAULT NULL,
  `municipality_email` varchar(128) DEFAULT NULL,
  `municipality_mobile` varchar(128) DEFAULT NULL,
  `user_address` varchar(500) DEFAULT NULL,
  `user_billing_address` varchar(500) DEFAULT NULL,
  `user_zip` varchar(64) DEFAULT NULL,
  `user_billing_zip` varchar(64) DEFAULT NULL,
  `user_name` varchar(128) DEFAULT NULL,
  `billing_user_name` varchar(128) DEFAULT NULL,
  `user_nif` varchar(255) DEFAULT NULL,
  `user_city` varchar(64) DEFAULT NULL,
  `user_state` varchar(64) DEFAULT NULL,
  `user_country` varchar(64) DEFAULT NULL,
  `user_bill_city` varchar(64) DEFAULT NULL,
  `user_bill_state` varchar(64) DEFAULT NULL,
  `user_bill_country` varchar(64) DEFAULT NULL,
  `date_of_creation` datetime DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `water_module_bills`
--

LOCK TABLES `water_module_bills` WRITE;
/*!40000 ALTER TABLE `water_module_bills` DISABLE KEYS */;
/*!40000 ALTER TABLE `water_module_bills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `water_module_device_column_config`
--

DROP TABLE IF EXISTS `water_module_device_column_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `water_module_device_column_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` tinyint(1) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL,
  `variable_name` tinyint(1) NOT NULL DEFAULT '0',
  `description` tinyint(1) NOT NULL DEFAULT '0',
  `units` tinyint(1) NOT NULL DEFAULT '0',
  `device_eui` tinyint(1) NOT NULL DEFAULT '0',
  `sensor_name` tinyint(1) NOT NULL DEFAULT '0',
  `user_name` tinyint(1) NOT NULL DEFAULT '0',
  `contract_number` tinyint(1) NOT NULL DEFAULT '0',
  `device_diameter` tinyint(1) NOT NULL DEFAULT '0',
  `installation_address` tinyint(1) NOT NULL DEFAULT '0',
  `last_observation` tinyint(1) NOT NULL DEFAULT '0',
  `last_message` tinyint(1) NOT NULL DEFAULT '0',
  `numContador` tinyint(1) NOT NULL DEFAULT '0',
  `numModuleLora` tinyint(1) NOT NULL DEFAULT '0',
  `provider` tinyint(1) NOT NULL DEFAULT '0',
  `authToken` tinyint(1) NOT NULL DEFAULT '0',
  `use_for` tinyint(1) NOT NULL DEFAULT '0',
  `coeficiente_corrector` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `water_module_device_column_config`
--

LOCK TABLES `water_module_device_column_config` WRITE;
/*!40000 ALTER TABLE `water_module_device_column_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `water_module_device_column_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `water_module_group_balance`
--

DROP TABLE IF EXISTS `water_module_group_balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `water_module_group_balance` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `group_id` int(15) NOT NULL,
  `balance` int(15) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `water_module_group_balance`
--

LOCK TABLES `water_module_group_balance` WRITE;
/*!40000 ALTER TABLE `water_module_group_balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `water_module_group_balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `water_module_observation`
--

DROP TABLE IF EXISTS `water_module_observation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `water_module_observation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) NOT NULL,
  `sensor_id` int(11) NOT NULL,
  `var_id` int(11) DEFAULT NULL,
  `device_name` varchar(64) NOT NULL,
  `device_eui` varchar(128) NOT NULL,
  `var_name` varchar(64) NOT NULL,
  `gateway_mac` varchar(64) CHARACTER SET utf8mb4 DEFAULT NULL,
  `sensor_type_id` int(11) DEFAULT NULL,
  `observation_value` double NOT NULL,
  `message_timestamp` timestamp NULL DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `alert_type` varchar(64) DEFAULT NULL,
  `observation_type` varchar(64) DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `water_module_observation`
--

LOCK TABLES `water_module_observation` WRITE;
/*!40000 ALTER TABLE `water_module_observation` DISABLE KEYS */;
/*!40000 ALTER TABLE `water_module_observation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `water_module_users`
--

DROP TABLE IF EXISTS `water_module_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `water_module_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(64) DEFAULT NULL,
  `last_name` varchar(64) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `user_nif` varchar(255) DEFAULT NULL,
  `mobile` varchar(128) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `municipality_id` int(11) DEFAULT NULL,
  `water_device_id` int(11) DEFAULT NULL,
  `dob` datetime DEFAULT NULL,
  `user_created_dt` datetime DEFAULT NULL,
  `house_no` varchar(32) DEFAULT NULL,
  `street` varchar(32) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(64) DEFAULT NULL,
  `state` varchar(64) DEFAULT NULL,
  `country` varchar(64) DEFAULT NULL,
  `zip_code` int(11) DEFAULT NULL,
  `same_address` tinyint(1) NOT NULL DEFAULT '1',
  `bill_house_no` varchar(64) DEFAULT NULL,
  `bill_street` varchar(64) DEFAULT NULL,
  `bill_address` varchar(255) DEFAULT NULL,
  `bill_city` varchar(64) DEFAULT NULL,
  `bill_state` varchar(64) DEFAULT NULL,
  `bill_country` varchar(64) DEFAULT NULL,
  `bill_zip_code` varchar(64) DEFAULT NULL,
  `bank_name` varchar(64) DEFAULT NULL,
  `bank_address` varchar(255) DEFAULT NULL,
  `IBAN` varchar(255) DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `account_certificate` varchar(255) DEFAULT NULL,
  `idproof` varchar(255) DEFAULT NULL,
  `sepa` varchar(255) DEFAULT NULL,
  `dni` varchar(255) DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `water_module_users`
--

LOCK TABLES `water_module_users` WRITE;
/*!40000 ALTER TABLE `water_module_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `water_module_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `water_municipality_info`
--

DROP TABLE IF EXISTS `water_municipality_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `water_municipality_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(64) DEFAULT NULL,
  `state` varchar(64) DEFAULT NULL,
  `country` varchar(64) DEFAULT NULL,
  `tax_number` varchar(128) DEFAULT NULL,
  `mobile` varchar(128) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `IBAN` varchar(255) DEFAULT NULL,
  `BIC` varchar(255) DEFAULT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  `sepa_id` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `water_municipality_info`
--

LOCK TABLES `water_municipality_info` WRITE;
/*!40000 ALTER TABLE `water_municipality_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `water_municipality_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `water_municipality_terms_condition`
--

DROP TABLE IF EXISTS `water_municipality_terms_condition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `water_municipality_terms_condition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `municipality_id` int(11) NOT NULL,
  `term` varchar(355) DEFAULT NULL,
  `year` int(11) NOT NULL,
  `created_dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_dt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `water_municipality_terms_condition`
--

LOCK TABLES `water_municipality_terms_condition` WRITE;
/*!40000 ALTER TABLE `water_municipality_terms_condition` DISABLE KEYS */;
/*!40000 ALTER TABLE `water_municipality_terms_condition` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-29 11:42:06
